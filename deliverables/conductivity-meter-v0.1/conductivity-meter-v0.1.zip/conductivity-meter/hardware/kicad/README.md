# 可编辑探头转接原理图

用 KiCad 9 打开 `probe_adapter.kicad_pro` 或 `probe_adapter.kicad_sch`。本图只有四个无源连接器和九个独立直通网络。没有主板测量芯片、PCB、制造封装或 CN0359 全板再设计。

| 本转接图位号 | 对应接口 |
| --- | --- |
| J1 | 对接原 CN0359 的 J5.1–5，针号一一对应 |
| J2 | 去电导池线缆；此图定义的针序，不是厂商探头的默认针序 |
| J3 | 对接原 CN0359 的 J3.1–4，针号一一对应 |
| J4 | 去四线 Pt1000；此图定义的针序，不是原板 SWD 口 |

**转接图 J2 不是原板 RS-485 J2；转接图 J4 不是原板 SWD J4。** 连接器朝向、间距和防水规格尚需与实际采购品核实，因此封装未分配。

两极探头在探头端把 F+/S+ 接同一电极、F−/S− 接另一个电极；独立屏蔽不与任一电极短接。四线 RTD 在元件端成对接上/下端，仪表端不短接 Sense 与 Force。R13 低自热换值发生在原 CN0359 板上，与本转接板的九个直通网络无关。

已用 KiCad 9.0.2 导出 PDF、XML 网表，ERC 为零违规。`../tools/check_adapter.py` 进一步检查每个网络的精确两端连接，防止意外短接或标签错误。它验证的是转接图的电连接，并不验证实际接插件方向、实板焊接或整机测量精度。

重新生成/检查时运行：

```sh
python hardware/tools/make_adapter.py
kicad-cli sch export pdf hardware/kicad/probe_adapter.kicad_sch -o hardware/kicad/probe_adapter.pdf
kicad-cli sch export netlist hardware/kicad/probe_adapter.kicad_sch --format kicadxml -o hardware/kicad/probe_adapter.xml
kicad-cli sch erc hardware/kicad/probe_adapter.kicad_sch --format json -o hardware/kicad/erc.json
python hardware/tools/check_adapter.py
```

云环境运行 KiCad/字体工具时使用已有可写 XDG 目录：`XDG_CONFIG_HOME=/workspace/toolchains/xdg/config`、`XDG_CACHE_HOME=/workspace/toolchains/xdg/cache`、`XDG_DATA_HOME=/workspace/toolchains/xdg/data`。标准符号库路径为 `/usr/share/kicad/symbols`；图内已嵌入所用符号。
