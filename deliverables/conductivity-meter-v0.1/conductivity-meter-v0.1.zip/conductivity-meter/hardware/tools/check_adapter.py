#!/usr/bin/env python3
"""Verify exported KiCad connectivity, including absence of unintended joins."""
from pathlib import Path
import xml.etree.ElementTree as ET
import json

folder=Path(__file__).resolve().parents[1]/'kicad'
expected={
    'CELL_F_P': {('J1','1'),('J2','1')},
    'CELL_S_P': {('J1','2'),('J2','2')},
    'CELL_S_N': {('J1','3'),('J2','3')},
    'CELL_F_N': {('J1','4'),('J2','4')},
    'CELL_SHIELD': {('J1','5'),('J2','5')},
    'RTD_F_P': {('J3','1'),('J4','1')},
    'RTD_S_P': {('J3','2'),('J4','2')},
    'RTD_S_N': {('J3','3'),('J4','3')},
    'RTD_F_N_BIAS': {('J3','4'),('J4','4')},
}
tree=ET.parse(folder/'probe_adapter.xml')
actual={}
for net in tree.findall('./nets/net'):
    actual[net.attrib['name'].lstrip('/')]={(n.attrib['ref'],n.attrib['pin']) for n in net.findall('node')}
assert actual==expected, (actual,expected)
erc=json.loads((folder/'erc.json').read_text())
violations=[v for sheet in erc['sheets'] for v in sheet['violations']]
assert not violations,violations
print('PASS: 9 independent nets, 18 connector pins, correct 1:1 mapping, KiCad ERC 0 violations.')
