#!/usr/bin/env python3
"""Create a passive, editable KiCad 9 schematic. Does not redraw the CN0359 AFE."""
from pathlib import Path
import uuid
import re
import json

out = Path(__file__).resolve().parents[1] / 'kicad'
out.mkdir(exist_ok=True)
library=Path('/usr/share/kicad/symbols/Connector_Generic.kicad_sym').read_text()

def uid(name):
    return str(uuid.uuid5(uuid.NAMESPACE_URL,'conductivity-meter/probe_adapter/'+name))

def q(value):
    return json.dumps(str(value))

def symbol_definition(name):
    begin=library.index('(symbol '+q(name))
    depth=0; quoted=False; escaped=False
    for i in range(begin,len(library)):
        char=library[i]
        if quoted:
            if escaped: escaped=False
            elif char=='\\': escaped=True
            elif char=='"': quoted=False
        elif char=='"': quoted=True
        elif char=='(': depth+=1
        elif char==')':
            depth-=1
            if not depth:
                return library[begin:i+1].replace('(symbol '+q(name),'(symbol '+q('Connector_Generic:'+name),1)

page_uid=uid('page')
rows=[('J1','Conn_01x05',88.9,63.5,'CN0359_J5_HARNESS', ['CELL_F_P','CELL_S_P','CELL_S_N','CELL_F_N','CELL_SHIELD']),
      ('J2','Conn_01x05',228.6,63.5,'CELL_CABLE', ['CELL_F_P','CELL_S_P','CELL_S_N','CELL_F_N','CELL_SHIELD']),
      ('J3','Conn_01x04',88.9,120.65,'CN0359_J3_HARNESS', ['RTD_F_P','RTD_S_P','RTD_S_N','RTD_F_N_BIAS']),
      ('J4','Conn_01x04',228.6,120.65,'PT1000_4WIRE', ['RTD_F_P','RTD_S_P','RTD_S_N','RTD_F_N_BIAS'])]
parts=['(kicad_sch (version 20250114) (generator "eeschema")',
       '(uuid '+page_uid+')', '(paper "A4")',
       '(title_block (title "CN0359 Rev A - passive probe wiring adapter") (date "2026-10-19") (rev "0.1") (company "Prototype - review before assembly") (comment 1 "Not a CN0359 motherboard redesign; no manufacturing PCB included"))',
       '(lib_symbols '+symbol_definition('Conn_01x05')+' '+symbol_definition('Conn_01x04')+')']

def note(x,y,text,size=1.27):
    parts.append('(text '+q(text)+' (at '+str(x)+' '+str(y)+' 0) (effects (font (size '+str(size)+' '+str(size)+')) (justify left)) (uuid '+uid('note/'+text)+'))')

note(25,18,'CN0359 REV A EXTERNAL WIRING / PASSIVE ADAPTER',2.0)
note(25,25,'9 isolated nets. No active parts. Confirm connector orientation, pin 1 and actual board revision.',1.1)
note(25,32,'Original AFE: ADI 2016 Chinese article figures 3 and 7. J2/J4 names here refer to THIS adapter only.',1.1)
note(25,43,'TO CN0359 BOARD: harness terminals',1.4)
note(160,43,'TO SENSOR CABLE: user-assigned connector',1.4)
note(25,92,'CELL: 2-pole = join F+/S+ at electrode A; join S-/F- at electrode B. Independent shield only.',1.1)
note(25,99,'For a 4-pole cell, F+/F- are outer current electrodes; S+/S- are their nearest inner voltage electrodes.',1.1)
note(25,149,'PT1000: F+/S+ join ONLY at RTD element upper end; S-/F- join ONLY at its lower end.',1.1)
note(25,156,'RTD_F_N_BIAS is approximately 0.115 V on the original board, NOT chassis ground.',1.1)
note(25,165,'Adapter J1.1-5 -> CN0359 J5.1-5; Adapter J3.1-4 -> CN0359 J3.1-4, all 1:1.',1.1)
note(25,172,'No probe manufacturer pinout, CN0359 RS485 J2 pinout or SWD J4 pinout is inferred here.',1.1)
note(25,179,'Footprints are intentionally unassigned until connector/pitch/mechanical orientation are verified.',1.1)

for ref,lib,x,y,value,names in rows:
    sid=uid(ref)
    parts.append('(symbol (lib_id '+q('Connector_Generic:'+lib)+') (at '+str(x)+' '+str(y)+' 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid '+sid+')'
                 '(property "Reference" '+q(ref)+' (at '+str(x)+' '+str(y-11)+' 0) (effects (font (size 1.27 1.27))))'
                 '(property "Value" '+q(value)+' (at '+str(x)+' '+str(y+12)+' 0) (effects (font (size 1.27 1.27))))'
                 '(property "Footprint" "" (at '+str(x)+' '+str(y)+' 0) (effects (font (size 1.27 1.27)) (hide yes)))'
                 '(property "Datasheet" "" (at '+str(x)+' '+str(y)+' 0) (effects (font (size 1.27 1.27)) (hide yes)))'
                 + ''.join('(pin '+q(i)+' (uuid '+uid(ref+'/pin/'+str(i))+'))' for i in range(1,len(names)+1))+
                 '(instances (project "probe_adapter" (path "/'+page_uid+'" (reference '+q(ref)+') (unit 1)))))')
    top=5.08 if len(names)==5 else 2.54
    for i,name in enumerate(names):
        py=round(y-top+i*2.54,3)
        left=x-35.56
        parts.append('(wire (pts (xy '+str(left)+' '+str(py)+') (xy '+str(x-5.08)+' '+str(py)+')) (stroke (width 0) (type default)) (uuid '+uid(ref+'/wire/'+str(i))+'))')
        parts.append('(label '+q(name)+' (at '+str(left)+' '+str(py)+' 0) (effects (font (size 1 1)) (justify left bottom)) (uuid '+uid(ref+'/label/'+str(i))+'))')

parts.append('(embedded_fonts no))')
(out/'probe_adapter.kicad_sch').write_text('\n'.join(parts))
(out/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Connector_Generic")(type "KiCad")(uri "${KICAD9_SYMBOL_DIR}/Connector_Generic.kicad_sym")(options "")(descr "KiCad standard passive connectors")))\n')
(out/'probe_adapter.kicad_pro').write_text(json.dumps({'meta':{'filename':'probe_adapter.kicad_pro','version':1}},indent=2)+'\n')
print(out/'probe_adapter.kicad_sch')
