#!/usr/bin/env python3
"""Vector diagram of CN0359 Rev A external wiring; no inferred IC pin numbers."""
from pathlib import Path
from html import escape

root = Path(__file__).resolve().parents[1]
parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1120" viewBox="0 0 1600 1120"><style>text{font-family:"Noto Sans CJK SC","DejaVu Sans",sans-serif}</style>']

def box(x, y, w, h, fill='#fff', stroke='#9ab2c6'):
    parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')

def text(x, y, value, size=19, color='#173348'):
    parts.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}">{escape(value)}</text>')

def wire(points, color='#176b93', dash=''):
    parts.append(f'<polyline points="{points}" fill="none" stroke="{color}" stroke-width="3" stroke-dasharray="{dash}"/>')

box(0, 0, 1600, 1120, '#f4f8fc', '#f4f8fc')
text(50, 55, '淡水电导率原型：系统接线图', 34)
text(50, 95, '10–2000 µS/cm · K≈1 cm⁻¹ · 四线 Pt1000 · EVAL-CN0359-EB1Z Rev A', 23)
text(50, 132, '本图是外部接线设计；板内电路见 ADI 原图。线色仅为本图约定，不代表探头厂商线色。', 19, '#9c3b28')
box(560, 185, 455, 770)
text(585, 222, 'ADI EVAL-CN0359-EB1Z Rev A', 22)
text(585, 265, 'J5：电导池接口', 21)
for y, label in [(300,'1  Force+ → R23 = 1 kΩ'), (345,'2  Sense+ → U15 (−)'), (390,'3  Sense− → U14 buffer'), (435,'4  Force− → U19 TIA'), (480,'5  独立屏蔽 → Board GND')]:
    parts.append(f'<circle cx="598" cy="{y}" r="5" fill="#176b93"/>')
    text(620,y+6,label,18)
box(80,280,250,65,'#deedf4');text(103,318,'上电极 E+（两线同点）',20)
box(80,420,250,65,'#deedf4');text(103,459,'下电极 E−（两线同点）',20)
text(80,238,'两极探头：推荐四芯 Kelvin 引出',20)
wire('330,300 598,300','#a54b28');wire('330,325 470,325 470,345 598,345')
wire('330,440 420,440 420,390 598,390');wire('330,465 450,465 450,435 598,435','#a54b28')
wire('80,525 500,525 500,480 598,480','#667783','8 5')
text(80,559,'独立外屏蔽层，只在仪表侧接 J5.5。',18)
text(80,590,'两芯探头：J5.1/2 → E+，J5.3/4 → E−。',18)
text(80,620,'回流芯线不可同时接 J5.5；线缆与探头一并校准。',17,'#9c3b28')
text(585,650,'J3：四线 Pt1000 接口',21)
for y,label in [(705,'1  F+ → R13* → IEXC'), (750,'2  S+ → AIN6'), (795,'3  S− → AIN5'), (840,'4  F− → 0.115 V 偏置')]:
    parts.append(f'<circle cx="598" cy="{y}" r="5" fill="#176b93"/>')
    text(620,y+6,label,17)
box(145,756,175,75,'#e5f0db');text(165,789,'Pt1000',24);text(165,818,'独立温度元件',17)
wire('230,705 230,756','#a54b28');wire('230,831 230,885','#a54b28')
wire('230,705 598,705','#a54b28');wire('230,705 410,705 410,750 598,750')
wire('230,885 430,885 430,795 598,795');wire('230,885 475,885 475,840 598,840','#a54b28')
for y in [705,885]:parts.append(f'<circle cx="230" cy="{y}" r="5" fill="#176b93"/>')
text(80,684,'分支点均在元件端，不能在仪表端短接 Sense。',17)
text(80,930,'Class AA 或更好，并对整支温度探头标定。',18)
text(585,887,'J3.4 是偏置回流，不是机壳地。',18,'#9c3b28')
text(585,927,'* 原板 1.5k；低自热改 4.99k，须匹配固件。',17)
items=[(195,160,'RS-485 → 隔离 USB 适配器 → PC',['接 J2：A/B、参考地按实物 Rev A 核实','J2 针序未取得，禁止猜接针号']), (390,160,'J-Link / SWD（3.3 V 逻辑）',['接 J4：VTref、GND、SWDIO、SWCLK','针序、方向、RESET 按原板资料核实']), (590,140,'6 V 浮地稳压电源 → J1',['官方输入 4–7 V；正负按丝印核实','不得直接接入 12 V / 24 V 现场电源']), (770,185,'首轮实验边界',['塑料杯，充分混匀，温度与电导同处样品','激励幅值及频率须按探头额定值确认','需标液和恒温验收后才能声明 ±0.5%'])]
for y,h,title,notes in items:
    box(1100,y,445,h,'#fff');text(1120,y+37,title,21)
    for i,n in enumerate(notes):text(1120,y+76+i*34,n,17, '#9c3b28' if i==1 else '#173348')
    if y<770:wire(f'1015,{y+80} 1100,{y+80}','#667783')
wire('50,985 1545,985','#b7c7d5')
text(50,1020,'依据：ADI 2016-11 中文文章图 3、7、14；J5/J3 按 Rev A 原图逐线核实。红线=激励/回流，蓝线=检测，虚线=屏蔽。',18)
text(50,1056,'独立 KiCad 转接板仅实现 J5/J3 信号直通，不包含 CN0359 主板重设计。J2/J4 不在转接板中。',18)
text(50,1092,'审阅版 v0.1 · 2026-10-19 · 尚无实板验证；图纸不能替代完整制造 CAD、实际探头说明书与验收。',18,'#9c3b28')
parts.append('</svg>')
(root/'system_wiring.svg').write_text('\n'.join(parts),encoding='utf-8')
