#!/usr/bin/env bash
# Rootless, signature-verified Debian toolchain setup. Does not modify ADI checkout.
set -euo pipefail
project_root="$(cd "$(dirname "$0")/.." && pwd)"
toolchain_root="${CONDUCTIVITY_TOOLCHAIN_ROOT:-/workspace/toolchains/arm}"
apt_root="${CONDUCTIVITY_APT_ROOT:-/workspace/toolchains/apt}"
if ! command -v arm-none-eabi-g++ >/dev/null 2>&1 && [ ! -x "$toolchain_root/usr/bin/arm-none-eabi-g++" ]; then
    mkdir -p "$apt_root/lists/partial" "$apt_root/archives/partial" "$apt_root/empty" "$toolchain_root"
    cat > "$apt_root/apt.conf" <<EOF
Dir::Etc::Parts "$apt_root/empty";
Dir::Etc::sourcelist "$apt_root/sources.list";
Dir::Etc::sourceparts "$apt_root/empty";
Dir::State::lists "$apt_root/lists";
Dir::Cache::archives "$apt_root/archives";
Acquire::Languages "none";
EOF
    cat > "$apt_root/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
EOF
    APT_CONFIG="$apt_root/apt.conf" apt-get update
    (
        cd "$apt_root/archives"
        APT_CONFIG="$apt_root/apt.conf" apt-get download \
          gcc-arm-none-eabi=15:14.2.rel1-1 \
          binutils-arm-none-eabi=2.44-3+23+b1 \
          libnewlib-arm-none-eabi=4.5.0.20241231-1 \
          libnewlib-dev=4.5.0.20241231-1 \
          libstdc++-arm-none-eabi-dev=15:14.2.rel1-1+29 \
          libstdc++-arm-none-eabi-newlib=15:14.2.rel1-1+29
    )
    for archive in "$apt_root"/archives/*.deb; do
        dpkg-deb -x "$archive" "$toolchain_root"
    done
fi
if [ -x "$toolchain_root/usr/bin/arm-none-eabi-g++" ]; then
    # Debian postinst normally registers these alternatives in /usr; use local links.
    [ -e "$toolchain_root/usr/lib/arm-none-eabi/lib" ] || \
        ln -s newlib "$toolchain_root/usr/lib/arm-none-eabi/lib"
    [ -e "$toolchain_root/usr/lib/arm-none-eabi/include" ] || \
        ln -s ../../include/newlib "$toolchain_root/usr/lib/arm-none-eabi/include"
    export PATH="$toolchain_root/usr/bin:$PATH"
fi
arm-none-eabi-g++ --version | head -1
test "$(arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -print-file-name=nano.specs)" != nano.specs
make -C "$project_root/firmware" all
make -C "$project_root/firmware" baseline
make -C "$project_root/firmware" freshwater_lowheat
make -C "$project_root/firmware" verify-rtd
cd "$project_root"
python3 -m unittest discover -s tests -v
