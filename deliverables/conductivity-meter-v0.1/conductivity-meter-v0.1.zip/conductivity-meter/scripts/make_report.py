#!/usr/bin/env python3
"""Render reviewed Chinese notes to HTML and a portable PDF (pandoc/reportlab)."""
from pathlib import Path
import json
import re
import subprocess
import textwrap
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Preformatted

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables"
OUT.mkdir(exist_ok=True)
files = [ROOT / "README.md"] + [ROOT / "docs" / name for name in (
    "hardware.md", "firmware.md", "acquisition.md", "probe_procurement.md",
    "calibration.md", "sources.md", "validation.md")]
def read_with_project_links(path):
    def rewrite(match):
        target=match[1]
        if ":" in target or target.startswith("#"):
            return match[0]
        return "](" + (path.parent/target).resolve().relative_to(ROOT).as_posix() + ")"
    return re.sub(r"\]\(([^)]+)\)",rewrite,path.read_text(encoding="utf-8"))
body = "\n\n".join(read_with_project_links(path) for path in files)
source = OUT / "engineering-notes.md"
source.write_text(body, encoding="utf-8")
style = OUT / "report.css"
style.write_text("""
@page { size: A4; margin: 16mm 15mm; }
body { font-family: 'Noto Sans CJK SC', sans-serif; font-size: 10px; line-height: 1.65; color: #172b3a; }
h1 { font-size: 21px; margin: 24px 0 12px; color: #123d5a; page-break-before: always; }
h1:first-child { page-break-before: auto; }
h2 { font-size: 15px; color: #17566a; margin: 20px 0 8px; }
h3 { font-size: 12px; margin: 16px 0 6px; }
pre, code { font-family: 'DejaVu Sans Mono', 'Noto Sans CJK SC', monospace; font-size: 8px; }
pre { white-space: pre-wrap; overflow-wrap: anywhere; background: #f1f4f6; padding: 8px; border-left: 2px solid #508fa0; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; font-size: 9px; }
th, td { border: 1px solid #c4cfd5; padding: 5px 7px; text-align: left; vertical-align: top; }
th { background: #e8f0f3; }
tr { break-inside: avoid; }
thead { display: table-header-group; }
strong { color: #154b60; }
a { color: #246680; text-decoration: none; overflow-wrap: anywhere; }
img { max-width: 100%; }
""", encoding="utf-8")
html = OUT / "engineering-notes.html"
subprocess.run(["pandoc", "--from=gfm", "--to=html5", "--standalone", "--embed-resources",
                "--metadata=title:淡水电导率与温度仪工程说明", "--metadata=lang:zh-CN",
                "--css", str(style), str(source), "-o", str(html)], check=True, cwd=ROOT)
html.write_text(html.read_text(encoding="utf-8").replace("<head>",'<head>\n<base href="../">',1),encoding="utf-8")
ast = json.loads(subprocess.check_output(["pandoc", "--from=gfm", "--to=json", str(source)]))
pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
pdfmetrics.registerFont(TTFont("UnicodeSymbols", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
normal = ParagraphStyle("Chinese", fontName="STSong-Light", fontSize=9, leading=14,
                        wordWrap="CJK", spaceAfter=6, textColor=colors.HexColor("#172b3a"))
cell_style = ParagraphStyle("Cell", parent=normal, fontSize=7.5, leading=11, spaceAfter=0)
headings = {n: ParagraphStyle(f"H{n}", parent=normal, fontSize={1:17,2:13,3:11}.get(n,10),
                             leading=22 if n==1 else 18, spaceBefore=12, spaceAfter=8,
                             textColor=colors.HexColor("#123d5a"), keepWithNext=True) for n in range(1,7)}
code_style = ParagraphStyle("Code", fontName="Courier", fontSize=6.5, leading=9,
                           backColor=colors.HexColor("#f1f4f6"), spaceAfter=8)

def escaped_text(text):
    result=escape(text)
    for symbol in "µκΩΣΔαρθα±×−≤≥≈°⁻¹²³":
        result=result.replace(symbol, f'<font name="UnicodeSymbols">{symbol}</font>')
    return result

def inline(nodes):
    parts=[]
    for node in nodes:
        kind, value = node["t"], node.get("c")
        if kind=="Str": parts.append(escaped_text(value))
        elif kind in ("Space","SoftBreak"): parts.append(" ")
        elif kind=="LineBreak": parts.append("<br/>")
        elif kind=="Code": parts.append(escaped_text(value[1]))
        elif kind in ("Strong","Emph","Strikeout","SmallCaps","Superscript","Subscript"): parts.append(inline(value))
        elif kind in ("Link","Image"): parts.append(inline(value[1]))
        elif kind=="Quoted": parts.append(inline(value[1]))
        elif kind=="Math": parts.append(escaped_text(value[1]))
    return "".join(parts)

def cell_text(blocks):
    parts=[]
    for block in blocks:
        if block["t"] in ("Para","Plain"): parts.append(inline(block["c"]))
        elif block["t"]=="CodeBlock": parts.append(escaped_text(block["c"][1]))
    return "<br/>".join(parts)

story=[]
def blocks_to_story(blocks, prefix=""):
    for block in blocks:
        kind, value=block["t"], block.get("c")
        if kind=="Header":
            level=value[0]
            if level==1 and story: story.append(PageBreak())
            story.append(Paragraph(inline(value[2]),headings[level]))
        elif kind in ("Para","Plain"):
            story.append(Paragraph(prefix+inline(value),normal))
        elif kind=="CodeBlock":
            wrapped="\n".join("\n".join(textwrap.wrap(line,110,replace_whitespace=False,drop_whitespace=False))
                                if len(line)>110 else line for line in value[1].splitlines())
            story.append(Preformatted(wrapped,code_style))
        elif kind=="BulletList":
            for item in value: blocks_to_story(item,"• ")
        elif kind=="OrderedList":
            for i,item in enumerate(value[1],value[0][0]): blocks_to_story(item,f"{i}. ")
        elif kind=="BlockQuote": blocks_to_story(value)
        elif kind=="Table":
            rows=list(value[3][1])
            header_count=len(rows)
            for body in value[4]: rows.extend(body[2]); rows.extend(body[3])
            rows.extend(value[5][1])
            data=[[Paragraph(cell_text(cell[4]),cell_style) for cell in row[1]] for row in rows]
            if not data: continue
            count=max(map(len,data)); width=180*mm
            ratios={2:[.31,.69],3:[.25,.38,.37]}.get(count,[1/count]*count)
            table=Table(data,colWidths=[width*r for r in ratios],repeatRows=header_count,hAlign="LEFT")
            table.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
                                       ("GRID",(0,0),(-1,-1),.35,colors.HexColor("#c4cfd5")),
                                       ("BACKGROUND",(0,0),(-1,max(0,header_count-1)),colors.HexColor("#e8f0f3")),
                                       ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5)]))
            story.extend([table,Spacer(1,7)])

blocks_to_story(ast["blocks"])
pdf=OUT / "conductivity-meter-engineering.pdf"
def page_number(canvas,doc):
    canvas.setFont("STSong-Light",8)
    canvas.setFillColor(colors.HexColor("#577080"))
    canvas.drawString(15*mm,10*mm,"淡水电导率与温度仪 · 原型设计 v0.1 · 尚未实物验收")
    canvas.drawRightString(195*mm,10*mm,str(doc.page))
SimpleDocTemplate(str(pdf),pagesize=(210*mm,297*mm),leftMargin=15*mm,rightMargin=15*mm,
                  topMargin=15*mm,bottomMargin=18*mm,title="淡水电导率与温度仪工程说明").build(
                      story,onFirstPage=page_number,onLaterPages=page_number)
import fitz
document=fitz.open(pdf)
toc=[[1,"工程说明与验证记录",1]]
for title,relative in [("系统接线图","hardware/system_wiring.pdf"),
                       ("低自热R13改动图","hardware/rtd_lowheat_modification.pdf"),
                       ("KiCad探头转接原理图","hardware/kicad/probe_adapter.pdf"),
                       ("ADI原始模拟电路与电源参考图","hardware/ADI_reference_circuit_excerpts.pdf")]:
    toc.append([1,title,len(document)+1])
    with fitz.open(ROOT/relative) as diagram:
        document.insert_pdf(diagram)
document.set_toc(toc)
temporary=pdf.with_suffix(".tmp.pdf")
document.save(temporary,garbage=3,deflate=True)
document.close()
temporary.replace(pdf)
print(OUT / "conductivity-meter-engineering.pdf")
