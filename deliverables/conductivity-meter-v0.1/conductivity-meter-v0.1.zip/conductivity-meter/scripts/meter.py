#!/usr/bin/env python3
"""CN0359 freshwater ASCII acquisition: Linux/macOS, 115200 8N2, auto-direction USB-RS485.

collect requires certificate metadata JSON; it never invents reference values.
decode reads a captured raw line from stdin, for diagnosis without serial hardware.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import select
import sys
import termios
import time
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from calibration.calibrate import CSV_FIELDS, DataError, Sample, corrected, validate_calibration

STATUSES = {"OK", "LOW_RANGE", "HIGH_RANGE", "RTD_ERROR", "SIGNAL_ERROR", "OVERLOAD", "LOW_SIGNAL"}
REQUIRED = {"conductance_us", "temperature_c", "rtd_type", "rtd_wires", "status"}


def parse_raw(line: str) -> dict:
    fields = line.strip().split(",")
    if fields[0] != "RAW":
        raise DataError("expected freshwater firmware RAW response")
    result = {}
    for field in fields[1:]:
        if "=" not in field:
            raise DataError("malformed RAW field")
        key, value = field.split("=", 1)
        if not key or key in result:
            raise DataError("empty or duplicate RAW key")
        result[key] = value
    if not REQUIRED <= result.keys() or result["status"] not in STATUSES:
        raise DataError("RAW response missing fields or contains an unknown status")
    for key in ("conductance_us", "temperature_c"):
        try:
            result[key] = float(result[key])
        except ValueError as exc:
            raise DataError(f"invalid RAW number: {key}") from exc
    if result["status"] in {"OK", "LOW_RANGE", "HIGH_RANGE"}:
        if not all(math.isfinite(result[k]) for k in ("conductance_us", "temperature_c")):
            raise DataError("valid-status RAW contains NaN or infinity")
        if result["conductance_us"] <= 0:
            raise DataError("RAW conductance must be positive")
        if result["rtd_type"] != "1000" or result["rtd_wires"] != "4":
            raise DataError("freshwater workflow requires a four-wire Pt1000")
        if not -5 <= result["temperature_c"] <= 55:
            raise DataError("RAW temperature is outside the temperature-calibration capture limits")
    return result


def measurement_profile(raw: dict) -> tuple[str, float]:
    required = {"profile", "reference_ohm", "iexc_ua", "source_voltage_v", "frequency_hz"}
    if not required <= raw.keys():
        raise DataError("RAW lacks instrument configuration; rebuild the supplied freshwater firmware")
    values = {}
    for key in required - {"profile"}:
        try:
            values[key] = float(raw[key])
        except (ValueError, TypeError) as exc:
            raise DataError(f"invalid configuration field: {key}") from exc
        if not math.isfinite(values[key]) or values[key] <= 0:
            raise DataError(f"nonpositive/nonfinite configuration field: {key}")
    expected = {"freshwater": (1500, 400), "freshwater_lowheat": (4990, 200)}
    if raw["profile"] not in expected:
        raise DataError("unrecognized hardware profile")
    if (values["reference_ohm"], values["iexc_ua"]) != expected[raw["profile"]]:
        raise DataError("profile/reference/current mismatch")
    profile = (f"{raw['profile']}:V{values['source_voltage_v']:.12g}"
               f":Rref{values['reference_ohm']:.12g}:I{values['iexc_ua']:.12g}")
    if "temperature_calibration_id" in raw:
        profile += f":Tcal{raw['temperature_calibration_id']}"
    return profile, values["frequency_hz"]


def apply_temperature_calibration(raw: dict, model: dict | None, model_id: str | None) -> dict:
    if model is None or raw["status"] in {"RTD_ERROR", "SIGNAL_ERROR", "OVERLOAD", "LOW_SIGNAL"}:
        return raw
    from calibration.temperature import correct_temperature
    result = dict(raw)
    result["raw_temperature_c"] = raw["temperature_c"]
    result["temperature_c"] = correct_temperature(model, raw["temperature_c"])
    result["temperature_calibration_id"] = model_id
    return result


class Serial485:
    def __init__(self, port: str, timeout: float = 4.0):
        self.fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        self.timeout = timeout
        try:
            self.old = termios.tcgetattr(self.fd)
            attr = termios.tcgetattr(self.fd)
            attr[0] = 0
            attr[1] = 0
            attr[2] = termios.CS8 | termios.CLOCAL | termios.CREAD | termios.CSTOPB
            attr[3] = 0
            attr[4] = attr[5] = termios.B115200
            attr[6][termios.VMIN] = 0
            attr[6][termios.VTIME] = 0
            termios.tcsetattr(self.fd, termios.TCSANOW, attr)
        except BaseException:
            os.close(self.fd)
            raise

    def __enter__(self):
        return self

    def __exit__(self, *args):
        try:
            termios.tcsetattr(self.fd, termios.TCSANOW, self.old)
        finally:
            os.close(self.fd)

    def raw(self, address: int = 30) -> dict:
        if not 0 <= address <= 255:
            raise DataError("address must be 0–255")
        termios.tcflush(self.fd, termios.TCIFLUSH)
        command = f"{address} raw\n".encode("ascii")
        offset = 0
        deadline = time.monotonic() + self.timeout
        while offset < len(command):
            if time.monotonic() >= deadline:
                raise DataError("serial write timed out")
            _, writable, _ = select.select([], [self.fd], [], max(0, deadline - time.monotonic()))
            if writable:
                offset += os.write(self.fd, command[offset:])
        data = b""
        while time.monotonic() < deadline:
            readable, _, _ = select.select([self.fd], [], [], max(0, deadline - time.monotonic()))
            if not readable:
                break
            chunk = os.read(self.fd, 4096)
            if not chunk:
                raise DataError("serial device disconnected")
            data += chunk
            if len(data) > 16384:
                raise DataError("serial response exceeded 16 KiB")
            while b"\n" in data:
                line, data = data.split(b"\n", 1)
                # Permit UART echo/diagnostic lines, but only accept an actual RAW line.
                if line.lstrip(b"\r").startswith(b"RAW,"):
                    try:
                        return parse_raw(line.strip().decode("ascii"))
                    except UnicodeDecodeError as exc:
                        raise DataError("RAW response is not ASCII") from exc
        raise DataError("no complete RAW response; check firmware, address, 115200 8N2 and A/B wiring")


def make_sample(raw: dict, metadata: dict, index: int, sample_prefix: str) -> Sample:
    if raw["status"] not in {"OK", "LOW_RANGE", "HIGH_RANGE"}:
        raise DataError(f"measurement rejected: {raw['status']}")
    # These fields must come from the instrument, never from manually supplied metadata.
    forbidden = {"conductance_us", "temperature_c", "sample_id", "origin"} & metadata.keys()
    if forbidden:
        raise DataError(f"metadata must not override measured/provenance fields: {sorted(forbidden)}")
    metadata = dict(metadata)
    profile, frequency = measurement_profile(raw)
    if "range_id" in metadata and metadata["range_id"] != profile:
        raise DataError("metadata range_id differs from instrument configuration")
    if "frequency_hz" in metadata and abs(float(metadata["frequency_hz"]) - frequency) > 1e-6:
        raise DataError("metadata frequency differs from instrument configuration")
    metadata.update(range_id=profile, frequency_hz=frequency)
    row = Sample(sample_id=f"{sample_prefix}-{index:04d}", origin="real",
                 conductance_us=raw["conductance_us"], temperature_c=raw["temperature_c"], **metadata)
    row.validate()
    return row


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    decode = commands.add_parser("decode")
    decode.add_argument("--calibration", type=Path)
    decode.add_argument("--temperature-calibration", type=Path)
    collect = commands.add_parser("collect")
    collect.add_argument("--port", required=True)
    collect.add_argument("--address", type=int, default=30)
    collect.add_argument("--metadata", type=Path, required=True)
    collect.add_argument("--output", type=Path, required=True)
    collect.add_argument("--samples", type=int, default=10)
    collect.add_argument("--interval", type=float, default=1.5)
    collect.add_argument("--temperature-calibration", type=Path)
    args = parser.parse_args(argv)
    try:
        tmodel = None
        tmodel_id = None
        if args.temperature_calibration:
            from calibration.temperature import validate_model
            encoded = args.temperature_calibration.read_bytes()
            tmodel = json.loads(encoded)
            validate_model(tmodel)
            if tmodel["origin"] != "real":
                raise DataError("synthetic temperature calibration cannot correct a real instrument reading")
            tmodel_id = hashlib.sha256(encoded).hexdigest()[:12]
        if args.command == "decode":
            result = apply_temperature_calibration(parse_raw(sys.stdin.readline()), tmodel, tmodel_id)
            if args.calibration:
                if result["status"] != "OK":
                    raise DataError("only status=OK can be reported as a valid calibrated measurement")
                if not 0 <= result["temperature_c"] <= 50:
                    raise DataError("corrected water temperature is outside 0–50 °C")
                cal = json.loads(args.calibration.read_text(encoding="utf-8"))
                validate_calibration(cal)
                if cal["origin"] != "real":
                    raise DataError("synthetic calibration cannot correct a real instrument reading")
                profile, frequency = measurement_profile(result)
                if f"{profile}@{frequency:.12g}Hz" not in cal["profiles"]:
                    raise DataError("instrument configuration differs from the calibration profile")
                value = corrected(cal, result["conductance_us"])
                low, high = cal["fit_reference_domain_us_cm"]
                if not low <= value <= high:
                    raise DataError("corrected measurement is outside the calibrated domain")
                result["calibrated_conductivity_us_cm"] = value
            # Fault NaNs remain explicit JSON nulls and cannot enter fit/verify.
            result = {k: (None if isinstance(v, float) and not math.isfinite(v) else v) for k, v in result.items()}
            print(json.dumps(result, ensure_ascii=False, allow_nan=False))
            return 0
        if not 1 <= args.samples <= 100000 or not math.isfinite(args.interval) or args.interval < 1:
            raise DataError("samples must be 1–100000 and interval must be finite and ≥1 second")
        metadata = json.loads(args.metadata.read_text(encoding="utf-8"))
        if not isinstance(metadata, dict):
            raise DataError("metadata must be a JSON object")
        prefix = str(uuid.uuid4())
        raw_path = args.output.with_suffix(args.output.suffix + ".raw.jsonl")
        with Serial485(args.port) as serial, args.output.open("x", newline="", encoding="utf-8") as stream, \
                raw_path.open("x", encoding="utf-8") as raw_log:
            writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for index in range(args.samples):
                source = serial.raw(args.address)
                logged = {k: (None if isinstance(v, float) and not math.isfinite(v) else v) for k, v in source.items()}
                raw_log.write(json.dumps({"collected_utc": datetime.now(timezone.utc).isoformat(),
                                          "sample_id": f"{prefix}-{index:04d}",
                                          "temperature_calibration_id": tmodel_id,
                                          "raw": logged}, ensure_ascii=False, allow_nan=False) + "\n")
                raw_log.flush()
                raw = apply_temperature_calibration(source, tmodel, tmodel_id)
                row = make_sample(raw, metadata, index, prefix)
                writer.writerow(asdict(row))
                stream.flush()
                print(f"{index+1}/{args.samples}: {row.conductance_us:.8g} µS, {row.temperature_c:.5g} °C")
                if index + 1 < args.samples:
                    time.sleep(args.interval)
        return 0
    except (DataError, OSError, ValueError, TypeError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
