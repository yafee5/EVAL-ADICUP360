# 固件与烧录

## 适配边界

主交付是 ADI 官方完整 CN0359 程序的 GNU Arm 移植，`freshwater` 保持原板的 R13=1.5 kΩ，`freshwater_lowheat` 为更换 R13 后的低自热版；保留 ADC、双 AD8253 自动增益、正负交流激励、PWM 同步采样、DAC、RTD、LCD/DMA、旋钮菜单、Flash 参数及 RS-485 的实际实现。不是仅在电脑运行的算法示例。

硬件依据是用户上传的 2016 年中文资料：两片 AD8253（U15/U18）、ADA4000 缓冲（U14）、R47=1 kΩ、R13=1.5 kΩ 的 CN0359 路径。**只烧录到经核对的该版本电路。** 官网现行 CN0359 Rev C 的缓冲器、通信接口等已有变更；不能仅凭板卡商品名确认引脚兼容。EVAL-ADICUP360 的工程仓库收录该示例，不代表 ADICUP360 开发板能直接插上探头测量。现行板卡和自行改板必须逐项核对原理图、电源、AD8253 增益锁存、模拟通道及收发器引脚。

上游：`yafee5/EVAL-ADICUP360`，提交 `7d76cf79a72e9e6f28345b37f9476a1da2c2d930`，目录 `projects/ADuCM360_demo_cn0359_reva`。`firmware/vendor_cn0359_reva/` 完整保留该目录，文件内容及原版权声明不变。仓库根许可见 `firmware/ADI_REPOSITORY_LICENSE`；ADI 源文件内的许可要求软件运行在 ADI 器件上或与 ADI 器件直接连接，分发时保留相关声明。

## 已验证与待验证

已在此云环境用 GNU Arm GCC 14.2.1 + newlib-nano 实际编译、链接完整应用并生成 ELF、Intel HEX、原始 BIN、MAP 和 SHA-256 清单，三个 profile 均成功。`freshwater_lowheat` 的链接结果为 `.text` 82,952 B、`.data` 656 B、`.bss` 3,472 B；RAM 实际布局占用 4,496 B，另留 2,048 B 栈，堆上限约 1,648 B。BIN 包含 Flash 中的数据初值，大小大于 `.text`；以生成的 BIN 和 MAP 为准。

云环境没有实物板、探头、串口和校准槽，因此未进行上板启动、堆栈峰值、模拟噪声、线缆/极化、自热和 ±0.5% 读数验收。链接通过不等于测量精度达标；首次上板需观察启动、菜单、连续采集、参数保存和长时间运行，并按 `calibration.md` 做独立标准液验证。

## 构建

需要 Python 3.9+、GNU make 和带 C++/newlib-nano 的 `arm-none-eabi` 工具链。示例在本机测试的安装位置为 `/workspace/toolchains/arm/usr/bin/`，脚本会自动发现；其他位置通过 `CROSS_COMPILE` 指定。

```sh
cd /workspace/conductivity-meter/firmware
make freshwater
make baseline
# 仅适用于已经将 R13 改为 4.99 kΩ 的硬件：
make freshwater_lowheat
# 本机 C++ 编译器运行实际温度算法的独立物理模型验证：
make verify-rtd
# 任意已安装的 GNU Arm 工具链：
make freshwater CROSS_COMPILE=/path/to/bin/arm-none-eabi-
```

每个 profile 的产物位于 `firmware/build/<profile>/`：`cn0359_<profile>.elf`、`.hex`、`.bin`、`.map`、`manifest.json`、`porting.patch` 及各文件编译日志。`make` 默认构建 `freshwater`。构建脚本从原样保留的 vendor 创建生成目录，只在 `build/` 内应用移植；完整差异自动写入 `porting.patch`。`make clean` 只删除生成的 `build/`。工具链版本固定且路径相同时，输出可重复。

## 配置

| 项目 | baseline | freshwater（默认） |
|---|---|---|
| 官方模拟测量主路径 | 保留 | 保留 |
| 出厂默认交流幅度设置 | 1.0 V | 0.2 V |
| 频率 | 100 Hz | 100 Hz |
| K 初值 | 1.0 cm⁻¹ | 1.0 cm⁻¹，必须随探头校准 |
| 温度系数初值 | 2 %/°C | 0，明确输出实温电导率 κ(T) |
| Pt 激励电流名义值 | 600 µA | 400 µA |
| RTD 类型 | 原厂自动识别 Pt100/Pt1000、2/3/4 线 | 测量结果必须四线 Pt1000 有效 |
| 正负通道发布 | 原厂每次单通道更新 | 完整 +I、+V、−I、−V 周期后发布 |
| 数据诊断 | 原厂行为 | 拒绝无效 RTD/弱信号/过载，`raw` 给出状态 |
| `raw` 机器接口 | 无 | 有 |

推荐精度版 `freshwater_lowheat` 继承 `freshwater` 的所有淡水设置，但 **必须把 R13 替换为 4.99 kΩ、0.01%、温漂≤2 ppm/K**，并采用 200 µA Pt1000 激励。原板 1.5 kΩ 不可刷此配置，改过 R13 的板也不可刷 `freshwater`/`baseline`。低热版参考约 0.998 V，自热功率约为 400 µA 版的四分之一，25°C 时约 0.044 mW。其 ADC 比例转换重算为：

```text
x = ADC1_CODE / 2^28
R_RTD = 4990 · 2000000 · x / (2000000 + 4990 − 4990 · x)
normalized = R_RTD / 1000
```

其中 2 MΩ 是原厂对未缓冲 ADC 输入负载的名义模型；负载实际值和漂移仍需温度校准验证。有效性先按换算后的电阻判定 −20–120°C 的诊断窗口，再转换温度，不沿用 1.5 kΩ 板的原始 ADC 数值门槛；只接受四线 Pt1000。精度验收范围仍以设计文档的 0–50°C 为准。

`make verify-rtd` 用独立的并联电阻前向物理模型生成 ADC 码，调用实际低热版 C++ 转换及 ADI `res2temp()` 对 0–50°C 的 501 个点验证。已测逆算/浮点/量化等效误差最大约 0.000053°C，包含原厂温度有理逼近后的最大算法误差约 0.0071°C；忽略 2 MΩ 负载将出现约 2.265 Ω 的偏差。该验证不包含实际电阻、ADC 增益/输入电流变化、探头、热接触和自热误差，不能代替温度标定。

`baseline` 同样包含 GNU 运行时及必要程序错误修复，因此不声称与原厂发布 HEX 逐位一致。原始源码仍可在 vendor 目录查看。原厂在 RTD 失效时使用 25°C，此行为仅在 baseline 保留；不得用 baseline 的无效温度读数做精度验收。

400 µA 是保留 R13=1.5 kΩ 时对自热和参考电压的折中。正常 RTD 测量会把 ADC1 参考切换至 `EXTREF2`，R13 上名义参考为 0.60 V；初始 `INTREF` 仅用于断线诊断。ADuCM360/361 数据手册 Rev D 第 7 页要求外部参考差分电压至少 0.40 V，因此不能直接改成 200 µA（仅 0.30 V）。数据手册已存于 `hardware/sources/ADuCM360_361_RevD.pdf`。Pt1000 在 25°C 时功率约 0.176 mW；若实际水中散热系数为 4 mW/°C，自热约 0.044°C。必须采购并实测满足热预算的探头，低流速或静水中尤其需要验证；本固件没有用未经验证的经验值扣除自热。

参数保存在 Flash；首次烧录、切换 profile 或维修后均应按下文显式设置并查询。参数有效时不会仅因切换配置名自动重置。

## GNU 移植的共同修复

1. 使用仓库自带 GNU 汇编启动文件及链接布局，显式复制 `.data`、清 `.bss`、初始化芯片、运行 C++ 构造器后进入完整 `main`；补充受栈边界约束的 newlib 堆及文件系统接口。ADC、激励、LCD 等硬件函数没有替换为空实现。
2. 统一零参数消息为 `argv=nullptr`，有参数消息使用匹配的数组分配/释放；修复多个 `int` 回调缺少返回值，ISR 消息队列以保存/恢复 `PRIMASK` 防止中断嵌套竞争。
3. 配置成员偏移改用 `offsetof`，避免对未初始化指针进行运算；修复串口空行和缺命令的空指针访问。
4. UART 快照并正确解码中断原因，每个字符只读取一次；发送 FIFO 满时等待 ISR 排出，停止发送时关闭 TX 空中断，避免重复空队列事件。发送队列只由 ISR 取出数据。
5. Flash 参数独占真实的 512 B 页，采用 volatile 硬件读写并等待最终写完成；保留页对齐和链接保活，避免擦除同页程序。修改参数时不要断电。
6. 采用 newlib-nano 和正确的浮点 printf/scanf 链接；保留双精度/单精度数学库。排序 BSS 对齐以回收 RAM 间隙；保留断言。构建中剩余警告主要来自原厂菜单显式 fall-through 和通用 seek 的符号比较，未屏蔽缺少返回值的问题。

## 烧录

关闭电源并核对实物版次；先按 `hardware/system_wiring.pdf` 完成正确电源和地连接。使用支持 ADuCM360 的 SWD 调试器和厂商驱动。SEGGER J-Link 的命令文件示例：

```text
r
loadfile /absolute/path/cn0359_freshwater.hex
r
g
exit
```

主机安装 SEGGER 工具后，用 `JLinkExe -device ADuCM360 -if SWD -speed 1000 -CommanderScript flash.jlink`；Windows 对应 `JLink.exe`。调试器连接目标板 `SWDIO`、`SWCLK`、`RESET`、`GND` 和目标参考电压，具体连接器脚号以实物原理图为准。烧录前备份已有校准参数；HEX 内含参数页初始内容。此云环境未连接调试器，烧录命令尚未在实物执行。

## 串口与命令

默认 **115200 baud、8 数据位、无校验、2 停止位（8N2）**，ASCII、小写命令、十进制地址 30，行末 `\n`（也接受 `\r\n`）。这是原厂 ASCII 命令协议，**不是 Modbus RTU**。RS-485 使用带自动方向控制的 USB 适配器；旧版板上经过收发器后再接 A/B，不能把 RS-485 A/B 当 MCU UART 引脚直连。

MCU 逻辑信号：P0.5=收发方向（高发送、低接收），P0.6=UART RX，P0.7=UART TX。调试时若直接接逻辑 UART，需核对目标 I/O 电压和共地，并避开 RS-485 总线电压。

推荐第一次启动后逐条发送，每条等响应完成：

```text
30 setvolt 0.2
30 setfreq 100
30 setk 1.0
30 setcof 0
30 setstm 10
30 sethtm 1
30 poll
30 raw
```

| 命令 | 参数/作用 |
|---|---|
| `30 poll` | 原厂可读报告，激励、增益、电流/电压、RTD、计算结果 |
| `30 raw` | 本版单行机器接口，两个淡水配置均有，baseline 无 |
| `30 setvolt 0.2` | 激励幅度设置，V；先用 0.2 V，极化/线缆影响需实测 |
| `30 setfreq 100` | 激励频率，Hz；改变后重新验证极化/寄生电容影响 |
| `30 setk 1.0032` | 例：写入校准得到的有效 K，cm⁻¹；例值不是实测校准值 |
| `30 setcof 0` | 0 禁用温补；`2` 表示 2 %/°C，只有水样系数有依据时才设置 |
| `30 setstm 10` | 同步检波建立时间占比，% |
| `30 sethtm 1` | 同步检波保持时间占比，% |

波特率和地址通过板上原厂设置菜单更改；串口命令表没有 `setbaud`、`setaddr` 或自动标液校准命令，不应发送虚构命令。查询结果、温度稳定后再记录；多台设备上总线前先逐台设置唯一地址。

## raw 输出与校准应用

一条完整响应格式（下列数值仅示意）：

```text
RAW,conductance_us=1413,temperature_c=25.000000,rtd_type=1000,rtd_wires=4,adc0_hits=104,adc1_hits=8,status=OK,conductivity_us_cm=1413,alpha_pct_c=0,profile=freshwater_lowheat,reference_ohm=4990,iexc_ua=200,frequency_hz=100,source_voltage_v=0.2
```

`conductance_us` 恒为 `1e6·(I+−I−)/(V+−V−)`，单位 µS，**不含 K，也不含温度补偿**。`conductivity_us_cm` 为 `K·conductance_us`，单位 µS/cm，恒为实温 κ(T)，即使 `alpha_pct_c` 非零也保持此定义；`poll` 和 LCD 才按用户系数选择显示 κ(T) 或线性模型的 κ25。`adc0_hits` 是原厂单通道累计数，freshwater 仅每四次完成后发布；`adc1_hits` 是有效 RTD 更新数，重启会复位。主机应检查数据是否持续更新。

`profile`、`reference_ohm`、`iexc_ua` 为编译时硬件配置声明，不能自动检测实际焊接的电阻；开机必须核对实物与固件。`frequency_hz`、`source_voltage_v` 为当前参数设置。校准记录必须包含这些条件，改变配置后重新验证。

`status` 为 `OK`、`RTD_ERROR`、`SIGNAL_ERROR`、`OVERLOAD`、`LOW_SIGNAL`、`LOW_RANGE` 或 `HIGH_RANGE`。量程判断基于 K·G 的 10–2000 µS/cm 工作范围；边界外仍保留未补偿 G 以便台架校准，不能标记为量程内合格。RTD 断线/型号不符/非四线时温度为 `nan`，无效测量电导率为 `nan`；ADC 无法形成有效比值时 G 也为 `nan`。弱信号/过载不作为有效精度数据。

标定先显式设置 `setcof 0`、`setk 1`，用电阻和有证标准液记录未补偿 `conductance_us`、实测温度和证书对应的 κ(T)，然后按 `calibration.md` 运行 `calibration/calibrate.py`。默认零截距拟合得到的 `gain_cm_inv` 可直接写入 `setk`。若显式选择 affine 模型，其 offset 只能由主机工具应用，原厂参数没有偏置项；不得声称写一个 K 就实现仿射校准。独立标准液及多个温度点验证通过后，才可声明相应条件下的 ±0.5% 读数。
