# 从串口原始读数到校准结果

`scripts/meter.py` 使用 Python 标准库，在 Linux/macOS 的 POSIX 串口上工作；无需 pyserial。使用**自动收发方向**的 USB–RS485，115200、8 数据位、无校验、2 停止位，仪器地址默认 30。此协议是 ADI ASCII 协议，不是 Modbus RTU。只使用与测量板电路匹配的 `freshwater` 固件；原厂 baseline 没有新增的 raw 命令。

## 数据来源与单位

发送 `30 raw\n`，收到类似以下单行响应（这是格式示例）：

```text
RAW,conductance_us=1412.5,temperature_c=25,rtd_type=1000,rtd_wires=4,adc0_hits=10,adc1_hits=10,status=OK,conductivity_us_cm=1412.5,alpha_pct_c=0,profile=freshwater_lowheat,reference_ohm=4990,iexc_ua=200,frequency_hz=100,source_voltage_v=0.2
```

`conductance_us` 是 G=I/V，单位 µS，不含电极常数，不含温度补偿。`conductivity_us_cm` 是按固件电极常数计算的 κ(T)，单位 µS/cm。校准工具始终使用前者，避免重复乘 K 或重复温补。

可离线检查一条真实捕获的响应：

```bash
python3 scripts/meter.py decode < captured-line.txt
```

RTD_ERROR / SIGNAL_ERROR / OVERLOAD / LOW_SIGNAL 被拒绝为校准输入；LOW_RANGE / HIGH_RANGE 可以保留为校准端点诊断，正式有效读数必须为 OK。故障响应中的 NaN 在 decode JSON 中写成 null，不伪装为 25 °C。软件可验证解析和错误处理，但尚未与真实 USB–RS485 或板卡联调。

## 使用有证标准液采集

为当前这一杯标准液创建 `standard-metadata.json`，下面的所有占位值必须替换为实际证书／仪器配置／会话记录。不要照抄虚构证书号，不要把 25 °C 瓶标值用于其他温度：

```json
{
  "role": "fit",
  "session_id": "YOUR_REAL_CALIBRATION_SESSION",
  "reference_us_cm": 1413.0,
  "reference_temperature_c": 25.0,
  "reference_uncertainty_pct": 0.1,
  "certificate_id": "REPLACE_WITH_REAL_CERTIFICATE",
  "standard_id": "REPLACE_WITH_REAL_LOT"
}
```

证书不确定度字段单位是百分数，0.1 代表 0.1%，而不是 10%。采集程序从 RAW 中读取频率和配置，自动生成 `range_id`，例如 `freshwater_lowheat:V0.2:Rref4990:I200`；如果 metadata 也提供 `range_id` 或 `frequency_hz`，必须与仪器一致。探头、线缆、增益策略的身份应另外纳入 `session_id` 及实验记录，校准后必须保持一致。实际 κ(T) 必须来自证书温度表或有依据的插值，不自动假定水样温度系数。温度误差超过工具规定的匹配阈值时采集会失败，应更新证书对应值并先稳定水温。

```bash
python3 scripts/meter.py collect --port /dev/ttyUSB0 --address 30 \
  --metadata standard-metadata.json --output point-1413-fit.csv --samples 10
```

输出文件及同名 `.csv.raw.jsonl` 原始日志以独占模式创建，避免覆盖已有测量。原始日志保留未作主机温度修正的读数、配置、时间及校准标识。若中途失败，保留已采集行；它们不是完整验收。重复测量前换文件名。多杯标准液各自使用正确 metadata，合并时仅保留一个 CSV 表头。

至少三个不同电导率拟合点，覆盖需要使用的校准区间：

```bash
python3 calibration/calibrate.py fit real-fit.csv --output real-calibration.json
```

默认拟合模型 κ(T)=K·G，输出 `gain_cm_inv` 即等效电极常数。若拟合明显不良，先排查极化、漏电、温度和量程切换，不用增加自由参数掩盖硬件问题。

使用**新的** `session_id`、`role=verify` 和新的 `sample_id` 采集独立检查点，再运行：

```bash
python3 calibration/calibrate.py verify real-calibration.json real-verify.csv \
  --decision-uncertainty-pct YOUR_EVALUATED_TOTAL_PERCENT \
  --output real-verification.json
```

`YOUR_EVALUATED_TOTAL_PERCENT` 必须来自实际不确定度分析，不能直接沿用示例的 0.15%。未提供总不确定度时，只报告原始误差，不能完成含保护带的精度判定。

将真实捕获的一条有效 RAW 响应应用主机校准：

```bash
python3 scripts/meter.py decode --calibration real-calibration.json < captured-line.txt
```

主机输出未温补的 `calibrated_conductivity_us_cm`；不自动输出 κ25。解码工具核对固件 profile、参考电阻、电流、激励幅值及频率与校准档案一致，但无法确认实物探头、线缆或电阻是否确实匹配；操作者必须核对。写入设备 K 与 host 修正不可重复相乘；这里 host 直接用独立原始 G，不受固件 K 设置影响。

## 温度通道校准

`calibration/temperature.py` 独立拟合并检查原始 RTD 温度与可溯源参考温度的关系。完成真实温度标定后，采集电导标准液及解码时都传入同一文件：

```bash
python3 scripts/meter.py collect --port /dev/ttyUSB0 \
  --metadata standard-metadata.json --output point-1413-fit.csv \
  --temperature-calibration real-temperature-calibration.json
python3 scripts/meter.py decode --calibration real-calibration.json \
  --temperature-calibration real-temperature-calibration.json < captured-line.txt
```

修正后的水温写入校准 CSV，原始温度保留在 JSONL 日志。温度校准文件的摘要会绑定到 `range_id`；换温度校准文件后需重新复核电导校准。此修正目前在主机端执行，仪器 LCD 和原始 RAW 温度仍是未作该主机修正的读数，不能把主机达标误称为独立设备 LCD 已达标。
