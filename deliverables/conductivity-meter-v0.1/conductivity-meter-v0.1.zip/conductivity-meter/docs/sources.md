# 参考资料核对与适用性

核对日期：2026-10-19。以下把“实际读到的资料”“本设计的工程判断”“尚未核实的采购信息”分开记录。网页访问失败不等于资料不存在，也不能把记忆中的参数当作本次已核实事实。

## 设计取舍

本项目采用 **2016 年资料对应的 CN0359 / EVAL-CN0359-EB1Z 架构及仓库 `cn0359_reva` 固件**作为电导率与温度的第一版原型基础。目标是淡水 **10–2000 µS/cm、±0.5% 读数**，温度范围 **0–50 °C**，配 K≈1 cm⁻¹ 两极电导池和独立四线 Pt1000。当前官网 CN0359 PDF 已更新到 Rev. C，不能仅凭“CN0359”名称认定新购板与这套旧固件直接兼容，版本识别见下文。

这是设计与验收目标；ADI 电阻模拟实验、开源固件可编译以及软件测试均不能单独证明整台仪器已经达到该指标。浸水探头、电缆、标准液、温度及补偿模型必须参加实物验收。

| 资料 | 实际用途及已证实事实 | 对本项目的意义 |
| --- | --- | --- |
| **CN0349**，Rev. A，官方 PDF 已读 | 标题 *Fully Isolated Conductivity Measurement Data Acquisition System*；AD5934、AD8606、ADG715、ADuM1250、ADuM5000；配 Pt100；标称校准后总误差小于 1% FSR。第 5 页给出 **25–2500 µS 档，读数误差不超过 0.5%** 的电阻模拟测试。 | 是相关水质电导率参考。不能把“1% FSR”换成“1% 读数”；也不能忽略其低档实测接近目标精度。但 K=1 时本项目 10 µS/cm 低端超出该低档已发表测试范围；表中非感性电阻模拟也没有覆盖实际电极、温度和长期漂移，因此本版不直接沿用它声称整机达标。 |
| **CN0359**，用户上传中文文章与本地固件已读 | 中文文章为《全自动自校准电导率测量系统》，作者 Wyatt Taylor、David Brown，《模拟对话》50-11，2016-11；明确板号 EVAL-CN0359-EB1Z；支持两极/四极电导池、Pt100/Pt1000、两/三/四线 RTD；同步采样交流电压与电流；文中称电子电路在宽电导范围可优于 0.3%，电阻模拟实验最大误差小于 0.1%。 | 与用户目标最接近，且已有可追溯的完整固件。文中“自校准”不代替探头电极常数校准、温度校准、标准液溯源或成品验收；不能把电阻模拟结果作为水样整机精度证书。 |
| **CN0565**，官方 no-OS README 已读 | 明确用途是 **Electrical Impedance Tomography（EIT，电阻抗层析）**；器件 AD5940、ADG2128；支持多电极配置，文中最多 24 电极；官方软件例程用于 EIT 控制与数据传输。 | 多电极 EIT 可参考阻抗采集、开关矩阵和隔离思路，但并非本项目所需的专用双参量淡水电导率仪。没有从该 README 推导水样精度。 |
| **CN0510**，Rev. A，官方 PDF 和英文网页已读 | 标题 *Electrochemical Impedance Spectroscopy (EIS) for Batteries*；AD5941、AD8694、ADG636；EVAL-AD5941BATZ + EVAL-ADICUP3029；针对毫欧级电池阻抗，采用电流激励；官方 BATImpedance 示例的校准电阻是 50 mΩ，串口输出实部/虚部 mΩ。 | 用于电池状态与阻抗谱分析。其模拟输入量级和激励拓扑不应直接套用到 K=1、约 500 Ω–100 kΩ 的淡水电导池。可作交流测量方法参考，本版不以此作为主电路。 |

在 K=1 cm⁻¹ 时，由 κ=K/R 可得：10 µS/cm ↔100 kΩ，2000 µS/cm ↔500 Ω。这里 κ 是电导率（S/cm），G=1/R 是电导（S）；部分 ADI 文档为简写会省略“/cm”，实施时不能混淆。

## 可追溯来源与访问状态

| ID | 地址或本地文件 | 本次状态与引用范围 |
| --- | --- | --- |
| S1 | 用户上传 `fully-automatic-self-calibrated-conductivity-measurement-system_cn.pdf`；本次解析文本 `/tmp/conductivity_reference.txt` | 已读正文及图示。内容为 CN0359 对应的《模拟对话》文章，不应误标成 CN0349。 |
| S2 | [CN0349 官方英文 PDF](https://www.analog.com/media/en/reference-design-documentation/reference-designs/CN0349.pdf)；交付副本 [CN0349_RevA.pdf](../references/official_notes/CN0349_RevA.pdf) | HTTPS 下载成功；已读首页、第 2–5 页架构、校准、量程和误差表。PDF SHA-256：`9131ca93f9608b015237499a58f05932dc3b6ba4a063e9b66e4d7cdc4a5d0ad0`。 |
| S3 | [用户给出的 CN0349 中文页面](https://www.analog.com/cn/resources/reference-designs/circuits-from-the-lab/cn0349.html#rd-description) | 本次中文页面读取超时；英文页面也超时。引用 CN0349 参数来自成功下载的 S2，而不是声称完整读取了此网页。 |
| S4 | [CN0359 英文页面](https://www.analog.com/en/resources/reference-designs/circuits-from-the-lab/cn0359.html)；[当前官方 PDF](https://www.analog.com/media/en/reference-design-documentation/reference-designs/CN0359.pdf)；交付副本 [CN0359.pdf](../hardware/sources/CN0359.pdf) | 页面和 PDF 已取得；当前 PDF 是 **Rev. C**，修订历史记载 **02/2023—Rev. B to Rev. C**。已读第 1–2 页、第 4 页和末页修订记录。官方 design-support ZIP 入口确认，但 ZIP 本轮访问受限，未据此声称获得原始 PCB/CAD 完整包。 |
| S5 | [现有仓库 CN0359 Rev. A 固件](https://github.com/yafee5/EVAL-ADICUP360/tree/7d76cf79a72e9e6f28345b37f9476a1da2c2d930/projects/ADuCM360_demo_cn0359_reva) | 本地已读；工作区原始仓库 HEAD 为 `7d76cf79a72e9e6f28345b37f9476a1da2c2d930`。本项目保留来源和软件许可；固件可用性需结合构建记录与硬件修订核对。 |
| S6 | [CN0565 官方 no-OS README，固定版本](https://github.com/analogdevicesinc/no-OS/blob/bdd9427af10c767f6bf3aa9a61100317d1192b44/projects/cn0565/README.rst) | 已通过 `raw.githubusercontent.com` 成功读取。上表 CN0565 信息来自该官方仓库，不从未读到的 PDF 推测。 |
| S7 | [用户给出的 CN0565 页面](https://www.analog.com/cn/resources/reference-designs/circuits-from-the-lab/cn0565.html)；[CN0565 PDF](https://www.analog.com/media/en/reference-design-documentation/reference-designs/CN0565.pdf) | 原先网页受访问限制；本轮英文页面及 PDF 超时，未取得其完整原理图或测量精度表。CN0565 具体精度、频率范围和 PCB 细节仍未独立核实。 |
| S8 | [CN0510 官方 PDF](https://www.analog.com/media/en/reference-design-documentation/reference-designs/CN0510.pdf)；交付副本 [CN0510_RevA.pdf](../references/official_notes/CN0510_RevA.pdf) | HTTPS 下载成功；已读用途、器件、板卡、激励及量级说明。PDF SHA-256：`8bfe02fdb743c4088b4767a9b28adb37a356a1d2fe52e6abba7c2cb1908eb0b4`。 |
| S9 | [CN0510 英文页面](https://www.analog.com/en/resources/reference-designs/circuits-from-the-lab/cn0510.html)；[用户给出的中文页面](https://www.analog.com/cn/resources/reference-designs/circuits-from-the-lab/cn0510.html) | 英文页面 HTTPS 成功，确认 PDF 入口；中文页面读取超时。 |
| S10 | [ADI 官方 AD5940 电池阻抗示例](https://github.com/analogdevicesinc/AD5940-examples/blob/ae917b69b4f71214c7f19ae3eef563b9c547d48f/examples/AD5940_BATImpedance/AD5940Main.c) | 已读 AD5940Main.c 和同目录 BATImpedance.c。源文件包含 50 mΩ RCAL、EVAL-AD5941BATZ 名称及 mΩ 串口输出，和 S8 相互印证。该代码未混入本版 CN0359 固件。 |
| S11 | [ADI 中文主页](https://www.analog.com/cn/index.html) | 用户给出的官方入口。主页本身不能作为电路参数或整机精度依据，本版没有把主页当作技术数据表。 |

以上 PDF 保持正常 TLS 验证下载。记录的 SHA-256 用来让后续读者检查交付副本是否改变；它不是厂商独立签名或出厂校准证明。

## CN0359 板卡版本与固件对应

用户上传文章是 2016 年的旧版说明，交付副本见 [ADI_AnalogDialogue_2016_CN0359_cn.pdf](../hardware/sources/ADI_AnalogDialogue_2016_CN0359_cn.pdf)；它标注 EVAL-CN0359-EB1Z，图中电压缓冲器是 ADA4000-1，通信描述为 RS-485。现有固件项目名为 `ADuCM360_demo_cn0359_reva`，本版移植、构建和默认烧录入口以这套硬件为依据。

官网当前 Rev. C 文档首页板号写作 EVAL-CN0359-EBZ，第 2 页简图的电压缓冲器改为 ADA4622-1，通信描述为 USB-to-UART bridge。**Rev. C 图中仍有两个 AD8253，电压通道 G1、电流通道 G2 均标明 1/10/100/1000 可选；其正文“fixed, selectable gains”不能解释成电压通道固定增益。** 电路修改、接口描述和板号差异需要在采购与烧录前核实，但这些文档差异本身不足以证明全部板卡必然不兼容。

本版主选板卡应要求供方提供板正反面清晰照片、丝印硬件修订号和对应完整原理图，确认其符合旧版 Rev. A 固件的 GPIO、PGA 选通、ADC 差分输入、RTD 接线与串口收发器连接。若拿到当前 Rev. C 或其他修订板，应按实际完整原理图核对这些映射并完成实板验证后再使用；现有云端构建不能证明跨硬件修订兼容。仅有相似料号或两颗 AD8253 都不足以完成版本识别。

## 探头选型与采购边界

本版已经选定 **国产按技术规格定制的 K≈1 cm⁻¹ 镀铂黑铂两极电导池＋独立四线 Pt1000，0–50 °C** 为主选采购路径，详见 [probe_procurement.md](probe_procurement.md)。这是明确的已选技术规格，尚未完成供应商定标或下单；探头与线缆须逐支校准并参与整机验收。

Atlas Scientific K=1.0 与 Endress+Hauser Condumax CLS21 仅作为主选供方不能满足规格时的备选询价对象；本次未取得其现行完整官方数据表，**不将它们列为已经确认能达到本项目整机精度的已选型号**。不把 EZO 数字转换板的精度写成裸电导池的精度，也不默认某个商业电导池内置温度元件一定是四线 Pt1000。

本次 Atlas 产品页与 `https://files.atlas-scientific.com/EC_K_1.0_probe.pdf` 访问被代理拒绝（403）。尚未核实料号后缀、温度元件、线制、库存、交期、材质证明或校准证书；采购前须由供应商按参数表书面确认。若供应商只提供两线温度元件，可使用独立的四线 Pt1000，不在本版精度预算里默默替换。
