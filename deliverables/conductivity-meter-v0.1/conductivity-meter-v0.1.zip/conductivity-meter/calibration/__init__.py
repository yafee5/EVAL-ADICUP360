"""Offline calibration; see docs/calibration.md before using real measurements."""
