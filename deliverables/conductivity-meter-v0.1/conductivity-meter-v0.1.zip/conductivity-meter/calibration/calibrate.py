#!/usr/bin/env python3
"""Conductivity calibration and independent acceptance; Python standard library only.

All conductivity references are certificate values AT THE MEASURED TEMPERATURE.
This tool never guesses water chemistry and never applies a generic 2 %/°C factor.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import asdict, dataclass, fields
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
from typing import Iterable

MIN_US_CM = 10.0
MAX_US_CM = 2000.0
MIN_TEMP_C = 0.0
MAX_TEMP_C = 50.0
ERROR_LIMIT_PCT = 0.5
RECOMMENDED_LEVELS = (10, 20, 50, 84, 100, 500, 1000, 1413, 2000)
MAX_REFERENCE_TEMP_DIFFERENCE_C = 0.02
SCHEMA = "conductivity-calibration-v1"


class DataError(ValueError):
    """An input cannot support the requested metrology operation."""


def finite(value: object, name: str) -> float:
    if isinstance(value, bool):
        raise DataError(f"{name}: boolean is not a measurement")
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise DataError(f"{name}: expected a finite number") from exc
    if not math.isfinite(number):
        raise DataError(f"{name}: NaN and infinity are forbidden")
    return number


@dataclass(frozen=True)
class Sample:
    sample_id: str
    role: str
    origin: str
    session_id: str
    conductance_us: float
    temperature_c: float
    reference_us_cm: float
    reference_temperature_c: float
    reference_uncertainty_pct: float
    certificate_id: str
    standard_id: str
    range_id: str
    frequency_hz: float

    @property
    def profile(self) -> str:
        return f"{self.range_id}@{self.frequency_hz:.12g}Hz"

    def validate(self) -> None:
        for name in ("sample_id", "session_id", "certificate_id", "standard_id", "range_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise DataError(f"{self.sample_id or 'row'}: {name} is required")
        if self.role not in ("fit", "verify"):
            raise DataError(f"{self.sample_id}: role must be fit or verify")
        if self.origin not in ("real", "synthetic"):
            raise DataError(f"{self.sample_id}: origin must be real or synthetic")
        for name in ("conductance_us", "temperature_c", "reference_us_cm", "reference_temperature_c",
                     "reference_uncertainty_pct", "frequency_hz"):
            if not isinstance(getattr(self, name), (int, float)):
                raise DataError(f"{name}: numeric API fields must be int or float")
            finite(getattr(self, name), name)
        if not 0 < self.conductance_us < 1e8:
            raise DataError(f"{self.sample_id}: conductance must be positive and < 1e8 µS")
        if not MIN_US_CM <= self.reference_us_cm <= MAX_US_CM:
            raise DataError(f"{self.sample_id}: reference is outside 10–2000 µS/cm")
        if not MIN_TEMP_C <= self.temperature_c <= MAX_TEMP_C:
            raise DataError(f"{self.sample_id}: temperature is outside 0–50 °C")
        if not MIN_TEMP_C <= self.reference_temperature_c <= MAX_TEMP_C:
            raise DataError(f"{self.sample_id}: reference temperature is outside 0–50 °C")
        if abs(self.reference_temperature_c - self.temperature_c) > MAX_REFERENCE_TEMP_DIFFERENCE_C + 1e-12:
            raise DataError(f"{self.sample_id}: use certified κ(T) at the measured temperature (≤0.02 °C mismatch)")
        if not 0 < self.reference_uncertainty_pct <= 1:
            raise DataError(f"{self.sample_id}: enter positive certificate expanded uncertainty in %, not a fraction")
        if not 1 <= self.frequency_hz <= 100000:
            raise DataError(f"{self.sample_id}: frequency must be 1–100000 Hz")


CSV_FIELDS = tuple(f.name for f in fields(Sample))
NUMERIC_FIELDS = {"conductance_us", "temperature_c", "reference_us_cm", "reference_temperature_c",
                  "reference_uncertainty_pct", "frequency_hz"}


def read_csv(path: Path) -> list[Sample]:
    result = []
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise DataError("CSV has missing or duplicate column names")
        if set(reader.fieldnames) != set(CSV_FIELDS):
            missing = sorted(set(CSV_FIELDS) - set(reader.fieldnames))
            extra = sorted(set(reader.fieldnames) - set(CSV_FIELDS))
            raise DataError(f"CSV columns do not match; missing={missing}, extra={extra}")
        for line, record in enumerate(reader, 2):
            if None in record or any(value is None for value in record.values()):
                raise DataError(f"CSV line {line}: wrong number of fields")
            values = {key: finite(value, f"line {line} {key}") if key in NUMERIC_FIELDS else value.strip()
                      for key, value in record.items()}
            sample = Sample(**values)
            sample.validate()
            result.append(sample)
    validate_collection(result)
    return result


def validate_collection(samples: Iterable[Sample]) -> None:
    rows = list(samples)
    if not rows:
        raise DataError("CSV has no measurements")
    ids = set()
    for row in rows:
        row.validate()
        if row.sample_id in ids:
            raise DataError(f"duplicate sample_id: {row.sample_id}")
        ids.add(row.sample_id)
    if len({row.origin for row in rows}) != 1:
        raise DataError("real and synthetic measurements cannot be mixed")


def allowed_origin(samples: list[Sample], allow_synthetic: bool) -> str:
    validate_collection(samples)
    origin = samples[0].origin
    if origin == "synthetic" and not allow_synthetic:
        raise DataError("synthetic data require --allow-synthetic; they are not hardware evidence")
    return origin


def corrected(calibration: dict, conductance_us: float) -> float:
    g = finite(conductance_us, "conductance_us")
    if g <= 0:
        raise DataError("conductance_us must be positive")
    gain = finite(calibration["gain_cm_inv"], "gain_cm_inv")
    offset = finite(calibration["offset_us_cm"], "offset_us_cm")
    value = gain * g + offset
    if not math.isfinite(value) or value <= 0:
        raise DataError("calibration predicts a nonpositive or nonfinite conductivity")
    return value


def fit(samples: list[Sample], *, model: str = "cell", allow_synthetic: bool = False,
        nominal_cell_constant: float = 1.0) -> dict:
    origin = allowed_origin(samples, allow_synthetic)
    rows = [row for row in samples if row.role == "fit"]
    if model not in ("cell", "affine"):
        raise DataError("model must be cell or affine")
    if len(rows) < 3 or len({row.reference_us_cm for row in rows}) < 3:
        raise DataError("at least three distinct reference levels are required for fitting")
    nominal = finite(nominal_cell_constant, "nominal_cell_constant")
    if not 0.01 <= nominal <= 100:
        raise DataError("nominal cell constant must be 0.01–100 cm⁻¹")
    # Equal RELATIVE residual weighting; no statistical uncertainty is inferred.
    # Scaling x by nominal K keeps the affine normal equations well conditioned.
    x = [row.conductance_us * nominal / row.reference_us_cm for row in rows]
    z = [1.0 / row.reference_us_cm for row in rows]
    xx = math.fsum(a * a for a in x)
    if not math.isfinite(xx) or xx <= 0:
        raise DataError("degenerate conductance data")
    if model == "cell":
        gain = nominal * math.fsum(x) / xx
        offset = 0.0
    else:
        xz = math.fsum(a * b for a, b in zip(x, z))
        zz = math.fsum(a * a for a in z)
        sx, sz = math.fsum(x), math.fsum(z)
        determinant = xx * zz - xz * xz
        if determinant <= 1e-12 * xx * zz:
            raise DataError("affine fit is singular or ill-conditioned; use separated conductance points")
        gain = nominal * (sx * zz - sz * xz) / determinant
        offset = (xx * sz - xz * sx) / determinant
    if not math.isfinite(gain) or not 0.5 * nominal <= gain <= 2 * nominal or not math.isfinite(offset):
        raise DataError("fitted gain is nonphysical for the nominal cell; check units and wiring")
    calibration = {
        "schema": SCHEMA,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "origin": origin,
        "evidence_status": "synthetic_only_not_hardware_evidence" if origin == "synthetic" else "user_supplied_real_measurements_unverified_provenance",
        "quantity": "uncompensated_conductivity_at_measured_temperature",
        "model": model,
        "formula": "kappa_T_us_cm = gain_cm_inv * conductance_us + offset_us_cm",
        "gain_cm_inv": gain,
        "offset_us_cm": offset,
        "nominal_cell_constant_cm_inv": nominal,
        "fit_reference_domain_us_cm": [min(row.reference_us_cm for row in rows), max(row.reference_us_cm for row in rows)],
        "fit_temperature_domain_c": [min(row.temperature_c for row in rows), max(row.temperature_c for row in rows)],
        "profiles": sorted({row.profile for row in rows}),
        "fit_sample_ids": [row.sample_id for row in rows],
        "fit_session_ids": sorted({row.session_id for row in rows}),
        "fit_standard_ids": sorted({row.standard_id for row in rows}),
        "fit_certificate_ids": sorted({row.certificate_id for row in rows}),
        "fit_rows": [asdict(row) for row in rows],
    }
    residuals = [{"sample_id": row.sample_id,
                  "error_pct": 100 * (corrected(calibration, row.conductance_us) / row.reference_us_cm - 1)}
                 for row in rows]
    calibration["fit_residuals"] = residuals
    calibration["fit_max_abs_error_pct"] = max(abs(row["error_pct"]) for row in residuals)
    calibration["fit_raw_error_pass"] = calibration["fit_max_abs_error_pct"] <= ERROR_LIMIT_PCT + 1e-12
    calibration["warning"] = "Fit residuals are not independent acceptance evidence. No 25 °C compensation or temperature-model qualification is performed."
    return calibration


def validate_calibration(calibration: dict) -> None:
    if not isinstance(calibration, dict) or calibration.get("schema") != SCHEMA:
        raise DataError("unsupported calibration JSON schema")
    if calibration.get("quantity") != "uncompensated_conductivity_at_measured_temperature":
        raise DataError("calibration quantity must be uncompensated conductivity")
    if calibration.get("model") not in ("cell", "affine"):
        raise DataError("invalid calibration model")
    gain = finite(calibration.get("gain_cm_inv"), "gain_cm_inv")
    offset = finite(calibration.get("offset_us_cm"), "offset_us_cm")
    nominal = finite(calibration.get("nominal_cell_constant_cm_inv"), "nominal_cell_constant_cm_inv")
    if nominal <= 0 or not 0.5 * nominal <= gain <= 2 * nominal:
        raise DataError("invalid calibration gain")
    if calibration["model"] == "cell" and offset != 0:
        raise DataError("cell model requires exactly zero offset")
    domain = calibration.get("fit_reference_domain_us_cm")
    if not isinstance(domain, list) or len(domain) != 2:
        raise DataError("calibration has no valid fit domain")
    lower, upper = (finite(v, "fit domain") for v in domain)
    if not MIN_US_CM <= lower < upper <= MAX_US_CM:
        raise DataError("invalid calibration domain")
    for key in ("fit_sample_ids", "fit_session_ids", "profiles"):
        value = calibration.get(key)
        if not isinstance(value, list) or not value or not all(isinstance(v, str) and v for v in value):
            raise DataError(f"invalid calibration {key}")
    if calibration.get("origin") not in ("real", "synthetic"):
        raise DataError("invalid calibration origin")


def verify(calibration: dict, samples: list[Sample], *, allow_synthetic: bool = False,
           decision_uncertainty_pct: float | None = None) -> dict:
    validate_calibration(calibration)
    origin = allowed_origin(samples, allow_synthetic)
    if origin != calibration["origin"]:
        raise DataError("calibration and verification origins differ")
    rows = [row for row in samples if row.role == "verify"]
    if not rows:
        raise DataError("no independent verification measurements")
    total_u = None
    if decision_uncertainty_pct is not None:
        total_u = finite(decision_uncertainty_pct, "decision_uncertainty_pct")
        if not 0 < total_u < ERROR_LIMIT_PCT:
            raise DataError("decision uncertainty must be positive and below 0.5 %")
    lower, upper = (finite(value, "fit domain") for value in calibration["fit_reference_domain_us_cm"])
    points = []
    for row in rows:
        if row.sample_id in calibration["fit_sample_ids"]:
            raise DataError(f"{row.sample_id}: reusing a fit measurement for acceptance is forbidden")
        if row.session_id in calibration["fit_session_ids"]:
            raise DataError(f"{row.sample_id}: verification needs a separate measurement session")
        if row.profile not in calibration["profiles"]:
            raise DataError(f"{row.sample_id}: profile {row.profile} was not represented during calibration")
        if not lower <= row.reference_us_cm <= upper:
            raise DataError(f"{row.sample_id}: extrapolation outside fitted reference range is forbidden")
        if total_u is not None and total_u < row.reference_uncertainty_pct:
            raise DataError(f"{row.sample_id}: total decision uncertainty is smaller than certificate uncertainty")
        value = corrected(calibration, row.conductance_us)
        error = 100 * (value / row.reference_us_cm - 1)
        reference_guardband = abs(error) + row.reference_uncertainty_pct
        points.append({
            "sample_id": row.sample_id, "profile": row.profile,
            "temperature_c": row.temperature_c, "reference_us_cm": row.reference_us_cm,
            "corrected_us_cm": value, "error_pct": error,
            "raw_error_pass": abs(error) <= ERROR_LIMIT_PCT + 1e-12,
            "certificate_only_guardband_pct": reference_guardband,
            "certificate_only_guardband_pass": reference_guardband <= ERROR_LIMIT_PCT + 1e-12,
            "decision_uncertainty_pct": total_u,
            "guardband_pass": None if total_u is None else abs(error) + total_u <= ERROR_LIMIT_PCT + 1e-12,
        })
    covered = [level for level in RECOMMENDED_LEVELS
               if any(abs(row.reference_us_cm - level) <= max(0.01, 0.001 * level) for row in rows)]
    all_raw = all(point["raw_error_pass"] for point in points)
    all_guard = None if total_u is None else all(point["guardband_pass"] for point in points)
    return {
        "schema": "conductivity-verification-v1", "origin": origin,
        "evidence_status": "synthetic_only_not_hardware_evidence" if origin == "synthetic" else "user_supplied_real_measurements_unverified_provenance",
        "scope": "sampled independent uncompensated points only; no continuous range, full-temperature or compensation accuracy claim",
        "error_limit_pct_reading": ERROR_LIMIT_PCT,
        "decision_rule": "abs(error_pct) + total_decision_expanded_uncertainty_pct <= 0.5",
        "decision_uncertainty_pct": total_u,
        "all_points_raw_error_pass": all_raw,
        "all_points_guardband_pass": all_guard,
        "qualification_status": "raw_errors_only_total_uncertainty_missing" if total_u is None else
                                "sampled_points_guardband_pass" if all_guard else "failed",
        "max_abs_error_pct": max(abs(point["error_pct"]) for point in points),
        "covered_recommended_levels_us_cm": covered,
        "missing_recommended_levels_us_cm": [level for level in RECOMMENDED_LEVELS if level not in covered],
        "missing_calibration_profiles": sorted(set(calibration["profiles"]) - {row.profile for row in rows}),
        "tested_temperature_domain_c": [min(row.temperature_c for row in rows), max(row.temperature_c for row in rows)],
        "points": points,
    }


def save_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    fit_parser = commands.add_parser("fit", help="fit κ(T)=K·G, or an explicitly selected affine correction")
    fit_parser.add_argument("csv", type=Path)
    fit_parser.add_argument("--output", type=Path, required=True)
    fit_parser.add_argument("--model", choices=("cell", "affine"), default="cell")
    fit_parser.add_argument("--nominal-cell-constant", type=float, default=1.0)
    fit_parser.add_argument("--allow-synthetic", action="store_true")
    verify_parser = commands.add_parser("verify", help="check independent points with a guard band")
    verify_parser.add_argument("calibration", type=Path)
    verify_parser.add_argument("csv", type=Path)
    verify_parser.add_argument("--output", type=Path, required=True)
    verify_parser.add_argument("--decision-uncertainty-pct", type=float)
    verify_parser.add_argument("--allow-synthetic", action="store_true")
    template_parser = commands.add_parser("template", help="write a header-only CSV; fill with real observations")
    template_parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        for name in ("csv", "calibration"):
            source = getattr(args, name, None)
            if source is not None and args.output.resolve() == source.resolve():
                raise DataError("output must not overwrite an input")
        if args.command == "template":
            args.output.parent.mkdir(parents=True, exist_ok=True)
            # Exclusive creation prevents a new template overwriting collected measurements.
            with args.output.open("x", newline="", encoding="utf-8") as stream:
                csv.writer(stream).writerow(CSV_FIELDS)
            print(f"Empty measurement template: {args.output}")
            return 0
        samples = read_csv(args.csv)
        if args.command == "fit":
            result = fit(samples, model=args.model, allow_synthetic=args.allow_synthetic,
                         nominal_cell_constant=args.nominal_cell_constant)
        else:
            with args.calibration.open(encoding="utf-8") as stream:
                calibration = json.load(stream)
            result = verify(calibration, samples, allow_synthetic=args.allow_synthetic,
                            decision_uncertainty_pct=args.decision_uncertainty_pct)
        save_json(args.output, result)
        print(f"{args.command}: {args.output}; origin={result['origin']}")
        if args.command == "verify":
            print(f"max |error|={result['max_abs_error_pct']:.6g} %; {result['qualification_status']}")
            return 0 if result["all_points_raw_error_pass"] and result["all_points_guardband_pass"] is not False else 2
        print(f"fit max |residual|={result['fit_max_abs_error_pct']:.6g} %; independent acceptance still required")
        return 0 if result["fit_raw_error_pass"] else 2
    except (DataError, OSError, json.JSONDecodeError, KeyError, TypeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
