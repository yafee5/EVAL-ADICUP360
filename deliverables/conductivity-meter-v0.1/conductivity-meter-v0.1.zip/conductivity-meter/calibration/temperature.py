#!/usr/bin/env python3
"""Host-only Pt1000 temperature correction and independent verification.

Measurements must come from the final probe/current/front-end assembly in a
traceable bath. Synthetic examples and native firmware sweeps are not bath tests.
"""
from __future__ import annotations
import argparse
import csv
from dataclasses import asdict, dataclass, fields
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys

try:
    from .calibrate import DataError, finite
except ImportError:  # executable script
    from calibrate import DataError, finite

SCHEMA = "temperature-calibration-v1"
MIN_C, MAX_C = 0.0, 50.0
RAW_MIN_C, RAW_MAX_C = -5.0, 55.0


@dataclass(frozen=True)
class TemperatureSample:
    sample_id: str
    role: str
    origin: str
    session_id: str
    measured_temperature_c: float
    reference_temperature_c: float
    reference_uncertainty_c: float

    def validate(self) -> None:
        for name in ("sample_id", "session_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip():
                raise DataError(f"temperature {name} must be nonempty")
        if self.role not in ("fit", "verify") or self.origin not in ("real", "synthetic"):
            raise DataError("temperature role must be fit/verify; origin real/synthetic")
        for name in ("measured_temperature_c", "reference_temperature_c", "reference_uncertainty_c"):
            value = getattr(self, name)
            if not isinstance(value, (int, float)):
                raise DataError(f"temperature {name} must be numeric")
            finite(value, name)
        if not RAW_MIN_C <= self.measured_temperature_c <= RAW_MAX_C:
            raise DataError("raw temperature must be within −5..55 °C; check sensor/configuration")
        if not MIN_C <= self.reference_temperature_c <= MAX_C:
            raise DataError("reference temperature must be within 0..50 °C")
        if not 0 < self.reference_uncertainty_c <= 0.5:
            raise DataError("positive reference expanded uncertainty in °C is required")


CSV_FIELDS = tuple(field.name for field in fields(TemperatureSample))
NUMERIC_FIELDS = {"measured_temperature_c", "reference_temperature_c", "reference_uncertainty_c"}


def validate_samples(rows: list[TemperatureSample], allow_synthetic=False) -> str:
    if not rows:
        raise DataError("no temperature measurements")
    seen = set()
    for row in rows:
        row.validate()
        if row.sample_id in seen:
            raise DataError(f"duplicate temperature sample_id: {row.sample_id}")
        seen.add(row.sample_id)
    origins = {row.origin for row in rows}
    if len(origins) != 1:
        raise DataError("real and synthetic temperature measurements cannot be mixed")
    origin = rows[0].origin
    if origin == "synthetic" and not allow_synthetic:
        raise DataError("synthetic temperature data require --allow-synthetic")
    return origin


def read_csv(path: Path) -> list[TemperatureSample]:
    rows = []
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        names = reader.fieldnames
        if names is None or len(names) != len(set(names)) or set(names) != set(CSV_FIELDS):
            raise DataError(f"temperature CSV must contain exactly {','.join(CSV_FIELDS)}")
        for number, record in enumerate(reader, 2):
            if None in record or any(value is None for value in record.values()):
                raise DataError(f"temperature CSV line {number}: wrong number of fields")
            values = {key: finite(value, key) if key in NUMERIC_FIELDS else value.strip()
                      for key, value in record.items()}
            row = TemperatureSample(**values)
            row.validate()
            rows.append(row)
    if not rows:
        raise DataError("temperature CSV has no measurements")
    return rows


def validate_model(model: dict) -> None:
    if not isinstance(model, dict) or model.get("schema") != SCHEMA:
        raise DataError("unsupported temperature calibration schema")
    if model.get("origin") not in ("real", "synthetic"):
        raise DataError("invalid temperature calibration origin")
    gain = finite(model.get("gain"), "temperature gain")
    offset = finite(model.get("offset_c"), "temperature offset_c")
    if not 0.9 <= gain <= 1.1 or abs(offset) > 2:
        raise DataError("implausible temperature gain/offset; check configuration")
    domain = model.get("fit_domain_c")
    if not isinstance(domain, list) or len(domain) != 2:
        raise DataError("invalid temperature reference domain")
    lo, hi = [finite(value, "temperature fit domain") for value in domain]
    if not 0 <= lo < hi <= 50 or lo > 0.2 or hi < 49.8:
        raise DataError("temperature calibration must cover near 0 and 50 °C")
    raw_domain = model.get("fit_raw_domain_c")
    if not isinstance(raw_domain, list) or len(raw_domain) != 2:
        raise DataError("invalid temperature raw domain")
    raw_lo, raw_hi = [finite(value, "temperature raw domain") for value in raw_domain]
    if not RAW_MIN_C <= raw_lo < raw_hi <= RAW_MAX_C:
        raise DataError("invalid temperature raw domain")
    for name in ("fit_sample_ids", "fit_session_ids"):
        value = model.get(name)
        if not isinstance(value, list) or not value or not all(isinstance(item, str) and item for item in value):
            raise DataError(f"invalid temperature calibration {name}")


def correct_temperature(model: dict, raw_c: float) -> float:
    """Apply correction only; caller must enforce its required operating domain.

    The wider raw guard allows a slightly negative reading at a true 0 °C. The
    result is never clipped; clipping would hide endpoint error. For metrology,
    scope is the stored fit_domain_c, not the whole −5..55 °C input guard.
    """
    validate_model(model)
    raw = finite(raw_c, "raw temperature")
    if not RAW_MIN_C <= raw <= RAW_MAX_C:
        raise DataError("raw temperature outside −5..55 °C input guard")
    result = finite(model["gain"], "gain") * raw + finite(model["offset_c"], "offset_c")
    if not math.isfinite(result):
        raise DataError("nonfinite corrected temperature")
    return result


def fit(samples: list[TemperatureSample], *, allow_synthetic=False) -> dict:
    origin = validate_samples(samples, allow_synthetic)
    rows = [row for row in samples if row.role == "fit"]
    refs = [row.reference_temperature_c for row in rows]
    if len(rows) < 3 or len(set(refs)) < 3:
        raise DataError("at least three distinct temperature fit references are required")
    if not (any(value <= 0.2 for value in refs) and any(abs(value - 25) <= 1 for value in refs)
            and any(value >= 49.8 for value in refs)):
        raise DataError("temperature fit requires references near 0, 25 and 50 °C")
    # Least squares in absolute °C error, centered to avoid cancellation.
    xbar = math.fsum(row.measured_temperature_c for row in rows) / len(rows)
    ybar = math.fsum(refs) / len(rows)
    xx = math.fsum((row.measured_temperature_c - xbar) ** 2 for row in rows)
    if xx < 1:
        raise DataError("degenerate temperature measurements")
    gain = math.fsum((row.measured_temperature_c - xbar) * (row.reference_temperature_c - ybar)
                     for row in rows) / xx
    offset = ybar - gain * xbar
    model = {
        "schema": SCHEMA, "origin": origin,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "application": "host_only_not_instrument_flash",
        "evidence_status": "synthetic_only_not_hardware_evidence" if origin == "synthetic" else "user_supplied_real_measurements_unverified_provenance",
        "formula": "corrected_temperature_c = gain * measured_temperature_c + offset_c",
        "gain": gain, "offset_c": offset,
        "fit_domain_c": [min(refs), max(refs)],
        "fit_raw_domain_c": [min(row.measured_temperature_c for row in rows), max(row.measured_temperature_c for row in rows)],
        "fit_sample_ids": [row.sample_id for row in rows],
        "fit_session_ids": sorted({row.session_id for row in rows}),
        "fit_rows": [asdict(row) for row in rows],
        "warning": "Linear correction cannot remove unmeasured self-heating, gradients, nonlinearities or changed flow conditions. Independent bath checks required.",
    }
    validate_model(model)
    model["fit_residuals_c"] = [
        {"sample_id": row.sample_id,
         "error_c": correct_temperature(model, row.measured_temperature_c) - row.reference_temperature_c}
        for row in rows]
    model["fit_max_abs_error_c"] = max(abs(row["error_c"]) for row in model["fit_residuals_c"])
    return model


def verify(model: dict, samples: list[TemperatureSample], *, allow_synthetic=False,
           limit_c=0.03, decision_uncertainty_c=None) -> dict:
    validate_model(model)
    origin = validate_samples(samples, allow_synthetic)
    if origin != model["origin"]:
        raise DataError("temperature calibration/check origins differ")
    limit = finite(limit_c, "temperature error limit")
    if not 0 < limit <= 0.05:
        raise DataError("temperature limit must be positive and ≤0.05 °C")
    total_u = None if decision_uncertainty_c is None else finite(decision_uncertainty_c, "temperature decision uncertainty")
    if total_u is not None and not 0 < total_u < limit:
        raise DataError("temperature total decision uncertainty must be positive and below the limit")
    rows = [row for row in samples if row.role == "verify"]
    if not rows:
        raise DataError("independent temperature checks are required")
    lo, hi = (finite(value, "temperature fit domain") for value in model["fit_domain_c"])
    points = []
    for row in rows:
        if row.sample_id in model["fit_sample_ids"] or row.session_id in model["fit_session_ids"]:
            raise DataError("temperature check must not reuse fit measurements or sessions")
        if not lo <= row.reference_temperature_c <= hi:
            raise DataError("temperature check outside fitted reference domain")
        if total_u is not None and total_u < row.reference_uncertainty_c:
            raise DataError("temperature total uncertainty is smaller than reference uncertainty")
        value = correct_temperature(model, row.measured_temperature_c)
        error = value - row.reference_temperature_c
        points.append({"sample_id": row.sample_id, "reference_temperature_c": row.reference_temperature_c,
                       "measured_temperature_c": row.measured_temperature_c,
                       "corrected_temperature_c": value, "error_c": error,
                       "reference_uncertainty_c": row.reference_uncertainty_c,
                       "raw_error_pass": abs(error) <= limit + 1e-12,
                       "certificate_only_guardband_pass": abs(error) + row.reference_uncertainty_c <= limit + 1e-12,
                       "guardband_pass": None if total_u is None else abs(error) + total_u <= limit + 1e-12})
    raw_pass = all(point["raw_error_pass"] for point in points)
    guard_pass = None if total_u is None else all(point["guardband_pass"] for point in points)
    missing = [target for target in (12.5, 37.5)
               if not any(abs(row.reference_temperature_c - target) <= 1 for row in rows)]
    return {"schema": "temperature-verification-v1", "origin": origin,
            "evidence_status": "synthetic_only_not_hardware_evidence" if origin == "synthetic" else "user_supplied_real_measurements_unverified_provenance",
            "scope": "sampled independent bath points only; no continuous-temperature or self-heating guarantee",
            "application": "host_only_not_instrument_flash", "limit_c": limit,
            "decision_uncertainty_c": total_u,
            "decision_rule": "abs(error_c) + total_expanded_uncertainty_c <= limit_c",
            "all_points_raw_error_pass": raw_pass, "all_points_guardband_pass": guard_pass,
            "qualification_status": "raw_errors_only_total_uncertainty_missing" if total_u is None else
                                    "sampled_points_guardband_pass" if guard_pass else "failed",
            "max_abs_error_c": max(abs(point["error_c"]) for point in points),
            "missing_recommended_intermediate_checks_c": missing, "points": points}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    template = commands.add_parser("template")
    template.add_argument("--output", type=Path, required=True)
    fitting = commands.add_parser("fit")
    fitting.add_argument("csv", type=Path)
    fitting.add_argument("--output", type=Path, required=True)
    fitting.add_argument("--allow-synthetic", action="store_true")
    checking = commands.add_parser("verify")
    checking.add_argument("calibration", type=Path)
    checking.add_argument("csv", type=Path)
    checking.add_argument("--output", type=Path, required=True)
    checking.add_argument("--allow-synthetic", action="store_true")
    checking.add_argument("--limit-c", type=float, default=0.03)
    checking.add_argument("--decision-uncertainty-c", type=float)
    args = parser.parse_args(argv)
    try:
        for name in ("csv", "calibration"):
            source = getattr(args, name, None)
            if source is not None and source.resolve() == args.output.resolve():
                raise DataError("temperature output must not overwrite an input")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        if args.command == "template":
            with args.output.open("x", newline="", encoding="utf-8") as stream:
                csv.writer(stream).writerow(CSV_FIELDS)
            print(f"Empty temperature template: {args.output}")
            return 0
        rows = read_csv(args.csv)
        if args.command == "fit":
            result = fit(rows, allow_synthetic=args.allow_synthetic)
        else:
            model = json.loads(args.calibration.read_text(encoding="utf-8"))
            result = verify(model, rows, allow_synthetic=args.allow_synthetic, limit_c=args.limit_c,
                            decision_uncertainty_c=args.decision_uncertainty_c)
        with args.output.open("w", encoding="utf-8") as stream:
            json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
        print(f"temperature {args.command}: {args.output}; origin={result['origin']}")
        if args.command == "verify":
            print(f"max |error|={result['max_abs_error_c']:.6g} °C; {result['qualification_status']}")
            return 0 if result["all_points_raw_error_pass"] and result["all_points_guardband_pass"] is not False else 2
        return 0
    except (DataError, OSError, ValueError, KeyError, TypeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
