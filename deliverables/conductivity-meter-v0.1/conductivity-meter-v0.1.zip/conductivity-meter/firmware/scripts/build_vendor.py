#!/usr/bin/env python3
"""Build complete, unmodified-on-disk ADI sources through a reviewable port layer."""
from __future__ import annotations
import argparse
import concurrent.futures
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "vendor_cn0359_reva"


def replace(text: str, old: str, new: str, expected: int = 1) -> str:
    if text.count(old) != expected:
        raise RuntimeError(f"Port patch mismatch: expected {expected} occurrences of {old[:100]!r}")
    return text.replace(old, new)


def add_returns(text: str, names: set[str]) -> str:
    # Locate balanced function bodies, ignoring braces in strings and comments.
    token = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[{}]')
    positions = []
    for m in re.finditer(r'\bint\s+(?:static\s+)?(\w+)\s*\([^;{}]*\)\s*\{', text):
        if m[1] not in names:
            continue
        depth = 1
        for t in token.finditer(text, m.end()):
            if t[0] == "{":
                depth += 1
            elif t[0] == "}":
                depth -= 1
                if depth == 0:
                    positions.append(t.start())
                    break
    for pos in reversed(positions):
        text = text[:pos] + "\treturn 0; // GNU port: explicit return avoids C++ undefined behavior.\n" + text[pos:]
    return text


def patched_sources(destination: Path, profile: str) -> None:
    shutil.copytree(VENDOR, destination, dirs_exist_ok=True)
    patches = []
    return_names = {"rx_line", "on_cw", "on_ccw", "on_button_down", "on_button_up",
                    "on_conductivity", "on_rtd", "on_time", "debounce", "on_int7",
                    "tx_empty", "beep_loop", "cmd_poll", "cmd_cellconstant", "cmd_coefficient",
                    "cmd_frequency", "cmd_holdtime", "cmd_setuptime", "cmd_voltage"}
    for source in sorted(destination.rglob("*.cpp")):
        original = source.read_text()
        text = original
        # All argv allocations use matching arrays, including zero-argument events.
        text = re.sub(r'new\s+char\s*\*\s*;', 'nullptr;', text)
        text = text.replace("delete application.argv;", "delete[] application.argv;")
        text = text.replace("delete timer_v[i].timer_app.argv;", "delete[] timer_v[i].timer_app.argv;")
        # Original offset idiom evaluates an indeterminate pointer; use standard offsetof.
        text = re.sub(r'\(int\)\s*\(&p_flash_file->(\w+)\)\s*-\s*\(int\)\s*\(p_flash_file\)',
                      r'offsetof(flash_file, \1)', text)
        if "offsetof(" in text:
            text = "#include <cstddef>\n" + text
        text = add_returns(text, return_names)
        if source.name == "message.cpp":
            text = "#include <ADuCM360.h>\n" + text
            text = replace(text, '\tassert(ts_msg_back != (ts_msg_front - 1));',
                           '\tconst uint32_t primask = __get_PRIMASK();\n\t__disable_irq();\n'
                           '\tassert(ts_msg_back != (ts_msg_front - 1));')
            text = replace(text, '\t\t++ts_msg_back;\n\t}\n}',
                           '\t\t++ts_msg_back;\n\t}\n\t__set_PRIMASK(primask);\n}')
        if source.name == "flash.cpp":
            text = replace(text, 'static const struct flash_file flash_disk __attribute__ ((aligned (512),\n\t\tsection (".flash_disk")));',
                           'static const unsigned char flash_disk[512] __attribute__ ((used, aligned (512),\n\t\tsection (".flash_disk"))) = {};')
            text = replace(text, 'static const char * const p_flash_disk = (const char *) (&flash_disk);',
                           'static const volatile char * const p_flash_disk = (const volatile char *) flash_disk;')
            text = replace(text, '\tint start_page = position >> 9;',
                           '\tif (count > sizeof(flash_file) - position) count = sizeof(flash_file) - position;\n'
                           '\tif (!count) return 0;\n\tint start_page = position >> 9;')
            text = replace(text, '\t\tmemcpy(buffer, &p_flash_disk[i << 9], 512);',
                           '\t\tfor (int j = 0; j < 512; ++j) buffer[j] = p_flash_disk[(i << 9) + j];')
            text = replace(text, '\t\tunsigned long *p_src, *p_dst;',
                           '\t\tunsigned long *p_src;\n\t\tvolatile unsigned long *p_dst;')
            text = replace(text, 'p_dst = (unsigned long *)', 'p_dst = (volatile unsigned long *)')
            text = replace(text, '\t\tFEECON0_WREN_BBA = false;',
                           '\t\twhile (FEESTA_WRBUSY_BBA) {}\n\t\tFEECON0_WREN_BBA = false;')
            text = replace(text, '\tmemcpy(buf, &p_flash_disk[position], count);',
                           '\tfor (size_t j = 0; j < count; ++j) ((char*)buf)[j] = p_flash_disk[position + j];')
        if source.name == "uart_exec.cpp":
            text = replace(text, 'fgets(line, 128, stdin);', 'if (!fgets(line, 128, stdin)) return 0;')
            text = replace(text, 'sscanf(p, "%i", &address);',
                           'if (!p) return 0;\n\tsscanf(p, "%i", &address);')
            text = replace(text, 'p = strtok(nullptr, ", \\t\\r\\n");\n\n\t\tfor',
                           'p = strtok(nullptr, ", \\t\\r\\n");\n\t\tif (!p) return 0;\n\n\t\tfor')
            if profile.startswith("freshwater"):
                text = '#include "cmd_raw.h"\n' + text
                text = replace(text, '{{"poll", cmd_poll},', '{{"raw", cmd_raw}, {"poll", cmd_poll},')
        if source.name == "uart.cpp":
            text = replace(text, 'COMIEN_ETBEI_EN\n', 'COMIEN_ETBEI_DIS\n')
            text = replace(text, '\tfor (int i = 0; i < count; ++i) {\n\t\ttx_fifo[tx_fifo_back]',
                           '\tif (count) GP0SET_SET5_BBA = true; // RS485 transmit direction\n'
                           '\tfor (int i = 0; i < count; ++i) {\n'
                           '\t\twhile ((tx_fifo_back + 1) % SIZE(tx_fifo) == tx_fifo_front) { /* IRQ drains FIFO */ }\n'
                           '\t\ttx_fifo[tx_fifo_back]')
            text = replace(text, '\t\tassert(tx_fifo_back != tx_fifo_front); // overflow',
                           '\t\t__DMB();\n\t\tCOMIEN_ETBEI_BBA = true; // only ISR removes bytes from FIFO')
            text = replace(text, '\tif (COMLSR_TEMT_BBA) {\n\t\tchar c = tx_fifo[tx_fifo_front];\n\n'
                           '\t\tif (tx_fifo_front == SIZE(tx_fifo) - 1) {\n\t\t\ttx_fifo_front = 0;\n'
                           '\t\t} else {\n\t\t\t++tx_fifo_front;\n\t\t}\n\n'
                           '\t\tGP0SET_SET5_BBA = true; //change to send status\n\n\t\tpADI_UART->COMTX = c;\n\t}\n', '')
            text = replace(text, '\tif ((pADI_UART->COMIIR & COMIIR_STA_TXBUFEMPTY) == COMIIR_STA_TXBUFEMPTY) {',
                           '\tconst unsigned int irq = pADI_UART->COMIIR;\n'
                           '\tif (irq & COMIIR_NINT_MSK) return;\n'
                           '\tif ((irq & COMIIR_STA_MSK) == COMIIR_STA_TXBUFEMPTY) {')
            text = replace(text, '\t\t} else {\n\t\t\tapp msg;\n\t\t\tmsg.argc = 0;\n\t\t\tmsg.fun = tx_empty;',
                           '\t\t} else {\n\t\t\tCOMIEN_ETBEI_BBA = false;\n\t\t\tapp msg;\n\t\t\tmsg.argc = 0;\n\t\t\tmsg.fun = tx_empty;')
            text = replace(text, '\tif ((pADI_UART->COMIIR & COMIIR_STA_RXBUFFULL) == COMIIR_STA_RXBUFFULL) {',
                           '\tif ((irq & COMIIR_STA_MSK) == COMIIR_STA_RXLINESTATUS) { (void)pADI_UART->COMLSR; }\n'
                           '\tif ((irq & COMIIR_STA_MSK) == COMIIR_STA_RXBUFFULL) {\n'
                           '\t\tconst char received = pADI_UART->COMRX;')
            text = text.replace('= pADI_UART->COMRX;', '= received;')
            text = text.replace('const char received = received;', 'const char received = pADI_UART->COMRX;')
            text = text.replace("if (pADI_UART->COMRX == '\\n')", "if (received == '\\n')")
        if profile.startswith("freshwater"):
            text = freshwater_patch(source, text, lowheat=profile == "freshwater_lowheat")
        if text != original:
            source.write_text(text)
            path = source.relative_to(destination).as_posix()
            patches.extend(difflib.unified_diff(original.splitlines(True), text.splitlines(True),
                                               fromfile="vendor/" + path, tofile=profile + "/" + path))
    source = destination / "include/applications/message.h"
    original = source.read_text()
    text = replace(original, 'char **argv;', 'char **argv = nullptr;')
    source.write_text(text)
    patches.extend(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile="vendor/include/applications/message.h", tofile=profile + "/include/applications/message.h"))
    source = destination / "ld_script/gcc_arm.ld"
    original = source.read_text()
    text = replace(original, '*(.flash_disk)', 'KEEP(*(.flash_disk))')
    text = replace(text, '*(.bss*)', '*(SORT_BY_ALIGNMENT(.bss*))')
    source.write_text(text)
    patches.extend(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile="vendor/ld_script/gcc_arm.ld", tofile=profile + "/ld_script/gcc_arm.ld"))
    if profile.startswith("freshwater"):
        source = destination / "include/hal/drivers/flash.h"
        original = source.read_text()
        text = replace(original, 'float voltage = 1.f;', 'float voltage = 0.2f;')
        text = replace(text, 'float temp_coef = 2.f;', 'float temp_coef = 0.f; // Uncompensated kappa(T) until water coefficient is known.')
        source.write_text(text)
        patches.extend(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile="vendor/include/hal/drivers/flash.h", tofile="freshwater/include/hal/drivers/flash.h"))
        source = destination / "include/hal/drivers/adc.h"
        original = source.read_text()
        text = replace(original, 'unsigned long adc1_hit;', 'unsigned long adc1_hit;\n\tunsigned int signal_flags; // bit0 overload, bit1 weak signal at maximum gain')
        source.write_text(text)
        patches.extend(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile="vendor/include/hal/drivers/adc.h", tofile="freshwater/include/hal/drivers/adc.h"))
    (destination.parent / "porting.patch").write_text("".join(patches))


def freshwater_patch(source: Path, text: str, lowheat: bool = False) -> str:
    if source.name == "adc.cpp":
        text = '#include <cmath>\n' + text
        text = replace(text, 'IEXCDAT_IDAT_600uA | IEXCDAT_IDAT0_EN; //610uA',
                       ('IEXCDAT_IDAT_200uA | IEXCDAT_IDAT0_EN; // REQUIRES R13=4.99k; external VREF approximately 0.998V.' if lowheat else
                        'IEXCDAT_IDAT_400uA | IEXCDAT_IDAT0_EN; // 0.6V on R13=1.5k: above external VREF 0.4V minimum; validate self-heating.'))
        text = text.replace('result.temp = 25;', 'result.temp = NAN;')
        if lowheat:
            text = '#include "rtd_lowheat.h"\n' + text
            begin = text.index('\t\tif ((adc1_result >= 0x09d54f53')
            end = text.index('\n\t\tapp msg;', begin)
            text = text[:begin] + '''\t\t// Lowheat hardware: R13 must be 4.99k, not the original 1.5k.
\t\tconst float normalized = lowheat_rtd_normalized(adc1_result);
\t\tif (wire == 4 && normalized >= temp2res(-20.f) && normalized <= temp2res(120.f)) {
\t\t\tresult.temp = res2temp(normalized);
\t\t\tresult.rtd_type = 1000;
\t\t\tresult.wire_mode = 4;
\t\t\t++result.adc1_hit;
\t\t} else {
\t\t\tresult.temp = NAN;
\t\t\tresult.rtd_type = -1;
\t\t\tresult.wire_mode = -1;
\t\t}
''' + text[end:]
        text = replace(text, 'static adc_file result;', 'static adc_file result;\nstatic adc_file published_result;\nstatic unsigned int cycle_signal_flags;')
        text = replace(text, 'memcpy(buf, (char*) (&result) + position, count);',
                       'memcpy(buf, (char*) (&published_result) + position, count);')
        text = replace(text, '\tpwm_file pwm;\n\n\tswitch (adc0_cfg)',
                       '\tif (adc0_cfg == 0) cycle_signal_flags = 0;\n'
                       '\tif (abs(adc0_result) > (0x10000000 * 0.94)) cycle_signal_flags |= 1;\n'
                       '\tif (abs(adc0_result) < (0x10000000 * 0.088)) cycle_signal_flags |= 2;\n'
                       '\tpwm_file pwm;\n\n\tswitch (adc0_cfg)')
        text = replace(text, '\t++result.adc0_hit;\n\n\tapp msg;',
                       '\t++result.adc0_hit;\n'
                       '\tif (adc0_cfg != 0) return 0; // Publish only a complete +I,+V,-I,-V cycle.\n'
                       '\tresult.signal_flags = cycle_signal_flags;\n'
                       '\tpublished_result = result;\n\n\tapp msg;')
        text = replace(text, '\t\tapp msg;\n\t\tmsg.argc = 0;\n\t\tmsg.fun = on_rtd;',
                       '\t\tpublished_result.temp = result.temp;\n'
                       '\t\tpublished_result.rtd_type = result.rtd_type;\n'
                       '\t\tpublished_result.wire_mode = result.wire_mode;\n'
                       '\t\tpublished_result.adc1_hit = result.adc1_hit;\n'
                       '\t\tapp msg;\n\t\tmsg.argc = 0;\n\t\tmsg.fun = on_rtd;')
    if source.name == "cmd_poll.cpp":
        text = '#include "cmd_raw.h"\n#include <cmath>\n' + text
        text = replace(text, '\t\tfloat conductivity = (cell_const',
                       '\t\tif (!freshwater_valid(adc)) {\n'
                       '\t\t\tprintf("MEASUREMENT ERROR: valid four-wire Pt1000 and in-range signal required\\n");\n'
                       '\t\t\tfflush(stdout); return 0;\n\t\t}\n'
                       '\t\tfloat conductivity = (cell_const')
        text = replace(text, 'printf("conductivity: %eS/cm\\n\\n", conductivity);',
                       'printf("%s: %eS/cm\\n\\n", temp_coef == 0 ? "conductivity at measured T (uncompensated)" : "conductivity at 25C (linear model)", conductivity);')
    if source.name == "HomeDialog.cpp":
        text = '#include "cmd_raw.h"\n' + text
        text = replace(text, '\tif (!(isfinite(conductivity)',
                       '\tif (!freshwater_valid(adc)) conductivity = NAN;\n\tif (!(isfinite(conductivity)')
        text = replace(text, '\tif (rtd_wire == -1) {\n\t\tbeep(10);',
                       '\tif (!freshwater_valid(adc)) conductivity = NAN;\n\tif (rtd_wire == -1) {\n\t\tbeep(10);')
        text = replace(text, 'fputs("    use 25\\xf8" "C", p_lcd);', 'fputs("measurement off", p_lcd);')
        text = replace(text, 'fputs("Conductivity:", p_lcd);',
                       'flash_file setting;\n\trewind(p_flash);\n\tfread(&setting, sizeof(setting), 1, p_flash);\n'
                       '\tfputs(setting.temp_coef == 0 ? "k(T) no ATC:" : "k25(linear):", p_lcd);')
    return text


def run(command: list[str], log: Path) -> None:
    p = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.write_text("$ " + " ".join(command) + "\n" + p.stdout)
    if p.returncode:
        sys.stderr.write(p.stdout)
        raise RuntimeError(f"Failed ({p.returncode}), see {log}")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--profile", choices=("baseline", "freshwater", "freshwater_lowheat"), default="freshwater")
    p.add_argument("--cross-prefix", default="arm-none-eabi-")
    p.add_argument("--jobs", type=int, default=4)
    args = p.parse_args()
    prefix = args.cross_prefix
    if not shutil.which(prefix + "gcc"):
        local = Path("/workspace/toolchains/arm/usr/bin/arm-none-eabi-gcc")
        if prefix == "arm-none-eabi-" and local.exists():
            prefix = str(local).removesuffix("gcc")
        else:
            p.error("GNU Arm Embedded toolchain missing; set CROSS_COMPILE=/path/to/arm-none-eabi-")
    build = ROOT / "build" / args.profile
    generated = build / "src"
    build.mkdir(parents=True, exist_ok=True)
    patched_sources(generated, args.profile)
    flags = ["-mcpu=cortex-m3", "-mthumb", "-mfloat-abi=soft", "-Os", "-g3", "-ffunction-sections",
             "-fdata-sections", "-fno-common", "-fsigned-char", "-fno-strict-aliasing", "-fno-builtin",
             "-Wall", "-Wextra", "-Wno-unused-parameter", "-Wno-sign-compare", "-Wno-unused-variable",
             "-D__ADUCM360__", "-DCLK_TCK=100", "-D__STARTUP_CLEAR_BSS", "-D__START=firmware_start",
             "-D__STACK_SIZE=2048", "-D__HEAP_SIZE=0", "-D__DATE__=\"Oct 19 2026\"", "-D__TIME__=\"00:00:00\"",
             "-D__TIMESTAMP__=\"reproducible-build\"", "-Wno-builtin-macro-redefined", "--specs=nano.specs",
             "-I" + str(generated / "include"), "-I" + str(generated / "src/system/include/cmsis"),
             "-I" + str(ROOT / "port")]
    sources = sorted((generated / "src").rglob("*.cpp"))
    sources += [generated / "src/system/cmsis/system_ADuCM360.c",
                generated / "src/system/cmsis/startup_ADuCM360.S", ROOT / "port/runtime.c"]
    if args.profile.startswith("freshwater"):
        sources += [ROOT / "port/cmd_raw.cpp"]
    if args.profile == "freshwater_lowheat":
        flags += ["-DFRESHWATER_LOWHEAT=1"]
    objects = []
    commands = []
    for i, source in enumerate(sources):
        obj = build / "obj" / f"{i:03d}_{source.stem}.o"
        obj.parent.mkdir(parents=True, exist_ok=True)
        cxx = source.suffix == ".cpp"
        command = [prefix + ("g++" if cxx else "gcc"), *flags]
        if cxx:
            command += ["-std=gnu++11", "-fno-exceptions", "-fno-rtti", "-fno-threadsafe-statics", "-Wno-narrowing"]
        command += ["-c", str(source), "-o", str(obj)]
        commands.append((command, obj.with_suffix(".log")))
        objects.append(obj)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as executor:
        list(executor.map(lambda c: run(*c), commands))
    elf = build / ("cn0359_" + args.profile + ".elf")
    command = [prefix + "g++", "-mcpu=cortex-m3", "-mthumb", "-mfloat-abi=soft", "--specs=nano.specs",
               "-nostartfiles", "-T" + str(generated / "ld_script/gcc_arm.ld"), "-Wl,--gc-sections",
               "-Wl,-Map=" + str(elf.with_suffix(".map")), "-Wl,--print-memory-usage",
               "-Wl,-u,_printf_float", "-Wl,-u,_scanf_float", *map(str, objects),
               "-Wl,--start-group", "-lstdc++_nano", "-lsupc++_nano", "-lm", "-lc_nano", "-lgcc", "-lnosys",
               "-Wl,--end-group", "-o", str(elf)]
    run(command, build / "link.log")
    print((build / "link.log").read_text().split("\n", 1)[1], end="")
    for fmt, suffix in (("ihex", ".hex"), ("binary", ".bin")):
        run([prefix + "objcopy", "-O", fmt, str(elf), str(elf.with_suffix(suffix))], build / (suffix[1:] + ".log"))
    run([prefix + "size", str(elf)], build / "size.log")
    print((build / "size.log").read_text().split("\n", 1)[1], end="")
    manifest = {"profile": args.profile, "compiler": subprocess.check_output([prefix + "gcc", "--version"], text=True).splitlines()[0],
                "files": {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in [elf, elf.with_suffix(".hex"), elf.with_suffix(".bin")]},
                "vendor_tree_sha256": hashlib.sha256(b"".join(path.relative_to(VENDOR).as_posix().encode() + b"\0" + path.read_bytes()
                                                         for path in sorted(VENDOR.rglob("*")) if path.is_file())).hexdigest()}
    (build / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Built complete {args.profile} firmware: {elf}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
