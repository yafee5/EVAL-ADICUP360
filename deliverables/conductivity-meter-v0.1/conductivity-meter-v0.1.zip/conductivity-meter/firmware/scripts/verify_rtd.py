#!/usr/bin/env python3
"""Compile actual firmware RTD conversion and verify independent analog-model sweep."""
from pathlib import Path
import math
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    compiler = shutil.which("g++") or shutil.which("clang++")
    if compiler is None:
        raise SystemExit("A native C++ compiler is required for RTD mathematical validation")
    # Forward model uses physical parallel resistors; inverse is compiled directly
    # from the same header that the real ADuCM360 image includes.
    cases = []
    for n in range(501):
        t = n / 10
        rtd = 1000 * (1 + 3.9083e-3 * t - 5.775e-7 * t * t)
        loaded_rtd = 1 / (1 / rtd + 1 / 2e6)
        loaded_ref = 1 / (1 / 4990 + 1 / 2e6)
        code = round((loaded_rtd / loaded_ref) * 2**28)
        cases.append((t, rtd, code))
    with tempfile.TemporaryDirectory(prefix="cn0359-rtd-") as temp:
        temp = Path(temp)
        # Only the MCU register header is absent on the PC. The RTD implementation
        # uses no registers; this is a host math harness, never part of firmware.
        (temp / "ADuCM360.h").write_text("/* Host-only RTD math test. No peripheral API is used. */\n")
        bridge = temp / "verify.cpp"
        bridge.write_text('#include <cstdio>\n#include "rtd_lowheat.h"\n#include <hal/RTD.h>\n'
                          'int main(){unsigned int c; while(scanf("%u",&c)==1) '
                          'printf("%.9g %.9g\\n",(double)lowheat_rtd_normalized(c),'
                          '(double)res2temp(lowheat_rtd_normalized(c)));}\n')
        binary = temp / "verify"
        subprocess.run([compiler, "-std=c++11", "-O2", "-Wno-narrowing", "-I" + str(temp),
                        "-I" + str(ROOT / "port"), "-I" + str(ROOT / "vendor_cn0359_reva/include"),
                        str(ROOT / "vendor_cn0359_reva/src/hal/RTD.cpp"), str(bridge), "-o", str(binary)], check=True)
        result = subprocess.run([str(binary)], input="".join(f"{code}\n" for _, _, code in cases), text=True, capture_output=True, check=True)
        measured_pairs = [tuple(map(float, x.split())) for x in result.stdout.splitlines()]
        measured = [r for r, _ in measured_pairs]
    if len(measured) != len(cases):
        raise AssertionError("Compiled converter did not return every case")
    max_resistance_error = max(abs(actual * 1000 - r) for actual, (_, r, _) in zip(measured, cases))
    # Local dR/dT varies across temperature; this bounds temperature conversion
    # error caused by float arithmetic and ADC quantization, excluding RTD fit.
    max_temperature_error = max(abs(actual * 1000 - r) / (1000 * (3.9083e-3 - 2 * 5.775e-7 * t))
                                for actual, (t, r, _) in zip(measured, cases))
    if max_temperature_error > 0.0002:
        raise AssertionError(f"Lowheat RTD inverse/ADC rounding error {max_temperature_error} C")
    max_total_error = max(abs(measured_t - true_t) for (_, measured_t), (true_t, _, _) in zip(measured_pairs, cases))
    if max_total_error > 0.025:
        raise AssertionError(f"RTD rational approximation error {max_total_error} C")
    # Ignoring ADC loading would be materially wrong: show the test exercises it.
    uncorrected = max(abs((code / 2**28) * 4990 - r) for _, r, code in cases)
    if uncorrected < 1.0:
        raise AssertionError("ADC loading challenge did not exercise the correction")
    # External reference remains safely above the 400mV minimum, even -5% source.
    assert 200e-6 * 0.95 * (1 / (1 / 4990 + 1 / 2e6)) > 0.4
    print(f"PASS: 501 physical-model points, 0..50 C; max resistance error {max_resistance_error:.6g} ohm; "
          f"equivalent inverse error {max_temperature_error:.6g} C; ignored-loading error {uncorrected:.6g} ohm.")
    print(f"Actual ADI res2temp() polynomial included: max combined model/ADC/arithmetic error {max_total_error:.6g} C.")
    print("This validates calculation/quantization only; it is not hardware temperature accuracy or self-heating validation.")


if __name__ == "__main__":
    main()
