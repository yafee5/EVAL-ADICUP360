/* SPDX-License-Identifier: MIT
 * CN0359 low-heating hardware variant: R13=4990 ohms, Pt1000, 200 uA.
 * ADC gain=1, external reference is the voltage across R13. The ADI baseline
 * models unbuffered ADC loading as 2 Mohms across both RTD and reference.
 * x = ADC / 2^28 = (Rtd || Radc) / (Rref || Radc).
 * Inverse: Rtd = Rref*Radc*x / (Radc + Rref - Rref*x).
 * Rtd/R0 is returned, where R0=1000 ohms. No old 1.5k code thresholds apply.
 */
#ifndef CN0359_RTD_LOWHEAT_H
#define CN0359_RTD_LOWHEAT_H
static inline float lowheat_rtd_normalized(unsigned int code)
{
    const float x = (float)code / 268435456.0f;
    return (4990.0f * 2000000.0f * x) /
           ((2000000.0f + 4990.0f - 4990.0f * x) * 1000.0f);
}
#endif
