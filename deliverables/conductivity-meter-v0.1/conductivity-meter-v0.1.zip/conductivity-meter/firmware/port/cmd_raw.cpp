/* SPDX-License-Identifier: MIT
 * Machine-readable observations; no calibration constant or temperature model
 * is hidden in conductance_us. All physical analog acquisition remains ADI's.
 */
#include "cmd_raw.h"
#include <cmath>
#include <cstddef>
#include <cstdio>
#include <hal/devices.h>
#include <hal/drivers/flash.h>

bool freshwater_valid(const adc_file &adc)
{
    return adc.adc0_hit >= 4 && adc.adc1_hit > 0 && adc.rtd_type == 1000 &&
           adc.wire_mode == 4 && std::isfinite(adc.temp) && adc.signal_flags == 0 &&
           std::fabs(adc.p_volt - adc.n_volt) > 1e-6f &&
           std::isfinite((adc.p_curt - adc.n_curt) / (adc.p_volt - adc.n_volt)) &&
           (adc.p_curt - adc.n_curt) / (adc.p_volt - adc.n_volt) > 0;
}

int cmd_raw(int argc, char *argv[])
{
    (void)argv;
    if (argc != 1) { printf("ERROR,syntax=ADDRESS raw\n"); fflush(stdout); return 0; }
    adc_file adc;
    flash_file setting;
    rewind(p_adc);
    fread(&adc, sizeof(adc), 1, p_adc);
    rewind(p_flash);
    fread(&setting, sizeof(setting), 1, p_flash);
    const bool rtd_ok = adc.adc1_hit > 0 && adc.rtd_type == 1000 && adc.wire_mode == 4 && std::isfinite(adc.temp);
    const float dv = adc.p_volt - adc.n_volt;
    const float di = adc.p_curt - adc.n_curt;
    const float g = adc.adc0_hit >= 4 && std::fabs(dv) > 1e-6f ? 1e6f * di / dv : NAN;
    const float kappa = setting.cell_const * g;
    const char *status = "OK";
    if (!rtd_ok) status = "RTD_ERROR";
    else if (adc.signal_flags & 1) status = "OVERLOAD";
    else if (adc.signal_flags & 2) status = "LOW_SIGNAL";
    else if (!std::isfinite(g) || g <= 0) status = "SIGNAL_ERROR";
    else if (kappa < 10) status = "LOW_RANGE";
    else if (kappa > 2000) status = "HIGH_RANGE";
    printf("RAW,conductance_us=%.8g,temperature_c=%.6f,rtd_type=%d,rtd_wires=%d,"
           "adc0_hits=%lu,adc1_hits=%lu,status=%s,conductivity_us_cm=%.8g,alpha_pct_c=%.6g"
#ifdef FRESHWATER_LOWHEAT
           ",profile=freshwater_lowheat,reference_ohm=4990,iexc_ua=200"
#else
           ",profile=freshwater,reference_ohm=1500,iexc_ua=400"
#endif
           ",frequency_hz=%.8g,source_voltage_v=%.8g\n",
           static_cast<double>(g), static_cast<double>(rtd_ok ? adc.temp : NAN),
           adc.rtd_type, adc.wire_mode, adc.adc0_hit, adc.adc1_hit, status,
           static_cast<double>(freshwater_valid(adc) ? kappa : NAN), static_cast<double>(setting.temp_coef),
           static_cast<double>(setting.frequency), static_cast<double>(setting.voltage));
    fflush(stdout);
    return 0;
}
