/* SPDX-License-Identifier: MIT */
#ifndef FRESHWATER_CMD_RAW_H
#define FRESHWATER_CMD_RAW_H
#include <hal/drivers/adc.h>
int cmd_raw(int argc, char *argv[]);
bool freshwater_valid(const adc_file &adc);
#endif
