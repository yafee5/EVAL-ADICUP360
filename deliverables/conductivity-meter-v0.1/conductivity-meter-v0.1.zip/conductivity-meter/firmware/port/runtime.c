/* SPDX-License-Identifier: MIT
 * GNU/newlib runtime glue for the complete ADI CN0359 firmware.
 * Peripheral I/O is implemented by ADI's src/hal/syscalls.cpp, not stubbed here.
 */
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/stat.h>
#include <sys/types.h>

extern char __HeapBase, __StackLimit;
extern void __libc_init_array(void);
extern int main(void);
void *__dso_handle = &__dso_handle;

/* The supplied startup copies .data, clears .bss, and runs SystemInit first. */
void firmware_start(void)
{
    __libc_init_array();
    (void)main();
    for (;;) { __asm volatile("wfi"); }
}

void _init(void) {}
void _fini(void) {}

/* Heap grows only into RAM explicitly left below the reserved stack. */
void *_sbrk(ptrdiff_t increment)
{
    static char *end;
    if (!end) end = &__HeapBase;
    if ((increment > 0 && (size_t)increment > (size_t)(&__StackLimit - end)) ||
        (increment < 0 && (size_t)(-increment) > (size_t)(end - &__HeapBase))) {
        errno = ENOMEM;
        return (void *)-1;
    }
    char *previous = end;
    end += increment;
    return previous;
}

int _fstat(int fd, struct stat *st)
{
    (void)fd;
    st->st_mode = S_IFCHR;
    st->st_blksize = 64;
    return 0;
}

int _isatty(int fd) { (void)fd; return 1; }
int _close(int fd) { (void)fd; return 0; }
int _getpid(void) { return 1; }
int _kill(int pid, int sig) { (void)pid; (void)sig; errno = EINVAL; return -1; }
void _exit(int status) { (void)status; for (;;) { __asm volatile("wfi"); } }
