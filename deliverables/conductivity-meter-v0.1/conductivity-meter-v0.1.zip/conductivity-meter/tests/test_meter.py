import importlib.util
import csv
import json
import os
from pathlib import Path
import pty
import subprocess
import sys
import tempfile
import threading
import unittest

SPEC = importlib.util.spec_from_file_location("meter", Path(__file__).resolve().parents[1] / "scripts/meter.py")
meter = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(meter)
LINE = "RAW,conductance_us=1412.5,temperature_c=25,rtd_type=1000,rtd_wires=4,status=OK,conductivity_us_cm=1412.5,alpha_pct_c=0\n"
CONFIG = ",profile=freshwater_lowheat,reference_ohm=4990,iexc_ua=200,frequency_hz=100,source_voltage_v=0.2"


class MeterTests(unittest.TestCase):
    def test_raw_units(self):
        self.assertEqual(meter.parse_raw(LINE)["conductance_us"], 1412.5)

    def test_configuration_is_read_from_instrument(self):
        raw = meter.parse_raw(LINE.strip()+CONFIG)
        self.assertEqual(meter.measurement_profile(raw), ("freshwater_lowheat:V0.2:Rref4990:I200", 100))
        raw["reference_ohm"] = "1500"
        with self.assertRaises(meter.DataError):
            meter.measurement_profile(raw)

    def test_collected_csv_binds_configuration_and_certificate(self):
        raw = meter.parse_raw(LINE.strip()+CONFIG)
        metadata = dict(role="fit", session_id="real-session", reference_us_cm=1413,
                        reference_temperature_c=25, reference_uncertainty_pct=0.1,
                        certificate_id="TEST-ONLY", standard_id="TEST-ONLY")
        row = meter.make_sample(raw, metadata, 0, "test")
        self.assertEqual(row.profile, "freshwater_lowheat:V0.2:Rref4990:I200@100Hz")
        for extra in ({"range_id":"wrong"}, {"frequency_hz":300}, {"temperature_c":25}):
            with self.assertRaises(meter.DataError):
                meter.make_sample(raw, dict(metadata, **extra), 0, "test")

    def test_temperature_correction_is_bound_to_measurement_profile(self):
        from calibration.temperature import TemperatureSample, fit
        rows = [TemperatureSample(f"test-{i}", "fit", "synthetic", "test", t+0.1, t, 0.005)
                for i, t in enumerate([0,25,50])]
        model = fit(rows, allow_synthetic=True)
        raw = meter.parse_raw(LINE.strip()+CONFIG)
        corrected = meter.apply_temperature_calibration(raw, model, "TEST_DIGEST")
        self.assertAlmostEqual(corrected["temperature_c"], 24.9)
        self.assertEqual(corrected["raw_temperature_c"], 25)
        self.assertIn(":TcalTEST_DIGEST", meter.measurement_profile(corrected)[0])

    def test_cli_rejects_synthetic_temperature_model(self):
        root = Path(meter.__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as directory:
            model_path = Path(directory)/"temperature.json"
            fit_result = subprocess.run([sys.executable, str(root/"calibration/temperature.py"), "fit",
                                         str(root/"calibration/examples/synthetic_temperature_fit.csv"),
                                         "--allow-synthetic", "--output", str(model_path)],
                                        capture_output=True, text=True)
            self.assertEqual(fit_result.returncode, 0, fit_result.stderr)
            result = subprocess.run([sys.executable, str(Path(meter.__file__)), "decode",
                                     "--temperature-calibration", str(model_path)], input=LINE.strip()+CONFIG,
                                    capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("synthetic", result.stderr)

    def test_fault_not_valid_measurement(self):
        raw = meter.parse_raw(LINE.replace("status=OK", "status=RTD_ERROR").replace("temperature_c=25", "temperature_c=nan"))
        with self.assertRaises(meter.DataError):
            meter.make_sample(raw, {}, 0, "test")

    def test_reject_nan_or_wrong_rtd(self):
        for bad in (LINE.replace("1412.5", "nan"), LINE.replace("rtd_wires=4", "rtd_wires=2"),
                    LINE.replace("rtd_type=1000", "rtd_type=100"), LINE.strip()+",status=OK"):
            with self.assertRaises(meter.DataError):
                meter.parse_raw(bad)

    def test_posix_serial_request_and_fragmented_reply(self):
        master, slave = pty.openpty()
        received = []
        def simulator():
            request = b""
            while not request.endswith(b"\n"):
                request += os.read(master, 128)
            received.append(request)
            os.write(master, b"diagnostic\r\n" + LINE[:30].encode())
            os.write(master, LINE[30:].encode())
        try:
            with meter.Serial485(os.ttyname(slave), timeout=1) as serial:
                thread = threading.Thread(target=simulator, daemon=True)
                thread.start()
                raw = serial.raw(30)
                thread.join(timeout=1)
            self.assertEqual(received, [b"30 raw\n"])
            self.assertEqual(raw["status"], "OK")
        finally:
            os.close(master)
            os.close(slave)

    def test_timeout(self):
        master, slave = pty.openpty()
        try:
            with meter.Serial485(os.ttyname(slave), timeout=0.02) as serial:
                with self.assertRaises(meter.DataError):
                    serial.raw(30)
        finally:
            os.close(master)
            os.close(slave)

    def test_cli_collect_creates_calibration_csv_and_raw_log(self):
        master, slave = pty.openpty()
        def simulator():
            request = b""
            while not request.endswith(b"\n"):
                request += os.read(master, 128)
            os.write(master, (LINE.strip()+CONFIG+"\n").encode())
        try:
            with tempfile.TemporaryDirectory() as directory:
                target = Path(directory)
                metadata = dict(role="fit", session_id="TEST-ONLY", reference_us_cm=1413,
                                reference_temperature_c=25, reference_uncertainty_pct=0.1,
                                certificate_id="TEST-ONLY", standard_id="TEST-ONLY")
                (target/"metadata.json").write_text(json.dumps(metadata))
                thread = threading.Thread(target=simulator, daemon=True)
                thread.start()
                result = subprocess.run([sys.executable, str(Path(meter.__file__)), "collect",
                                         "--port", os.ttyname(slave), "--samples", "1",
                                         "--metadata", str(target/"metadata.json"),
                                         "--output", str(target/"point.csv")],
                                        capture_output=True, text=True, timeout=5)
                thread.join(timeout=1)
                self.assertEqual(result.returncode, 0, result.stderr)
                with (target/"point.csv").open() as stream:
                    rows = list(csv.DictReader(stream))
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["range_id"], "freshwater_lowheat:V0.2:Rref4990:I200")
                raw = json.loads((target/"point.csv.raw.jsonl").read_text())
                self.assertEqual(raw["raw"]["conductance_us"], 1412.5)
                self.assertEqual(raw["sample_id"], rows[0]["sample_id"])
        finally:
            os.close(master)
            os.close(slave)


if __name__ == "__main__":
    unittest.main()
