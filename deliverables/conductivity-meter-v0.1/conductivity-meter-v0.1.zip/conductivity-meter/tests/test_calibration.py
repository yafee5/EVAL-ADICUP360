"""Mathematical and input-safety tests; none of these are physical measurements."""
from dataclasses import replace
import csv
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from calibration.calibrate import (CSV_FIELDS, DataError, Sample, corrected, fit,
                                   read_csv, verify, validate_calibration)


def row(level, *, role="fit", index=0, gain=1.012, offset=0.0, origin="synthetic", **kwargs):
    sample = Sample(sample_id=f"{role}-{index}-{level}", role=role, origin=origin,
                    session_id=f"session-{role}", conductance_us=(level - offset) / gain,
                    temperature_c=25.0, reference_us_cm=float(level),
                    reference_temperature_c=25.0, reference_uncertainty_pct=0.10,
                    certificate_id="SYNTHETIC-not-a-certificate", standard_id=f"synthetic-{level}",
                    range_id="bench", frequency_hz=1000.0)
    return replace(sample, **kwargs)


def calibration_rows(**kwargs):
    return [row(level, **kwargs) for level in (10, 84, 500, 2000)]


class CalibrationTests(unittest.TestCase):
    def test_cell_fit_recovers_physical_constant(self):
        result = fit(calibration_rows(gain=1.012), allow_synthetic=True)
        self.assertAlmostEqual(result["gain_cm_inv"], 1.012, places=13)
        self.assertEqual(result["offset_us_cm"], 0.0)
        self.assertLess(result["fit_max_abs_error_pct"], 1e-10)
        self.assertEqual(result["evidence_status"], "synthetic_only_not_hardware_evidence")

    def test_affine_recovers_gain_and_offset(self):
        result = fit(calibration_rows(gain=0.994, offset=0.017), model="affine", allow_synthetic=True)
        self.assertAlmostEqual(result["gain_cm_inv"], 0.994, places=12)
        self.assertAlmostEqual(result["offset_us_cm"], 0.017, places=11)
        self.assertAlmostEqual(corrected(result, (100 - 0.017) / 0.994), 100)

    def test_relative_fit_does_not_ignore_low_level_error(self):
        rows = calibration_rows(gain=1.0)
        rows[0] = replace(rows[0], conductance_us=10.1)
        result = fit(rows, allow_synthetic=True)
        # An unweighted absolute fit would change K by only ~0.0000002.
        self.assertLess(result["gain_cm_inv"], 0.999)
        self.assertFalse(result["fit_raw_error_pass"])

    def test_synthetic_requires_opt_in(self):
        with self.assertRaisesRegex(DataError, "--allow-synthetic"):
            fit(calibration_rows())

    def test_real_and_synthetic_cannot_mix(self):
        rows = calibration_rows()
        rows[0] = replace(rows[0], origin="real")
        with self.assertRaisesRegex(DataError, "cannot be mixed"):
            fit(rows, allow_synthetic=True)

    def test_at_least_three_distinct_points(self):
        for rows in ([], calibration_rows()[:2], [row(84, index=i) for i in range(3)]):
            with self.subTest(rows=rows), self.assertRaises(DataError):
                fit(rows, allow_synthetic=True)

    def test_affine_rejects_singular_raw_conductance(self):
        rows = [replace(r, conductance_us=50.0) for r in calibration_rows()]
        with self.assertRaisesRegex(DataError, "singular"):
            fit(rows, model="affine", allow_synthetic=True)

    def test_wrong_conductance_units_rejected(self):
        rows = [replace(r, conductance_us=r.conductance_us * 1e-6) for r in calibration_rows()]
        with self.assertRaisesRegex(DataError, "nonphysical"):
            fit(rows, allow_synthetic=True)

    def test_rejects_all_nonfinite_numeric_measurements(self):
        for field in ("conductance_us", "temperature_c", "reference_us_cm", "reference_temperature_c",
                      "reference_uncertainty_pct", "frequency_hz"):
            for bad in (math.nan, math.inf, -math.inf):
                with self.subTest(field=field, bad=bad), self.assertRaises(DataError):
                    replace(row(84), **{field: bad}).validate()

    def test_rejects_invalid_temperature_and_wrong_reference_temperature(self):
        for kwargs in ({"temperature_c": -0.01}, {"temperature_c": 50.01},
                       {"temperature_c": 20, "reference_temperature_c": 25},
                       {"reference_temperature_c": 50.1}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                replace(row(84), **kwargs).validate()
        # A non-25 °C value IS accepted if both temperatures agree.
        replace(row(84), temperature_c=20, reference_temperature_c=20).validate()

    def test_out_of_device_range_rejected(self):
        for level in (0, 9.999, 2000.001):
            with self.subTest(level=level), self.assertRaises(DataError):
                row(level).validate()

    def test_invalid_zero_negative_and_string_metadata(self):
        for kwargs in ({"conductance_us": 0}, {"conductance_us": -1},
                       {"reference_uncertainty_pct": 0}, {"reference_uncertainty_pct": -0.1},
                       {"certificate_id": ""}, {"session_id": ""}, {"frequency_hz": 0},
                       {"role": "cal"}, {"origin": "measured?"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                replace(row(84), **kwargs).validate()

    def test_duplicate_sample_ids_rejected(self):
        rows = calibration_rows()
        rows[1] = replace(rows[1], sample_id=rows[0].sample_id)
        with self.assertRaisesRegex(DataError, "duplicate"):
            fit(rows, allow_synthetic=True)

    def test_independent_check_pass_and_level_coverage(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        checks = [row(level, role="verify") for level in (10, 20, 50, 84, 100, 500, 1000, 1413, 2000)]
        result = verify(model, checks, allow_synthetic=True, decision_uncertainty_pct=0.2)
        self.assertTrue(result["all_points_guardband_pass"])
        self.assertEqual(result["missing_recommended_levels_us_cm"], [])
        self.assertEqual(result["qualification_status"], "sampled_points_guardband_pass")
        self.assertIn("no continuous range", result["scope"])

    def test_missing_total_uncertainty_is_not_qualification(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        result = verify(model, [row(84, role="verify")], allow_synthetic=True)
        self.assertTrue(result["all_points_raw_error_pass"])
        self.assertIsNone(result["all_points_guardband_pass"])
        self.assertEqual(result["qualification_status"], "raw_errors_only_total_uncertainty_missing")
        self.assertIn(2000, result["missing_recommended_levels_us_cm"])

    def test_guardband_can_fail_a_raw_error_pass(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        check = row(100, role="verify")
        check = replace(check, conductance_us=check.conductance_us * 1.004)
        result = verify(model, [check], allow_synthetic=True, decision_uncertainty_pct=0.15)
        self.assertTrue(result["all_points_raw_error_pass"])
        self.assertFalse(result["all_points_guardband_pass"])

    def test_negative_reading_error_fails_symmetrically(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        check = row(100, role="verify")
        result = verify(model, [replace(check, conductance_us=check.conductance_us * 0.994)],
                        allow_synthetic=True, decision_uncertainty_pct=0.15)
        self.assertFalse(result["all_points_raw_error_pass"])
        self.assertFalse(result["all_points_guardband_pass"])

    def test_cannot_reuse_fit_id_or_measurement_session(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        for kwargs in ({"sample_id": model["fit_sample_ids"][0]},
                       {"session_id": model["fit_session_ids"][0]}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                verify(model, [row(84, role="verify", **kwargs)], allow_synthetic=True)

    def test_cannot_extrapolate_beyond_fitted_domain(self):
        rows = [row(level) for level in (84, 500, 1413)]
        model = fit(rows, allow_synthetic=True)
        with self.assertRaisesRegex(DataError, "extrapolation"):
            verify(model, [row(20, role="verify")], allow_synthetic=True)

    def test_unknown_range_or_frequency_rejected(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        for kwargs in ({"range_id": "unknown"}, {"frequency_hz": 500}):
            with self.subTest(kwargs=kwargs), self.assertRaisesRegex(DataError, "profile"):
                verify(model, [row(84, role="verify", **kwargs)], allow_synthetic=True)

    def test_inadequate_total_uncertainty_rejected(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        for uncertainty in (0, 0.05, 0.5, math.nan):
            with self.subTest(uncertainty=uncertainty), self.assertRaises(DataError):
                verify(model, [row(84, role="verify")], allow_synthetic=True,
                       decision_uncertainty_pct=uncertainty)

    def test_origin_must_match_model(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        with self.assertRaisesRegex(DataError, "origins differ"):
            verify(model, [row(84, role="verify", origin="real")], allow_synthetic=True)

    def test_corrupt_model_is_rejected(self):
        model = fit(calibration_rows(), allow_synthetic=True)
        for kwargs in ({"gain_cm_inv": math.nan}, {"offset_us_cm": math.inf},
                       {"offset_us_cm": 0.1}, {"gain_cm_inv": -1}, {"schema": "old"},
                       {"fit_reference_domain_us_cm": [0, 2000]}, {"profiles": []}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                validate_calibration({**model, **kwargs})

    def test_csv_rejects_extra_duplicate_and_ragged_columns(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.csv"
            for content in ("a,b\n1,2\n", "sample_id,sample_id\na,b\n",
                            ",".join(CSV_FIELDS) + "\na,b\n"):
                path.write_text(content)
                with self.subTest(content=content), self.assertRaises(DataError):
                    read_csv(path)

    def test_cli_end_to_end_and_failed_check_exit_code(self):
        fixture = ROOT / "calibration/examples/synthetic_measurements.csv"
        tool = ROOT / "calibration/calibrate.py"
        with tempfile.TemporaryDirectory() as directory:
            model_path, report_path = (Path(directory) / name for name in ("cal.json", "report.json"))
            a = subprocess.run([sys.executable, str(tool), "fit", str(fixture), "--allow-synthetic",
                                "--output", str(model_path)], capture_output=True, text=True)
            self.assertEqual(a.returncode, 0, a.stderr)
            b = subprocess.run([sys.executable, str(tool), "verify", str(model_path), str(fixture),
                                "--allow-synthetic", "--decision-uncertainty-pct", "0.2",
                                "--output", str(report_path)], capture_output=True, text=True)
            self.assertEqual(b.returncode, 0, b.stderr)
            self.assertTrue(json.loads(report_path.read_text())["all_points_guardband_pass"])
            # Move one independent point by 1 %; the command must produce a failed report and exit 2.
            modified = Path(directory) / "failed.csv"
            with fixture.open(newline="") as stream:
                records = list(csv.DictReader(stream))
            for record in records:
                if record["role"] == "verify":
                    record["conductance_us"] = str(float(record["conductance_us"]) * 1.01)
                    break
            with modified.open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS)
                writer.writeheader()
                writer.writerows(records)
            c = subprocess.run([sys.executable, str(tool), "verify", str(model_path), str(modified),
                                "--allow-synthetic", "--decision-uncertainty-pct", "0.2",
                                "--output", str(report_path)], capture_output=True, text=True)
            self.assertEqual(c.returncode, 2, c.stderr)
            self.assertFalse(json.loads(report_path.read_text())["all_points_raw_error_pass"])


if __name__ == "__main__":
    unittest.main()
