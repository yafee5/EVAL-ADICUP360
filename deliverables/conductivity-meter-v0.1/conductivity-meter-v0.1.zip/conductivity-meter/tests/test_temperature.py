"""Temperature math/independence tests, not physical calibration evidence."""
import csv
from dataclasses import replace
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from calibration.temperature import (CSV_FIELDS, DataError, TemperatureSample, correct_temperature,
                                     fit, read_csv, validate_model, verify)


def sample(level, role="fit", **kwargs):
    row = TemperatureSample(f"SYNTHETIC-T-{role}-{level}", role, "synthetic", f"T-session-{role}",
                            (level - .04) / 1.0008, float(level), .005)
    return replace(row, **kwargs)


def fits():
    return [sample(level) for level in (0, 25, 50)]


class TemperatureTests(unittest.TestCase):
    def test_recovers_known_gain_offset(self):
        model = fit(fits(), allow_synthetic=True)
        self.assertAlmostEqual(model["gain"], 1.0008, places=13)
        self.assertAlmostEqual(model["offset_c"], .04, places=12)
        self.assertAlmostEqual(correct_temperature(model, (12.5 - .04) / 1.0008), 12.5)
        self.assertEqual(model["application"], "host_only_not_instrument_flash")

    def test_independent_guardband_pass(self):
        model = fit(fits(), allow_synthetic=True)
        report = verify(model, [sample(v, "verify") for v in (12.5, 37.5)],
                        allow_synthetic=True, decision_uncertainty_c=.01)
        self.assertTrue(report["all_points_guardband_pass"])
        self.assertEqual(report["missing_recommended_intermediate_checks_c"], [])
        self.assertEqual(report["evidence_status"], "synthetic_only_not_hardware_evidence")

    def test_03_fails_but_05_passes(self):
        model = fit(fits(), allow_synthetic=True)
        point = sample(12.5, "verify")
        point = replace(point, measured_temperature_c=point.measured_temperature_c + .04 / model["gain"])
        strict = verify(model, [point], allow_synthetic=True, limit_c=.03, decision_uncertainty_c=.005)
        initial = verify(model, [point], allow_synthetic=True, limit_c=.05, decision_uncertainty_c=.005)
        self.assertFalse(strict["all_points_guardband_pass"])
        self.assertTrue(initial["all_points_guardband_pass"])

    def test_uncertainty_is_required_for_qualification(self):
        report = verify(fit(fits(), allow_synthetic=True), [sample(12.5, "verify")], allow_synthetic=True)
        self.assertIsNone(report["all_points_guardband_pass"])
        self.assertEqual(report["qualification_status"], "raw_errors_only_total_uncertainty_missing")

    def test_guardband_can_fail_good_raw_error(self):
        model = fit(fits(), allow_synthetic=True)
        point = sample(12.5, "verify")
        point = replace(point, measured_temperature_c=point.measured_temperature_c + .025 / model["gain"])
        report = verify(model, [point], allow_synthetic=True, decision_uncertainty_c=.01)
        self.assertTrue(report["all_points_raw_error_pass"])
        self.assertFalse(report["all_points_guardband_pass"])

    def test_nonfinite_fields_rejected(self):
        for name in ("measured_temperature_c", "reference_temperature_c", "reference_uncertainty_c"):
            for value in (math.nan, math.inf, -math.inf):
                with self.subTest(name=name, value=value), self.assertRaises(DataError):
                    replace(sample(25), **{name:value}).validate()

    def test_invalid_input_values_rejected(self):
        for kwargs in ({"measured_temperature_c":-5.01}, {"measured_temperature_c":55.01},
                       {"reference_temperature_c":-0.001}, {"reference_temperature_c":50.001},
                       {"reference_uncertainty_c":0}, {"session_id":""}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                replace(sample(25), **kwargs).validate()

    def test_fit_requires_0_25_50_and_separated_raw_data(self):
        for rows in (fits()[:2], [sample(v) for v in (5,25,45)],
                     [replace(r,measured_temperature_c=25) for r in fits()]):
            with self.subTest(rows=rows), self.assertRaises(DataError):
                fit(rows, allow_synthetic=True)

    def test_no_synthetic_without_opt_in_and_no_mixing(self):
        with self.assertRaises(DataError):
            fit(fits())
        rows=fits()
        rows[0]=replace(rows[0], origin="real")
        with self.assertRaises(DataError):
            fit(rows,allow_synthetic=True)

    def test_reused_fit_session_or_id_rejected(self):
        model=fit(fits(),allow_synthetic=True)
        for kwargs in ({"session_id":model["fit_session_ids"][0]}, {"sample_id":model["fit_sample_ids"][0]}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                verify(model,[sample(12.5,"verify",**kwargs)],allow_synthetic=True)

    def test_reference_uncertainty_cannot_exceed_total(self):
        model=fit(fits(),allow_synthetic=True)
        with self.assertRaises(DataError):
            verify(model,[sample(12.5,"verify")],allow_synthetic=True,decision_uncertainty_c=.001)

    def test_corrupt_model_rejected(self):
        model=fit(fits(),allow_synthetic=True)
        for kwargs in ({"gain":math.nan}, {"offset_c":math.inf}, {"gain":-1},
                       {"origin":"other"}, {"fit_domain_c":[5,45]}, {"fit_session_ids":[]}):
            with self.subTest(kwargs=kwargs), self.assertRaises(DataError):
                validate_model({**model,**kwargs})

    def test_endpoint_correction_preserves_errors_without_clipping(self):
        model=fit(fits(),allow_synthetic=True)
        self.assertLess(correct_temperature(model, model["fit_raw_domain_c"][0]-.002),0)
        self.assertAlmostEqual(correct_temperature(model,model["fit_raw_domain_c"][0]),0,places=11)

    def test_cli_example(self):
        tool=ROOT/"calibration/temperature.py"
        with tempfile.TemporaryDirectory() as directory:
            model,report=[Path(directory)/name for name in ("t.json","report.json")]
            command=[sys.executable,str(tool),"fit",str(ROOT/"calibration/examples/synthetic_temperature_fit.csv"),
                     "--allow-synthetic","--output",str(model)]
            result=subprocess.run(command,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            command=[sys.executable,str(tool),"verify",str(model),
                     str(ROOT/"calibration/examples/synthetic_temperature_verify.csv"),
                     "--allow-synthetic","--decision-uncertainty-c","0.01","--output",str(report)]
            result=subprocess.run(command,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertTrue(json.loads(report.read_text())["all_points_guardband_pass"])

    def test_csv_rejects_bad_columns_and_duplicate_samples(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/"x.csv"
            path.write_text("a,b\n1,2\n")
            with self.assertRaises(DataError):
                read_csv(path)
            rows=fits()
            rows[1]=replace(rows[1],sample_id=rows[0].sample_id)
            with self.assertRaises(DataError):
                fit(rows,allow_synthetic=True)

if __name__=="__main__":
    unittest.main()
