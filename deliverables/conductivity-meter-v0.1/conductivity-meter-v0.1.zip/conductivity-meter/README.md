# 淡水电导率／温度仪：第一版工程包

本工程面向 **10–2000 µS/cm、误差目标 ±0.5% 读数**，测量电导率和水温。采用 ADI CN0359 的参考测量电路、ADuCM360 原厂固件和独立校准工具。项目交付的是可审阅的原型设计及软件；尚未连接实物，不能把软件测试或 ADI 电阻试验结果当作本整机精度认证。

## 先看这几个文件

| 内容 | 文件 |
|---|---|
| 电路、探头与电源接线、器件要求 | [docs/hardware.md](docs/hardware.md) |
| 固件构建、烧录、串口指令及原厂差异 | [docs/firmware.md](docs/firmware.md) |
| 量程、误差预算、标准液校准与验收 | [docs/calibration.md](docs/calibration.md) |
| CN0349 / CN0359 / CN0565 / CN0510 资料对比与出处 | [docs/sources.md](docs/sources.md) |
| 串口采集与校准工作流 | [docs/acquisition.md](docs/acquisition.md) |
| 实际执行的构建／测试记录 | [docs/validation.md](docs/validation.md) |

## 已确定的设计条件

- 测量对象：淡水；10–2000 µS/cm，0–50 °C 为工程工作范围。全温区精度仍须按验收矩阵验证。
- 电导率探头：两极、标称 K≈1.0 cm⁻¹；优先短线 ≤1 m，电极、最终电缆、接插件作为整体校准。
- 温度探头：独立四线 Pt1000，IEC 60751；等级、激励自热、封装响应与校准必须一并考虑。
- 测量板：ADI EVAL-CN0359-EB1Z 对应的参考电路。**EVAL-ADICUP360 开发板本身不含这套模拟前端，不能仅下载固件就接水样。** 新旧 CN0359 电路版本不同，实际采购／复制前必须核对版本。
- 首版淡水固件：低幅值交流激励、零温补系数默认值、RTD 故障检查、独立原始电导数据命令。原板版保留 R13=1.5 kΩ；低自热版必须把 R13 换为 4.99 kΩ 精密电阻，同时使用对应固件；具体设置与修改见固件说明。
- 默认输出实际水温下的 κ(T)。输出 κ25 需要已知并验证过的温补模型，不能对任意淡水固定套用 2%/°C 后保证 ±0.5%。

目标 ±0.5% 读数在 10 µS/cm 对应 ±0.05 µS/cm，在 2000 µS/cm 对应 ±10 µS/cm。不能用 ±0.5% 满量程（±10 µS/cm）替代低端要求。

## 软件快速开始

在本云环境中：

```bash
cd /workspace/conductivity-meter
bash scripts/setup_environment.sh
```

脚本使用签名验证的 Debian 包准备 GNU Arm 工具链，保留原仓库不变，并执行固件构建与主机测试。工具链位于 `/workspace/toolchains/arm`，不是工程 ZIP 的组成部分。下载需要 `deb.debian.org`。也可以使用本机已有的 GNU Arm Embedded GCC：

```bash
make -C firmware freshwater
make -C firmware baseline
make -C firmware freshwater_lowheat
python3 -m unittest discover -s tests -v
```

固件输出位于 `firmware/build/<profile>/`。请阅读烧录说明后选择对应电路版本。`baseline` 保留原厂测量行为作为对照；`freshwater` 对应未改 R13 的原板；`freshwater_lowheat` 对应 R13=4.99 kΩ 的低自热改板。低自热版用于冲刺温度误差预算，**不可把固件刷到 R13=1.5 kΩ 的未改板上**。三者均需实体板验证。

## 校准工具演示

以下 CSV 是明确标记为 synthetic 的数学演示，不是实物测量：

```bash
python3 calibration/calibrate.py fit calibration/examples/synthetic_fit.csv \
  --allow-synthetic --output /tmp/demo-calibration.json
python3 calibration/calibrate.py verify /tmp/demo-calibration.json \
  calibration/examples/synthetic_verify.csv --allow-synthetic \
  --decision-uncertainty-pct 0.15 --output /tmp/demo-verification.json
```

真实验收必须使用标准液证书在**实际温度**下的电导率，使用不同批次／独立测量会话复核；详见校准文档。拟合得到的零偏电极常数可用固件的 `setk` 命令写入；带偏置的仿射修正由主机应用，不得误称原厂固件支持偏置项。

## 从工程包到实物

1. 按硬件文档采购测量板、K≈1 探头、四线 Pt1000、供电和自动收发 USB–RS485；确认测量板电路版本与固件。
2. 未接水样时检查电源、交流幅值／频率／直流分量，完成精密电阻替代电导池测试。
3. 完成温度链校准及自热测试，再用有证标准液校准最终探头和线缆。
4. 按独立量程点、温度点、线缆与频率扫描验收，满足含不确定度的判定规则后再声明 ±0.5%。

本包不包含已投产的 PCB 布局、Gerber、外壳防水验证或工厂校准证书。电路图来源、可编辑转接图与尚未取得的制造资料在硬件文档分别注明。

## 版权与来源

`firmware/vendor_cn0359_reva` 保留 ADI 原文件与版权声明。ADI 软件许可包含必须运行在或直接连接到 ADI 器件的条件；使用及再分发须遵循原文件许可。参考 PDF 及其图纸归各原作者，随工程包保留出处。新增工程脚本及文档是本次原型交付内容。
