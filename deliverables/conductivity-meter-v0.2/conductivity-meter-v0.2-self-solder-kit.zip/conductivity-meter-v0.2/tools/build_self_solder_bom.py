#!/usr/bin/env python3
"""Make a reviewable self-solder BOM without changing official manufacturing files."""
from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "assembly"
OUT.mkdir(exist_ok=True)
SOURCE = BASE / "sources" / "official_bom_reva_expanded.csv"
FIELDS = ["板件", "原位号", "采购子项", "数量", "原值", "装配值", "封装", "原厂商", "原MPN", "采购MPN或选型方式", "推荐采购规格", "装配状态", "备注", "自焊难点", "来源"]
PRECISION_RATIOS = {"R19", "R20", "R29", "R31", "R37", "R38", "R48", "R52"}
NEW_DNP = {"U4", "L2", "D3", "C17"}


def base_row(src: dict[str, str]) -> dict[str, object]:
    ref = src["reference"]
    status = "不装(DNP)" if src["population"] == "DNP" else "装"
    val = src["value"] or src["manufacturer_part_number"] or "按原图"
    row: dict[str, object] = {
        "板件": "CN0359 Rev.A主板", "原位号": ref, "采购子项": "", "数量": 1,
        "原值": src["value"], "装配值": val, "封装": src["package"],
        "原厂商": src["manufacturer"], "原MPN": src["manufacturer_part_number"],
        "采购MPN或选型方式": src["manufacturer_part_number"] or "按原图采购",
        "推荐采购规格": "保持原BOM数值、封装与额定参数；原MPN的供货状态需采购时核实。",
        "装配状态": status, "备注": "原ADI Rev.A BOM原件保留。", "自焊难点": "",
        "来源": "sources/official_bom_reva_expanded.csv；官方Rev.A完整原理图",
    }
    if ref.startswith(("C", "R")):
        row["自焊难点"] = "0805可手焊；精密模拟输入区域焊后彻底清洁、干燥，避免助焊剂泄漏。"
    elif ref.startswith("U"):
        row["自焊难点"] = "核对完整订购后缀和pin1；按官方封装焊接并放大检查。"
    elif ref.startswith("L"):
        row["自焊难点"] = "核对电感/EMI滤波器方向、实际尺寸、额定电流和焊盘。"
    elif ref.startswith(("D", "Q")):
        row["自焊难点"] = "核对极性及pin1；BAT54S是双二极管，不能用单二极管代替。" if src["manufacturer_part_number"] == "BAT54S" else "核对极性、针序和外形；相似SOT/SOD外形不代表针序相同。"
    elif ref.startswith("J"):
        row["自焊难点"] = "核对针距、安装方向和壳体外形；避免焊锡堵塞端子。"

    if status == "不装(DNP)":
        row.update({"数量": 0, "装配值": "DNP", "采购MPN或选型方式": "无需采购", "备注": "原ADI BOM已标DNP，保留空焊盘。"})
    if ref in NEW_DNP:
        row.update({"数量": 0, "装配值": "DNP", "采购MPN或选型方式": "本版不采购", "装配状态": "不装(DNP)", "备注": "电源ECO：停用原板ADP2300降压支路，改外接3.3V线性稳压小板；不得桥接L2或同时恢复U4。"})
    if ref == "R13":
        row.update({"装配值": "4.99kΩ", "采购MPN或选型方式": "参数选型/询价，未指定已核实MPN", "推荐采购规格": "0805；4.99kΩ；初始容差≤0.01%；TCR绝对值≤2ppm/°C；额定功率≥0.1W；索取准确值、TCR及批次记录。", "备注": "必改：原1.50k/原MPN不满足本版改值与升级规格，禁止按原MPN下单冒充升级件；配freshwater_lowheat固件及200µA RTD激励。"})
    elif ref == "R47":
        row.update({"装配值": "1.00kΩ", "采购MPN或选型方式": "参数选型/询价，未指定已核实MPN", "推荐采购规格": "0805；1.00kΩ；初始容差≤0.01%；TCR优选≤2ppm/°C，采用≤5ppm件须重新核算环境温漂并实测；额定功率≥0.1W；不得改变焊盘或阻值。", "备注": "必改精度等级，阻值保持1k；原MPN仅供追溯，不作为满足升级规格的推荐件。"})
    elif ref in PRECISION_RATIOS:
        row.update({"采购MPN或选型方式": "参数选型/询价，未指定已核实MPN", "推荐采购规格": f"0805；保持{src['value']}原值；初始容差≤0.01%；TCR优选≤2ppm/°C，≤5ppm替代须验证温漂；额定功率≥0.1W；优先同系列/同批次并记录实测匹配。", "备注": "优选升级：四路衰减比例电阻，数值和0805焊盘保持；原MPN不被声称满足新精度/TCR要求。若降级使用原BOM，必须另记录并重新核算/验证误差预算。"})
    elif ref in {"R24","R27"}:
        row.update({"采购MPN或选型方式":"参数选型/询价，未指定已核实MPN", "推荐采购规格":"0805；27.0kΩ；两只同系列，≤0.01%，TCR优选≤2ppm/°C、最多5ppm/°C并实测匹配；保持原尺寸和阻值。", "备注":"可选交流正负幅值对称性升级；最终仍须示波器检查电极直流分量。"})
    elif ref in {"R49", "R50"}:
        row.update({"采购MPN或选型方式": "原MPN或经核实的同封装1%备选", "推荐采购规格": "0805；10kΩ；原件可用，建议两只均升级为≤1%、同系列、TCR≤100ppm/°C，功率≥0.1W。", "备注": "可选VMID分压余量升级；原MPN保留，但原件不冒充1%件。两只同规格采购，装配方案和VMID实测写入记录。"})
    elif ref in {"R21", "R32", "R39", "R53"}:
        row["备注"] = "保持完整官方原图/BOM的24Ω；不要按文章简图误买240Ω。"
    elif ref in {"C50", "C73", "C84", "C93"}:
        row["备注"] = "采样保持4.7µF，保持原件及其额定电压/介质；不得为滤波或冗余随意加大/减小。"
    elif ref == "U8":
        row["自焊难点"] = "最高难度：7×7mm、0.5mm间距LFCSP，底部EP必须焊接接地；需钢网+锡膏+受控热风/回流和检查，单靠烙铁无法保证EP。"
        row["备注"] = "完整型号ADuCM360BCPZ128；底部焊盘不可省略；可单独委托芯片焊接后再自行完成其余器件。"
    elif ref in {"U11", "U12", "U20"}:
        row["自焊难点"] = "MSOP8、0.65mm间距，需助焊剂/放大与桥连检查；不能直接换SOIC或LFCSP。"
    elif ref in {"U15", "U18", "U6"}:
        row["自焊难点"] = "MSOP10、0.5mm间距，需放大/拖焊；检查相邻脚短路和pin1；不能跨封装代换。"
    elif ref == "U17":
        row["自焊难点"] = "TSSOP16、0.65mm间距；ADG1211低有效，不能买成1212/1213或LFCSP。"
    elif ref == "L5":
        row["备注"] = "保留原3.3V EMI滤波器；子板+3.3V接其pin1(B)前端，pin2为滤后3.3V；必须按接线图确认。"
    elif ref.startswith("X"):
        row.update({"数量": 0, "装配值": "PCB特征", "采购MPN或选型方式": "无需电子元件采购", "推荐采购规格": "保留原Gerber中的PAD3MM特征；安装/固定件按实板孔位与机壳选配。", "装配状态": "PCB特征/不另贴装", "备注": "原BOM没有独立制造商料号；不得虚构电子元件。", "自焊难点": "无需贴装电子元件；检查与机壳的间隙。"})
    return row


def split_mechanical(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    result = []
    for row in rows:
        if row["原位号"] == "U1":
            lcd = row.copy()
            lcd.update({"采购子项": "LCD显示模块", "原厂商": "BATRON", "原MPN": "BTHQ128064AVC1-COG-STF-LED", "装配值": "128×64 LCD，原厂指定模块", "采购MPN或选型方式": "BTHQ128064AVC1-COG-STF-LED", "推荐采购规格": "按原LCD型号及接口/控制器采购，提供现行数据表核对外形、接触方向、背光与针脚；缺货时不能只按12864名称替代。", "备注": "原BOM逗号分隔的第一项；与下行连接器是两种不同物料，不是替代型号。", "自焊难点": "玻璃/柔性排线易损；核对接触方向，勿在玻璃或排线上过热。"})
            connector = row.copy()
            connector.update({"采购子项": "LCD板端连接器", "原厂商": "WURTH ELEKTRONIK", "原MPN": "68612214122", "装配值": "LCD匹配板端连接器", "封装": "原U1接口焊盘；按原件外形", "采购MPN或选型方式": "68612214122", "推荐采购规格": "与原LCD和Gerber匹配；采购前核对针距、触点方向、安装高度及锁扣，不能用外观相近连接器替换。", "备注": "原BOM逗号分隔的第二项；LCD模块和该连接器各采购1件。", "自焊难点": "细间距连接器；避免焊锡进锁扣/触点，保护塑料壳。"})
            result.extend([lcd, connector])
        elif row["原位号"] == "S1":
            encoder = row.copy()
            encoder.update({"采购子项": "旋转编码器", "原厂商": "BOURNS", "原MPN": "PEC12R-4120F-S0012", "装配值": "带按压开关旋转编码器", "采购MPN或选型方式": "PEC12R-4120F-S0012", "推荐采购规格": "保持完整订购型号、引脚排列、轴型、轴长及脉冲/定位特性；不能按PCB封装标注PEC11R-S猜替代料。", "备注": "原BOM第一项，编码器本体；与旋钮分别采购。", "自焊难点": "通孔可手焊；大固定脚吸热较强，注意机械垂直。"})
            knob = row.copy()
            knob.update({"采购子项": "编码器旋钮", "原厂商": "MENTOR", "原MPN": "506.61", "装配值": "匹配编码器轴的旋钮", "封装": "机械件/不焊接", "采购MPN或选型方式": "506.61", "推荐采购规格": "采购前核对轴孔、轴型与外径/高度；机械外观替换须保持轴配合和面板间隙。", "备注": "原BOM第二项，机械旋钮；不是编码器替代料。", "自焊难点": "无需焊接；避免压装时损伤编码器轴。"})
            result.extend([encoder, knob])
        else:
            result.append(row)
    return result


def save_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)


def make_sheet(book: Workbook, name: str, rows: list[dict[str, object]]) -> None:
    sheet = book.create_sheet(name)
    sheet.append(FIELDS)
    for row in rows:
        sheet.append([row.get(k, "") for k in FIELDS])
    sheet.freeze_panes = "D2"
    sheet.auto_filter.ref = sheet.dimensions
    widths = [24, 14, 24, 8, 15, 34, 30, 26, 40, 40, 70, 22, 85, 70, 50]
    for i, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(i)].width = width
    for cell in sheet[1]:
        cell.font = Font(color="FFFFFF", bold=True)
        cell.fill = PatternFill("solid", fgColor="1D4F73")
        cell.alignment = Alignment(vertical="top", wrap_text=True)
    for cells in sheet.iter_rows(min_row=2):
        for cell in cells:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        state = cells[FIELDS.index("装配状态")].value
        ref = cells[FIELDS.index("原位号")].value
        color = "EEEEEE" if "DNP" in str(state) else "FFF2CC" if ref == "R13" or ref == "R47" or ref in PRECISION_RATIOS else None
        if color:
            for cell in cells:
                cell.fill = PatternFill("solid", fgColor=color)
    sheet.print_options.horizontalCentered = False
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.paperSize = sheet.PAPERSIZE_A3
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.print_title_rows = "1:1"


def main() -> None:
    source = list(csv.DictReader(SOURCE.open(encoding="utf-8-sig")))
    assert len({r["reference"] for r in source}) == len(source)
    main_rows = split_mechanical([base_row(row) for row in source])
    # The adapter designer supplies Chinese-column rows using the same schema.
    adapter_path = OUT / "power_adapter_procurement.json"
    adapter_rows = json.loads(adapter_path.read_text()) if adapter_path.exists() else []
    all_rows = main_rows + adapter_rows
    save_csv(OUT / "self_solder_bom.csv", all_rows)
    book = Workbook()
    del book[book.sheetnames[0]]
    make_sheet(book, "自焊总BOM", all_rows)
    make_sheet(book, "主板", main_rows)
    if adapter_rows:
        make_sheet(book, "3V3电源子板", adapter_rows)
    make_sheet(book, "DNP与PCB特征", [r for r in all_rows if r["装配状态"] != "装"])
    book.save(OUT / "self_solder_bom.xlsx")
    print(json.dumps({"source_positions": len(source), "main_procurement_rows_after_splitting": len(main_rows), "adapter_rows": len(adapter_rows), "total_rows": len(all_rows), "status_counts": dict(Counter(r['装配状态'] for r in all_rows))}, ensure_ascii=False))


if __name__ == "__main__":
    main()
