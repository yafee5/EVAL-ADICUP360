#!/usr/bin/env python3
"""Package two independent board CAM archives plus the self-solder project."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
PROJECT=Path('/workspace/conductivity-meter')
OUT=ROOT/'deliverables'
OUT.mkdir(exist_ok=True)

def archive_files(output,files):
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for source,target in files:z.write(source,target)
    with zipfile.ZipFile(output) as z:assert z.testzip() is None

main=OUT/'CN0359_mainboard_4layer_Gerber_v02.zip'
archive_files(main,[(p,p.name) for p in sorted((ROOT/'manufacturer/mainboard_4layer/checked_cam').iterdir()) if p.is_file()])
power=OUT/'CN0359_power_adapter_2layer_Gerber_v02.zip'
archive_files(power,[(p,p.name) for p in sorted((ROOT/'power_adapter/manufacturer').iterdir())
                    if p.is_file() and p.suffix.lower() not in {'.pdf','.gbrjob'}])
factory=OUT/'conductivity-meter-v0.2-factory-only.zip'
archive_files(factory,[(main,main.name),(power,power.name),
                      (ROOT/'manufacturer/发厂家_裸板要求.md','README_发厂家_只做裸板.md'),
                      (ROOT/'schematics/mainboard_revA_lowheat_eco.pdf','主板完整电路_ECO.pdf'),
                      (ROOT/'power_adapter/cn0359_ldo_adapter.pdf','电源小板电路.pdf')])

payload={}
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if rel.parts[0]=='deliverables' or '__pycache__' in rel.parts:continue
    if p.suffix in {'.pyc','.kicad_prl'} or p.name.startswith('core'):continue
    if rel.parts[:3]==('manufacturer','mainboard_4layer','gerbers'):continue
    payload[rel.as_posix()]=p.read_bytes()
payload['完整电路与自焊说明_v0.2.pdf']=(OUT/'conductivity-meter-v0.2-schematics-and-build.pdf').read_bytes()
payload['发厂家裸板包.zip']=factory.read_bytes()
for p in sorted((PROJECT/'firmware').rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(PROJECT/'firmware')
    if '__pycache__' in rel.parts or p.suffix=='.pyc':continue
    if rel.parts[0]=='build':
        if len(rel.parts)<3 or rel.parts[1]!='freshwater_lowheat':continue
        if rel.parts[2] in {'obj','src'}:continue
    data=p.read_bytes()
    if rel.as_posix()=='Makefile':
        data=data.replace(b'PROFILE ?= freshwater\n',b'PROFILE ?= freshwater_lowheat\n')
    payload['firmware/'+rel.as_posix()]=data
for group in ['calibration','tests']:
    for p in sorted((PROJECT/group).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
            payload[group+'/'+p.relative_to(PROJECT/group).as_posix()]=p.read_bytes()
payload['scripts/meter.py']=(PROJECT/'scripts/meter.py').read_bytes()
payload['电导与温度校准说明.md']=(PROJECT/'docs/calibration.md').read_bytes()
manifest={'version':'0.2-self-solder-prototype','date':'2026-10-20',
          'hardware_accuracy_status':'not_yet_measured_or_qualified',
          'release_adjustment':'Included firmware Makefile defaults to freshwater_lowheat; source algorithms unchanged.',
          'files':{name:hashlib.sha256(value).hexdigest() for name,value in payload.items()}}
payload['RELEASE_SHA256.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
selfkit=OUT/'conductivity-meter-v0.2-self-solder-kit.zip'
with zipfile.ZipFile(selfkit,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,value in payload.items():z.writestr('conductivity-meter-v0.2/'+name,value)
with zipfile.ZipFile(selfkit) as z:
    assert z.testzip() is None
    for name,digest in manifest['files'].items():
        assert hashlib.sha256(z.read('conductivity-meter-v0.2/'+name)).hexdigest()==digest,name
for p in [main,power,factory,selfkit]:
    print(p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
