#!/usr/bin/env python3
"""Add explicit assembly ECO notes in the unused top page margin; retain circuit."""
from pathlib import Path
import fitz
root=Path(__file__).resolve().parents[1]
doc=fitz.open(root/'sources/eval-cn0359-eb1z-padsschematic-reva.pdf')
notes=[
 'ECO-01: R13 = 4.99 kOhm / 0.01% / <=2 ppm/K. Use freshwater_lowheat firmware and 200 uA RTD current.',
 'ECO-02: DNP U4, L2, D3, C17. Regulated 5.0V +/-2% IN; external LDO 3.3V -> L5 pin1 (B). L5 pin3 is GND.',
 'ECO-03: Retain topology and component values. Precision R47 and eight 7.5k/1.2k ratio resistors; see assembly BOM.'
]
for i,page in enumerate(doc):
 page.insert_text((56,10),'V0.2 ASSEMBLY ECO OVERLAY - original ADI connectivity retained; red ECO overrides populated parts.',fontsize=8,color=(.75,.05,.05))
 page.draw_rect(fitz.Rect(56,16,page.rect.width-56,49),color=(.8,.1,.1),fill=(1,.98,.94),width=1)
 page.insert_textbox(fitz.Rect(64,23,page.rect.width-64,47),notes[i],fontsize=10,fontname='helv',color=(.75,.05,.05))
 if i==0:
  for box in page.search_for('1.50k'):
   mark=page.add_strikeout_annot(box);mark.set_colors(stroke=(.85,.05,.05));mark.update()
 if i==1:
  for name in ['U4','L2','D3','C17']:
   for box in page.search_for(name):
    mark=page.add_rect_annot(box+(-2,-2,2,2));mark.set_colors(stroke=(.85,.05,.05));mark.update()
out=root/'schematics/mainboard_revA_lowheat_eco.pdf'
out.parent.mkdir(exist_ok=True)
doc.save(out,garbage=3,deflate=True)
print(out)
