#!/usr/bin/env python3
"""Audit original ADI CAM, recover explicit drill format, export checked copies.

Run with /workspace/toolchains/gerber-review/bin/python (gerbonara==1.6.3).
This is geometry/registration validation, not a connectivity DRC.
"""
from pathlib import Path
from collections import Counter
import dataclasses
import hashlib
import json
import math
import re
import warnings
import zipfile
from gerbonara import GerberFile, ExcellonFile, LayerStack
from gerbonara.cam import FileSettings
from gerbonara.utils import MM
from gerbonara.graphic_objects import Flash
from gerbonara.apertures import Aperture

# gerbonara 1.6.3 defaults to four significant digits in ADD dimensions.
# Preserve source aperture geometry instead of rounding it during unit conversion.
def precise_aperture_definition(aperture,settings=None):
    unit=settings.unit if settings else None
    params='X'.join(f'{float(value):.10f}'.rstrip('0').rstrip('.')
                    for value in aperture._params(unit) if value is not None)
    return aperture._gerber_shape_code+(','+params if params else '')
Aperture.to_gerber=precise_aperture_definition

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'sources/eval-cn0359-eb1z-grb-reva.zip'
OUT=ROOT/'manufacturer/mainboard_4layer'
RAW=OUT/'gerbers'
CHECKED=OUT/'checked_cam'
CHECKED.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(SOURCE) as z:
    assert z.testzip() is None
    for name in z.namelist():
        path=Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        if not name.endswith('/'):
            target=OUT/path
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(z.read(name))

def primitive_signature(obj):
    def normalize(value):
        if isinstance(value,float):return round(value,5)
        if isinstance(value,dict):return {k:normalize(v) for k,v in value.items()}
        if isinstance(value,(tuple,list)):return [normalize(v) for v in value]
        return value
    return [(type(p).__name__,normalize(dataclasses.asdict(p))) for p in obj.to_primitives(unit=MM)]

names={
    'top.pho':('CN0359.GTL',('top','copper')),
    'layer2.pho':('CN0359.G2',('inner_1','copper')),
    'layer3.pho':('CN0359.G3',('inner_2','copper')),
    'bottom.pho':('CN0359.GBL',('bottom','copper')),
    'topsolder.pho':('CN0359.GTS',('top','mask')),
    'bottomsolder.pho':('CN0359.GBS',('bottom','mask')),
    'topover.pho':('CN0359.GTO',('top','silk')),
    'bottomover.pho':('CN0359.GBO',('bottom','silk')),
    'boardshape.pho':('CN0359.GKO',('mechanical','outline')),
}
layers={};layer_report={};warning_counter=Counter();warning_samples=[]
for original,(output,role) in names.items():
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        gerber=GerberFile.open(RAW/original)
    for warning in caught:
        message=str(warning.message)
        label='legacy_implicit_modal_operation' if 'without explicit operation code' in message else message.split(': ')[-1]
        warning_counter[label]+=1
        if len(warning_samples)<10:warning_samples.append(message)
    gerber.save(CHECKED/output,settings=FileSettings(unit=MM,number_format=(4,7),zeros='leading'))
    generated=(CHECKED/output).read_text().replace('\nG75\n','\nG75*\n')
    assert generated.count('%MOMM*%')==1
    (CHECKED/output).write_text(generated.replace('%MOMM*%','%MOMM*%\nG75*',1))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        recovered=GerberFile.open(CHECKED/output)
    assert not caught,(output,[str(w.message) for w in caught[:3]])
    assert len(gerber.objects)==len(recovered.objects),(original,'object_count')
    for i,(old,new) in enumerate(zip(gerber.objects,recovered.objects)):
        assert primitive_signature(old)==primitive_signature(new),(original,'geometry',i)
    layers[role]=gerber
    widths=[MM(o.aperture.diameter,o.aperture.unit) for o in gerber.objects
            if getattr(o,'aperture',None) is not None and hasattr(o.aperture,'diameter')
            and type(o).__name__ in ('Line','Arc')]
    layer_report[original]={
        'output':output,'role':role,'object_count':len(gerber.objects),
        'bounds_mm':gerber.bounding_box(unit=MM),'roundtrip_geometry_match':True,
        'min_draw_width_mm':min(widths) if widths else None,
        'original_sha256':hashlib.sha256((RAW/original).read_bytes()).hexdigest(),
        'normalized_sha256':hashlib.sha256((CHECKED/output).read_bytes()).hexdigest()}

# Original PADS drill omits the M48 header and includes six-place coordinates
# with TRAILING zero suppression (2 integer + 4 fractional inch digits).
# Retain the original; write a separate, explicit-decimal metric derivative.
tool_sizes={};drill_rows=[];current_tool=None;previous=[None,None]
for lineno,line in enumerate((RAW/'drill.drl').read_text().splitlines(),1):
    line=line.strip()
    if not line or line in ('%','M30'):continue
    match=re.fullmatch(r'T(\d+)C([.\d]+)F[.\d]+S[.\d]+',line)
    if match:
        current_tool=int(match[1]);diameter=float(match[2])*25.4
        assert current_tool not in tool_sizes
        tool_sizes[current_tool]=diameter
        continue
    assert current_tool is not None,('drill_before_tool',lineno)
    halves=line.split('G85')
    assert len(halves) in (1,2),('unsupported_drill_command',lineno,line)
    points=[]
    for half in halves:
        words=re.findall(r'([XY])(-?\d+)',half)
        assert ''.join(a+b for a,b in words)==half,('unsupported_coordinate',lineno,line)
        values=list(previous)
        for axis,number in words:
            sign=-1 if number.startswith('-') else 1
            digits=number.lstrip('-')
            assert len(digits)<=6
            values['XY'.index(axis)]=sign*int(digits.ljust(6,'0'))/10000*25.4
        assert all(v is not None for v in values)
        previous=values
        points.append(values)
    drill_rows.append({'tool':current_tool,'points_mm':points,'source_line':lineno})

lines=['M48',';CN0359 Rev A: metric explicit decimals, derived from original PADS 2:4 inch TZ',
       ';Original archive retained; drill registration checked against copper flashes',
       'METRIC,LZ',';FILE_FORMAT=3:6']
lines.extend(f'T{tool:02d}C{diameter:.6f}' for tool,diameter in tool_sizes.items())
lines.extend(['G90','%','G05'])
last_tool=None
for row in drill_rows:
    if row['tool']!=last_tool:
        lines.append(f"T{row['tool']:02d}");last_tool=row['tool']
    words=[f'X{x:.6f}Y{y:.6f}' for x,y in row['points_mm']]
    lines.append('G85'.join(words))
lines.append('M30')
drill_file=CHECKED/'CN0359_explicit_metric.drl'
drill_file.write_text('\n'.join(lines)+'\n')
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always');drill=ExcellonFile.open(drill_file)
assert not caught,[str(w.message) for w in caught]
assert len(drill.objects)==len(drill_rows)
for obj,row in zip(drill.objects,drill_rows):
    points=row['points_mm']
    if len(points)==1:
        assert abs(obj.x-points[0][0])<1e-6 and abs(obj.y-points[0][1])<1e-6
    else:
        assert all(abs(a-b)<1e-6 for a,b in zip((obj.x1,obj.y1,obj.x2,obj.y2),points[0]+points[1]))

flash_points=[]
closed_pad_contour_count=0
for role in [('top','copper'),('bottom','copper')]:
    objects=layers[role].objects
    for obj in objects:
        if isinstance(obj,Flash):
            converted=obj.converted(MM);flash_points.append((converted.x,converted.y))
    # PADS renders some large through-hole pads as closed line/arc contours,
    # rather than flashed apertures. Verify undirected closure before using
    # their bounding-box centers for drill registration.
    for length in [4,8]:
        for start in range(len(objects)-length+1):
            group=objects[start:start+length]
            if not all(type(o).__name__ in ('Line','Arc') for o in group):continue
            degree=Counter()
            for o in group:
                degree[(round(MM(o.x1,o.unit),5),round(MM(o.y1,o.unit),5))]+=1
                degree[(round(MM(o.x2,o.unit),5),round(MM(o.y2,o.unit),5))]+=1
            if not degree or any(value!=2 for value in degree.values()):continue
            boxes=[o.bounding_box(unit=MM) for o in group]
            x1=min(box[0][0] for box in boxes);y1=min(box[0][1] for box in boxes)
            x2=max(box[1][0] for box in boxes);y2=max(box[1][1] for box in boxes)
            if .5<x2-x1<8 and .5<y2-y1<8:
                flash_points.append(((x1+x2)/2,(y1+y2)/2));closed_pad_contour_count+=1
registration=[]
for row in drill_rows:
    points=row['points_mm'];center=[sum(v[i] for v in points)/len(points) for i in (0,1)]
    distance=min(math.dist(center,p) for p in flash_points)
    registration.append(distance)
assert max(registration)<0.03,('drill_copper_registration',max(registration))

outline=layers[('mechanical','outline')]
outer=list(outline.objects[:4]);slot=list(outline.objects[4:])
def check_closed(objects):
    for previous,current in zip(objects,objects[1:]+objects[:1]):
        assert math.dist((previous.x2,previous.y2),(current.x1,current.y1))<1e-10
check_closed(outer);check_closed(slot)
width=(max(o.x1 for o in outer)-min(o.x1 for o in outer))*25.4
height=(max(o.y1 for o in outer)-min(o.y1 for o in outer))*25.4
report={
    'scope':'geometry_and_drill_registration_only_not_electrical_DRC',
    'original_archive_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'copper_layer_order':['top.pho','layer2.pho','layer3.pho','bottom.pho'],
    'outline_centerline_dimensions_mm':[round(width,6),round(height,6)],
    'outline_closed_loops':2,'internal_routed_slot_present':True,
    'layer_report':layer_report,'legacy_parser_warnings':dict(warning_counter),
    'warning_samples':warning_samples,
    'drill_format_recovery':'original PADS 2:4 inch, trailing-zero suppression -> explicit decimal metric',
    'drill_tool_diameters_mm':tool_sizes,'drill_total_operations':len(drill_rows),
    'closed_pad_contours_used_for_registration':closed_pad_contour_count,
    'drill_round_hits':sum(len(r['points_mm'])==1 for r in drill_rows),
    'drill_slots':sum(len(r['points_mm'])==2 for r in drill_rows),
    'drill_max_distance_to_corresponding_copper_flash_center_mm':max(registration),
    'drill_operation_counts_by_tool':dict(Counter(r['tool'] for r in drill_rows)),
    'drill_rows':drill_rows,
    'limitations':['No IPC-356 or editable mainboard CAD: connectivity DRC not performed.',
                   'No vendor stackup/board thickness/copper weight found.',
                   'Original drill does not separately identify PTH vs NPTH; CAM must confirm mounting/slot plating.',
                   'Original archive has no solder-paste layers; do not manufacture stencil from solder mask blindly.']}
(OUT/'cam_audit.json').write_text(json.dumps(report,indent=2)+'\n')
stack=LayerStack(graphic_layers=layers,drill_pth=drill,board_name='CN0359 Rev A')
for side in ['top','bottom']:
    (OUT/f'mainboard_{side}_review.svg').write_text(str(stack.to_pretty_svg(side=side,margin=2)))
print(json.dumps({k:report[k] for k in ['outline_centerline_dimensions_mm','drill_total_operations','drill_round_hits','drill_slots','drill_max_distance_to_corresponding_copper_flash_center_mm']},indent=2))
print('All nine artwork layers roundtrip geometry matched; outer outline and internal slot closed.')
