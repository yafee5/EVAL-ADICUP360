# CN0359 官方完整硬件资料核验

核验日期：2026-10-20。本次取得了 ADI 官方 **三页完整原理图 PDF、Rev A 全量 BOM、四层 Gerber/钻孔包和对应旧版源代码包**，已不再只有文章中的简化图。文件保留在本目录 `sources/`，原文件未改写。

## 1. 从哪里取得

官网现行页面能读取，但整包 `cn0359-designsupport.zip` 仍返回代理 CONNECT 403。改读 ADI wiki **公开历史版本**中的原始下载链接，成功取得以下文件；不是第三方重画或镜像：

- [官方 2022 年历史用户手册](https://wiki.analog.com/resources/eval/user-guides/circuits-from-the-lab/cn0359?rev=1668738180&do=export_xhtml)：保留 Rev A、Rev0 的独立 PDF/XLSX/ZIP 下载链接。
- [官方 2023 年历史用户手册](https://wiki.analog.com/resources/eval/user-guides/circuits-from-the-lab/cn0359?rev=1676382474&do=export_xhtml)：保留 Rev A/Rev B 识别、连接照片和固件链接。

直接下载的统一前缀为：

`https://wiki.analog.com/_media/resources/eval/user-guides/circuits-from-the-lab/cn0359/`

| 文件 | 内容与取得后的检查 |
| --- | --- |
| `eval-cn0359-eb1z-padsschematic-reva.pdf` | 3 页矢量原理图；MAIN、POWER、ANALOG；标题 CN0359，图框 Rev A，绘图日期 2016-10-05。 |
| `eval-cn0359-eb1z-bom-reva.xlsx` | 官方 Rev A BOM；70 行、197 个唯一位号，其中 193 装配位号、4 个 DNP。 |
| `eval-cn0359-eb1z-grb-reva.zip` | ZIP CRC 通过；11 个制造文件：4 铜层、2 丝印、2 阻焊、板形、钻孔及钻孔图。 |
| `cn0359-sourcecode-reva.zip` | ZIP CRC 通过，168 项，旧 Eclipse/GCC 工程和源码；原封保留。 |
| `eval-cn0359-eb1z-padsschematic-rev0.pdf` | 官方旧 PDF，用于比对，不与 Rev A 装配表混用。 |
| `eval-cn0359-eb1z-bom-rev0.xlsx` | 官方旧 BOM，用于交叉验证更新内容。 |
| `eval-cn0359-eb1z-grb-rev0.zip` | 官方旧制造包，与标为 reva 的包逐字节一致。 |
| `cn0359_reva_front.jpg` | 官方 Rev A 正面连接器照片，带针序方向标注。 |

`sources/source_manifest.json` 记录每份原始文件的完整 URL、字节数和 SHA-256；`sources/SHA256SUMS` 可重算核对。对 ZIP 还执行了逐文件 CRC 检查。官方没有另行公布用于交叉认证的 SHA-256，因此本地哈希的作用是固定本次取得的原文件，不能写成“经 ADI 签名认证”。HTTPS 证书检查始终开启。

## 2. Rev0 与 Rev A 到底改了什么

对两份完整 PDF 用 `pdftotext -raw` 进行逐行对比，再和两份 BOM 的逐行内容交叉核对，得到一致的三项物料变化：

| 位号 | 官方 rev0 文件 | 官方 reva 文件 |
| --- | --- | --- |
| U1 | MIDAS MCCOG128064A6S-SPTLY LCD | BATRON BTHQ128064AVC1-COG-STF-LED LCD |
| C32 | 330 nF，Panasonic ECJ-2YB1C334K | NP，不装 |
| U7 | ADM3483ARZ | ADM3075EARZ |

其他文本差异为绘图日期由 2014-10-31 更新至 2016-10-05；两份 PDF 图框本身都标 Rev A。`rev0` 是官方文件名中的旧资料标识，不能据此把 PCB 丝印说成“Rev 0”。对比证据保留为 `sources/official_rev0_to_reva_text.diff`、`sources/official_bom_rev0_to_reva.json`。文本/BOM 比对本身不等同于完整电气网表等价证明，关键连接还需按原图与制造层复核。

两个官方 Gerber ZIP **内容字节完全相同**，均为 295709 字节，SHA-256：

`c935df90e440806a3186bdefb6369d1cf745f3f06e6982fc2d945baa96bf9b7b`

这说明官方就为上述装配更新复用了同一套裸板制造资料，而不是必须为 2016 年 BOM 另找一套新走线。

## 3. 为什么 Gerber 内部写 CN0343.pcb 仍可判定归属

原 Gerber 的 PADS 9.5 头部包含遗留内部工程名 `%IN "CN0343.pcb"*%`，文件时间为 2014-07-28。仅凭这个头部或修改时间不能否定归属，也不能只凭 ZIP 文件名认定归属。本次进一步完成了以下核对：

1. 用 Gerbonara 1.6.3 解析并渲染原始顶层丝印；丝印清楚写 **EVAL-CN0359-EB1Z Rev. A**。
2. 顶层 J1 左上、J3/J5 左边、J2/J4 右边、中央 LCD、右下编码器的布局与官方 `cn0359_reva_front.jpg` 一致。
3. J3 的 RTD、J5 的 Conductivity、J2 的 RS485、J4 的 JTAG 标签，以及显示器旁 C2/C3、下方 C4–C8 的相对位置均与官方照片吻合。
4. 官方 rev0/reva 下载入口提供的 Gerber ZIP 本就完全相同，和只改 LCD/C32/RS-485 器件的 BOM 更新吻合。

据此可把这份 Gerber 明确归档为官方 CN0359 Rev A 裸板资料；内部 CN0343 工程名是历史遗留，不将其擅改为另一个名称。原始丝印与版权保留。

渲染证据：`sources/topover_official_render.svg`、`sources/bottomover_official_render.svg`。它们是查看用派生文件，不取代未修改的原 Gerber。解析器对旧 PADS 的省略 D 操作码发出语法兼容提示，但仍按模态操作解析；提示不等于实际缺线，后续制造审核需要独立 CAM 检查。

## 4. 已核实接口与曾经的误读

官方三页图补齐了此前没有的实际引脚资料。接口的最终结论应按高清线图核对，不能按 PDF 提取后的文字排列猜测。

**J2（RS-485）针序为 1=B、2=GND、3=A。** 其中 R10=10 kΩ 跨接 A/B，并非 120 Ω 长线终端。早期曾由文字位置误读为 1=GND/2=B，现已通过高清裁图纠正；任何旧聊天中的不同顺序应弃用。

J1 原图针 1 接电源正输入、针 2 接 PGND、针 3 切换触点不接铜网；连接器物理中心尺寸、插头长度和替代件焊脚次序仍应按 MJ-179PH 器件图及实物复核。J4 为 20 针 J-Link 接口；实际 SWDIO、SWCLK、RESET、VTref 和地按完整原图和接口审查文件执行。主板 MCU 的部分功能引脚存在图上外部短接，例如 P1.0/P1.2 的关联，不能仅看低分辨简图作 NC 判断。

## 5. BOM 导出和制造边界

- `sources/official_bom_reva.csv`：逐行导出官方 BOM，保留原制造商与原料号。
- `sources/official_bom_reva_expanded.csv`：逐个位号展开，共 197 行；所有组的声明数量与展开数量一致，无重复位号。
- DNP 为 **C32、C65、C66、Y1**；NP 不等于漏买。
- 193 是装配位号数，不能直接当作严格的物理件数。U1 行同时列 LCD 和 Würth 68612214122 连接器；S1 行同时列 Bourns 编码器和 Mentor 506.61 旋钮，采购清单应拆子项，不能把两个并列料号当作任选替代。
- 已取得的是完整原理图 PDF 和制造 Gerber，**未取得可编辑的 PADS 原理图/PCB 源工程**。改板逻辑应单独记录并对应固件，不能只改 PDF 后仍把未改的 Gerber 称为改版。
- 此下载包没有单独的层叠/板厚/铜重说明、贴片坐标或锡膏层；未从文件中猜测这些参数。后续生产选项、层序/孔表检查和手工装配工艺由本项目制造说明明确列出。
- 低自热版 R13=4.99 kΩ、200 µA 是本项目的后续装配变体，不是 ADI 原版 1.5 kΩ BOM；必须配匹配固件并保留原版对照。
