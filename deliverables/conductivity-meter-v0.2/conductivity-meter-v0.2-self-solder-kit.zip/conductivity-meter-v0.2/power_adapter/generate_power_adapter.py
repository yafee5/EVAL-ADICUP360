#!/usr/bin/python3
"""Generate the independent 30 x 25 mm ADP3338 adapter, never the ADI motherboard."""
import os, json, csv, uuid
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
    os.environ.setdefault(k,'/tmp/kicad-power/'+v)
    Path(os.environ[k]).mkdir(parents=True,exist_ok=True)
import pcbnew as p
ROOT=Path(__file__).resolve().parent
NAME='cn0359_ldo_adapter'
UID=lambda s:str(uuid.uuid5(uuid.NAMESPACE_URL,'cn0359-power-adapter-v0.2/'+s))
ROOTID=UID('root')
mm=p.FromMM
vec=lambda x,y:p.VECTOR2I(mm(x),mm(y))
LIB=Path('/usr/share/kicad/footprints')
TERMINAL='TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal'
HEADER='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical'
CAP='Capacitor_SMD:C_0805_2012Metric'
SOT='Package_TO_SOT_SMD:SOT-223-3_TabPin2'
TP='TestPoint:TestPoint_THTPad_D2.0mm_Drill1.0mm'
HOLE='MountingHole:MountingHole_3.2mm_M3'
parts=[
 dict(ref='U1',value='ADP3338AKCZ-3.3',footprint=SOT,pins={'1':'GND','2':'VOUT_LDO','3':'VIN_LDO'},xy=[65,57.2],mpn='ADP3338AKCZ-3.3RL7',description='3.3 V anyCAP LDO, SOT-223, tab = OUT'),
 dict(ref='C1',value='10uF 25V X5R',footprint=CAP,pins={'1':'GND','2':'VIN_LDO'},xy=[60,62.4],mpn='GRM21BR61E106KA73L',description='0805 MLCC; effective capacitance >= 1 uF at 5.1 V'),
 dict(ref='C2',value='10uF 25V X5R',footprint=CAP,pins={'1':'VOUT_LDO','2':'GND'},xy=[69,62.4],mpn='GRM21BR61E106KA73L',description='0805 MLCC; effective capacitance >= 1 uF at 3.3 V'),
 dict(ref='J1',value='5V_POST_U3_IN',footprint=TERMINAL,pins={'1':'VIN_POST_U3','2':'GND'},xy=[53.4,69.5],mpn='MKDS 1,5/2-5,08',description='Phoenix Contact 2-pole 5.08 mm horizontal terminal; match footprint and drill'),
 dict(ref='J2',value='3V3_TO_L5_PIN1',footprint=TERMINAL,pins={'1':'VOUT_TO_MAIN','2':'GND'},xy=[71.2,69.5],mpn='MKDS 1,5/2-5,08',description='Phoenix Contact 2-pole 5.08 mm horizontal terminal; pin 2 optional common ground return'),
 dict(ref='JP1',value='INPUT_ENABLE',footprint=HEADER,pins={'1':'VIN_POST_U3','2':'VIN_LDO'},xy=[56,58.1],mpn='1x02 P2.54mm straight header + removable shunt',description='Fit shunt for operation; remove to isolate LDO input'),
 dict(ref='JP2',value='OUTPUT_ENABLE',footprint=HEADER,pins={'1':'VOUT_LDO','2':'VOUT_TO_MAIN'},xy=[74,58.1],mpn='1x02 P2.54mm straight header + removable shunt',description='Fit shunt after verifying 3.3 V on unloaded adapter; remove for output current measurement'),
 dict(ref='TP1',value='GND_TEST',footprint=TP,pins={'1':'GND'},xy=[64,71.7],mpn='Bare plated test hole',description='2 mm plated pad / 1 mm hole; optional wire test loop'),
 dict(ref='H1',value='M3_NPTH',footprint=HOLE,pins={},xy=[50.5,50.5],mpn='M3 nylon standoff',description='3.2 mm non-plated mounting hole'),
 dict(ref='H2',value='M3_NPTH',footprint=HOLE,pins={},xy=[79.5,50.5],mpn='M3 nylon standoff',description='3.2 mm non-plated mounting hole'),
]
# The three-pad U1 symbol directly implements ADP3338 Table 3, not another regulator's pins.
def effects(sz=1.27,hidden=False):return f'(effects (font (size {sz} {sz}))'+(' (hide yes)' if hidden else '')+')'
def pin(num,name,x,y,ang,kind='passive'):
 return f'(pin {kind} line (at {x} {y} {ang}) (length 2.54) (name "{name}" {effects()}) (number "{num}" {effects()}))'
def libsymbol(key,pinlist,rect=(-5.08,5.08,5.08,-5.08)):
 x1,y1,x2,y2=rect
 return f'''(symbol "PowerAdapter:{key}" (pin_names (offset 0.5)) (exclude_from_sim no) (in_bom yes) (on_board yes)
 (property "Reference" "U" (at 0 7.62 0) {effects()}) (property "Value" "{key}" (at 0 -7.62 0) {effects()})
 (symbol "{key}_0_1" (rectangle (start {x1} {y1}) (end {x2} {y2}) (stroke (width 0.254) (type default)) (fill (type background))))
 (symbol "{key}_1_1" {''.join(pin(*a) for a in pinlist)}))'''
libs=[libsymbol('ADP3338_3V3',[('3','IN',-7.62,0,0,'power_in'),('2','OUT_TAB',7.62,0,180,'power_out'),('1','GND',0,-7.62,90,'power_in')]),
 libsymbol('TWO_PINS',[('1','1',-7.62,1.27,0),('2','2',-7.62,-1.27,0)]),
 libsymbol('CAP',[('1','1',-7.62,0,0),('2','2',7.62,0,180)],(-2.54,2.54,2.54,-2.54)),
 libsymbol('TEST',[('1','1',-7.62,0,0)],(-1.27,1.27,1.27,-1.27)),
 libsymbol('HOLE',[],(-2.54,2.54,2.54,-2.54)),
 libsymbol('PWRFLAG',[('1','pwr',0,0,90,'power_out')],(-1.27,1.27,1.27,-1.27))]
# Every physical component has the same pin nets in the schematic and PCB.
schpos={'U1':(130.81,68.58),'C1':(88.9,106.68),'C2':(162.56,106.68),'J1':(53.34,68.58),'J2':(223.52,68.58),
 'JP1':(88.9,68.58),'JP2':(185.42,68.58),'TP1':(223.52,106.68),'H1':(53.34,139.7),'H2':(78.74,139.7)}
keys={'U1':'ADP3338_3V3','C1':'CAP','C2':'CAP','TP1':'TEST','H1':'HOLE','H2':'HOLE'}
def inst(ref,value,key,x,y,fp='',physical=True):
 props=f'(property "Reference" "{ref}" (at {x} {y-10.16} 0) {effects()})'+f'(property "Value" "{value}" (at {x} {y+10.16} 0) {effects(1.0)})'+f'(property "Footprint" "{fp}" (at {x} {y} 0) {effects(hidden=True)})'
 return f'(symbol (lib_id "PowerAdapter:{key}") (at {x} {y} 0) (unit 1) (in_bom {"yes" if physical else "no"}) (on_board {"yes" if physical else "no"}) (dnp no) (uuid {UID(ref)}) {props} (instances (project "{NAME}" (path "/{ROOTID}" (reference "{ref}") (unit 1)))))'
def label(net,x,y,right=False):
 return f'(label "{net}" (at {x} {y} 0) (effects (font (size 1 1)) (justify {"right" if right else "left"} bottom)) (uuid {UID(net+str(x)+str(y))}))'
def wire(a,c,key):
 return f'(wire (pts (xy {a[0]} {a[1]}) (xy {c[0]} {c[1]})) (stroke (width 0) (type default)) (uuid {UID(key)}))'
items=[]
for a in parts:
 ref=a['ref'];x,y=schpos[ref];key=keys.get(ref,'TWO_PINS'); items.append(inst(ref,a['value'],key,x,y,a['footprint']))
 if key=='ADP3338_3V3':loc={'3':(x-7.62,y),'2':(x+7.62,y),'1':(x,y+7.62)}
 elif key=='CAP':loc={'1':(x-7.62,y),'2':(x+7.62,y)}
 elif key=='TWO_PINS':loc={'1':(x-7.62,y-1.27),'2':(x-7.62,y+1.27)}
 elif key=='TEST':loc={'1':(x-7.62,y)}
 else:loc={}
 for n,net in a['pins'].items():
  px,py=loc[n]
  if key=='ADP3338_3V3' and n=='1':
   end=(px,round(py+7.62,3));items.append(wire((px,py),end,ref+n));items.append(label(net,*end))
  else:
   right=key in ('ADP3338_3V3','CAP') and n=='2'
   end=(round(px+(12.7 if right else -15.24),3),py)
   items.append(wire((px,py),end,ref+n));items.append(label(net,*end,right=right))
for ref,net,x,y in [('#FLG01','VIN_POST_U3',134.62,135.89),('#FLG02','VIN_LDO',185.42,135.89),('#FLG03','GND',236.22,135.89)]:
 items.append(inst(ref,net,'PWRFLAG',x,y,physical=False));items.append(label(net,x,y))
notes=[('ADP3338: 1=GND, 2=OUT/TAB, 3=IN. Verify ADI Table 3 before assembly.',30.48,157.48),
 ('Mainboard ECO: DNP U4/L2/D3/C17. J1.1 from main C9 VCC after U3. J2.1 to main L5.1 B.',30.48,162.56),
 ('Main L5.3 is PGND, NEVER inject 3.3 V there. Fit JP1/JP2 shunts for normal use.',30.48,167.64),
 ('Input: regulated 5.0 V +/-2%. 200 mA continuous target; thermal validation required.',30.48,172.72),
 ('C1/C2: 10 uF 25 V 0805; effective C >=1 uF with bias and temperature.',30.48,177.8)]
for s,x,y in notes:items.append(f'(text "{s}" (at {x} {y} 0) (effects (font (size 1.0 1.0)) (justify left)) (uuid {UID(s)}))')
sch=f'''(kicad_sch (version 20250114) (generator "eeschema") (uuid {ROOTID}) (paper "A4")
(title_block (title "CN0359 Rev A - independent 3.3 V LDO adapter") (date "2026-10-20") (rev "0.2") (company "Prototype: main PCB unchanged; see power ECO"))
(lib_symbols {''.join(libs)}) {''.join(items)} (embedded_fonts no))'''
(ROOT/(NAME+'.kicad_sch')).write_text(sch)
(ROOT/'PowerAdapter.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor") '+''.join(libs).replace('(symbol "PowerAdapter:','(symbol "')+')')
(ROOT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "PowerAdapter") (type "KiCad") (uri "${KIPRJMOD}/PowerAdapter.kicad_sym") (options "") (descr "Verified ADP3338 adapter symbols")))')
footprint_libs=sorted({a['footprint'].split(':')[0] for a in parts})
(ROOT/'fp-lib-table').write_text('(fp_lib_table (version 7) '+''.join(f'(lib (name "{lib}") (type "KiCad") (uri "${{KICAD9_FOOTPRINT_DIR}}/{lib}.pretty") (options "") (descr "KiCad standard"))' for lib in footprint_libs)+')')
# PCB: terminal/jumper polarity is explicit; OUT thermal copper is not ground.
b=p.BOARD();b.SetFileName(str(ROOT/(NAME+'.kicad_pcb'))); b.GetDesignSettings().SetCopperLayerCount(2)
b.GetDesignSettings().SetBoardThickness(mm(1.6))
nets={}
for i,name in enumerate(['GND','VIN_POST_U3','VIN_LDO','VOUT_LDO','VOUT_TO_MAIN'],1):
 net=p.NETINFO_ITEM(b,'/'+name,i);b.Add(net);nets[name]=net
fps={}
for a in parts:
 lib,n=a['footprint'].split(':'); f=p.FootprintLoad(str(LIB/(lib+'.pretty')),n);assert f,a['footprint']
 f.SetReference(a['ref']);f.SetValue(a['value']);f.SetPosition(vec(*a['xy']));f.SetFPID(p.LIB_ID(lib,n))
 f.SetAttributes(f.GetAttributes() & ~p.FP_EXCLUDE_FROM_BOM)
 path=p.KIID_PATH();path.push_back(p.KIID(ROOTID));path.push_back(p.KIID(UID(a['ref'])));f.SetPath(path)
 for pad in f.Pads():
  if pad.GetNumber() in a['pins']:pad.SetNet(nets[a['pins'][pad.GetNumber()]])
 f.Value().SetVisible(False)
 f.Reference().SetTextSize(vec(.8,.8));f.Reference().SetTextThickness(mm(.12));f.Reference().SetVisible(True)
 b.Add(f);fps[a['ref']]=f
# Position references within the board without printing on pads or copper test holes.
refxy={'U1':(65,53.0),'C1':(60,60.9),'C2':(69.5,60.9),'J1':(55,75),'J2':(73,75),'JP1':(56,63),'JP2':(74,63),'TP1':(64,74),'H1':(50.5,53.6),'H2':(79.5,53.6)}
for r,xy in refxy.items():fps[r].Reference().SetPosition(vec(*xy))
def seg(net,pts,w=.7,layer=p.F_Cu):
 for a,c in zip(pts,pts[1:]):
  t=p.PCB_TRACK(b);t.SetStart(vec(*a));t.SetEnd(vec(*c));t.SetWidth(mm(w));t.SetLayer(layer);t.SetNet(nets[net]);b.Add(t)
def via(net,x,y):
 v=p.PCB_VIA(b);v.SetPosition(vec(x,y));v.SetWidth(p.F_Cu,mm(.7));v.SetDrill(mm(.3));v.SetViaType(p.VIATYPE_THROUGH);v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetNet(nets[net]);b.Add(v)
seg('VIN_POST_U3',[(53.4,69.5),(51.6,67.7),(51.6,59.5),(53,58.1),(56,58.1)],1.0)
seg('VIN_LDO',[(56,60.64),(57.5,60.64),(59.5,58.64),(60.8,58.64),(61.85,59.5)],.7)
seg('VIN_LDO',[(61.85,59.5),(61.85,61.5),(60.95,62.4)],.7)
seg('GND',[(61.85,54.9),(59.6,54.9)],.7);via('GND',59.6,54.9)
seg('GND',[(59.05,62.4),(58.6,63.2)],.55);via('GND',58.6,63.2)
seg('GND',[(69.95,62.4),(70.2,63.2)],.55);via('GND',70.2,63.2)
seg('VOUT_LDO',[(61.85,57.2),(68.15,57.2),(74,58.1)],1.0)
seg('VOUT_LDO',[(68.15,57.2),(68.05,62.4)],.9)
seg('VOUT_TO_MAIN',[(74,60.64),(77.2,63.84),(77.2,64.6),(71.2,64.6),(71.2,69.5)],1.0)
for xy in [(71.5,55),(71.5,56.5),(71.5,58),(67,60.5),(68.5,60.5),(70,60.5)]:via('VOUT_LDO',*xy)
# Four exact edges: 35 x 35 mm provides hand-solder and mounting clearance.
for a,c in [((47.5,47.5),(82.5,47.5)),((82.5,47.5),(82.5,82.5)),((82.5,82.5),(47.5,82.5)),((47.5,82.5),(47.5,47.5))]:
 s=p.PCB_SHAPE();s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*c));s.SetLayer(p.Edge_Cuts);s.SetWidth(mm(.05));b.Add(s)
def zone(net,layer,pts,priority=0,solid=False):
 z=p.ZONE(b);z.SetLayer(layer);z.SetNet(nets[net]);z.SetLocalClearance(mm(.3));z.SetThermalReliefGap(mm(.3));z.SetThermalReliefSpokeWidth(mm(.45));z.SetAssignedPriority(priority)
 z.SetPadConnection(p.ZONE_CONNECTION_FULL if solid else p.ZONE_CONNECTION_THERMAL)
 out=z.Outline();out.NewOutline()
 for x,y in pts:out.Append(mm(x),mm(y))
 b.Add(z)
# Explicit connected copper avoids reliance on an interactive zone-fill state.
# SOT-223 TAB is OUT, never GND: dedicated output thermal copper on both layers.
def thermal_copper(net,x1,y1,x2,y2,layer):
 y=y1
 while y<=y2+.0001:
  seg(net,[(x1,y),(x2,y)],.6,layer)
  y+=.5
 seg(net,[(x1,y1),(x1,y2)],.6,layer)
 seg(net,[(x2,y1),(x2,y2)],.6,layer)
thermal_copper('VOUT_LDO',66.8,52.8,72.2,60.8,p.F_Cu)
thermal_copper('VOUT_LDO',60.5,51.5,72.4,61.0,p.B_Cu)
seg('GND',[(58.48,69.5),(58.48,78),(76.28,78),(76.28,69.5)],1.0,p.B_Cu)
seg('GND',[(64,71.7),(64,78)],.8,p.B_Cu)
seg('GND',[(59.6,54.9),(59,54.9),(59,65),(58.48,69.5)],.8,p.B_Cu)
seg('GND',[(58.6,63.2),(58.6,65),(58.48,69.5)],.8,p.B_Cu)
seg('GND',[(70.2,63.2),(79.5,63.2),(79.5,69.5),(76.28,69.5)],.8,p.B_Cu)
def text(s,x,y,size=.8,layer=p.F_SilkS):
 t=p.PCB_TEXT(b);t.SetText(s);t.SetPosition(vec(x,y));t.SetTextSize(vec(max(.8,size),max(.8,size)));t.SetTextThickness(mm(.12));t.SetLayer(layer);t.SetMirrored(layer==p.B_SilkS);b.Add(t)
text('5V IN',55.2,65.3,.8);text('3V3 OUT',73.5,65.3,.8)
text('+  G',55.7,66.7,.8);text('+  G',73.5,66.7,.8)
text('IN',56,56.2,.7);text('OUT',74,56.2,.7)
text('LDO v0.2',65,51.2,.8);text('TAB=3V3',65,65.6,.65)
text('200mA CONT / 5V ONLY',65,74.1,.7,p.B_SilkS)
# Keep the output copper and mounting hardware insulated from a grounded enclosure.
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
b.BuildConnectivity()
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
pro={'board':{'design_settings':{'rules':{'min_clearance':.2,'min_track_width':.25,'min_via_diameter':.6,'min_through_hole_diameter':.3,'min_hole_to_hole':.25,'min_copper_edge_clearance':.4}},},'meta':{'filename':NAME+'.kicad_pro','version':1},'net_settings':{'classes':[{'name':'Default','clearance':.25,'track_width':.7,'via_diameter':.7,'via_drill':.3,'microvia_diameter':.3,'microvia_drill':.1,'diff_pair_width':.2,'diff_pair_gap':.25,'diff_pair_via_gap':.25,'bus_width':12,'line_style':0,'wire_width':6,'pcb_color':'rgba(0,0,0,0)','schematic_color':'rgba(0,0,0,0)'}],'net_colors':None,'netclass_assignments':None,'netclass_patterns':[]}}
(ROOT/(NAME+'.kicad_pro')).write_text(json.dumps(pro,indent=2))
metadata={'name':NAME,'revision':'0.2','board_mm':[35,35],'layers':2,'board_thickness_mm':1.6,'copper_um':35,'schematic_uuid':ROOTID,
 'input_V':[4.9,5.1],'output_V_nominal':3.3,'continuous_current_target_A':.2,'peak_current_test_target_A':.3,'maximum_ambient_target_C':40,
 'thermal_rating_note':'200 mA is the design target, not hardware-qualified. 300 mA is transient characterization only until duration/temperature is measured. IC 1 A rating is NOT adapter board rating.',
 'components':parts,'critical_pinout':{'U1.1':'GND','U1.2':'VOUT_LDO','U1.TAB':'VOUT_LDO','U1.3':'VIN_LDO'},
 'motherboard_eco':{'DNP':['U4','L2','D3','C17'],'retain':['L5','C25','C26','C31','C81','R5','R2'],
 'connections':[{'adapter':'J1.1','motherboard':'C9 VCC pad after U3','net':'VCC'},{'adapter':'J1.2','motherboard':'C9 PGND pad','net':'PGND'}, {'adapter':'J2.1','motherboard':'L5 pin 1 B / C26 non-ground pad','net':'pre-filter 3.3V'}],
 'warning':'L5 pin3 is PGND; never inject 3.3V into pin3. Never power the adapter from J1 raw contact before U3. Never populate U4 while using the adapter.'},
 'official_datasheet':'https://www.analog.com/media/en/technical-documentation/data-sheets/ADP3338.pdf'}
(ROOT/'power_adapter_netlist.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
with (ROOT/'power_adapter_bom.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['Reference','Quantity','Value','Manufacturer_Part_Number_or_spec','Footprint','Note'])
 for a in parts:w.writerow([a['ref'],1,a['value'],a['mpn'],a['footprint'],a['description']])
print('Generated',ROOT)
