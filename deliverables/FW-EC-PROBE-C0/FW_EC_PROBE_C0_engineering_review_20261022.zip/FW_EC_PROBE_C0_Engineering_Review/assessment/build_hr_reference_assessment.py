#!/usr/bin/env python3
"""Reference audit only. Does not create firmware or production CAD."""
import csv,hashlib,json,math
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent/'references'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[
 ['water_temperature','0x0003',1,'int16','R','IMPLEMENT_COMPATIBLE','raw/100 °C; two\'s complement; e.g +10.80=0x0438, -10.80=0xFBC8','manual Table4 example0x006C/0xFF94 is ±1.08°C, not ±10.80°C','C0 reserves0x8000 as invalid; float extension0x1004..1005; invalid sentinel is C0 addition'],
 ['conductivity','0x0006',2,'uint32','R','IMPLEMENT_COMPATIBLE','integer µS/cm; C0 defines κ25, rounded; high16bit word then low16bit word','manual says µS without /cm and does not clearly state compensation; C0 request resolves to κ25','C0 invalid0xFFFFFFFF; float κT0x1000..1001/κ250x1002..1003; max rounding±0.5µS/cm'],
 ['slave_address','0x0130',1,'uint16','R/W','IMPLEMENT_COMPATIBLE','1..247; FC03 read/FC10 write','table address chosen; examples must not override explicit C0 request','C0 firmware write protection/Flash SAVE applies; default address1 is C0 design choice'],
 ['baud_code','0x0132',1,'uint16','R/W','IMPLEMENT_SUBSET','only manual-confirmed code1=9600; FC03 read/FC10 write','example0x0013 conflicts with Table3 0x0132; other baud encodings not specified','reject unknown HR codes; other rates use explicitly documented C0 native extension0x1107; no alias0x0013'],
 ['serial_format','0x0134',1,'uint16','R/W','IMPLEMENT_COMPATIBLE','0=8O1,1=8E1,2=8N2,3=8N1(default)','example0x0014 conflicts with Table3 0x0134; overlaps manualECoffset0133 length2','no alias0x0014; C0 protected save and apply after old-settings reply'],
 ['EC_zero_offset','0x0133',2,'float32','R/W','DO_NOT_IMPLEMENT_HR_ADDRESS','manual IEEE754 float, word order not generally established','occupies0133 AND0134, conflicting with parity0134','C0 calibration lives extended nonoverlapping map; do not forward this HR write'],
 ['water_level','0x0001',2,'uint32','R','OUT_OF_SCOPE','manual mm','not a conductivity/temperature function','not implemented; do not synthesize0 or pressure-derived values'],
 ['water_pressure','0x0004',2,'uint32','R','OUT_OF_SCOPE','manual Pa','not a conductivity/temperature function','not implemented; do not add pressure sensor'],
 ['density','0x0135',2,'float32','R/W','OUT_OF_SCOPE','manual kg/m³','manual float example7CEE3F7F implies lowwordfirst for0.998, other float text inconsistent','no density or salinity conversion; C0 floats use its own documented order'],
 ['pressure_zero_offset','0x0137',2,'float32','R/W','OUT_OF_SCOPE','manual example/mm','manual mixes float with two\'s complement integer description','not implemented'],
 ['pressure_coefficient','0x0191',2,'float32','R/W','OUT_OF_SCOPE','manual coefficient','pressure only','not implemented'],
 ['EC_coefficient','0x0181',2,'float32','R/W','NOT_REQUIRED_COMPATIBILITY','manual coefficient','no gain/frequency indexing or protection defined','C0 K/gain table at own extended addresses; no claim of fullHR calibration compatibility'],
 ['temperature_zero_offset','0x0139',2,'float32','R/W','NOT_REQUIRED_COMPATIBILITY','manual offset','manual does not provide fullchain calibration model','C0 temperature gain/offset in extended map'],
 ['serial_number','0x0161',16,'Char*','R','NOT_REQUIRED_COMPATIBILITY','manual says16registers and16bytes/12digits','16register span0161..0170 overlaps manufacturedate0169..016A','do not copy without corrected manufacturer spec'],
 ['manufacture_date','0x0169',2,'int32','R','NOT_REQUIRED_COMPATIBILITY','manual dateencoding absent','overlaps serial number if stated16registerlength used','no invented HR identity'],
 ['version','0x0171',1,'short','R','NOT_REQUIRED_COMPATIBILITY','manual device version','not an identity of this customC0','C0 has its own version register'],
]
with (D/'HR_regs.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['name','hr_address_hex_PDU_zero_based','register_count','manual_datatype','manual_access','C0_decision','coding_and_units','manual_conflict_or_limit','C0_resolution']);w.writerows(rows)
manual=R/'HR8033_用户原始手册.docx';md=R/'C0_用户最终要求.md';img=R/'image1.png'
facts={
 'status':'REFERENCE_AUDIT_ONLY_NO_INTERNAL_MECHANICAL_RELEASE',
 'source':{'manual':str(manual.relative_to(D.parent)),'manual_sha256':sha(manual),'manual_version':'V0.41','image':str(img.relative_to(D.parent)),'image_sha256':sha(img),'user_requirement':str(md.relative_to(D.parent)),'user_requirement_sha256':sha(md)},
 'direct_labeled_dimensions_mm':{'main_body_outer_diameter':30,'overall_axial_length_nominal':210.20,'overall_axial_length_tolerance_plus_minus':1,'secondary_axial_span':186,'front_adjacent_span1':32,'front_adjacent_span2':26,'rear_transverse_feature':27},
 'calculated_nominal_dimensions_mm':{'nose_to_secondary_span_start':24.2,'two_adjacent_front_spans_sum':58,'nose_to_end_of_three_front_spans':82.2,'end_of_front_spans_to_rear_datum_external_only':128},
 'calculation_notes':['24.2=210.20-186; nominal arithmetic only; no tolerance assigned to186/32/26 in drawing.','58=32+26 starts after24.2mm frontsection, not at nose datum.','82.2=24.2+32+26 is nominal nose-to-frontsectionend.','128=210.2-82.2 is an EXTERIOR residual span including rearconnector region; not an electronics cavity.','27mm is transverse dimension in drawing, not an axial cablegland length and not a guaranteed innerdiameter.','No pixel scaling performed.'],
 'unknown_internal_dimensions':['minimum_inner_diameter_at_all_axial_positions','wall_thickness','seal_lands_and_stops','electrode_insert_rear_intrusion','cable_gland_internal_intrusion','actual_dry_electronics_cavity_length','harness_bend_and_solder_clearance','real_transformer_height_and_width'],
 'latest_user_requirements':{'maximum_total_board_and_components_width_mm':17,'preferred_board_length_max_mm':150,'electrode_configuration':'four-electrode K≈1 with truefourwirePt1000; twoelectrodepairedconnectioncompatible','board_quantity':'rootselected architecture','fit_verified':False,'production_dimensions_verified':False},
 'fit_formula':{'definition':'centered rectangular bounding envelope in circular clearbore','required_inner_diameter_mm':'sqrt(W²+(h_top+t_pcb+h_bottom)²)+2*radial_clearance','assumed_example_only':{'W_mm':17,'h_top_mm':4,'t_pcb_mm':1.0,'h_bottom_mm':2,'radial_clearance_mm':.5,'required_min_ID_mm':math.sqrt(17**2+7**2)+1},'conditions':['all component,harness,solder overhangs included','actualbore and assembly tilt/tolerance verified','example componentheights not selectedhardwareguarantees']},
 'conclusion':'UseHR8033 exterior shape as userchosen reference; cannot honestly prove fit or issueproductionhousingdimensions without internalcavity data. 150mmPCB is not established by exterior210minus58.'
}
(D/'mechanical_reference.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
(D/'mechanical_reference.md').write_text('''# HR8033 外形与 C0 装配约束核对

只核对用户提供的 HR8033 V0.41 手册外形图，源图为 references/image1.png。外形采用用户已选的 HR8033 资料；没有从图片像素反推尺寸，也没有把外径当内径。数据和 SHA256 见 mechanical_reference.json。

| 原图直接标注 | 可确认的含义 |
|---|---|
| Φ30 mm | 主管外径，未给内径或壁厚 |
| 210.20±1 mm | 最前端至最后端基准的总长 |
| 186 mm | 从前段后方另一个基准到最后端的轴向跨度，起点不是最前端 |
| 32 mm、26 mm | 前部相邻两个轴向区段，合计58 mm |
| 27 mm | 尾部横向尺寸；不把它当轴向电缆接头占长或内径 |

按图上各轴向基准的关系，前端未计入186mm跨度的长度为 `210.20−186=24.20mm`。因此32+26=58mm从约24.2mm处起算，保留三个前部区段时末端约在鼻端后 `24.2+32+26=82.2mm`。这些是名义值运算；原图未给186/32/26公差，不能自行写成制造公差。

前部区段末端至最后端仅剩名义外部轴向跨度 `210.2−82.2=128.0mm`，里面还包括尾部外形和接线结构。这仍不等于电路板净腔长。不能用210−58≈152mm论证150mm PCB装得下。手册没有剖视图，前部电极结构是否容许电路板伸入也无法由外观确定。

未提供的内部数据包括：最小通孔内径、壁厚、密封台阶/止口、前端电极后座伸入长度、电缆接头内伸长度、实际干燥腔净长、导线焊接和转弯空间。Φ30外壳不能直接证明17mm板宽有余量。新四电极和内置四线Pt1000的组件与HR8033原件也不能默认具有相同后伸尺寸。

17mm上限应覆盖PCB、器件和焊点的横向投影，连接器、磁件和绝缘物不能伸出。双面PCB的截面约束还取决于板厚及两面高度。对居中的保守矩形包络，可用：

`所需最小内径 ≥ sqrt(W²+(h_top+t_pcb+h_bottom)²) + 2×径向装配间隙`

例如仅作算例，W=17mm、板厚1mm、正面4mm、背面2mm、径向间隙0.5mm时，所需内径约19.385mm。这里的高度和间隙不是已选器件/壳体规格，也不构成装得下的证明；实际STEP轮廓、偏心位置、绝缘和线束必须一起核对。

可交付已知外形的参考图、标有所需最小内径/所需净腔长的截面条件图和PCB真实高度包络。内部尺寸未知时，STEP和截面只能标“装配条件未验证”，不能标“已适配HR8033”“可直接加工壳体”或“已证明可装”。本核对不新增水压、水位或导气功能。
''')
(D/'手册矛盾审查.md').write_text('''# HR8033 V0.41 协议参考审查

核对对象是用户提供手册，作为工程参考资料；以最新版C0要求和用户后续确认决定产品功能。C0只测电导率、温度并用RS485传输，最新电极要求是四电极K≈1、内置真四线Pt1000，并兼容两电极配对接线。手册中的水位、水压、盐度、密度、压力补偿、导气结构不是本产品功能，不复刻HR8033的厂家身份和性能宣称。兼容范围与拒绝照搬的项目详见HR_regs.csv；实际C0全部扩展地址以firmware/docs及firmware/README.md为准。

## 确认采用的线序与通信格式

红=电源正，黄=电源负，蓝=485A，绿=485B，屏蔽接壳体并按现场接地设计连接。电极域必须同时隔离电缆电源和485，不能因线色相同而连接两个地。A/B的电平极性仍应按实际收发器和主机确认。

默认9600bps、8N1。手册前面的通用RTU描述写11位字符（有校验），后面的明确出厂值是无校验1停止位，后者与用户C0要求一致。8N1每字10位；8O1/8E1/8N2每字11位。RTU帧间隔和UART配置必须同步变化，不能沿用B0固定8E1/11位的时间计算。

最小兼容功能为FC03读和FC10写。手册文字称“四种功能码”，表中仅列03/10，不能据此增加未定义的查询地址/读文件记录命令。CRC16在报文末尾低字节先发；16位寄存器的高字节先发。用户明确兼容的uint32电导值按高16位字在前。手册没有为所有浮点数建立一致可靠的字序，C0扩展float须独立明确字序，不能声称兼容未定义的HR浮点校准指令。

## 必须解决的手册矛盾

| 问题 | 手册证据 | C0处理 |
|---|---|---|
| 参数地址矛盾 | 表3地址0130、波特率0132、校验0134；写例却用0013/0014 | 按用户明确要求和表3选0x0130/0x0132/0x0134，不自动接受0013/0014别名 |
| 寄存器重叠 | 电导零偏0133长度2，占0133和0134；0134又是校验 | 不复制0133校准寄存器。K、分档/频率校准、温度增益偏移均在C0扩展区 |
| 未定义波特率编码 | 表3仅说明1=9600 | HR0132只接受已知1；其他速率只在独立文档的C0原生扩展编码提供，不能推断2/3等HR含义 |
| 温度示例算错10倍 | 表4定义int16/100，却写006C=10.80和FF94=−10.80 | 0x006C=108即1.08°C，0xFF94=−108即−1.08°C；±10.80应为0438/FBC8 |
| 默认串口与通用段落不一致 | 通用段写11位有校验，默认段与表3代码3明确8N1 | C0默认8N1，模式可选0=8O1、1=8E1、2=8N2、3=8N1 |
| 功能码数量不一致 | 宣称四种，但仅列03/10 | 只以明确定义和C0需要为准 |
| 读例从机/数量文字不一致 | 文字写从机95及4寄存器，实际帧02/0003 | 不把文字与帧混合造例；实际请求为从机2读取3字 |
| 电导单位/补偿语义不全 | 表4仅写uS，未明确T或25°C补偿 | 用户明确为整数µS/cm的κ25；扩展区同时给κT/κ25并带状态 |
| 序列号长度矛盾及重叠 | 0161长度16寄存器却说明16字节；按16字会与0169日期重叠 | 不照搬身份区；C0用独立版本/标识 |
| 浮点描述/字序不可靠 | 密度0.998示例7CEE3F7F暗示低字先；其他行混写浮点与补码 | 不复刻旧浮点校准布局，C0统一明确IEEE754字序 |

校验代码来源明确：0奇校验、1偶校验、2无校验两停止位、3无校验一停止位（默认）。B0原生波特率0=9600/1=19200等与HR“1=9600”不同，必须分成不同编码域，不能只把旧变量映射到新地址。

B0的旧0x0002浮点κ25占0x0002/0003、旧0x0006浮点原始电导占0006/0007，与HR温度0003和整数电导0006直接冲突。应整体迁移原生测量/参数区到C0扩展区；不能在相同地址叠加不同类型“别名”。未实现的水压水位地址不要返回虚构0，须按C0固件已定义的非法地址行为处理。

## 整数兼容输出的精度限制

HR电导兼容值用整数µS/cm表示。四舍五入的单独量化误差最多±0.5µS/cm（不含实际测量误差），相对误差上界为 `0.5/κ×100%`：

| 电导率 | 量化误差上界 |
|---|---:|
| 10µS/cm | ±5% |
| 50µS/cm | ±1% |
| 100µS/cm | ±0.5% |
| 2000µS/cm | ±0.025% |

因此兼容整数输出不能承载全10–2000µS/cm的±0.5%精度目标；50–100µS/cm处量化本身还可能吃完或超过原50–2000±0.5%目标。精度验收和新上位机必须读扩展float32的κT、κ25与有效/故障/nLF状态，不能通过偷偷改变兼容寄存器单位解决。温度兼容输出0.01°C步进的量化误差为±0.005°C，仍须和整链误差合并。

传感器故障、未校准、样本过期和nLF因子未可信启用时，不得以25°C或陈旧κ25伪装有效结果。C0兼容寄存器无效哨兵与饱和标志属于本设计补充，不是手册原生定义，外机应配套读取扩展状态。不能宣称旧HR软件只读整数就能识别全部新故障。

## 例帧CRC独立核验

下列手册给出的字节序列CRC确实匹配，但有效CRC不证明其中地址和说明正确：

| 帧体（不含CRC） | CRC在线字节 |
|---|---|
| 02 03 00 01 00 03 | 54 38 |
| 02 03 06 FF FF FF FF 01 2A | B5 F5 |
| 5F 10 00 13 00 02 04 00 01 00 01 | 17 5F |
| 5F 10 00 13 00 02 | BD 73 |

本审查已核对文档表格、字节算术与CRC；没有与真实HR8033仪表或最终C0硬件做互操作试验。不能声称已通过HR8033软件/设备兼容认证。手册的30mA、IP68、电导1%FS、温度±0.1°C是原厂原产品参数，不是本设计已验证数据。
''')
def crc16(d):
 c=0xffff
 for b in d:
  c ^= b
  for _ in range(8):c=(c>>1)^0xa001 if c&1 else c>>1
 return c
for raw,expected in [('02 03 00 01 00 03','54 38'),('02 03 06 FF FF FF FF 01 2A','B5 F5'),('5F 10 00 13 00 02 04 00 01 00 01','17 5F'),('5F 10 00 13 00 02','BD 73')]:
 c=crc16(bytes.fromhex(raw));assert bytes((c&255,c>>8))==bytes.fromhex(expected)
assert int.from_bytes(bytes.fromhex('006C'),'big',signed=True)/100==1.08
assert int.from_bytes(bytes.fromhex('FF94'),'big',signed=True)/100==-1.08
assert int.from_bytes(bytes.fromhex('FBC8'),'big',signed=True)/100==-10.8
print('Reference files generated; 4 CRC and 3 signed-temperature examples verified.')
