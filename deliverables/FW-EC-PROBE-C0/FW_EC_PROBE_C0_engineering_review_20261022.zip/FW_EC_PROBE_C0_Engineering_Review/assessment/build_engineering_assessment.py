#!/usr/bin/env python3
"""Reproduce C0 power estimate and protocol/mechanical source assessment.
Numbers explicitly marked assumptions are engineering allowances, not guarantees.
"""
import csv, hashlib, json, math
from pathlib import Path
D=Path(__file__).resolve().parent
ROOT=D.parent
ic=[
 dict(ref='U15,U18',part='AD8253ARMZ',quantity=2,rail='±15V',typical_W=.273,budget_W=.318,source='AD8253.txt:242-243',basis='per IC +IS 4.6 mA typ/5.3 max, -IS 4.5 typ/5.3 max; ±15 V'),
 dict(ref='U19',part='ADA4627-1ARZ',quantity=1,rail='±15V',typical_W=.210,budget_W=.225,source='ADA4627-1_4637-1.txt:214',basis='7.0 mA typ, 7.5 mA max; 30 V rail span'),
 dict(ref='U10,U13,U16,U21',part='ADA4638-1ARZ',quantity=4,rail='±15V',typical_W=.102,budget_W=.126,source='ADA4638-1.txt:136',basis='0.85 mA typ, 1.05 mA max per amplifier; 30 V operation'),
 dict(ref='U14',part='ADA4000-1ARZ',quantity=1,rail='±15V',typical_W=.0405,budget_W=.0495,source='ADA4000-1_4000-2_4000-4.txt:167',basis='1.35 mA typ, 1.65 mA max; ±15 V'),
 dict(ref='U9',part='ADA4077-2ARZ',quantity=1,rail='±15V',typical_W=.024,budget_W=.030,source='ADA4077-2.txt:145,224',basis='two amplifiers, 0.4 mA typ; use 0.5 mA/amplifier allowance (±15 V table max 0.45 mA)'),
 dict(ref='U11',part='ADG1419BRMZ',quantity=1,rail='±15V',typical_W=.001,budget_W=.003,source='ADG1419.txt:162-168',basis='allowance, not guaranteed: 58 µA typical at logic5 V; actual PWM logic3.3 V requires measurement; ignore near-zero rail-logic typical'),
 dict(ref='U17',part='ADG1211YRUZ',quantity=1,rail='±15V',typical_W=.0033,budget_W=.010,source='ADG1211.txt:170-176,Fig11',basis='220 µA typ IDD at logic5 V; conservative allowance includes logic current uncertainty at3.3 V; no max given'),
 dict(ref='U12,U20',part='ADA4528-2ARMZ',quantity=2,rail='3.3V',typical_W=.0198,budget_W=.02376,source='ADA4528-1_4528-2.txt:196,267',basis='four amplifiers: use1.5 mA typ/1.8mA max from5 V table as3.3 V budget; measured3.3 V needed'),
 dict(ref='U22',part='AD8542ARZ',quantity=1,rail='3.3V',typical_W=.000297,budget_W=.000429,source='AD8541_8542_8544.txt:124,177,230',basis='two amplifiers:45 µA typ/65 max from5 V table as3.3 V allowance'),
]
hvtyp=sum(x['typical_W'] for x in ic if x['rail']=='±15V')
hvmax=sum(x['budget_W'] for x in ic if x['rail']=='±15V')
lvtyp=sum(x['typical_W'] for x in ic if x['rail']=='3.3V')/3.3
lvmax=sum(x['budget_W'] for x in ic if x['rail']=='3.3V')/3.3
params={
 'typical':dict(hv_static_W=hvtyp,hv_output_reserve_W=.05,adp1613_efficiency=.80,mcu_A=.008,logic485_A=.00074,other3v3_A=.002,adp7118_iq_A=.00018,extra5V_W=.005,adp7104_iq_A=.001,adum4070_efficiency=.70,bus485_A=.015,buck_efficiency={'12':.86,'24':.82,'30':.80},series_diode_V=.35,lv_afe_A=lvtyp),
 'conservative':dict(hv_static_W=hvmax,hv_output_reserve_W=.15,adp1613_efficiency=.65,mcu_A=.015,logic485_A=.008,other3v3_A=.005,adp7118_iq_A=.00032,extra5V_W=.015,adp7104_iq_A=.0016,adum4070_efficiency=.55,bus485_A=.154,buck_efficiency={'12':.78,'24':.76,'30':.74},series_diode_V=.55,lv_afe_A=lvmax)
}
results={}
for case,p in params.items():
 hv=p['hv_static_W']+p['hv_output_reserve_W']
 i3=p['lv_afe_A']+p['mcu_A']+p['logic485_A']+p['other3v3_A']
 p5=hv/p['adp1613_efficiency']+5*(i3+p['adp7118_iq_A'])+p['extra5V_W']
 raw=p5*6.525/5+6.525*p['adp7104_iq_A']
 primary=raw/p['adum4070_efficiency']
 buck=primary+5*p['bus485_A']
 vin={}
 for v,e in p['buck_efficiency'].items():
  v=float(v); pin=buck/e*v/(v-p['series_diode_V']);vin[str(int(v))]={'estimate_input_W':pin,'estimate_input_mA':pin/v*1000}
 results[case]={'hv_load_W':hv,'3v3_A':i3,'isolated_5V_load_W':p5,'isolated_6V525_load_W':raw,'isolator_primary_5V_W':primary,'buck_total_load_W':buck,'buck_total_load_mA':buck/5*1000,'buck_1000mA_margin_mA':1000-buck/5*1000,'within_1000mA_nominal_rating':buck<=5,'adp7104_dissipation_W':p5/5*1.525+6.525*p['adp7104_iq_A'],'input_estimates':vin}
report={'status':'ENGINEERING_ESTIMATE_NOT_MEASURED_NOT_PRODUCTION_APPROVAL','revision':'C0-2026-10-22','decision':'Original30mA cancelled by user; preserve full RevA analog chain. Buck upgraded to LT8631 1A; conservative nominal margin only85mA, thermal derating and actual isolation power remain unverified.','architecture':'12..30V -> seriesSchottky -> LT8631 5V -> ADuM4070/JA4650 6.525V -> ADP7104 5V -> ADP1613 ±15V and ADP7118 3.3V; ADM2763E cable side directly on5V buck','ic_quiescent_items':ic,'assumptions':params,'results':results,'notes':['Typical is a modeled scenario at typical IC currents and assumed efficiencies, not datasheet-guaranteed total.','Conservative is an engineering envelope combining some datasheet max currents with assumed reserves/efficiency floors, not mathematically guaranteed worst case.','ADP1613 conversion efficiency is whole converter and includes switching controller current, not double-counted.','ADuM4070 conversion efficiency is whole isolation stage incl own controller current and transformer/rectifier losses, not double-counted.','ADM2763E dynamic145mA at5V,54ohm,500kbps plus9mA quiescent reserve conservatively summed for bus154mA; actual9600baud load/duty must be measured.','Input estimates use stated efficiency assumptions; satisfying 1A nominal arithmetic does not qualify thermal derating, startup, isolation transformer or transient behavior.','No real copper layout, transformer thermal/footprint or complete sensor assembly thermal test exists.']}
(D/'power_feasibility.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# C0 功耗与测温发热工程预算','', '状态：工程估算，未实测；不能据此批准投产。用户已选择保留 Rev A 模拟链并放宽原输入 30 mA 限制。后板候选已升级为 LT8631 5 V/1 A；保守模型电流约915 mA，名义余量约85 mA，热降额、启动及隔离级实际能力仍待验证，不据此发布生产 PCB。','', '## 架构与计算口径','', '`12–30 V → 反接肖特基 → LT8631 5 V → ADuM4070 + JA4650-BL 隔离 6.525 V → ADP7104-5.0 → 原 ADP1613 ±15 V、ADP7118-3.3`。ADM2763E 的电缆侧直接取 LT8631 的 5 V，逻辑侧取隔离 3.3 V。以 hardware/power/power_netlist.json 和 core/afe_reference 的当前电气网表为依据。','', '下表是 IC 静态功耗，均未包含输出负载。典型值来自所存原厂数据手册相应测试条件；预算列混合了手册最大值和明示的工程留量，不能把整列叫作保证最大值。±15 V 器件用 30 V 电源跨度计算，不能只乘 15 V。','', '| 位号 / 器件 | 典型 mW | 预算 mW | 依据与限制 |','|---|---:|---:|---|']
for x in ic: lines.append(f"| {x['ref']} {x['part']} | {x['typical_W']*1000:.3f} | {x['budget_W']*1000:.3f} | {x['basis']}；{x['source']} |")
lines += ['',f'±15 V 静态合计：**{hvtyp*1000:.1f} mW 典型 / {hvmax*1000:.1f} mW 预算**。仅两只 AD8253 与一只 ADA4627 已是 483 mW 典型 / 543 mW 手册表值组合；这不是完整 AFE 功耗。原 12 V × 30 mA = 360 mW，低于这三只芯片的典型静态需求，原连续 30 mA 目标不能与当前链路并存。此处是典型工程矛盾，不把典型值误说成器件保证最小值。','', '## 其他负载与转换损耗的显式假设','', '| 项目 | 典型场景 | 保守预算场景 |','|---|---|---|', '| 激励、电阻网络、运放输出额外 ±15 V 负载 | 50 mW | 150 mW；待按各增益、激励和短路保护实测 |','| ADP1613 整级效率 | 80% | 65%；均为设计假设，包含控制器/磁件/整流损耗 |','| ADuCM360 3.3 V | 8 mA | 15 mA 留量；手册16MHz全外设典型5.5mA，Flash编程另典型7mA，非最大值保证 |','| 其他3.3 V及中点/RTD等负载 | 2 mA | 5 mA；含200µA激励的总供电留量 |','| ADM2763E 逻辑侧 | 0.74 mA（10%发送，0.6mA接收/2mA发送典型） | 8 mA（发送最大表值） |','| ADM2763E 电缆侧 | 15 mA（5mA静态+100mA动态×10%发送） | 154 mA（9mA+145mA，在5V、54Ω、500kbps试验条件的保守组合） |','| ADP7118 静态电流 | 180 µA | 320 µA；手册200mA负载行的留量，不重复计负载电流 |','| 额外5V偏置及未单列无源损耗 | 5 mW | 15 mW |','| ADP7104 静态电流 | 1 mA | 1.6 mA；手册500mA负载行作留量 |','| ADuM4070 整级效率 | 70% | 55%；6.525V/此变压器无保证效率，含自身静态电流，不另加4/5mA重复计算 |','| LT8631效率，12/24/30V | 86/82/80% | 78/76/74%；均为设计假设，不能用原厂曲线代替本板试验 |','| 输入反接二极管压降 | 0.35 V | 0.55 V；实际型号温度/电流曲线待核 |','', '发送占空比由主机轮询/响应长度决定，10%仅用来给出一个可计算的典型工作场景，不是协议保证。500kbps重载电流用于保守电源留量，不意味着产品支持该波特率。没有以短路故障电流作为正常连续额定；短路需单独验证限流与温升。','', '计算：`P5V_ISO = P±15/η1613 + 5×(I3V3 + IQ7118) + P5V_extra`；`P6.525 = P5V_ISO×6.525/5 + 6.525×IQ7104`；`P5V_CABLE = P6.525/ηISO + 5×I485_bus`；`Pin = P5V_CABLE/ηbuck × Vin/(Vin−Vdiode)`。转换效率已含各自控制器电流。','', '| 节点 | 典型 W | 保守预算 W |','|---|---:|---:|']
for k,title in [('hv_load_W','±15V负载，含额外输出留量'),('isolated_5V_load_W','隔离5V总负载'),('isolated_6V525_load_W','隔离6.525V负载，含LDO损耗'),('isolator_primary_5V_W','隔离级一次侧5V需求'),('buck_total_load_W','LT8631总5V输出需求')]:lines.append(f"| {title} | {results['typical'][k]:.3f} | {results['conservative'][k]:.3f} |")
lines += ['', '| 输入电压 | 典型输入功耗 / 电流 | 保守预算需求功耗 / 电流 |','|---|---:|---:|']
for v in ['12','24','30']:
 a=results['typical']['input_estimates'][v];b=results['conservative']['input_estimates'][v]
 lines.append(f"| {v} V | {a['estimate_input_W']:.3f} W / {a['estimate_input_mA']:.1f} mA | {b['estimate_input_W']:.3f} W / {b['estimate_input_mA']:.1f} mA |")
lines += ['',f"LT8631 的 5V 电流需求：典型 **{results['typical']['buck_total_load_mA']:.0f} mA**，保守 **{results['conservative']['buck_total_load_mA']:.0f} mA**；1A名义额定余量分别为 {results['typical']['buck_1000mA_margin_mA']:.0f} mA 与 {results['conservative']['buck_1000mA_margin_mA']:.0f} mA。**保守输入数值是依赖效率假设的需求预算，不是已通过的实测工作点。** 原600mA候选因保守余量不足已退出；当前1A候选在该模型下名义余量约8.5%，仍须复核高温降额、启动、电感、变压器/隔离级与瞬态。若实测负载或降额不足，应增加功率余量，不削减原模拟链。",'', f"ADP7104 单独发热估算：典型 {results['typical']['adp7104_dissipation_W']:.3f} W，保守 {results['conservative']['adp7104_dissipation_W']:.3f} W；6.525→5V 线性降压的理想效率仅76.6%。此LDO是为了隔离开关噪声/稳定5V，不能说它提高能源效率。ADuM4070表中5V→5V最大输出400mA最低规格不自动保证6.525V此组合的输出能力；JA4650-BL真实脚号、尺寸、磁件损耗未拿到，是单独放行阻碍。",'', '## 温度精度与发热验证','', '电缆输入的大部分功率最终在探头、线缆及总线终端耗散。为保守热设计可先以全部输入功率作壳体发热上界，不得把它当已经测到的局部热源分布。下表仅演示 `ΔT=P×Rθ` 对未知热阻的敏感性，10/20/40K/W均为假设，不是HR8033壳体实测参数。实际浸水、灌封、流速和PCB离Pt1000距离会改变耦合。','', '| 假设整体热阻 | 典型30V输入功率温升 | 保守30V需求功率温升（未验证可连续提供） |','|---|---:|---:|']
for theta in [10,20,40]: lines.append(f"| {theta} K/W | {results['typical']['input_estimates']['30']['estimate_input_W']*theta:.1f} °C | {results['conservative']['input_estimates']['30']['estimate_input_W']*theta:.1f} °C |")
lines += ['', 'Pt1000 自身在200µA时，0°C/50°C耗散约0.040/0.048mW。没有探头的水中自热系数，不能把这换算成已保证的温升。仅两点静态电阻标定不能消除PCB经金属壳传来的温差或热惯性。热源应放后段，Pt1000放电极前端并减少沿线导热；不能用软件固定偏移替代整机验证。','', '±0.05°C必须在最终探头/灌封/壳体上验证：0/10/25/35/50°C恒温浴，与溯源参考温度计同深度同流场；分别12/24/30V、空闲/最密轮询、各增益/频率；记录上电及变工况后的漂移与稳定时间，比较断电/低占空与正常供电的自热偏差。参考温度计、浴均匀性/稳定性及安装误差须进入不确定度预算。未做此实验前温度±0.05°C及电导率±0.5%均为目标。','', '## 已核与未核','', '已核：原厂BOM/电气网表里的IC数量和电源域；上述数据手册静态电流行；计算可由同目录build_engineering_assessment.py重现；原30mA冲突、原600mA候选保守不足及当前1A候选的名义余量。','', '未核：实际本板效率、各测量档输出/无源损耗、极限485发送占空、工作温度全范围电流、变压器封装/磁损、启动和短路、PCB散热、探头热耦合、整链准确度、EMC与整机隔离耐压。没有示波器/功耗仪/恒温浴试验记录。']
(D/'power_feasibility.md').write_text('\n'.join(lines)+'\n')
