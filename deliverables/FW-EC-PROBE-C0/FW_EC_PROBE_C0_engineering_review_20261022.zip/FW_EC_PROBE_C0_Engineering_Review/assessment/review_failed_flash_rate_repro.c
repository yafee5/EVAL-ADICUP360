#include "tx_protocol.h"
#include <stdio.h>
#include <string.h>
static unsigned erases;
static bool rd(void*u,unsigned s,uint32_t o,void*d,size_t n){(void)u;(void)s;(void)o;memset(d,255,n);return true;}
static bool er(void*u,unsigned s){(void)u;(void)s;erases++;return true;}
static bool pr(void*u,unsigned s,uint32_t o,const void*d,size_t n){(void)u;(void)s;(void)o;(void)d;(void)n;return false;}
int main(void){tx_flash_ops_t f={rd,er,pr};tx_context_t c;unsigned char q[11]={1,16,1,48,0,1,2,0,42,0,0},r[256];tx_protocol_init(&c,&f,0,0);unsigned crc=tx_modbus_crc16(q,9);q[9]=crc;q[10]=crc>>8;tx_protocol_process(&c,q,11,r,sizeof(r),100);tx_protocol_process(&c,q,11,r,sizeof(r),101);printf("two failed program attempts 1 ms apart: erases=%u, final exception=%u (expected erases=1 and exception=6)\n",erases,r[2]);return (erases==1&&r[2]==6)?0:1;}
