# C0 公开 nLF 来源补充检索记录

检索日期：2026-10-22 UTC。结论：**本轮仍未取得可核验的 ISO 7888 / EN 27888 天然水 nLF 正式因子表或多项式，κ25 仍为实际功能阻断。没有向生产固件加入任何系数，没有用线性2%/°C替代，也没有购买标准、填表或联系厂家。** 检索不穷尽所有互联网资料；访问失败只说明本环境未取得内容，不能推出标准不存在或厂家不公开数据。

先阅读 `compensation/source_evidence.json`，避免把此前结果当新发现。此前 WTW《ProfiLine LF197》副本支持“天然水nLF、EN27888、0–35°C、20/25°C参考”等功能说明，不包含完整因子表；该记录未改变。此前已拒绝的 `limnotrack/limnosens` 无系数出处多项式，以及承认未读标准正文的学习笔记，本轮没有重新采用。

## 新增检索与内容检查

所有实际URL、UTC时间、HTTP状态、响应字节数和保存内容SHA256见 `nlf_public_search/attempts.json`、`github_attempts.json`、`more_attempts.json`、`candidate_attempt.json`、`final_attempts.json`。HTTP200网页保存在同目录，GitHub嵌入JSON也有提取副本。代理403表示CONNECT隧道未建立，未取得被请求站点正文，不是站点内容的404或无系数结论。

| 公开来源/查询URL | 实际响应与内容 | 判定 |
|---|---|---|
| https://api.github.com/search/repositories?q=%22ISO%207888%22&per_page=20 | 代理CONNECT403；无正文 | 不能用此结果评估资料存在性 |
| https://api.github.com/search/repositories?q=EN27888&per_page=20 | 代理CONNECT403 | 同上 |
| https://api.github.com/search/repositories?q=DIN38404&per_page=20 | 代理CONNECT403 | 同上 |
| https://api.github.com/search/repositories?q=conductivity%20temperature%20compensation&per_page=20 | 代理CONNECT403 | 同上 |
| https://grep.app/api/search?q=ISO%207888 | 代理CONNECT403 | 未完成公开代码索引搜索 |
| https://grep.app/api/search?q=EN27888 | 代理CONNECT403 | 同上 |
| https://html.duckduckgo.com/html/?q=ISO+7888+nonlinear+temperature+correction+table | 代理CONNECT403 | 未取得搜索结果 |
| https://www.bing.com/search?q=ISO+7888+nLF+temperature+coefficients | 代理CONNECT403 | 同上 |
| https://cdn.standards.iteh.ai/samples/14838/ | 代理CONNECT403；此为样本目录候选而非已知PDF文件 | 未取得标准正文/片段 |
| https://github.com/search?type=commits&q=%22EN%2027888%22 | HTTP200，1条提交；命中旧审查已排除的学习笔记 | 无因子来源 |
| https://github.com/search?type=commits&q=%22DIN%2038404%22 | HTTP200，0条提交 | 仅此提交索引无结果 |
| https://github.com/search?type=commits&q=%22conductivity%22%20%22nlf%22 | HTTP200，1条；USGS-CMG/stglib删除nLF数据列 | 进一步查正文，见下 |
| https://github.com/search?type=commits&q=%22ISO7888%22 | HTTP200，0条提交 | 不等于全站代码无资料 |
| https://github.com/search?type=commits&q=%22nonlinear%20temperature%20compensation%22 | HTTP200，2条；一条Microdrop提交，一条dbarnas/mooreasgd电导数据处理 | 前者标题未提供天然水nLF或标准数值来源，未作系数证据；后者进一步核查 |
| https://github.com/search?type=commits&q=%22nLF%22%20%22temperature%22 | HTTP200，2条无关气动/统计代码 | 排除 |
| https://github.com/search?type=commits&q=%22conductivity%22%20%22natural%20water%22 | HTTP200，2条其他研究/计算器修正记录 | 无标准数值表 |
| https://github.com/search?type=commits&q=%22conductivity%22%20%22ISO%22 | HTTP200，134条，实际检查首屏10条；多为热导/电磁各向同性模型，其中再命中旧limnosens | 没有从无关首屏推断全量无结果 |
| https://github.com/search?type=commits&q=%22EN27888%22 | HTTP200，0条提交 | 无新候选 |
| https://github.com/search?type=commits&q=%22Temperaturkompensation%22 | HTTP200，18条；首屏为蜂箱称重、压力等 | 没有明确标准nLF数值来源 |
| https://github.com/search?type=commits&q=%22DIN38404%22 | HTTP200，0条提交 | 无新候选 |
| https://github.com/search?type=commits&q=%221.37023%22 | HTTP200，42条；首屏全是CockroachDB问题号37023等噪声 | 没有找到可追溯温补系数来源 |
| https://github.com/search?type=commits&q=%22EN+27888%22+%22nlf%22 | HTTP200，0条提交 | 无新候选 |

另有两条早期Google请求均返回CONNECT403，没有正文，未将它们当作内容证据；实际URL为：

- https://www.google.com/search?q=ISO+7888+nonlinear+temperature+correction+factors+table+nLF+25+conductivity
- https://www.google.com/search?q=ISO+7888+nLF+polynomial+coefficients+0+35

这两条未纳入上述27次有结构化日志的补充统计。

## 两个新增开源候选的具体核验

1. **USGS-CMG/stglib**：

   https://github.com/USGS-CMG/stglib/commit/e4b5705b32a4898b721b73e4c715157ace886faf

   HTTP200。提交标题 `Another variable to drop (nLF conductivity)`。实际差异在 `stglib/exo.py`，向删除字段列表增加 `nLF_Cond_mS_per_cm`；原注释仅引述仪器手册“此约定通常用于德国市场”（pp.85）。没有nLF计算、因子表或ISO系数，不能因USGS组织名就把删除数据列的代码当算法出处。正文提取在 `more_07.html.json`。

2. **dbarnas/mooreasgd**：

   https://github.com/dbarnas/mooreasgd/commit/7ae7397d28661dc93860779d208925a7163691b8

   https://raw.githubusercontent.com/dbarnas/mooreasgd/7ae7397d28661dc93860779d208925a7163691b8/R/CT_cleanup.R

   两者HTTP200。取得完整2414字节R文件，SHA256 `c4c3ce1e9577d10a6ff4399e68086218bf3d9b5dfbca737718850b5389b869ff`。这是HOBO电导温度记录器数据清洗代码，非厂家标准实现。注释只链接 `https://www.aqion.de/site/112`；没有ISO/EN条款、表号、原始因子定义及适用区间。式子含1.37023、8.36×10⁻⁴及0.889，但**未采用、未转换成因子表**。按该代码的直接乘法语义，低于25°C会把电导读数继续向下调，是否把κ(T)/κ25定义反向还需原文澄清，更不能直接复制到生产温补。

   原链接 https://www.aqion.de/site/112 实际请求返回代理CONNECT403，未取得原页面内容，无法核实该式的来源、方向或与标准的关系。其数值看似平滑或25°C接近1，都不能证明它就是要求的ISO nLF。

## 既有 WTW 副本的边界

旧来源完整URL为：

https://raw.githubusercontent.com/zaindroid/hbrs_labs/ee2811e27b3cf083d550695d4fcf6e3e7bab1807/profiline_lf_197.pdf

本轮HTTP200，但读取在2,000,000字节截断，属于不完整PDF，已丢弃该部分文件，且日志明确`complete_source_obtained=false`。不将部分文件哈希充当完整文件哈希。旧审核所记完整源SHA256仍为 `c679eda09200c732b3d4d5fe68d444b416af817e7bec1df2d2657fdb9bd58277`；这里不宣称本轮重获完整原文或取得因子。旧手册只有功能/区间说明这一结论维持不变。

## 剩余的真正缺项

必须取得正式标准数据或厂商明确公开且可追溯的nLF数值表/多项式，确认因子定义（κ参考=κ(T)×f还是除以f）、20/25°C参考、温度与电导适用区间、单位和插值规则，并记录原文版本、条款/页码及完整来源SHA256。20°C基准转25°C应从该因子定义正确归一化，不能拿KCl标准液温度表、海水公式、无出处开源曲线或恒定2%/°C替代天然水ISO nLF。

本轮只读搜索到此收敛。`κ(T)`和实测温度可以继续验证，但正式温补数据未取得前，`κ25`保持NaN/无效标志，HR兼容整数κ25保持既定无效哨兵，不能把此版本称为已完成温补的变送器。
