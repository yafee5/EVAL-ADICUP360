#include "tx_protocol.h"
#include <stdio.h>
#include <string.h>
int main(void){tx_context_t c;tx_snapshot_t s;unsigned char q[8]={1,3,0,3,0,1,0,0},r[256];
tx_protocol_init(&c,0,0,0);memset(&s,0,sizeof(s));s.status=TX_STATUS_TEMP_VALID|TX_STATUS_EC_FAULT;s.temperature_c=21.25f;s.sample_time_ms=0;tx_protocol_set_snapshot(&c,&s);
unsigned crc=tx_modbus_crc16(q,6);q[6]=crc;q[7]=crc>>8;
size_t n=tx_protocol_process(&c,q,8,r,sizeof(r),11000);
printf("fresh valid RTD=21.25 C, stalled EC age=11000 ms: n=%zu HR0003=0x%02X%02X (expected 0x084D)\n",n,r[3],r[4]);return (n==7&&r[3]==0x08&&r[4]==0x4D)?0:1;}
