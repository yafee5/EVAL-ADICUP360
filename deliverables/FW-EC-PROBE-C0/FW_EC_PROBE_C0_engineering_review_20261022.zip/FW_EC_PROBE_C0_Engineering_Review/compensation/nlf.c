#include "nlf.h"
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <string.h>

typedef char nlf_requires_float32[(sizeof(float) == 4 && FLT_RADIX == 2 &&
                                  FLT_MANT_DIG == 24 && FLT_MAX_EXP == 128) ? 1 : -1];
typedef char nlf_requires_profile_188[(sizeof(nlf_profile_t) == 188) ? 1 : -1];

static uint32_t crc_byte(uint32_t crc, uint8_t byte)
{
    unsigned bit;
    crc ^= byte;
    for (bit = 0; bit < 8; ++bit) {
        crc = (crc >> 1) ^ ((crc & 1u) ? UINT32_C(0xEDB88320) : 0u);
    }
    return crc;
}

uint32_t nlf_factors_crc32(const float factors[NLF_FACTOR_COUNT])
{
    uint32_t crc = UINT32_C(0xFFFFFFFF);
    unsigned i, byte;
    if (factors == NULL) return 0u;
    for (i = 0; i < NLF_FACTOR_COUNT; ++i) {
        uint32_t bits;
        memcpy(&bits, &factors[i], sizeof(bits));
        for (byte = 0; byte < 4; ++byte)
            crc = crc_byte(crc, (uint8_t)(bits >> (8u * byte)));
    }
    return crc ^ UINT32_C(0xFFFFFFFF);
}

uint32_t nlf_validate_fields(const float factors[NLF_FACTOR_COUNT],
                             uint32_t source_id,
                             const uint8_t source_sha256[32],
                             uint32_t table_crc32,
                             uint32_t flags_verified)
{
    unsigned i;
    uint32_t flags = 0u;
    bool all_zero = true, all_ff = true;
    if (factors == NULL || source_sha256 == NULL || source_id == 0u ||
        flags_verified != NLF_VERIFIED_MAGIC) return NLF_FLAG_TABLE_UNVERIFIED;
    for (i = 0; i < 32; ++i) {
        all_zero = all_zero && source_sha256[i] == 0u;
        all_ff = all_ff && source_sha256[i] == 255u;
    }
    if (all_zero || all_ff) return NLF_FLAG_TABLE_UNVERIFIED;
    if (nlf_factors_crc32(factors) != table_crc32) flags |= NLF_FLAG_TABLE_CRC;
    for (i = 0; i < NLF_FACTOR_COUNT; ++i) {
        /* Loose engineering plausibility limits, not a normative ISO limit. */
        if (!isfinite(factors[i]) || factors[i] < 0.25f || factors[i] > 4.0f)
            flags |= NLF_FLAG_TABLE_INVALID;
        if (i > 0 && !(factors[i-1] > factors[i])) flags |= NLF_FLAG_TABLE_INVALID;
    }
    if (!isfinite(factors[25]) || fabs((double)factors[25] - 1.0) > 1e-6)
        flags |= NLF_FLAG_TABLE_INVALID;
    return flags;
}

bool nlf_compensate_from_fields(float kappa_T_uScm, float temperature_C,
                                 const float factors[NLF_FACTOR_COUNT],
                                 uint32_t source_id,
                                 const uint8_t source_sha256[32],
                                 uint32_t table_crc32,
                                 uint32_t flags_verified,
                                 float *kappa25_uScm, uint32_t *flags)
{
    uint32_t result_flags = nlf_validate_fields(factors, source_id, source_sha256,
                                               table_crc32, flags_verified);
    double factor, result;
    unsigned low;
    if (kappa25_uScm != NULL) *kappa25_uScm = NAN;
    if (kappa25_uScm == NULL || !isfinite(kappa_T_uScm) || kappa_T_uScm <= 0.0f ||
        !isfinite(temperature_C)) result_flags |= NLF_FLAG_INVALID_INPUT;
    if (isfinite(temperature_C) && (temperature_C < 0.0f || temperature_C > 35.0f))
        result_flags |= NLF_FLAG_TEMPERATURE_RANGE;
    if (result_flags != 0u) {
        if (flags != NULL) *flags = result_flags;
        return false;
    }
    if (temperature_C == 25.0f) {
        factor = 1.0; /* Exact reference identity, after profile validation. */
    } else if (temperature_C == 35.0f) {
        factor = (double)factors[35];
    } else {
        const double temp = (double)temperature_C;
        low = (unsigned)temp; /* Validated nonnegative input, below 35. */
        factor = (double)factors[low] +
                 ((double)factors[low+1] - (double)factors[low]) *
                 (temp - (double)low);
    }
    result = (double)kappa_T_uScm * factor;
    if (!isfinite(result) || result > FLT_MAX || result <= 0.0) {
        result_flags |= NLF_FLAG_INVALID_INPUT;
        if (flags != NULL) *flags = result_flags;
        return false;
    }
    *kappa25_uScm = (float)result;
    if (!isfinite(*kappa25_uScm) || *kappa25_uScm <= 0.0f) {
        *kappa25_uScm = NAN;
        result_flags |= NLF_FLAG_INVALID_INPUT;
        if (flags != NULL) *flags = result_flags;
        return false;
    }
    if (*kappa25_uScm < 60.0f || *kappa25_uScm > 1000.0f)
        result_flags |= NLF_FLAG_CONDUCTIVITY_RANGE;
    if (flags != NULL) *flags = result_flags;
    return true;
}

bool nlf_compensate_with_profile(const nlf_profile_t *profile,
                                  float kappa_T_uScm, float temperature_C,
                                  float *kappa25_uScm, uint32_t *flags)
{
    if (profile == NULL) {
        if (kappa25_uScm != NULL) *kappa25_uScm = NAN;
        if (flags != NULL) *flags = NLF_FLAG_TABLE_UNVERIFIED;
        return false;
    }
    return nlf_compensate_from_fields(kappa_T_uScm, temperature_C, profile->factor25,
                                       profile->source_id, profile->source_sha256,
                                       profile->table_crc32, profile->flags_verified,
                                       kappa25_uScm, flags);
}
