#ifndef FW_EC_TX_NLF_H
#define FW_EC_TX_NLF_H

/* Natural-water table evaluator. No ISO coefficients are fabricated here.
 * A traceable, reviewed profile must be provisioned before kappa25 is valid.
 * This header and implementation are C99 and use no dynamic allocation. */
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define NLF_FACTOR_COUNT 36u
#define NLF_VERIFIED_MAGIC UINT32_C(0x4E4C4631) /* ASCII NLF1 */

enum {
    NLF_FLAG_INVALID_INPUT = UINT32_C(1) << 0,
    NLF_FLAG_TEMPERATURE_RANGE = UINT32_C(1) << 1,
    NLF_FLAG_CONDUCTIVITY_RANGE = UINT32_C(1) << 2,
    NLF_FLAG_TABLE_UNVERIFIED = UINT32_C(1) << 3,
    NLF_FLAG_TABLE_CRC = UINT32_C(1) << 4,
    NLF_FLAG_TABLE_INVALID = UINT32_C(1) << 5
};

/* Same 188-byte data content as the flattened tx_params fields agreed with
 * the Modbus/storage module. Do not cast an unrelated structure to this type.
 * Use nlf_compensate_from_fields() to avoid copying the profile on MCU stacks. */
typedef struct {
    float factor25[NLF_FACTOR_COUNT]; /* T=0,1,...,35 C; k25=kT*factor25[T] */
    uint32_t source_id;              /* zero means not provisioned */
    uint8_t source_sha256[32];       /* hash of the reviewed source artifact */
    uint32_t table_crc32;            /* canonical little-endian 36 float32 */
    uint32_t flags_verified;         /* NLF_VERIFIED_MAGIC only after review */
} nlf_profile_t;

/* Standard CRC32: reflected polynomial EDB88320, init/xor FFFFFFFF.
 * Input bytes are each IEEE754 float32 bit pattern in little-endian order,
 * independent of the endianness of the host doing this computation. */
uint32_t nlf_factors_crc32(const float factors[NLF_FACTOR_COUNT]);

/* Returns zero only when profile metadata, CRC and numerical conditions pass.
 * Structural checking verifies data integrity; it does not authenticate an ISO
 * source or certify the water composition. Review the source before setting
 * flags_verified, and protect all fields by the configuration journal CRC. */
uint32_t nlf_validate_fields(const float factors[NLF_FACTOR_COUNT],
                             uint32_t source_id,
                             const uint8_t source_sha256[32],
                             uint32_t table_crc32,
                             uint32_t flags_verified);

/* Diagnostic flags are local to this module; application maps them to its
 * system status bits. Flags are overwritten, not ORed with incoming contents.
 * Returns true when a finite kappa25 was computed. Outside 0..35 C no
 * extrapolation occurs: false + NaN + TEMPERATURE_RANGE. If kappa25 is outside
 * 60..1000 uS/cm the value is still computed, true + CONDUCTIVITY_RANGE.
 * All unverified/default profiles return false + NaN even at exactly 25 C. */
bool nlf_compensate_from_fields(float kappa_T_uScm, float temperature_C,
                                 const float factors[NLF_FACTOR_COUNT],
                                 uint32_t source_id,
                                 const uint8_t source_sha256[32],
                                 uint32_t table_crc32,
                                 uint32_t flags_verified,
                                 float *kappa25_uScm, uint32_t *flags);

bool nlf_compensate_with_profile(const nlf_profile_t *profile,
                                  float kappa_T_uScm, float temperature_C,
                                  float *kappa25_uScm, uint32_t *flags);

#ifdef __cplusplus
}
#endif
#endif
