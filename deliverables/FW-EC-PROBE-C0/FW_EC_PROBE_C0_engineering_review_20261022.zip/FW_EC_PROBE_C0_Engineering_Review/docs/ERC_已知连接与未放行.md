# 原生ERC的已知连接与未放行状态

总电气工程的原始ERC报告保留在 `hardware/native/erc.json`。没有为得到0错误而禁用电源输出冲突规则，也没有将全部IC引脚定义为被动。

ADuCM360 的 DVDD_REG（7）与 AVDD_REG（18）均按稳压输出建模，原 Rev A 将它们连在一起，原厂 ADuCM360/361 Rev D 引脚表也明确要求：

> This pin must be connected to DGND via a 470 nF capacitor and to Pin 18, AVDD_REG.

原厂PDF随包保存在 `references/analog_datasheets/ADuCM360_361_RevD.pdf`，对应本地提取文档约1114行。图中保留原两只470nF及原相连关系。KiCad因此产生一项 `power_out` 与 `power_out` 的规则冲突，这是有来源说明的预期连接，不应通过断开这两脚来消除。

另外电缆屏蔽/金属壳网CHASSIS只有一个板内端点，保留单次全局标签警告；并未因此把壳体接到电极测量地。

最终生产审查需要决定该特定连接的有依据规则处理并保留原始报告。当前仍为1项原始ERC错误和1项警告，**没有宣称满足用户要求的整套ERC零错误**。后板未布出、前板仍缺线，其他制造和整机验证缺项另见交付状态。
