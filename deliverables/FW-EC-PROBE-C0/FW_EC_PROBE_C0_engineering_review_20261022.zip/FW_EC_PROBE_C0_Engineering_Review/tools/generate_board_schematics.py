#!/usr/bin/env python3
"""Create separate per-board schematic projects for honest PCB parity checks."""
import importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('c0native',ROOT/'tools/generate_native.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
groups=m.load_groups()
for name,out,selected in [
    ('FW_EC_FRONTEND_C0_LAYOUT_DRAFT',ROOT/'hardware/frontend',{k:groups[k] for k in ('afe','core')}),
    ('FW_EC_POWER_C0_ELECTRICAL_DRAFT',ROOT/'hardware/power/native',{'power':groups['power']})]:
    out.mkdir(parents=True,exist_ok=True)
    pro=out/(name+'.kicad_pro');prior=pro.read_bytes() if pro.exists() else None
    m.NAME=name;m.OUT=out;m.native_schematics(selected)
    if prior is not None:pro.write_bytes(prior)
    # These libraries are local to each board's own project.
    f=out/'fp-lib-table';text=f.read_text()
    text=text.replace('${KIPRJMOD}/../frontend/C0Frontend.pretty','${KIPRJMOD}/C0Frontend.pretty' if 'FRONTEND' in name else '${KIPRJMOD}/../../frontend/C0Frontend.pretty')
    text=text.replace('${KIPRJMOD}/../power/C0Power.pretty','${KIPRJMOD}/../C0Power.pretty' if 'POWER' in name else '${KIPRJMOD}/../power/C0Power.pretty')
    f.write_text(text)
