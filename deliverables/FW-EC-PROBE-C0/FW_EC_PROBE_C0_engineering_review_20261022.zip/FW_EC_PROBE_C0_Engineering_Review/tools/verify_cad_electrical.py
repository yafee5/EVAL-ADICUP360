#!/usr/bin/env python3
"""Compare actual KiCad-exported pin nets to the source electrical transcription."""
from pathlib import Path
import json,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]/'hardware/native'
actual={}
r=ET.parse(ROOT/'FW_EC_PROBE_C0.net.xml').getroot()
expected=json.loads((ROOT/'merged_components.json').read_text())
for net in r.findall('nets/net'):
    for n in net.findall('node'):actual[(n.attrib['ref'],n.attrib['pin'])]=net.attrib['name']
differences=[]
for ref,part in expected.items():
    for pn,net in part['pins'].items():
        if net is None:continue
        if actual.get((ref,pn),'').lstrip('/')!=net:
            differences.append({'reference':ref,'pin':pn,'expected':net,'actual':actual.get((ref,pn))})
physical=[n for n in r.findall('components/comp') if not n.attrib['ref'].startswith('#')]
missing=sorted(set(expected)-{n.attrib['ref'] for n in physical})
extra=sorted({n.attrib['ref'] for n in physical}-set(expected))
result={'component_count':len(physical),'connected_pin_count':len(actual),'pin_net_differences':differences,
        'missing_components':missing,'extra_components':extra,'pass':not(differences or missing or extra),
        'scope':'Actual KiCad XML versus reviewed pin-net JSON. Does not certify transcription correctness, physical isolation, PCB DRC, fit or metrology.'}
(ROOT/'netlist_parity_review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result['pass'] else 1)
