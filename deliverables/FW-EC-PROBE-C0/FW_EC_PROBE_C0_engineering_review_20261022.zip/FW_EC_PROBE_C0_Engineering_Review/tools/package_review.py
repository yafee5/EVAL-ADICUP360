#!/usr/bin/env python3
"""Archive the current engineering state; assert software provenance and zip CRCs."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'probe_c0_release';OUT.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((ROOT/'firmware/build/manifest.json').read_text())
bad=[]
for group,base in [('source_files',ROOT),('build_inputs',ROOT/'firmware'),('vendor_header_dependencies',ROOT/'firmware'),('review_and_host_check_inputs',ROOT),('files',ROOT/'firmware/build')]:
    for name,expected in m.get(group,{}).items():
        f=base/name
        if not f.exists() or digest(f)!=expected:bad.append(str(f.relative_to(ROOT)))
if bad:raise RuntimeError('Firmware provenance mismatch: '+str(bad))
excluded_dirs={'__pycache__','control','models','.git'}
excluded_names={'C0_engineering_review_body.pdf','review_failed_flash_rate_repro','review_legacy_temp_repro','layout_debug.json','freerouting.json'}
excluded_suffixes={'.pyc','.o','.kicad_prl','.lck','.FCBak'}
files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if any(a in excluded_dirs for a in rel.parts) or p.name in excluded_names or p.suffix in excluded_suffixes:continue
    if p.name.startswith('~') or p.name.endswith('~'):continue
    if 'build' in rel.parts and p.suffix=='' and p.name not in ('Makefile',):continue
    files.append(p)
rows=[{'file':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]
manifest={'product':'FW-EC-PROBE-C0','state':'ENGINEERING_REVIEW_NOT_FOR_FABRICATION',
          'generated_at_utc':datetime.now(timezone.utc).isoformat(),'files':rows,
          'excluded':'caches, host executables, object files and router runtime controls; historical DSN/SES and EXPERIMENT boards retained for reproducibility, not selected for fabrication',
          'firmware_source_and_image_hashes_match':True,'production_release':False}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
name='FW_EC_PROBE_C0_engineering_review_20261022.zip';archive=OUT/name
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        info=zipfile.ZipInfo('FW_EC_PROBE_C0_Engineering_Review/'+str(p.relative_to(ROOT)))
        info.date_time=datetime.fromtimestamp(p.stat().st_mtime).timetuple()[:6]
        info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        z.writestr(info,p.read_bytes())
    z.writestr('FW_EC_PROBE_C0_Engineering_Review/package_manifest.json',manifest_bytes)
with zipfile.ZipFile(archive) as z:
    failed=z.testzip()
    if failed:raise RuntimeError('ZIP CRC failed: '+failed)
copies={
 'FW_EC_PROBE_C0_BOM_RFQ.xlsx':'bom/FW_EC_PROBE_C0_采购清单_工程询价未放行.xlsx',
 'FW_EC_PROBE_C0_project_procurement.csv':'bom/FW_EC_PROBE_C0_project_procurement.csv',
 'FW_EC_PROBE_C0_review.pdf':'docs/FW_EC_PROBE_C0_engineering_review_NOT_FOR_FABRICATION.pdf',
 'FW_EC_PROBE_C0_modbus_registers.csv':'firmware/protocol/register_map.csv',
 'fw_ec_probe_c0_bench.hex':'firmware/build/fw_ec_probe_c0_bench.hex',
 'FW_EC_PROBE_C0_wiring_DRAFT.pdf':'docs/C0_wiring_DRAFT.pdf',
 'delivery_status.json':'docs/delivery_status.json',
 'README.md':'README.md'}
for target,source in copies.items():
    p=ROOT/source
    if not p.exists():raise FileNotFoundError(p)
    shutil.copyfile(p,OUT/target)
artifacts=sorted([archive]+[OUT/n for n in copies])
(OUT/'SHA256SUMS.txt').write_text(''.join(digest(p)+'  '+p.name+'\n' for p in artifacts))
validation={'zip_entries':len(files)+1,'zip_crc':'PASS','firmware_hash_validation':'PASS',
            'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive),
            'production_release':False,'files':[{'file':p.name,'bytes':p.stat().st_size,'sha256':digest(p)} for p in artifacts]}
(OUT/'package_validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(validation,ensure_ascii=False))
