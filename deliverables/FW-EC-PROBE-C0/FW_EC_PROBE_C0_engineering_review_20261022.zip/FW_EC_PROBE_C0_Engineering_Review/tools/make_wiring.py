#!/usr/bin/env python3
"""Document the agreed C0 interface; no assertion of routed/qualified hardware."""
from pathlib import Path
from html import escape
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs';OUT.mkdir(exist_ok=True)
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1800" height="1150" viewBox="0 0 1800 1150">',
   '<rect width="1800" height="1150" fill="#f8fafc"/>',
   '<style>text{font-family:DejaVu Sans,sans-serif;fill:#172b4d} .small{font-size:17px} .body{font-size:21px} .title{font-size:31px;font-weight:700} .head{font-size:25px;font-weight:700} .note{font-size:19px;fill:#9a3412}</style>']
def text(t,x,y,cl='body'):s.append(f'<text x="{x}" y="{y}" class="{cl}">{escape(t)}</text>')
def box(x,y,w,h,c):s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{c}" stroke="#64748b" stroke-width="2"/>')
def line(x,y,xx,yy,c='#2563eb',dash=False):s.append(f'<path d="M{x},{y} L{xx},{yy}" fill="none" stroke="{c}" stroke-width="3"'+(' stroke-dasharray="9,7"' if dash else '')+'/>')
text('FW-EC-PROBE C0 | connection plan / engineering draft',35,50,'title')
text('Interfaces agreed; PCB routing, enclosure fit and assembled isolation are not released.',35,85,'note')
box(35,125,330,565,'#ecfdf5');box(475,125,560,565,'#eff6ff');box(1120,125,640,565,'#fff7ed')
text('Wetted probe',65,165,'head');text('Frontend / electrode domain',505,165,'head');text('Rear power + isolated RS-485',1150,165,'head')
text('4 electrodes, K about 1 / cm',65,205);text('ADuCM360 + original Rev A AFE',505,205);text('Cable side and electrode side separate',1150,205,'small')
texts=[('Outer electrode F+','J5.1  Force+'),('Inner electrode S+','J5.2  Sense+'),('Inner electrode S-','J5.3  Sense-'),('Outer electrode F-','J5.4  Force-')]
for i,(a,b) in enumerate(texts):
 y=260+i*55;text(a,65,y);text(b,505,y);line(345,y-7,490,y-7)
text('J5.5 = isolated measurement GND',505,470,'small');text('NOT the cable shield / metal shell',505,495,'note')
text('Pt1000: four separate wires',65,500);text('Two-wire mode: bridge BOTH pairs',505,545,'small')
text('JP401: F+ to S+; JP402: F- to S-',505,573,'small');text('Leave both OPEN for four electrodes.',505,602,'small')
for i,(a,b) in enumerate([('TF+','J3.1 Force high'),('TS+','J3.2 Sense high'),('TS-','J3.3 Sense low'),('TF-','J3.4 Force low / bias')]):
 y=540+i*35;text(a,80,y,'small');text(b,120,y,'small')
text('Sensor lead colours depend on the supplier.',65,675,'small')
text('No Pt100 / 2-wire / 3-wire RTD mode.',505,650,'small')
for i,(pin,n) in enumerate([(1,'5V isolated (VCC)'),(2,'power return PGND'),(3,'UART TX from MCU'),(4,'UART RX to MCU'),(5,'RS485 DE'),(6,'RS485 /RE'),(7,'3.3V filtered'),(8,'quiet return GND')]):
 y=255+i*41;text(f'{pin}: {n}',1150,y,'body')
text('J402 (frontend) <-> J202 (rear), pin-for-pin',1150,625,'small')
text('Pins 5 + 6 share MCU P0.5. Do not short 2 + 8 here.',1150,655,'small')
line(1035,240,1120,240);line(1035,600,1120,600)
box(35,725,1000,350,'#ffffff');box(1120,725,640,350,'#ffffff')
text('Minimum SWD pads: J401',65,770,'head')
text('1 = VTref 3.3 V; 2 = SWDIO; 3 = SWCLK; 4 = /RESET; 5 = GND',65,815)
text('VTref is a debugger reference, not an external power input.',65,855,'small')
text('An earthed debugger can bypass electrode-domain isolation during bench work.',65,893,'small')
text('Burn / calibrate through the electrode side; verify the complete isolation setup.',65,931,'small')
text('Only conductivity, temperature and Modbus RTU. No LCD, keys, buzzer or LEDs.',65,1000,'small')
text('External cable: J201',1150,770,'head')
for i,(t,c) in enumerate([('1 RED: +12 to +30 V DC','#dc2626'),('2 YELLOW: supply return','#ca8a04'),('3 BLUE: RS-485 A','#2563eb'),('4 GREEN: RS-485 B','#16a34a'),('5 SHIELD: metal housing only','#64748b')]):
 y=814+i*43;line(1150,y-7,1190,y-7,c);text(t,1210,y,'body')
text('Default 9600 / 8N1. 120 ohm termination is optional.',1150,1050,'small')
text('Do not connect cable return / shield to electrode GND or PGND.',35,1120,'note')
s.append('</svg>');(OUT/'C0_wiring_DRAFT.svg').write_text('\n'.join(s))
(OUT/'接线说明.md').write_text('''# C0 接线说明（接口约定，未放行生产）

图中位号属于 C0 新工程，不是旧 Rev A 下载口/接插件编号。图纸为电气接口约定，不能代替最终 PCB 装配图。

| 接口 | 引脚顺序 | 说明 |
|---|---|---|
| J5 电导池 | 1 F+、2 S+、3 S−、4 F−、5 测量侧 GND | 四电极外侧激励、内侧测压；5 不是电缆屏蔽壳 |
| J3 Pt1000 | 1 Force high、2 Sense high、3 Sense low、4 Force low/bias | 四根独立导线；4 不直接接地；采购时要求真正四线引出 |
| J402 ↔ J202 | 1 VCC/5V_ISO、2 PGND、3 TX、4 RX、5 DE、6 /RE、7 过滤后3.3V、8 GND | 内部逐脚连接；5/6 由同一 MCU 输出驱动；后板不额外短接2/8 |
| J401 SWD | 1 VTref、2 SWDIO、3 SWCLK、4 /RESET、5 GND | 最小焊盘组，不是原20脚J4；VTref不能作为外部电源输入 |
| J201 电缆 | 1红12–30V、2黄返回、3蓝485A、4绿485B、5屏蔽接壳 | 电缆电源和485均在隔离边界外侧；不可直接连测量地 |

四极模式：JP401/JP402 均开路。两极模式：两对桥均闭合，F+/S+ 接同一电极，F−/S− 接另一电极。两种模式均须重新确认探头常数、频率/增益标定；软件不能代替实际短接。

终端 JP201 默认开路，仅处于总线物理端点时闭合，把120Ω接入A/B。A/B命名存在厂家习惯差异，整机联调以确认的差分极性/实际通信为准。

烧录器的USB地可能通过电脑地把测量侧重新接到外部设备，台架测试须把调试链路计入隔离检查。SWD不得作为跨隔离供电连接。先完成烧录、校准和复测，再做最终密封。

正式封装前仍需核对探头厂家线色、PCB第一脚标识、连接器防呆/高度、引线应力释放与整体防水。图中接口并未完成实物连通性验证。
''')
print(OUT/'C0_wiring_DRAFT.svg')
