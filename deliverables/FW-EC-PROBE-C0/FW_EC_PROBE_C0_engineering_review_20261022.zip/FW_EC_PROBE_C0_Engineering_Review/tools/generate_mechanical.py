#!/usr/bin/python3
"""C0 frontend mechanical review, explicitly not enclosure fit signoff.

Reads the real native PCB and placement envelopes. STEP body heights and tube
inside diameter are declared assumptions, never manufacturer component models.
Run with system Python (pcbnew and FreeCAD bindings are installed there).
"""
from pathlib import Path
import csv, hashlib, json, math, os, subprocess, sys
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'mechanical';OUT.mkdir(exist_ok=True)
FRONT=ROOT/'hardware/frontend'
os.environ.setdefault('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/c0-mech-cache')
os.environ.setdefault('XDG_DATA_HOME','/tmp/c0-mech-data')
sys.path.extend(['/usr/lib/freecad-python3/lib','/usr/lib/freecad/lib'])
import FreeCAD as App
import Part
import pcbnew as pcb

RADIAL_CLEARANCE_MM=.5  # Design allowance, not a user-provided dimension.
ASSUMED_ID_MM=28.0
OD_MM=30.0
HEIGHT_OVERRIDES={'J402':6.0}  # Illustrative connector reserve, not max height.
FEATURE_REFS={'J3','J5','J401','JP401','JP402'}

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dims(shape):
    b=shape.BoundBox
    return dict(x_mm=b.XLength,y_mm=b.YLength,z_mm=b.ZLength,
                xmin_mm=b.XMin,ymin_mm=b.YMin,zmin_mm=b.ZMin,
                xmax_mm=b.XMax,ymax_mm=b.YMax,zmax_mm=b.ZMax)
def feature(doc,name,label,shape):
    obj=doc.addObject('Part::Feature',name);obj.Label=label;obj.Shape=shape
    return obj
def export_checked(objects,path):
    Part.export(objects,str(path))
    reread=Part.Shape();reread.read(str(path))
    if reread.isNull() or not reread.isValid():raise RuntimeError('Invalid STEP '+str(path))
    return {'file':path.name,'sha256':sha(path),'bytes':path.stat().st_size,
            'step_readback_valid':reread.isValid(),'solid_count':len(reread.Solids),
            'bounds':dims(reread)}
def tx(x,y,s,size=19,color='#1f2937',weight='normal'):
    return f'<text x="{x}" y="{y}" font-family="DejaVu Sans, sans-serif" font-size="{size}" fill="{color}" font-weight="{weight}">{escape(str(s))}</text>'
def line(x1,y1,x2,y2,color='#475569',width=2,dash=''):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{width}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>'
def rect(x,y,w,h,fill,stroke='#334155',opacity=1):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" fill-opacity="{opacity}" stroke="{stroke}" stroke-width="2"/>'

def build():
    statusfile=FRONT/'placement_status.json';envfile=FRONT/'component_envelopes.json'
    if not statusfile.exists() or not envfile.exists():
        raise SystemExit('WAITING: actual frontend placement_status.json and component_envelopes.json not yet generated; no STEP fabricated.')
    status=json.loads(statusfile.read_text());env=json.loads(envfile.read_text())
    pcbfile=FRONT/(status['board']+'.kicad_pcb')
    board=pcb.LoadBoard(str(pcbfile));edge=board.GetBoardEdgesBoundingBox()
    ox=pcb.ToMM(edge.GetX());oy=pcb.ToMM(edge.GetY())
    # Edge bounding boxes include line stroke; use the actual Edge.Cuts segment
    # coordinates for this rectangular frontend rather than its 0.05mm stroke.
    edgepts=[]
    for d in board.GetDrawings():
        if d.GetLayer()==pcb.Edge_Cuts:
            edgepts.extend([(pcb.ToMM(d.GetStart().x),pcb.ToMM(d.GetStart().y)),
                            (pcb.ToMM(d.GetEnd().x),pcb.ToMM(d.GetEnd().y))])
    ox=min(x for x,y in edgepts);oy=min(y for x,y in edgepts)
    width=max(x for x,y in edgepts)-ox;length=max(y for x,y in edgepts)-oy
    thick=pcb.ToMM(board.GetDesignSettings().GetBoardThickness())
    if abs(width-status['size_mm'][0])>.001 or abs(length-status['size_mm'][1])>.001:
        raise RuntimeError('Actual PCB edges disagree with placement status')
    bare=Part.makeBox(width,length,thick)
    drills=[];seen=set()
    for fp in board.GetFootprints():
        for p in fp.Pads():
            ds=p.GetDrillSize();dx=pcb.ToMM(ds.x);dy=pcb.ToMM(ds.y)
            if dx<=0 or dy<=0:continue
            if abs(dx-dy)>1e-5:raise RuntimeError('Oval hole needs explicit STEP treatment')
            x=pcb.ToMM(p.GetPosition().x)-ox;y=pcb.ToMM(p.GetPosition().y)-oy
            key=(round(x,6),round(y,6),round(dx,6))
            if key in seen:continue
            seen.add(key);drills.append({'reference':fp.GetReference(),'pad':p.GetNumber(),'x_mm':x,'y_mm':y,'diameter_mm':dx})
            bare=bare.cut(Part.makeCylinder(dx/2,thick+2,App.Vector(x,y,-1)))
    for v in board.GetTracks():
        if not isinstance(v,pcb.PCB_VIA):continue
        if v.GetViaType()!=pcb.VIATYPE_THROUGH:
            raise RuntimeError('Blind/buried via needs explicit STEP hole depth treatment')
        d=pcb.ToMM(v.GetDrillValue());x=pcb.ToMM(v.GetPosition().x)-ox;y=pcb.ToMM(v.GetPosition().y)-oy
        key=(round(x,6),round(y,6),round(d,6))
        if d<=0 or key in seen:continue
        seen.add(key);drills.append({'reference':'VIA','pad':'','x_mm':x,'y_mm':y,'diameter_mm':d})
        bare=bare.cut(Part.makeCylinder(d/2,thick+2,App.Vector(x,y,-1)))
    if not bare.isValid() or len(bare.Solids)!=1:raise RuntimeError('Bare PCB solid invalid')
    doc=App.newDocument('C0MechanicalReview')
    bareobj=feature(doc,'FrontendBarePCB','ACTUAL_FRONTEND_OUTLINE_AND_NATIVE_HOLES_NO_COPPER',bare)
    bare_report=export_checked([bareobj],OUT/'C0_frontend_actual_bare_PCB.step')
    objects=[bareobj];modeled=[];pts=[(0,0),(width,0),(0,thick),(width,thick)]
    assembled_y_min=min([0.]+[a['bbox_xy_mm'][1] for a in env])
    assembled_y_max=max([length]+[a['bbox_xy_mm'][3] for a in env])
    assembled_length=assembled_y_max-assembled_y_min
    top=0.;bottom=0.
    for a in env:
        ref=a['reference']
        if ref in FEATURE_REFS:continue  # Bare lands are not purchased bodies.
        x0,y0,x1,y1=a['bbox_xy_mm']
        height=HEIGHT_OVERRIDES.get(ref,a['height_envelope_assumed_mm'])
        z=thick if a['side']=='top' else -height
        box=Part.makeBox(x1-x0,y1-y0,height,App.Vector(x0,y0,z))
        obj=feature(doc,'ENV_'+ref,'ASSUMED_HEIGHT_'+ref+'_'+str(height)+'mm',box)
        objects.append(obj);modeled.append({'reference':ref,'side':a['side'],'height_mm':height,
            'height_manufacturer_verified':False,'bbox_xy_mm':a['bbox_xy_mm'],
            'geometry':'PCB library XY envelope extruded by assumed body height, not manufacturer STEP'})
        if a['side']=='top':top=max(top,height)
        else:bottom=max(bottom,height)
        for xx in (x0,x1):
            for zz in (z,z+height):pts.append((xx,zz))
    env_report=export_checked(objects,OUT/'C0_frontend_ASSUMED_HEIGHT_component_envelopes.step')
    totalheight=top+thick+bottom
    rect_diameter=math.hypot(width,totalheight)
    rect_required=rect_diameter+2*RADIAL_CLEARANCE_MM
    # More exact corner-envelope result with fixed lateral centring. It remains
    # hypothetical because the component heights themselves are assumptions.
    zlo=min(z for x,z in pts);zhi=max(z for x,z in pts)
    def radius(c):return max(math.hypot(x-width/2,z-c) for x,z in pts)
    for i in range(100):
        a=zlo+(zhi-zlo)/3;b=zhi-(zhi-zlo)/3
        if radius(a)<=radius(b):zhi=b
        else:zlo=a
    cz=(zlo+zhi)/2;r=radius(cz)
    corner_required=2*r+2*RADIAL_CLEARANCE_MM
    tube=Part.makeCylinder(OD_MM/2,assembled_length,App.Vector(width/2,assembled_y_min,cz),App.Vector(0,1,0)).cut(
        Part.makeCylinder(ASSUMED_ID_MM/2,assembled_length,App.Vector(width/2,assembled_y_min,cz),App.Vector(0,1,0)))
    tubeobj=feature(doc,'AssumedTube','ASSUMED_ID28_OD30_NOT_USER_PROVIDED_INTERNAL_GEOMETRY',tube)
    tube_report=export_checked([*objects,tubeobj],OUT/'C0_frontend_ASSUMED_ID28_context_NOT_FIT_SIGNOFF.step')
    doc.recompute();doc.saveAs(str(OUT/'C0_frontend_mechanical_review.FCStd'))
    # A source-backed outer drawing plus a conspicuously hypothetical cross-section.
    svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1240" viewBox="0 0 1440 1240">',
         '<rect width="1440" height="1240" fill="#f8fafc"/>',
         tx(45,52,'C0 mechanical review — ASSUMED HEIGHTS / ASSUMED ID',29,'#991b1b','bold'),
         tx(45,84,'NOT enclosure fit signoff. Manufacturer heights, tube ID and usable cavity length are missing.',20,'#991b1b')]
    cx,cy,scale=365,420,18
    svg.append(f'<circle cx="{cx}" cy="{cy}" r="{OD_MM*scale/2}" fill="#d1d5db" stroke="#334155" stroke-width="3"/>')
    svg.append(f'<circle cx="{cx}" cy="{cy}" r="{ASSUMED_ID_MM*scale/2}" fill="white" stroke="#d97706" stroke-width="3" stroke-dasharray="10 6"/>')
    # Centred bounding rectangle is conservative and easier to audit than a
    # visually convenient choice of hidden individual component locations.
    h=totalheight*scale;w=width*scale;yt=cy-h/2
    svg.extend([rect(cx-w/2,yt,w,top*scale,'#fecaca',opacity=.65),
                rect(cx-w/2,yt+top*scale,w,thick*scale,'#166534'),
                rect(cx-w/2,yt+(top+thick)*scale,w,bottom*scale,'#bfdbfe',opacity=.65),
                line(cx-320,cy,cx+320,cy,'#94a3b8',1,'5 4'),
                tx(55,735,f'PCB width {width:.2f} mm; thickness {thick:.2f} mm. Height envelope: +{top:.2f} / -{bottom:.2f} mm.',20)])
    notes=[('Outer diameter',f'{OD_MM:.1f} mm — HR8033 drawing'),
           ('Tube inner diameter',f'{ASSUMED_ID_MM:.1f} mm — ILLUSTRATION ONLY'),
           ('Component heights','ALL provisional; BNX 9.5 mm unverified'),
           ('Full rectangular envelope',f'{width:.2f} x {totalheight:.2f} mm'),
           ('Bare geometric diameter',f'sqrt(W² + H²) = {rect_diameter:.3f} mm'),
           ('Radial assembly allowance',f'{RADIAL_CLEARANCE_MM:.2f} mm — design assumption'),
           ('Minimum ID, rectangular bound',f'{rect_required:.3f} mm incl. allowance'),
           ('Minimum ID, actual XY corners',f'{corner_required:.3f} mm incl. allowance'),
           ('Excluded from the model','Wire bend, solder protrusion, support, coating'),
           ('Fit verdict','UNVERIFIED; actual housing ID unavailable')]
    for i,(a,b) in enumerate(notes):
        yy=175+i*48;svg.append(tx(720,yy,a,18,'#475569','bold'));svg.append(tx(720,yy+23,b,18,'#991b1b' if i in (1,2,9) else '#111827'))
    svg.extend([tx(45,795,'Axial space check from the supplied outer drawing',25,'#111827','bold'),
                tx(45,825,'82.2 mm is a drawing interpretation (24.2 + 32 + 26), NOT a measured electronics-cavity start.',18),
                tx(45,850,'Rear connector intrusion and the power-board length are unknown. No full assembly length is certified.',18)])
    ax=100;ay=920;s=5.5
    svg.append(rect(ax,ay,210.2*s,70,'#e5e7eb'))
    svg.append(rect(ax,ay,82.2*s,70,'#cbd5e1'))
    svg.append(rect(ax+82.2*s,ay+10,assembled_length*s,50,'#86efac'))
    remaining=210.2-82.2-assembled_length
    svg.extend([tx(ax,ay-12,'Front region interpretation: 82.2 mm',17),
                tx(ax+82.2*s+8,ay+41,f'Frontend XY envelope: {assembled_length:.3f} mm',18),
                tx(ax,ay+104,'Outer overall length 210.20 ± 1 mm (manual)',19),
                tx(ax,ay+138,f'Bare PCB {length:.2f} mm; with connector overhang {assembled_length:.3f} mm. Outer remainder {remaining:.3f} mm.',19,'#991b1b'),
                tx(ax,ay+168,'That remainder must still contain the rear board, connector intrusion, board gap, wiring and supports.',18),
                tx(45,1198,'STEP labels distinguish actual PCB outline from ASSUMED_HEIGHT component envelopes and ASSUMED_ID28 tube.',17),'</svg>'])
    svgfile=OUT/'C0_cross_section_ASSUMPTIONS_NOT_FIT_SIGNOFF.svg';svgfile.write_text('\n'.join(svg))
    cmd=['inkscape',str(svgfile),'--export-type=pdf','--export-filename='+str(OUT/'C0_cross_section_ASSUMPTIONS_NOT_FIT_SIGNOFF.pdf')]
    run=subprocess.run(cmd,capture_output=True,text=True)
    if run.returncode:raise RuntimeError(run.stderr)
    pngcmd=['inkscape',str(svgfile),'--export-type=png','--export-width=1440','--export-filename='+str(OUT/'C0_cross_section_ASSUMPTIONS_NOT_FIT_SIGNOFF.png')]
    pngrun=subprocess.run(pngcmd,capture_output=True,text=True)
    if pngrun.returncode:raise RuntimeError(pngrun.stderr)
    with (OUT/'component_height_assumptions.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['reference','side','height_mm','height_manufacturer_verified','bbox_xy_mm','geometry']);w.writeheader();w.writerows(modeled)
    audit={'status':'MECHANICAL_ENGINEERING_REVIEW_NOT_FIT_SIGNOFF','frontend_actual_outline_mm':[width,length,thick],
           'actual_native_pcb':str(pcbfile.relative_to(ROOT)),'actual_native_pcb_sha256':sha(pcbfile),
           'source_status_sha256':sha(statusfile),'source_envelopes_sha256':sha(envfile),
           'frontend_XY_assembly_length_mm':assembled_length,
           'frontend_assembly_y_interval_mm':[assembled_y_min,assembled_y_max],
           'modeled_component_count':len(modeled),'pcb_drilled_hole_count':len(drills),'drilled_holes':drills,
           'all_component_heights_manufacturer_verified':False,'height_overrides_assumptions_mm':HEIGHT_OVERRIDES,
           'top_height_assumed_mm':top,'bottom_height_assumed_mm':bottom,'rectangular_height_mm':totalheight,
           'radial_assembly_allowance_assumed_mm':RADIAL_CLEARANCE_MM,
           'rectangle_min_ID_assumed_heights_mm':rect_required,'corner_min_ID_assumed_heights_mm':corner_required,
           'tube_OD_from_reference_mm':OD_MM,'tube_ID_assumed_mm':ASSUMED_ID_MM,
           'actual_tube_ID_mm':None,'actual_electronics_cavity_length_mm':None,
           'reference_outer_overall_length_mm':210.2,'front_region_interpretation_mm':82.2,
           'remaining_outer_length_if_frontend_starts_at_82p2_mm':remaining,
           'rear_board_length_mm':None,'complete_assembly_STEP_complete':False,'existing_housing_fit_proven':False,
           'step_exports':[bare_report,env_report,tube_report],
           'pdf_export':{'command':cmd,'exit_code':run.returncode,'stderr':run.stderr},
           'png_export':{'command':pngcmd,'exit_code':pngrun.returncode,'stderr':pngrun.stderr},
           'manufacturer_BNX_download_attempt':{'url':'https://www.murata.com/en-us/products/productdata/8796778004510/QNFH9101.pdf?1496719830000','result':'proxy CONNECT 403; no PDF obtained; 9.5mm remains unverified'},
           'unverified':['Manufacturer maximum component heights including BNX025H01 and connector',
                         'Rear board/T201 physical pin map, dimensions and assembly envelope',
                         'User housing inner diameter, straight cavity length and connector/support intrusion',
                         'Cable strain relief, bend radii, solder/lead protrusion, coating and tolerances',
                         'Actual machined enclosure fit and ingress protection']}
    (OUT/'mechanical_validation.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:audit[k] for k in ('status','frontend_actual_outline_mm','modeled_component_count','rectangle_min_ID_assumed_heights_mm','existing_housing_fit_proven')},ensure_ascii=False))
    App.closeDocument(doc.Name)
    # These are generator-created backup copies, not deliverable source files.
    for p in OUT.glob('C0_frontend_mechanical_review.*.FCBak'):p.unlink()

if __name__=='__main__':build()
