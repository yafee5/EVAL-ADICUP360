#!/usr/bin/env python3
"""Export actual KiCad review PDFs/ERC/netlists; preserve all nonzero findings."""
from pathlib import Path
import os,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
env=dict(os.environ)
env.setdefault('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config')
env.setdefault('XDG_CACHE_HOME','/tmp/c0-export-cache')
env.setdefault('XDG_DATA_HOME','/tmp/c0-export-data')
projects=[('hardware/native','FW_EC_PROBE_C0'),('hardware/frontend','FW_EC_FRONTEND_C0_LAYOUT_DRAFT'),('hardware/power/native','FW_EC_POWER_C0_ELECTRICAL_DRAFT')]
logs=[]
for folder,name in projects:
    d=ROOT/folder;s=d/(name+'.kicad_sch')
    pdf=d/(name+'_electrical_DRAFT.pdf');net=d/(name+'.net.xml');erc=d/'erc.json'
    for command in [
        ['kicad-cli','sch','export','pdf',str(s),'-o',str(pdf)],
        ['kicad-cli','sch','export','netlist',str(s),'--format','kicadxml','-o',str(net)],
        ['kicad-cli','sch','erc',str(s),'--format','json','-o',str(erc)]]:
        r=subprocess.run(command,cwd=d,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        logs.append({'command':command,'exit_code':r.returncode,'output':r.stdout})
        if r.returncode:raise RuntimeError(r.stdout)
    report=json.loads(erc.read_text());v=[v for sh in report['sheets'] for v in sh['violations']]
    print(name,'ERC errors',sum(x['severity']=='error' for x in v),'warnings',sum(x['severity']=='warning' for x in v))
    sources=[s]+[d/(group+'.kicad_sch') for group in ('afe','core','power') if (d/(group+'.kicad_sch')).exists()]
    (d/'electrical_export_manifest.json').write_text(json.dumps({'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'outputs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (pdf,net,erc)},'production_release':False,'erc_raw_error_count':sum(x['severity']=='error' for x in v),'erc_raw_warning_count':sum(x['severity']=='warning' for x in v)},indent=2)+'\n')
(ROOT/'docs/electrical_export_log.json').write_text(json.dumps(logs,indent=2)+'\n')
