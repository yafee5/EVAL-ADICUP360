#!/usr/bin/python3
"""Build editable C0 electrical CAD from reviewed, pin-level source transcriptions.

This generator does not certify PCB layout, enclosure fit, or metrology accuracy.
Every electrical pin retains its reviewed electrical type; ERC is not suppressed.
"""
import json, math, os, uuid, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'hardware/native'
OUT.mkdir(parents=True,exist_ok=True)
NAME='FW_EC_PROBE_C0'
UID=lambda s:str(uuid.uuid5(uuid.NAMESPACE_URL,'fw-ec-probe-c0/'+s))
RID=UID('root')
def q(s): return json.dumps(str(s),ensure_ascii=False)
def eff(s=1,hide=False):
    return f'(effects (font (size {s} {s}))'+(' (hide yes)' if hide else '')+')'
def pcb_feature(ref,a):
    mpn=str(a.get('mpn') or '')
    return a.get('is_pcb_feature',False) or 'PCB feature' in mpn or 'no purchased' in mpn or mpn.startswith(('WIRE_SOLDER_PADS','CUSTOM_SOLDER_BRIDGE','PCB_SOLDER_BRIDGE'))
def normalize(n):
    return {'AD8253_WR0':'AD8253_WR0_n','AD8253_WR1':'AD8253_WR1_n',
            'PGND_ISO':'PGND','GND_ISO':'GND','5V_ISO':'VCC',
            '3V3_ISO':'+3.3V','RS485_DE':'RS485_DE_REn','RS485_nRE':'RS485_DE_REn',
            '485_DE':'RS485_DE_REn','485_nRE':'RS485_DE_REn',
            'DE':'RS485_DE_REn','nRE':'RS485_DE_REn'}.get(n,n)
def load_groups():
    groups={}
    for name,path in [('afe','afe_reference/afe_netlist.json'),('core','core_reference/core_netlist.json'),('power','power/power_netlist.json')]:
        f=ROOT/'hardware'/path
        if not f.exists(): continue
        d=json.loads(f.read_text()); parts=d['components']
        if isinstance(parts,list): parts={p.get('ref',p.get('reference')):p for p in parts}
        if name=='core':
            add=ROOT/'hardware/frontend/additional_components_for_schematic.json'
            if add.exists():
                for ref,part in json.loads(add.read_text()).items():
                    if ref in parts:raise ValueError('Additional ref already present '+ref)
                    part=dict(part)
                    part.setdefault('pin_names',{str(k):str(v) for k,v in part['pins'].items()})
                    part.setdefault('pin_types',{str(k):'passive' for k in part['pins']})
                    part.setdefault('source_page','C0 functional interface / electrode bridges')
                    parts[ref]=part
        groups[name]={}
        for ref,part in parts.items():
            a=dict(part);a['reference']=ref
            a['pins']={str(k):normalize(v) if v is not None else None for k,v in a['pins'].items()}
            for pn in a.get('no_connect_pins',a.get('unconnected_pins',[])): a['pins'].setdefault(str(pn),None)
            a['value']=a.get('value') or a.get('mpn') or ref
            a['footprint']=a.get('footprint') or a.get('recommended_footprint') or ''
            a['pin_names']={str(k):str(v) for k,v in a.get('pin_names',{}).items()}
            a['pin_types']={str(k):str(v) for k,v in a.get('pin_types',{}).items()}
            for pn in a['pins']:
                if pn not in a['pin_types']:raise ValueError(f'{ref}.{pn}: missing reviewed pin electrical type')
                a['pin_names'].setdefault(pn,pn)
            groups[name][ref]=a
    env=ROOT/'hardware/frontend/component_envelopes.json'
    if env.exists():
        # Use the precise same footprint identifiers as the generated PCB.
        for row in json.loads(env.read_text()):
            ref=row['reference']
            for group in ('afe','core'):
                if ref in groups.get(group,{}):groups[group][ref]['footprint']=row['footprint']
    return groups

def symbol_geometry(a):
    pins=sorted(a['pins'],key=lambda n:int(n) if n.isdigit() else 999)
    if len(pins)==2:
        return {'1':(-7.62,0,0),'2':(7.62,0,180)},(-3.81,2.54,3.81,-2.54)
    half=math.ceil(len(pins)/2); bodyy=max(5.08,(half+1)*1.27)
    geom={}
    for i,pn in enumerate(pins):
        right=i>=half;j=i-half if right else i
        geom[pn]=(17.78 if right else -17.78, round((half-1)*1.27-j*2.54,4),180 if right else 0)
    return geom,(-15.24,bodyy,15.24,-bodyy)

def libsym(ref,a):
    g,b=symbol_geometry(a);x1,y1,x2,y2=b;key='P_'+ref
    body=f'(rectangle (start {x1} {y1}) (end {x2} {y2}) (stroke (width 0.254) (type default)) (fill (type background)))'
    if len(g)==2 and ref.startswith('C'):
        body=''.join(f'(polyline (pts (xy {xx} -2.54) (xy {xx} 2.54)) (stroke (width 0.254) (type default)) (fill (type none)))' for xx in [-.635,.635])
    s=f'(symbol "C0:{key}" (pin_names (offset 0.508)) (exclude_from_sim no) (in_bom yes) (on_board yes) (property "Reference" {q(ref.rstrip("0123456789"))} (at 0 {y1+2.54} 0) {eff()}) (property "Value" {q(a["value"])} (at 0 {y2-2.54} 0) {eff()}) (symbol "{key}_0_1" {body}) (symbol "{key}_1_1" '
    for pn,(x,y,ang) in g.items():
        length=6.985 if ref.startswith('C') and len(g)==2 else 3.81 if len(g)==2 else 2.54
        s+=f'(pin {a["pin_types"][pn]} line (at {x} {y} {ang}) (length {length}) (name {q(a["pin_names"][pn])} {eff(.8)}) (number {q(pn)} {eff(.8)}))'
    return s+'))'
def glabel(net,x,y,right=False):
    # Label anchor is connected to the pin by an explicit wire.
    return f'(global_label {q(net)} (shape bidirectional) (at {x} {y} {180 if right else 0}) (effects (font (size .85 .85)) (justify {"right" if right else "left"})) (uuid {UID(f"label/{net}/{x}/{y}")}))'
def wire(x1,y1,x2,y2,key):
    return f'(wire (pts (xy {x1} {y1}) (xy {x2} {y2})) (stroke (width 0) (type default)) (uuid {UID(key)}))'
def native_schematics(groups):
    rootitems=[]; index={};allparts={};all_lib=[]
    for gi,(group,parts) in enumerate(groups.items()):
        sid=UID('sheet/'+group);fname=group+'.kicad_sch';lib=[];items=[]
        # Larger ICs first, then passives. A0 source pages retain readable pin labels.
        ordered=sorted(parts.items(),key=lambda kv:(-len(kv[1]['pins']),kv[0][0],int(re.sub(r'\D','',kv[0]) or '0')))
        x=110.;y=65.;rowh=0.
        for ref,a in ordered:
            if ref in allparts:raise ValueError('Duplicate reference '+ref)
            allparts[ref]=a;g,b=symbol_geometry(a)
            w=190.5 if len(g)>2 else 101.6;h=max(30.48,(b[1]-b[3])+20.32)
            if x+w/2>1140:x=110.;y+=rowh+7.62;rowh=0
            if y+h/2>790:raise ValueError('Schematic page overflow '+group)
            x=round(x/1.27)*1.27;y=round(y/1.27)*1.27
            lib.append(libsym(ref,a));all_lib.append(lib[-1])
            symid=UID('symbol/'+ref);index[ref]={'sheet':group,'sheet_uuid':sid,'symbol_uuid':symid,'x':x,'y':y}
            props=f'(property "Reference" {q(ref)} (at {x} {y-b[1]-3.81} 0) {eff(1.2)}) (property "Value" {q(a["value"])} (at {x} {y-b[3]+3.81} 0) {eff(.95)}) (property "Footprint" {q(a["footprint"])} (at {x} {y} 0) {eff(hide=True)}) (property "MPN" {q(a.get("mpn") or "HOLD-MPN")} (at {x} {y} 0) {eff(hide=True)})'
            inbom='no' if pcb_feature(ref,a) else 'yes'
            items.append(f'(symbol (lib_id "C0:P_{ref}") (at {x} {y} 0) (unit 1) (in_bom {inbom}) (on_board yes) (dnp no) (uuid {symid}) {props} (instances (project "{NAME}" (path "/{RID}/{sid}" (reference {q(ref)}) (unit 1)))))')
            for pn,net in a['pins'].items():
                dx,dy,ang=g[pn];px=round(x+dx,5);py=round(y-dy,5)
                if net is None:
                    items.append(f'(no_connect (at {px} {py}) (uuid {UID(ref+"nc"+pn)}))');continue
                right=ang==180;ex=round(px+(12.7 if right else -12.7),5)
                items.extend([wire(px,py,ex,py,ref+'wire'+pn),glabel(net,ex,py,right)])
            x+=w;rowh=max(rowh,h)
        sheet=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {sid}) (paper "A0") (title_block (title "FW-EC-PROBE C0 {group}: electrical reconstruction") (date "2026-10-22") (rev "C0-DRAFT") (company "Engineering draft; PCB not released")) (lib_symbols {"".join(lib)}) {"".join(items)} (embedded_fonts no))'
        (OUT/fname).write_text(sheet)
        sx=40;sy=45+gi*35
        rootitems.append(f'(sheet (at {sx} {sy}) (size 65 20) (stroke (width 0.1524) (type solid)) (fill (color 0 0 0 0)) (uuid {sid}) (property "Sheetname" "{group}" (at {sx} {sy-1.27} 0) {eff()}) (property "Sheetfile" "{fname}" (at {sx} {sy+21.27} 0) {eff()}) (instances (project "{NAME}" (path "/{RID}" (page "{gi+2}")))))')
    notes=['FW-EC-PROBE C0 / ELECTRICAL DRAFT - NOT FOR FABRICATION',
           'Original analog values and pin nets transcribed from ADI CN0359 Rev A.',
           'Latest user change: retain continuous Rev A analog chain; relax 30mA limit.',
           'Four EC electrodes + four Pt1000 wires; cable power and RS485 both isolated.',
           'PCB routing / clearance / physical fit / metrology are separate acceptance checks.',
           'HOLD precision MPNs and transformer mechanical data must not be treated as qualified.',
           'ISO7888 nLF production factors missing: default k25 invalid, explicit status flag.']
    for i,s in enumerate(notes):rootitems.append(f'(text {q(s)} (at 30 {165+i*5.08} 0) (effects (font (size 1 1)) (justify left)) (uuid {UID(s)}))')
    # Flags indicate external source/returns and power rails produced through
    # passive rectification/filtering, which ERC cannot infer. No physical part.
    flaglib='(symbol "C0:PWR_FLAG" (pin_names (offset 0)) (exclude_from_sim no) (in_bom no) (on_board no) (property "Reference" "#FLG" (at 0 2.54 0) '+eff()+') (property "Value" "PWR_FLAG" (at 0 5.08 0) '+eff()+') (symbol "PWR_FLAG_1_1" (pin power_out line (at 0 0 90) (length 0) (name "pwr" '+eff()+') (number "1" '+eff()+'))))'
    flag_nets=['GND','PGND','VCC','+3.3V','+15V','-15V'] if 'power' not in groups else ['GND','PGND','GND_CABLE','VIN_PROTECTED','+3.3V','+15V','-15V','ISO_RAW6V5'] if 'core' in groups else ['GND','PGND','GND_CABLE','VIN_PROTECTED','+3.3V','ISO_RAW6V5']
    for i,net in enumerate(flag_nets):
        x=round((145+(i%4)*34.29)/1.27)*1.27;y=round((45+(i//4)*17.78)/1.27)*1.27;ref=f'#FLG{i+1:02}'
        rootitems.append(f'(symbol (lib_id "C0:PWR_FLAG") (at {x} {y} 0) (unit 1) (in_bom no) (on_board no) (dnp no) (uuid {UID(ref)}) (property "Reference" "{ref}" (at {x} {y-5.08} 0) {eff(.8)}) (property "Value" "PWR_FLAG" (at {x} {y-2.54} 0) {eff(.8)}) (instances (project "{NAME}" (path "/{RID}" (reference "{ref}") (unit 1)))))')
        rootitems.append(glabel(net,x,y))
    root=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {RID}) (paper "A4") (title_block (title "FW-EC-PROBE C0 engineering draft") (date "2026-10-22") (rev "C0-DRAFT")) (lib_symbols {flaglib}) {"".join(rootitems)} (embedded_fonts no))'
    (OUT/(NAME+'.kicad_sch')).write_text(root)
    all_lib.append(flaglib)
    (OUT/'C0.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor") '+''.join(all_lib).replace('(symbol "C0:','(symbol "')+')')
    (OUT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "C0") (type "KiCad") (uri "${KIPRJMOD}/C0.kicad_sym") (options "") (descr "Reviewed C0 electrical pins")))')
    (OUT/'cad_index.json').write_text(json.dumps(index,indent=2))
    (OUT/'merged_components.json').write_text(json.dumps(allparts,ensure_ascii=False,indent=2))
    libs=sorted({a['footprint'].split(':')[0] for a in allparts.values() if ':' in a['footprint']})
    entries=[]
    for lib in libs:
        uri={'C0Frontend':'${KIPRJMOD}/../frontend/C0Frontend.pretty','C0Power':'${KIPRJMOD}/../power/C0Power.pretty'}.get(lib,'${KICAD9_FOOTPRINT_DIR}/'+lib+'.pretty')
        entries.append(f'(lib (name {q(lib)}) (type "KiCad") (uri {q(uri)}) (options "") (descr "C0 footprint reference; unresolved entries remain HOLD"))')
    (OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) '+''.join(entries)+')')
    (OUT/(NAME+'.kicad_pro')).write_text(json.dumps({'meta':{'filename':NAME+'.kicad_pro','version':1}},indent=2))
    print('Generated editable schematics:',len(groups),'sheets,',len(allparts),'components')
    return allparts,index

if __name__=='__main__':
    groups=load_groups();native_schematics(groups)
