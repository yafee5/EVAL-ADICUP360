#!/usr/bin/env python3
"""Create an evidence-led review PDF/status. Never invent absent CAM or passes."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re,csv
from html import escape
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
import pymupdf as fitz

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'docs';OUT.mkdir(exist_ok=True)
def read(p,default=None):
    f=ROOT/p
    return json.loads(f.read_text()) if f.exists() else default
def checks(p):
    d=read(p,{})
    if not d:return None
    vs=[v for sh in d.get('sheets',[]) for v in sh.get('violations',[])]
    if 'sheets' not in d:vs=d.get('violations',[])
    return {'errors':sum(v.get('severity')=='error' for v in vs),'warnings':sum(v.get('severity')=='warning' for v in vs),
            'unconnected':len(d.get('unconnected_items',[])),'parity':len(d.get('schematic_parity',[])),
            'source':p,'design_source':d.get('source'),'reported_at':d.get('date'),'pass':not vs and not d.get('unconnected_items') and not d.get('schematic_parity')}
erc=checks('hardware/native/erc.json')
front_drc=sorted([p for p in (ROOT/'hardware/frontend').glob('drc*.json') if not any(s in p.name.lower() for s in ('experiment','trial'))],key=lambda p:p.stat().st_mtime)
drc=checks(str(front_drc[-1].relative_to(ROOT))) if front_drc else None
bom=read('bom/bom_validation.json',{})
fw=read('firmware/build/firmware_validation.json',{})
mech=read('mechanical/mechanical_validation.json',{})
status={
 'product':'FW-EC-PROBE-C0','release_status':'ENGINEERING_REVIEW_NOT_FOR_FABRICATION',
 'generated_at_utc':datetime.now(timezone.utc).isoformat(),'production_release':False,
 'items':[
  {'item':'原生KiCad电气工程','status':'工程重建完成，未生产放行','evidence':'hardware/native；总210位号/前165/后45；逐脚网表对照报告'},
  {'item':'全部PCB','status':'未完成','evidence':'前板16.5×105mm布局草案，走线/DRC见实际报告；后板无PCB'},
  {'item':'ERC零错误','status':'未完成','evidence':erc},
  {'item':'DRC零错误与整板电气一致性','status':'未完成','evidence':drc},
  {'item':'可下单Gerber/顶底锡膏/分钻/IPC356/CPL','status':'未完成，未发布C0生产CAM','evidence':'随包ADI原Gerber仅作来源比对；不可当C0制造文件'},
  {'item':'叠层说明','status':'候选要求已列；板厂压合表未确认','evidence':'docs/叠层与制造边界.md'},
  {'item':'BOM/大陆采购入口/删除与差异表','status':'工程询价版已完成；HOLD未放行','evidence':{k:bom.get(k) for k in ('component_rows','physical_parts_per_unit','pcb_feature_rows','consolidated_electronic_lines','external_procurement_lines','hold_lines','deletion_rows')}},
  {'item':'固件源码和HEX/协议','status':'主机验证通过；台架候选，未上新板','evidence':{'all_checks_passed':fw.get('all_checks_passed'),'report':'firmware/build/firmware_validation.json'}},
  {'item':'ISO7888 nLF成品温补','status':'未完成；正式因子缺失，κ25默认无效','evidence':'compensation/ 与 assessment/nlf_source_search_C0.md'},
  {'item':'STEP与装壳截面','status':'前板裸板与假设包络完成；全机适配未完成','evidence':{'report':'mechanical/mechanical_validation.json','front_length_mm':mech.get('frontend_XY_assembly_length_mm'),'verified_fit':False}},
  {'item':'接线图','status':'接口约定已完成；未实物联线验证','evidence':'docs/C0_wiring_DRAFT.pdf'},
  {'item':'原始ADI资料','status':'Rev A官方PDF/BOM/Gerber/固件包归档；原生ADI CAD ZIP未取得','evidence':'references/C0_reference_manifest.json'},
  {'item':'实物精度/温升/耐压/EMC/密封','status':'全部未验证','evidence':'assessment/误差预算与验收方案.md 与 power_feasibility.md'}
 ],
 'blocking_missing_information':['T201 manufacturer mechanical drawing and physical pin map','L202 exact land pattern','U203 current RD8-4 exposed-pad drawing','qualified precision resistor and full probe MPNs','reviewed traceable ISO7888 nLF factors','actual housing inner dimensions and net cavity','complete PCB routing/ERC/DRC and hardware validation']}
(OUT/'delivery_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
with (OUT/'delivery_status.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['项目','状态','证据']);w.writerows((x['item'],x['status'],json.dumps(x['evidence'],ensure_ascii=False) if not isinstance(x['evidence'],str) else x['evidence']) for x in status['items'])
lines=['# C0 交付状态：工程评审版，不能直接下单','', '生产放行：否。未完成项明确如下；软件测试、静态封装检查和STEP重读均不等于整机实测。','', '|项目|状态|','|---|---|']
lines.extend('|'+x['item']+'|'+x['status']+'|' for x in status['items'])
def counts_text(c):
    return '未取得报告' if c is None else f"错误{c['errors']}、警告{c['warnings']}、未连接{c['unconnected']}、原理图一致性差异{c['parity']}；报告：{c['source']}"
lines+=['','总工程ERC原始计数：'+counts_text(erc),'','前板最新DRC原始计数：'+counts_text(drc),'',
 'ADuCM360 7/18两稳压输出相连来自原图和数据手册要求，原始ERC规则冲突保留说明，未全局关规则或把输出谎称被动脚。',
 '', '厂家当前可审图/询价，不得把原ADI或旧B0 Gerber作为C0下单文件。最终需全部CAD、器件料号、机械、布线及实验验收闭环后另发生产版本。']
(OUT/'交付状态.md').write_text('\n'.join(lines)+'\n')

pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
pdfmetrics.registerFontFamily('STSong-Light',normal='STSong-Light',bold='STSong-Light',italic='STSong-Light',boldItalic='STSong-Light')
styles={
 'body':ParagraphStyle('C0body',fontName='STSong-Light',fontSize=9.2,leading=13.5,spaceAfter=5,wordWrap='CJK'),
 'h1':ParagraphStyle('C0h1',fontName='STSong-Light',fontSize=17,leading=23,spaceBefore=7,spaceAfter=10,wordWrap='CJK',textColor=colors.HexColor('#17365d')),
 'h2':ParagraphStyle('C0h2',fontName='STSong-Light',fontSize=12,leading=17,spaceBefore=9,spaceAfter=6,wordWrap='CJK',textColor=colors.HexColor('#17365d')),
 'cell':ParagraphStyle('C0cell',fontName='STSong-Light',fontSize=8.2,leading=11.8,wordWrap='CJK')}
def para(t,style='body'):
    t=escape(t)
    t=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',t)
    t=re.sub(r'`([^`]+)`',r'\1',t)
    t=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'\1 (\2)',t)
    return Paragraph(t,styles[style])
story=[]
def add_md(path):
    text=(ROOT/path).read_text();table=[];pending=[]
    def flush_para():
        if pending:story.append(para(' '.join(pending)));pending.clear()
    def flush_table():
        if not table:return
        data=[[para(c,'cell') for c in row] for row in table]
        n=max(map(len,data));data=[r+[para('','cell')]*(n-len(r)) for r in data]
        widths=[(184*mm)/n]*n
        if n==2:widths=[65*mm,119*mm]
        elif n==4:widths=[38*mm,23*mm,23*mm,100*mm]
        t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eef5')),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#b4c3d3')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
        story.extend([t,Spacer(1,7)]);table.clear()
    for line in text.splitlines():
        line=line.strip()
        if line.startswith('|'):
            flush_para()
            if not re.fullmatch(r'[|:\-\s]+',line):table.append([s.strip() for s in line.strip('|').split('|')])
            continue
        flush_table()
        if line.startswith('#'):
            flush_para();n=len(line)-len(line.lstrip('#'));story.append(para(line.lstrip('# ').strip(),'h1' if n==1 else 'h2'))
        elif not line:flush_para()
        elif line.startswith('- ') or re.match(r'^\d+\. ',line):flush_para();story.append(para(line))
        else:pending.append(line)
    flush_para();flush_table()
for path in ['docs/交付状态.md','README.md','docs/叠层与制造边界.md','docs/接线说明.md','assessment/power_feasibility.md','assessment/误差预算与验收方案.md','assessment/手册矛盾审查.md','assessment/mechanical_reference.md']:
    if (ROOT/path).exists():
        if story:story.append(PageBreak())
        add_md(path)
def footer(c,d):
    c.setFont('STSong-Light',8);c.setFillColor(colors.HexColor('#475569'))
    c.drawString(13*mm,9*mm,'FW-EC-PROBE C0 / 工程评审 / 未放行生产')
    c.drawRightString(197*mm,9*mm,str(d.page))
body=OUT/'C0_engineering_review_body.pdf'
SimpleDocTemplate(str(body),pagesize=A4,leftMargin=13*mm,rightMargin=13*mm,topMargin=13*mm,bottomMargin=16*mm,title='C0 engineering review NOT for fabrication',author='FW-EC-PROBE').build(story,onFirstPage=footer,onLaterPages=footer)
combined=fitz.open()
append=[body,ROOT/'docs/C0_wiring_DRAFT.pdf',ROOT/'mechanical/C0_cross_section_ASSUMPTIONS_NOT_FIT_SIGNOFF.pdf',ROOT/'hardware/frontend/frontend_top_DRAFT.pdf',ROOT/'hardware/frontend/frontend_bottom_DRAFT.pdf',ROOT/'hardware/native/FW_EC_PROBE_C0_electrical_DRAFT.pdf',ROOT/'references/eval-cn0359-eb1z-padsschematic-reva.pdf']
toc=[]
for p in append:
    if p.exists():
        d=fitz.open(p);toc.append([1,p.stem,len(combined)+1]);combined.insert_pdf(d)
combined.set_toc(toc)
output=OUT/'FW_EC_PROBE_C0_engineering_review_NOT_FOR_FABRICATION.pdf'
combined.save(output,garbage=4,deflate=True)
print('Review PDF',len(combined),'pages;',output)
