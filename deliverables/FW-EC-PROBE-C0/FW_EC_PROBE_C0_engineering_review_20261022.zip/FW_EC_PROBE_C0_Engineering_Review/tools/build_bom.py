#!/usr/bin/env python3
"""C0 engineering procurement dossier. No invented MPNs, SKUs, stock or prices.

Reads the living electrical netlists; never modifies the hardware or B0 files.
Outputs are for engineering review/RFQ, not released production purchasing.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
from datetime import datetime,timezone
from urllib.parse import quote
import csv,hashlib,json,math,re
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Alignment,Font,PatternFill
from openpyxl.utils import get_column_letter

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'bom';OUT.mkdir(exist_ok=True)
FIELDS=['ID','类别','板件/用途','位号/项目','单台用量','单位','建议备件','建议采购量','数值/功能/规格','封装','CAD封装候选','精度/容差','温漂/TCR','厂家','采购MPN','原ADI MPN_仅供比对','立创或DigiKey SKU','MPN核验状态','库存/停产状态','装配/采购属性','放行状态','单价/币种','成本小计','大陆采购渠道','采购入口','淘宝查询入口','相对B0/原ADI变更','备注','来源']
INPUTS=[('前板AFE',ROOT/'hardware/afe_reference/afe_netlist.json'),
        ('前板MCU_RTD_原模拟供电',ROOT/'hardware/core_reference/core_netlist.json'),
        ('后板电源_隔离485',ROOT/'hardware/power/power_netlist.json'),
        ('前板必要板间接口_兼容焊桥',ROOT/'hardware/frontend/additional_components_for_schematic.json')]
SPEC_REFS={'R13':('4.99kΩ','0.01%','≤2 ppm/°C'), 'R47':('1.00kΩ','0.01%','≤2 ppm/°C')}
ATTENUATORS={'R19','R20','R29','R31','R37','R38','R48','R52'}
DELETED_REFS={'U1','U2','U6','U7','U3','S1','J2','J4'}
DIGI='https://www.digikey.cn/en/products?keywords='
TAO='https://s.taobao.com/search?q='
SOURCES=[Path(__file__).resolve()]
MISSING=[]

def read_json(path):
    SOURCES.append(path)
    return json.loads(path.read_text(encoding='utf-8'))
def flat(value):
    if isinstance(value,list):return '；'.join(map(str,value))
    if isinstance(value,dict):return json.dumps(value,ensure_ascii=False)
    return '' if value is None else str(value)
def numberkey(s):return [int(x) if x.isdigit() else x for x in re.split(r'(\d+)',s)]
def blank():
    x={k:'' for k in FIELDS}
    x.update({'立创或DigiKey SKU':'UNVERIFIED：未核实商城SKU；查询链接不是料号',
              '库存/停产状态':'UNVERIFIED：未实时核实库存、停产/EOL或交期',
              '放行状态':'工程询价候选；未放行生产采购',
              '单价/币种':'UNQUOTED：待供应商正式含税报价','成本小计':'未报价，不能计算',
              '单位':'件'})
    return x

baseline_path=OUT/'source_official_bom_reva.csv';SOURCES.append(baseline_path)
with baseline_path.open(encoding='utf-8-sig',newline='') as f:
    baseline={r['reference']:r for r in csv.DictReader(f)}
cap_path=OUT/'source_cap_specs_prior_reference.json';cap_specs=read_json(cap_path)
rows=[];seen=set();component_sources={}
for board,path in INPUTS:
    if not path.exists():MISSING.append(str(path.relative_to(ROOT)));continue
    data=read_json(path);components=data.get('components',data)
    if not isinstance(components,dict):raise ValueError(f'{path}: components must be a reference-keyed object')
    component_sources[board]=len(components)
    for ref,c in sorted(components.items(),key=lambda t:numberkey(t[0])):
        if ref in seen:raise ValueError('Duplicate C0 component reference across netlists: '+ref)
        seen.add(ref)
        if ref in DELETED_REFS:raise ValueError('Removed UI/old interface/power part leaked into C0 retained netlist: '+ref)
        pop=flat(c.get('population','')).upper()
        if pop=='DNP' or flat(c.get('assembly','')).upper()=='DNP':raise ValueError('DNP should not exist in new C0 production BOM: '+ref)
        old=baseline.get(ref,{}) if not re.search(r'\d{3}',ref) else {}
        mpn=flat(c.get('mpn'));val=flat(c.get('value')) or mpn
        orig=flat(c.get('original_mpn')) or old.get('manufacturer_part_number','')
        note=flat(c.get('notes'));package=flat(c.get('package'))
        feature=('PCB feature' in mpn or 'no purchased' in mpn or mpn.startswith(('WIRE_SOLDER_PADS','CUSTOM_SOLDER_BRIDGE','PCB_SOLDER_BRIDGE')) or c.get('is_pcb_feature',False))
        if mpn.startswith(('INTERNAL_8PAD_PINMAP_FIXED','PINHEADER_2X4_1.27_TBD')):
            note+='；源MPN字段是接口定义标签，不是可订购原厂料号。'
            mpn=''
        tol=flat(c.get('tolerance')) or 'UNVERIFIED：按原厂完整订货码待核'
        tcr=flat(c.get('tcr')) or ('≤'+str(c['tcr_max_ppm_per_C'])+' ppm/°C' if 'tcr_max_ppm_per_C' in c else 'UNVERIFIED：原厂保证值待核；不冒称低温漂')
        change='保留原ADI拓扑/数值；布局重做，未证明C0板精度'
        if ref in SPEC_REFS:
            val,tol,tcr=SPEC_REFS[ref];mpn='';change='R13改4.99kΩ/200µA；R47保持1kΩ；两只升级0.01%且≤2ppm/°C'
        elif ref in ATTENUATORS:
            tol='0.05%';tcr='≤5 ppm/°C（各分立电阻绝对TCR）';mpn=''
            change='C0取消LT5400适配片；恢复原7.5k/1.2k四对分立阻值；升级精度/温漂'
            assert val in ('7.50k','1.20k','7.5k','1.2k'),(ref,val)
        elif not old:
            change='C0新增/更换；按当前候选网表审查'
        if ref.startswith('C') and mpn in cap_specs:
            # This retained note is an old engineering description, not a new
            # manufacturer certificate or permission to change dielectric.
            note+='；原MPN释义参考：'+cap_specs[mpn]+' 保持C0原值/介质；任何替代需重新审核。'
            match=re.search(r'±\d+(?:\.\d+)?%',cap_specs[mpn])
            if match and not c.get('tolerance'):tol=match.group(0)+'（原MPN释义参考，仍须原厂核验）'
            tcr=flat(c.get('tcr')) or '电容介质/温度系数按原订货码；偏压/温度下有效容量待核'
        state=flat(c.get('procurement_status'))
        if feature:
            mpn='N/A：PCB焊盘/必要焊桥，无独立采购器件'
            status='PCB_FEATURE：不能按原连接器MPN买料';qty=0;tol=tcr='N/A'
            action='PCB必要接口特征，不采购器件；不是DNP占位'
            package=flat(c.get('recommended_footprint') or c.get('footprint')) or '待布局'
        elif not mpn or 'HOLD' in state.upper():
            status=state or 'HOLD-MPN：完整订货码和规格证据待选定';qty=1;action='HOLD：核准MPN/封装/规格前不付款'
            if not mpn:mpn='HOLD：完整合格MPN未选定'
        else:
            status=state or '原ADI BOM引用；完整包装后缀/原厂数据表待复核'
            qty=1;action='候选必装；全板未生产放行'
        manufacturer=flat(c.get('manufacturer')) or '待选/原厂信息待核'
        if ref in SPEC_REFS or ref in ATTENUATORS:manufacturer='待选（原ADI厂家仅供比对，不限定升级件厂家）'
        part_kind='电阻' if ref.startswith('R') else ('电容' if ref.startswith('C') else ('连接器' if ref.startswith('J') else '电子元件'))
        query=mpn if not mpn.startswith(('HOLD','N/A')) else f'{val} {package} {tol} {tcr} {part_kind}'
        x=blank();x.update({'ID':ref,'类别':'PCB特征' if feature else '电子料','板件/用途':board,'位号/项目':ref,
            '单台用量':qty,'建议备件':0,'建议采购量':qty,'数值/功能/规格':val,'封装':package,
            'CAD封装候选':flat(c.get('recommended_footprint') or c.get('footprint')),
            '精度/容差':tol,'温漂/TCR':tcr,'厂家':manufacturer,'采购MPN':mpn,
            '原ADI MPN_仅供比对':orig,'MPN核验状态':status,'装配/采购属性':action,
            '大陆采购渠道':'ADI中国/授权分销/得捷中国/立创商城；淘宝限可追溯渠道核验' if not feature else '不采购',
            '采购入口':('https://www.analog.com/cn/index.html\n' if manufacturer=='Analog Devices' else '')+DIGI+quote(query,safe='') if not feature else '',
            '淘宝查询入口':TAO+quote(query,safe='') if not feature else '',
            '相对B0/原ADI变更':change,'备注':note,
            '来源':str(path.relative_to(ROOT))+'；原ADI Rev A BOM引用，非新采购核验证书'})
        rows.append(x)

# Consolidate only physical components. PCB lands do not become purchase lines.
groups=defaultdict(list)
for x in rows:
    if x['单台用量']:
        # The same literal manufacturer part can occur in different boards with
        # differently worded values/review statuses. Sum it once and retain all
        # source/status notes; unknown MPNs still require value in the key.
        real_mpn=not x['采购MPN'].startswith(('HOLD','N/A'))
        keys=['采购MPN','封装','精度/容差','温漂/TCR'] if real_mpn else ['采购MPN','数值/功能/规格','封装','精度/容差','温漂/TCR']
        key=tuple(x[k] for k in keys)
        groups[key].append(x)
orders=[]
for ix,parts in enumerate(groups.values(),1):
    x=parts[0].copy();qty=sum(p['单台用量'] for p in parts)
    refs=[p['位号/项目'] for p in parts]
    precision=bool(set(refs)&(set(SPEC_REFS)|ATTENUATORS))
    passive=all(r.startswith(('R','C')) for r in refs)
    spare=max(2,math.ceil(qty*.5)) if precision else (max(2,math.ceil(qty*.25),10-qty) if passive else 1)
    for field in ['数值/功能/规格','MPN核验状态','来源','备注']:
        x[field]='；'.join(dict.fromkeys(p[field] for p in parts if p[field]))
    x.update({'ID':f'E{ix:03}','板件/用途':'；'.join(dict.fromkeys(p['板件/用途'] for p in parts)),
              '位号/项目':' '.join(refs),'单台用量':qty,'建议备件':spare,'建议采购量':qty+spare})
    orders.append(x)

external_path=OUT/'external_procurement.json';external=[]
if external_path.exists():
    external_items=read_json(external_path)['items']
    assert len({d['id'] for d in external_items})==len(external_items),'Duplicate external procurement IDs'
    for d in external_items:
        x=blank();qty=d.get('qty',1);spare=d.get('spare',0)
        assert isinstance(qty,(int,float)) and qty>0 and isinstance(spare,(int,float)) and spare>=0
        assert d.get('price_status')=='UNQUOTED','Unverified prices must not be invented'
        assert d.get('url','').startswith('https://'),'Procurement link must be an explicit HTTPS query/source'
        x.update({'ID':d['id'],'类别':d['category'],'板件/用途':'项目外采/实验验收','位号/项目':d['name'],
            '单台用量':qty,'单位':d.get('unit','件'),'建议备件':spare,'建议采购量':qty+spare,
            '数值/功能/规格':d['spec'],'封装':d.get('package','按合同/规格验收'),
            '精度/容差':d.get('tolerance','见规格；证书/性能待合同核准'),
            '温漂/TCR':d.get('tcr','非电阻项按规格/环境条件验收'),
            '厂家':d.get('manufacturer','待询价选定'),'采购MPN':d.get('mpn') or 'HOLD：型号未选定，按规格询价',
            'MPN核验状态':d.get('status','HOLD：规格询价'),
            '装配/采购属性':d.get('procurement_action','非板载BOM；已有合格设备可复用'),
            '单价/币种':d.get('price_status','UNQUOTED'),'大陆采购渠道':d.get('purchase_channel','待询价'),
            '采购入口':d.get('url',''),'淘宝查询入口':TAO+quote(d.get('taobao_query',d['name']),safe=''),
            '相对B0/原ADI变更':d.get('change','适配C0四电极/四线Pt1000及实验验证'),
            '备注':d.get('notes',''),'来源':'bom/external_procurement.json；C0新要求工程采购规格'})
        external.append(x)
else:MISSING.append(str(external_path.relative_to(ROOT)))

# Keep removed original references in a separate deletion record only.
delete_path=ROOT/'hardware/core_reference/deletion_list.json';deletions=[]
if delete_path.exists():deletions=read_json(delete_path)
else:MISSING.append(str(delete_path.relative_to(ROOT)))
changes=[]
for x in rows:
    ref=x['ID'];old=baseline.get(ref)
    feature=x['类别']=='PCB特征'
    if ref in SPEC_REFS or ref in ATTENUATORS or feature or not old:
        changes.append({'位号/项目':ref,'变更类型':'必要PCB焊盘替代连接器' if feature else ('精度/规格升级' if old else 'C0新增'),
            '原ADI/B0':' / '.join([old.get('value',''),old.get('manufacturer_part_number','')]) if old else '原ADI无此C0新增件',
            'C0要求':' / '.join(str(x[k]) for k in ['数值/功能/规格','精度/容差','温漂/TCR','采购MPN']),
            '原因/风险':x['相对B0/原ADI变更']+'；'+x['MPN核验状态']})
changes += [
 {'位号/项目':'B0主板/隔离板裸板','变更类型':'整套取代','原ADI/B0':'约100×104mm + 100×80mm','C0要求':'≤17mm宽两块板候选，生产文件未放行','原因/风险':'不按B0 Gerber采购，不把当前候选当生产板'},
 {'位号/项目':'B0四块LT5400网络适配片','变更类型':'删除','原ADI/B0':'四块LT5400适配片','C0要求':'无此板/无此芯片采购','原因/风险':'四对7.5k/1.2k分立薄膜电阻恢复原阻值；不能混用B0 BOM'},
 {'位号/项目':'独立LDO小板','变更类型':'删除','原ADI/B0':'旧LDO小板/转接线','C0要求':'不采购旧小板；新后板完整电源方案待审','原因/风险':'避免无效重复采购'},
 {'位号/项目':'电导池','变更类型':'四电极替换两极默认','原ADI/B0':'两电极K≈1','C0要求':'四电极K≈1＋真四线Pt1000整探头，8独立导线','原因/风险':'型号未核实HOLD；两极兼容需两处真实电气短接'},
 {'位号/项目':'精度','变更类型':'目标更新','原ADI/B0':'10–50±1%；50–2000±0.5%','C0要求':'10–2000µS/cm全量程±0.5%读数目标；温度0–50°C整链±0.05°C目标','原因/风险':'尚未实测；不能以软件测试或整数Modbus值认证精度'},
 {'位号/项目':'输入电流','变更类型':'用户授权放宽','原ADI/B0':'新要求原写≤30mA','C0要求':'保留RevA模拟链，输入电流上限按新电源审计结果及实测确认','原因/风险':'不再按12V30mA的矛盾预算选电源；热传导影响需实验'},
]
notes=[
 {'项目':'采购阶段','说明':'工程选型/询价清单，非生产放行BOM。PCB ERC/DRC、17mm装配和隔离耐压尚未验证，HOLD项不得凭原MPN替代。'},
 {'项目':'数量口径','说明':'按1台工程样机。逐位号与合并采购页为同一批电子料，不能重复购买；外采页不与板载料重复。备件为建议，不含最小包装量MOQ。'},
 {'项目':'全量程目标','说明':'C0电导10–2000µS/cm全量程±0.5%读数、温度0–50°C整链标定±0.05°C为目标，未获实测认证。'},
 {'项目':'MPN与商城SKU','说明':'原ADI MPN仅为来源；修改精密件完整MPN未确定时标HOLD，不用旧ERA料号冒充。立创C号/得捷-ND未核实，不虚构。'},
 {'项目':'价格/库存/成本','说明':'未取得供应商报价、实时库存和生命周期证据；所有金额空缺/UNQUOTED，不把未知价格填0。外协与已有设备可复用，须询价后才能计算项目总成本。'},
 {'项目':'询价入口','说明':'链接为中国大陆采购查询入口，不代表有库存或该商品已验证。半导体/精密阻优先原厂及授权渠道；淘宝购买须核原厂订货码、批次与证书。'},
 {'项目':'温补缺项','说明':'未取得可追溯ISO7888 nLF正式因子，固件默认κ25NaN/未验证。标准/资料授权费用列入实验成本，不把合成测试曲线当真实系数。'},
 {'项目':'焊接要求','说明':'至少0402，ADI LFCSP露铜焊盘需可靠焊接，不能把允许手焊理解为仅烙铁可保证质量。模拟高阻区洗净干燥；三防涂层避开电极/传感界面和焊盘。'},
 {'项目':'生成输入缺项','说明':'；'.join(MISSING) if MISSING else '当前AFE/core/power与外采、删除来源全部存在；存在来源不代表设计已生产验证。'},
]

def csvout(name,data,fields):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='raise');w.writeheader();w.writerows(data)

csvout('FW_EC_PROBE_C0_BOM_per_reference.csv',rows,FIELDS)
csvout('FW_EC_PROBE_C0_BOM_order.csv',orders,FIELDS)
csvout('FW_EC_PROBE_C0_project_procurement.csv',orders+external,FIELDS)
csvout('FW_EC_PROBE_C0_external_procurement.csv',external,FIELDS)
csvout('FW_EC_PROBE_C0_changes.csv',changes,['位号/项目','变更类型','原ADI/B0','C0要求','原因/风险'])
if deletions:csvout('FW_EC_PROBE_C0_deleted_only.csv',deletions,list(deletions[0]))

wb=Workbook();wb.remove(wb.active)
def sheet(name,data,fields):
    ws=wb.create_sheet(name);ws.append(fields)
    for r in data:ws.append([r.get(k,'') for k in fields])
    ws.freeze_panes='D2' if len(fields)>4 else 'A2';ws.auto_filter.ref=ws.dimensions
    ws.sheet_view.zoomScale=75
    for cell in ws[1]:cell.fill=PatternFill('solid',fgColor='17365D');cell.font=Font(color='FFFFFF',bold=True)
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment=Alignment(vertical='top',wrap_text=True)
            if isinstance(cell.value,str) and (cell.value.startswith('HOLD') or '未放行' in cell.value):cell.fill=PatternFill('solid',fgColor='FFF2CC')
            if isinstance(cell.value,str) and cell.value.startswith('http') and '\n' not in cell.value:cell.hyperlink=cell.value;cell.font=Font(color='0563C1',underline='single')
    for i,k in enumerate(fields,1):ws.column_dimensions[get_column_letter(i)].width=14 if k in ('单台用量','建议备件','建议采购量','单位') else (48 if k in ('备注','来源','数值/功能/规格','原因/风险','说明','C0要求') else 27)
    return ws
sheet('先读说明',notes,['项目','说明'])
sheet('电子逐位号',rows,FIELDS)
sheet('电子合并采购',orders,FIELDS)
sheet('外设设备耗材',external,FIELDS)
sheet('全项目采购汇总',orders+external,FIELDS)
sheet('C0变更表',changes,['位号/项目','变更类型','原ADI/B0','C0要求','原因/风险'])
if deletions:sheet('已删除_不要采购',deletions,list(deletions[0]))
sheet('HOLD待核准',[x for x in orders+external if 'HOLD' in x['采购MPN'] or 'HOLD' in x['MPN核验状态']],FIELDS)
sheet('成本待正式询价',[{k:x[k] for k in ['ID','类别','位号/项目','建议采购量','单位','单价/币种','成本小计','采购入口']} for x in orders+external],['ID','类别','位号/项目','建议采购量','单位','单价/币种','成本小计','采购入口'])
workbook=OUT/'FW_EC_PROBE_C0_采购清单_工程询价未放行.xlsx';wb.save(workbook)

assert len(rows)==sum(component_sources.values())
assert all(ref in seen for ref in set(SPEC_REFS)|ATTENUATORS)
assert len([x for x in rows if x['ID'] in ATTENUATORS])==8
assert all(x['采购MPN'].startswith('HOLD') for x in rows if x['ID'] in set(SPEC_REFS)|ATTENUATORS)
assert not any('LT5400' in x['采购MPN'] for x in orders)
assert not any('DNP'==x['装配/采购属性'] for x in rows)
assert not (set(d['reference'] for d in deletions)&seen),'Deleted original references must not leak into live C0 BOM'
assert sum(x['单台用量'] for x in orders)==sum(x['单台用量'] for x in rows)
# Read back the actual written Excel/CSV; verifies serialization/counts, not ratings.
check=load_workbook(workbook,read_only=True,data_only=True)
assert check['电子逐位号'].max_row==len(rows)+1
assert check['外设设备耗材'].max_row==len(external)+1
with (OUT/'FW_EC_PROBE_C0_project_procurement.csv').open(encoding='utf-8-sig',newline='') as f:
    assert len(list(csv.DictReader(f)))==len(orders)+len(external)
validation={'generated_at_utc':datetime.now(timezone.utc).isoformat(),'release_status':'ENGINEERING_RFQ_ONLY_NOT_PRODUCTION_RELEASE',
 'all_inputs_present':not MISSING,'missing_inputs':MISSING,'source_component_counts':component_sources,
 'component_rows':len(rows),'physical_parts_per_unit':sum(x['单台用量'] for x in rows),'pcb_feature_rows':sum(x['类别']=='PCB特征' for x in rows),
 'consolidated_electronic_lines':len(orders),'external_procurement_lines':len(external),'deletion_rows':len(deletions),
 'hold_lines':sum('HOLD' in x['采购MPN'] or 'HOLD' in x['MPN核验状态'] for x in orders+external),
 'verified':['dynamic JSON component coverage','unique references','deleted refs excluded','10 required precision upgrades kept HOLD with correct spec','8 discrete attenuator resistors; no LT5400 procurement','quantity consolidation','written Excel/CSV read-back'],
 'not_verified':['complete upgraded MPN qualification','distributor SKUs','real-time inventory/lifecycle','prices and project total','PCB manufacturability and assembly fit','17mm mechanical fit','physical isolation/EMC/temperature rise','conductivity/temperature accuracy','traceable ISO nLF factors'],
 'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCES},
 'output_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob('FW_EC_PROBE_C0_*')) if p.is_file()}}
(OUT/'bom_validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in validation.items() if k not in ('source_sha256','output_sha256','not_verified')},ensure_ascii=False,indent=2))
