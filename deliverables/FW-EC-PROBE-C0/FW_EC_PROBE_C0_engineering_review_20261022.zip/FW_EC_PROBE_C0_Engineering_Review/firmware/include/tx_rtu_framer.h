/* SPDX-License-Identifier: MIT */
#ifndef TX_RTU_FRAMER_H
#define TX_RTU_FRAMER_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define TX_RTU_MAX 256u
typedef struct {
 uint8_t active[TX_RTU_MAX],ready[TX_RTU_MAX];
 uint16_t length,ready_length;
 uint32_t last_tick,t15,t35,character_ticks,discarded;
 bool active_seen,invalid;
} tx_rtu_framer;
/* HR8033 serial_format: 0=8O1, 1=8E1, 2=8N2, 3=8N1.
 * 8N1 has 10 bits per character; the other supported formats have 11. */
void tx_rtu_init(tx_rtu_framer*,uint32_t clock_hz,uint32_t baud,uint8_t serial_format);
/* ticks are receive-complete timestamps (end of the stop bit), not start bits.
 * idle qualification conservatively waits t3.5 plus one character so an
 * incomplete byte spanning the t3.5 boundary cannot trigger an early reply. */
void tx_rtu_byte(tx_rtu_framer*,uint8_t byte,uint32_t ticks,bool line_error);
void tx_rtu_idle(tx_rtu_framer*,uint32_t ticks);
size_t tx_rtu_take(tx_rtu_framer*,uint8_t *out,size_t capacity);
#endif
