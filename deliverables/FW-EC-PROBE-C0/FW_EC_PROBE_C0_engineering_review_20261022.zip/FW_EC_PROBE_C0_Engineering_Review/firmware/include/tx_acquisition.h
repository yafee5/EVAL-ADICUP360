/* SPDX-License-Identifier: MIT */
#ifndef TX_ACQUISITION_H
#define TX_ACQUISITION_H
#include <stdbool.h>
#include <stdint.h>

enum {
 TX_ACQ_OVERLOAD=1u<<0, TX_ACQ_WEAK=1u<<1, TX_ACQ_ADC_ERROR=1u<<2,
 TX_ACQ_OUT_OF_RANGE=1u<<3, TX_ACQ_SETTLING=1u<<4
};
typedef enum { TX_ACQ_MORE, TX_ACQ_DISCARDED, TX_ACQ_READY, TX_ACQ_CHANGED } tx_acq_event;
typedef struct {
 int32_t raw[4];
 uint32_t cycle, published, cycle_fault;
 uint8_t phase, gv_index, gi_index, frequency_index, discard_cycles;
 bool forced;
} tx_acq_state;
typedef struct {
 float conductance_s, kappa_t_us_cm;
 int32_t raw[4];
 uint32_t status, cycle;
 uint16_t gv, gi, frequency_hz;
} tx_acq_result;

void tx_acq_init(tx_acq_state *s);
void tx_acq_restart(tx_acq_state *s);
tx_acq_event tx_acq_push(tx_acq_state *s, int32_t code, uint32_t adc_fault,
                        float cell_constant, float range_correction,
                        tx_acq_result *out);
float tx_pt1000_resistance(uint32_t adc_code);
bool tx_pt1000_temperature(uint32_t adc_code, float gain, float offset,
                           float *temperature, float *resistance);
unsigned tx_pwm_period(unsigned clock_hz,unsigned target_hz,unsigned *prescaler);
#endif
