# FW-EC-PROBE C0 台架候选固件与通信说明

本版用于新要求的四电极电导探头＋四线 Pt1000，只保留采集、补偿和 RS-485 Modbus RTU。两电极兼容必须通过实际电路的两处焊桥连接实现；本固件没有把软件状态当作电气短接。源代码不编译 LCD、菜单、编码器、蜂鸣器、Pt100、2/3 线识别、压力或水位功能。

**C0 PCB 尚未定版，本目录 HAL 暂沿用 CN0359 Rev A 引脚；生成的 HEX 是台架候选，不能直接认定与新 C0 PCB 匹配。未取得可追溯的 ISO 7888 nLF 正式因子，κ25 默认 NaN，并置 NLF_UNVERIFIED，HR 整数 κ25 为 0xFFFFFFFF。不得据此宣称温补功能完成或精度已达标。** nLF 只保留校验和导入通路，测试曲线不进入生产默认参数。

C0 电导率目标为 **10–2000 µS/cm 全量程 ±0.5% 读数**，测温目标为 0–50 °C 整链标定后 ±0.05 °C，均尚未通过实物验证。`EC_LOW_RANGE` 只提示处于 10–50 µS/cm，不能解释为降低精度指标，也不是已经达到指标的证明。

## 构建和检查

保留相邻的 `firmware/` 与 `compensation/`。需要 Python 3、GNU Arm Embedded 工具链；主机测试还需要 GCC/Clang 与 ASan/UBSan。连接物理串口另需 `pyserial`。

```sh
cd firmware
make
make test
python3 tools/verify_release.py
```

HEX、ELF、BIN、MAP 和构建清单由构建脚本写入 `build/`，台架 HEX 为 `fw_ec_probe_c0_bench.hex`；最终产物名以 `build/manifest.json` 为准。工具链不在 PATH 时可设 `CROSS_COMPILE=/绝对路径/arm-none-eabi-`。本云环境构建脚本识别 `/workspace/toolchains/arm/usr/bin/`。

IEXC 为名义 200 µA，额外 10 µA 位关闭；R13 应为 4.99 kΩ，Pt1000 必须四线连接。MCU BM 启动上拉属于必要的启动电路。C0 生产板只保留最小 SWD 焊盘组；当前台架 HAL 可经 Rev A 的 J4 调试，这不代表 C0 生产板保留 J4 排针。调试器 VTref 应为 3.3 V。C0 电源和针脚还须按最终原理图逐项复核。

`build/manifest.json`、`image_validation.json` 与 `firmware_validation.json` 记录源码/HEX 哈希和软件检查。主机模拟测试不验证实际 UART、RS-485 隔离、ADC 噪声、Flash 擦写时序、探头极化、温升或整机精度；实物验收须另做。

## 通信与两套寄存器

默认站址 **1，9600 baud，8N1**。地址全部为 Modbus PDU 零基地址；例如 0x0003 就是十六进制 0003，不加 40001。CRC16 为 Modbus RTU CRC，CRC 两字节低字节先传；所有 32 位数据寄存器高字在前，每字高字节先传。

完整逐项表见 [protocol/register_map.csv](protocol/register_map.csv)。C0 将 B0 的整套原生地址统一加 **0x1000**，为 HR8033 兼容地址留出空间。旧 B0 主机不能直接使用旧地址访问 C0。

| 地址 | 类型/功能码 | 内容 |
| --- | --- | --- |
| 0x0003 | int16，FC03 | HR 兼容温度，单位 0.01 °C；无效 0x8000 |
| 0x0006..0x0007 | uint32，FC03 | HR 兼容 κ25，整数 µS/cm；无效 0xFFFFFFFF |
| 0x0130 | uint16，FC03/FC10 | HR 兼容站址 1..247 |
| 0x0132 | uint16，FC03/FC10 | HR 波特率代码仅支持 **1=9600**；原生速率非 9600 时读 0xFFFF |
| 0x0134 | uint16，FC03/FC10 | HR 校验代码 0=8O1、1=8E1、2=8N2、3=8N1 |
| 0x1000..0x1001 | float32，FC03/FC04 | κ(T)，µS/cm |
| 0x1002..0x1003 | float32，FC03/FC04 | κ25，µS/cm |
| 0x1004..0x1005 | float32，FC03/FC04 | 温度，°C |
| 0x1006..0x1007 | float32，FC03/FC04 | 原始电导 G，S，未乘分档校正或 K |
| 0x1008..0x100B | int32，FC03/FC04 | 电压、电流 ADC 正负相差值 |
| 0x100C..0x100D | uint32，FC03/FC04 | 状态/故障位 |
| 0x100E..0x101F | FC03/FC04 | 样本计数、频率、增益、年龄、版本、错误计数 |
| 0x1100..0x110D | FC03/受保护写 | K、温度校准、地址、原生速率、校准掩码、参考切档值 |
| 0x110E | uint16，FC03/受保护写 | 串口格式代码，同 0x0134，默认 3 |
| 0x110F | uint16，FC03/受保护写 | 换极性稳定等待，50..2000 ms，默认 120 ms |
| 0x1200..0x123F | float32，FC03/受保护写 | 2 频率×4 GV×4 GI 的 32 项增益系数 |
| 0x1300..0x135D | FC03/受保护写 | nLF 36 点、来源 ID/SHA256、CRC、启用标记 |
| 0x1400..0x1407 | FC03/受保护写 | RAM 维护模式、强制频率/增益、续期 |
| 0x8F00..0x8F11 | FC03/FC10 | 解锁、SAVE、CRC、Flash 序号和状态 |

HR 整数值采用四舍五入，温度为有符号二补码。例如 +10.80 °C 为 **0x0438**，−10.80 °C 为 **0xFBC8**；手册的 0x006C 实际是 1.08 °C。整数电导有 ±0.5 µS/cm 量化误差，10 µS/cm 处可达 ±5%，因此它只用于外机兼容；精度数据应读取扩展 float32 和状态位。饱和结果必须结合 bit24/25 判断，不能当正常量程样本。温度兼容值饱和范围 −327.67..327.67 °C（0x8001..0x7FFF）；κ25 饱和上限 0xFFFFFFFE，以保留无效哨兵。电导样本超过 10 s 时，兼容 κ25 输出无效哨兵；温度有效性独立于电导年龄，由 RTD 的独立 5 s 更新超时和故障检测决定。

HR 手册中的 0x0133 两字偏移会与 0x0134 校验字段重叠，部分例子的 0x0013/0x0014 与参数表也不一致。本版按参数表采用 0x0130/0x0132/0x0134，不实现冲突的 0x0133 偏移、0x0013/14 参数别名及压力/水位/密度功能。HR 兼容写仅接受 FC10、count=1；不接受 FC06。

### 状态位

必须同时检查有效位、校准位、故障位和样本年龄。浮点无效值为 NaN；RTD 故障不会用 25 °C 代替。κ(T) 的有效性独立于测温；RTD 故障时 κ25 无效。频率或增益切换后丢弃完整测量周期，切换期间输出 SETTLING；轮询频率不等于更新频率。

| bit | 名称 | 含义 |
| --- | --- | --- |
| 0 / 1 / 2 | EC_VALID / TEMP_VALID / K25_VALID | κ(T) / 温度 / κ25 有效 |
| 3 | EC_LOW_RANGE | 10..50 µS/cm 低量程 |
| 4 / 5 | NLF_TEMP_OOR / NLF_EC_OOR | 超出 nLF 适用范围 0..35 °C / 60..1000 µS/cm |
| 6 / 7 | RTD_FAULT / EC_FAULT | RTD / 电导链故障 |
| 8 | SETTLING | 换档或极性稳定阶段 |
| 9 / 10 / 11 | UNCAL_GAIN / UNCAL_TEMP / UNCAL_K | 当前增益组合 / 温度 / 电极常数尚未标定 |
| 12 / 13 | FLASH_FAULT / ADC_TIMEOUT | 存储故障 / ADC 超时 |
| 14 / 15 | EC_OUT_OF_RANGE / TEMP_OUT_OF_RANGE | 电导 / 温度超出产品量程 |
| 16 | FACTORY_DEFAULTS | 未从有效 Flash 记录加载参数 |
| 17 / 18 | RTD_OPEN / RTD_SHORT | RTD 开路 / 短路 |
| 19 | STALE | 电导样本年龄超过 10 s |
| 20 | NLF_UNVERIFIED | 未安装通过完整性校验且记录审定的 nLF 数据 |
| 21 | MAINTENANCE | 正在 RAM 强制维护模式 |
| 22 / 23 | LEGACY_TEMP_INVALID / LEGACY_K25_INVALID | HR 温度 / κ25 整数接口无效，输出哨兵 |
| 24 / 25 | LEGACY_TEMP_SATURATED / LEGACY_K25_SATURATED | HR 整数接口超出可表示范围而饱和 |

### 兼容通信参数自动保存

一次 FC10 单字写 0x0130、0x0132 或 0x0134，会在当前 **active 参数副本**上只修改对应通信字段，进行 A/B journal 保存。保存成功后先按旧地址/波特率/格式回包，UART TEMT 确认最后停止位发送完成后再生效。主机收到回复后才能切换自身设置。保存失败返回异常，不切换；同一开机期间，两次 Flash 保存尝试至少间隔 5 s，擦除/编程/回读失败也计入节流；过密返回异常 06。写入值与当前 active 值相同时，直接成功回包，不擦 Flash、不触发切换，也不改 staged。

此接口无需校准解锁，以兼容外机的一次 FC10 设置。它不会提交正在暂存的校准；暂存校准仍需明确 SAVE。批量设置多个通信字段应走扩展接口的一次受保护事务。若回复丢失，设备可能已经采用新设置，应分别用新旧设置查询；不要反复盲写。广播写不支持。

### 扩展受保护参数事务

1. FC10 向 0x8F00 写两个寄存器：`0xC35A, 0x5AC3`，复制 active 到 staged 并解锁 30 s。重复解锁会重新复制，丢弃此前暂存；续期应向 0x1404 写 `0xA55A`。
2. 写 staged 参数。float32/uint32 必须一次写完整高低两字。K 范围 0.5..1.5 cm⁻¹，温度增益 0.95..1.05，偏移 −5..5 °C，分档系数 0.5..2.0。修改 K/温度会清对应已校准标志。
3. 原生速率 0x1107 编码为 `0=9600 / 1=19200 / 2=38400 / 3=57600 / 4=115200`，与 HR 0x0132 的编码不同。0x110E 格式、0x110F 稳定等待也在 staged 中。
4. 读取 0x8F08..09 的 staged CRC32。FC10 从 0x8F02 一次写四字：`0x5341, 0x5645, CRC高字, CRC低字`。范围、CRC、限频、Flash 回读全部通过才保存；旧格式回复完成后生效。
5. 要取消暂存，向 0x8F00 写 `[0,0]`。30 s 无续期且无待生效事务也会取消。SAVE/取消/超时退出 RAM 强制维护模式。

增益索引为 `f×16 + v×4 + i`，其中 f=0/1 为 100/1000 Hz，v、i=0/1/2/3 为 1/10/100/1000。每个系数独立校准，不能用一次测量标记所有档位。自动频率切换中心为 200 µS/cm，实际用 190/210 滞回；换档后丢弃整个周期。稳定等待默认 120 ms，实际探头/线缆下是否足够须实测。

nLF 表通过来源文件 SHA256、来源 ID、36 点 float32 CRC 和最后独立写入的 `NLF1` 标记审核导入。SHA/CRC 仅证明身份和完整性，不能证明 ISO 来源正确。导入程序拒绝无审定记录或来源文件不匹配的表，生产默认禁用 nLF。

## Flash 兼容性与擦除边界

应用区止于 **0x1FA00**；参数 A/B 页在 **0x1FA00** 与 **0x1FC00**，各 512 字节。最后 **0x1FE00–0x1FFFF** 是设备安全配置尾页，本固件不擦除它。HEX 不包含参数页或安全页。

C0 记录为 **schema 2**，规范 payload **340 字节**。前 336 字节保留 B0 字段次序，尾部 offset336 为格式代码 uint8，337 为保留 0，338..339 为稳定等待 uint16 小端。新字段纳入参数和记录 CRC。B0 schema1 不会被误当成有效 C0 参数；更换后应重新导入并审核标定，而非假定旧 Flash 自动兼容。

升级前备份参数，并核对烧录器的擦除范围；整片擦除会丢失标定，不能因为 HEX 未含参数就认定烧录工具一定保留它们。不得擦除尾页安全字。

## 主机工具

```sh
python3 -m pip install pyserial
python3 tools/tx_modbus.py --port COM5 status
python3 tools/tx_modbus.py --port COM5 legacy-status
python3 tools/tx_modbus.py --port COM5 --serial-format 8N1 configure --settling-ms 120
python3 tools/tx_modbus.py --port COM5 configure --new-address 17 --new-baud 19200 --new-serial-format 8E1
python3 tools/tx_modbus.py --port COM5 legacy-configure address 17
python3 tools/tx_modbus.py --port COM5 --address 17 legacy-configure serial-format 8E1
python3 tools/test_client.py
```

以上设置命令是独立示例，不是应连续执行的整套流程；实际命令须匹配设备当前地址/串口格式并遵守 5 s 提交间隔。客户端等待旧格式回复后再切换本机设置，并核对保存 CRC 或兼容字段回读。配置参数不能直接认证精度，`--mark-k-calibrated` / `--mark-temperature-calibrated` 只能在真实标定完成后使用。

客户端 `status` 返回扩展浮点和故障，JSON 将 NaN 转为 null；`legacy-status` 返回兼容整数及哨兵。`calibrate-gain` 在 RAM 维护模式读取多个不同周期的原始 G，并只设置对应频率/增益系数；`import-nlf` 需要来源文件及人工审定过的 profile。无物理串口的客户端集成测试编译真实 C 协议/存储代码，再通过分段模拟串口验证。

ADI 派生代码保留 [vendor/ADI_CN0359_LICENSE.txt](vendor/ADI_CN0359_LICENSE.txt) 及原版权条款，板级派生代码使用 `LicenseRef-ADI-CN0359`，不能当作无附加限制的标准 BSD 许可。
