#include "tx_rtu_framer.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static unsigned cases;
static uint32_t send_bytes(tx_rtu_framer *s,uint32_t t,unsigned count,unsigned base) {
 for(unsigned i=0;i<count;i++) {
  t+=s->character_ticks;
  tx_rtu_byte(s,(uint8_t)(base+i),t,false);
 }
 return t;
}
static uint32_t idle(tx_rtu_framer *s,uint32_t t) {
 t+=s->t35+s->character_ticks;tx_rtu_idle(s,t);return t;
}
static void basic_and_boundaries(uint32_t baud,uint8_t format,uint32_t initial_tick) {
 tx_rtu_framer s;uint8_t out[256];uint32_t t;
 tx_rtu_init(&s,16000000u,baud,format);
 /* Literal expected values distinguish the 10-bit N1 path from the three
  * 11-bit paths. >19200 keeps Modbus's fixed 750/1750 us thresholds. */
 if(baud==9600u) {
  if(format==3u)assert(s.t15==25000u&&s.t35==58334u&&s.character_ticks==16667u);
  else assert(s.t15==27500u&&s.t35==64167u&&s.character_ticks==18334u);
 }
 if(baud==19200u) {
  if(format==3u)assert(s.t15==12500u&&s.t35==29167u&&s.character_ticks==8334u);
  else assert(s.t15==13750u&&s.t35==32084u&&s.character_ticks==9167u);
 }
 if(baud>19200u)assert(s.t15==12000u&&s.t35==28000u);
 if(baud==115200u)assert(s.character_ticks==(format==3u?1389u:1528u));
 t=send_bytes(&s,initial_tick,8,0);
 /* RX-complete timestamps must not finalize an in-flight next byte. */
 tx_rtu_idle(&s,t+s.t35);assert(tx_rtu_take(&s,out,sizeof(out))==0);
 tx_rtu_idle(&s,t+s.t35+s.character_ticks-1u);assert(tx_rtu_take(&s,out,sizeof(out))==0);
 t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==8);
 for(unsigned i=0;i<8;i++)assert(out[i]==i);
 /* Silence at t1.5 is permitted; a single extra tick invalidates the ADU.
  * Silence at t3.5 starts a new ADU, including across CYCCNT wrap. */
 for(unsigned test=0;test<6;test++) {
  tx_rtu_init(&s,16000000u,baud,format);
  t=send_bytes(&s,initial_tick,4,10);
  uint32_t silence=test<3?s.t15+(test==0?UINT32_MAX:test-1u):s.t35+(test==3?UINT32_MAX:test-4u);
  t+=silence+s.character_ticks;tx_rtu_byte(&s,20,t,false);
  if(test<2) {
   t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==5&&out[0]==10&&out[4]==20);
  } else if(test<4) {
   t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==1);
  } else {
   assert(tx_rtu_take(&s,out,sizeof(out))==4&&out[0]==10);
   t=send_bytes(&s,t,3,21);t=idle(&s,t);
   assert(tx_rtu_take(&s,out,sizeof(out))==4&&out[0]==20&&out[3]==23);
  }
 }
 /* A next byte can still be on the wire at t3.5. Once it completes with an
  * illegal t1.5..t3.5 silence the whole frame must be discarded. */
 tx_rtu_init(&s,16000000u,baud,format);t=send_bytes(&s,initial_tick,4,0);
 tx_rtu_idle(&s,t+s.t35);assert(tx_rtu_take(&s,out,sizeof(out))==0);
 t+=s.t35-1u+s.character_ticks;tx_rtu_byte(&s,9,t,false);
 t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==1);
 /* UART parity/framing/overrun indications invalidate the complete ADU for
  * every serial format; even N1 still rejects framing/overrun errors. */
 tx_rtu_init(&s,16000000u,baud,format);
 for(unsigned i=0;i<8;i++) {
  initial_tick+=s.character_ticks;tx_rtu_byte(&s,(uint8_t)i,initial_tick,i==3);
 }
 idle(&s,initial_tick);assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==1);
 cases++;
}
static void lengths_and_pending(void) {
 tx_rtu_framer s;uint8_t out[256];uint32_t t=0;
 for(uint8_t format=0;format<4;format++) {
  tx_rtu_init(&s,16000000u,115200u,format);
  t=send_bytes(&s,t,256,0);t=idle(&s,t);
  assert(tx_rtu_take(&s,out,sizeof(out))==256);
  t=send_bytes(&s,t,257,0);t=idle(&s,t);
  assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==1);
  t=send_bytes(&s,t,3,0);t=idle(&s,t);
  assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==2);
  t=send_bytes(&s,t,8,10);t+=s.t35;t=send_bytes(&s,t,8,20);
  assert(tx_rtu_take(&s,out,sizeof(out))==8&&out[0]==10);
  t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==8&&out[0]==20);
  /* Don't overwrite an unread ready frame, and don't overrun caller output. */
  t=send_bytes(&s,t,8,30);t=idle(&s,t);
  t=send_bytes(&s,t,8,40);t=idle(&s,t);
  assert(tx_rtu_take(&s,out,sizeof(out))==8&&out[0]==30&&s.discarded==3);
  t=send_bytes(&s,t,8,50);t=idle(&s,t);
  assert(tx_rtu_take(&s,out,7)==0&&s.discarded==4&&s.ready_length==0);
 }
 /* Clock calculations must not round down a non-integer MHz clock. */
 tx_rtu_init(&s,16123456u,38400u,3u);
 assert(s.t15==12093u&&s.t35==28217u&&s.character_ticks==4199u);
}
int main(void) {
 const uint32_t baud[]={9600u,19200u,38400u,57600u,115200u};
 for(unsigned b=0;b<sizeof(baud)/sizeof(baud[0]);b++)for(uint8_t f=0;f<4;f++) {
  basic_and_boundaries(baud[b],f,0u);
  basic_and_boundaries(baud[b],f,UINT32_MAX-100u);
 }
 lengths_and_pending();
 printf("PASS RTU: %u format/baud/wrap cases, 8O1/8E1/8N2/8N1 10/11-bit timing, t1.5/t3.5 boundaries, RX-complete/idle, errors and ADU limits\n",cases);
 return 0;
}
