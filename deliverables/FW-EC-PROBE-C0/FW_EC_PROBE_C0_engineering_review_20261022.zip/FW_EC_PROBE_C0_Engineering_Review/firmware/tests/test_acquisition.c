#include "tx_acquisition.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>

static tx_acq_event cycle(tx_acq_state*s,int32_t ip,int32_t vp,float k,float c,tx_acq_result*o) {
 assert(tx_acq_push(s,ip,0,k,c,o)==TX_ACQ_MORE);
 assert(tx_acq_push(s,vp,0,k,c,o)==TX_ACQ_MORE);
 assert(tx_acq_push(s,-ip,0,k,c,o)==TX_ACQ_MORE);
 return tx_acq_push(s,-vp,0,k,c,o);
}
int main(void) {
 tx_acq_state s;tx_acq_result o;unsigned p;
 tx_acq_init(&s);
 assert(cycle(&s,40000000,100000000,1,1,&o)==TX_ACQ_DISCARDED);
 assert(cycle(&s,40000000,100000000,1,1,&o)==TX_ACQ_CHANGED); /* 400uS -> 1kHz */
 assert(s.frequency_index==1 && s.discard_cycles==1);
 assert(cycle(&s,40000000,100000000,1,1,&o)==TX_ACQ_DISCARDED);
 assert(cycle(&s,40000000,100000000,1,1,&o)==TX_ACQ_READY);
 assert(fabsf(o.kappa_t_us_cm-400.f)<.001f && o.frequency_hz==1000);
 /* Correction is keyed by frequency and gain outside this engine. */
 assert(cycle(&s,40000000,100000000,1.1f,.99f,&o)==TX_ACQ_READY);
 assert(fabsf(o.kappa_t_us_cm-435.6f)<.002f);
 assert(cycle(&s,40000000,200000000,1,1,&o)==TX_ACQ_READY); /* 200 holds 1kHz */
 assert(s.frequency_index==1);
 assert(cycle(&s,36000000,200000000,1,1,&o)==TX_ACQ_CHANGED); /* 180 ->100 */
 assert(s.frequency_index==0);
 assert(cycle(&s,36000000,200000000,1,1,&o)==TX_ACQ_DISCARDED);
 assert(cycle(&s,260000000,100000000,1,1,&o)==TX_ACQ_CHANGED); /* gain down */
 assert(s.gi_index==0);
 assert(cycle(&s,30000000,100000000,1,1,&o)==TX_ACQ_DISCARDED);
 /* A status error in any of the 4 phases invalidates the whole result. */
 assert(tx_acq_push(&s,30000000,1,1,1,&o)==TX_ACQ_MORE);
 tx_acq_push(&s,100000000,0,1,1,&o);tx_acq_push(&s,-30000000,0,1,1,&o);
 assert(tx_acq_push(&s,-100000000,0,1,1,&o)==TX_ACQ_READY);
 assert(isnan(o.kappa_t_us_cm)&&(o.status&TX_ACQ_ADC_ERROR));
 assert(tx_pwm_period(16000000,100,&p)==40000 && p==1);
 assert(tx_pwm_period(16000000,1000,&p)==8000 && p==0);
 float worst=0;
 for(unsigned i=0;i<=500;i++){
  float expected=i/10.f;
  float r=1000.f*(1.f+3.9083e-3f*expected-5.775e-7f*expected*expected);
  float x=(r*2000000.f/(r+2000000.f))/(4990.f*2000000.f/(4990.f+2000000.f));
  uint32_t code=(uint32_t)lroundf(x*268435456.f);float t,readr;
  bool ok=tx_pt1000_temperature(code,1,0,&t,&readr);
  assert(ok);float e=fabsf(t-expected);if(e>worst)worst=e;
 }
 float t,r;assert(!tx_pt1000_temperature(0,1,0,&t,&r)&&isnan(t));
 assert(!tx_pt1000_temperature(0x0fffffff,1,0,&t,&r));
 printf("PASS acquisition cycles, full-cycle discard, hysteresis, gain change, ADC faults, PWM clocks; RTD501 max %.8f C\n",worst);
 return 0;
}
