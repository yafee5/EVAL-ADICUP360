#!/usr/bin/env python3
from pathlib import Path
import subprocess,json
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
results=[]
for name,src in [('acquisition','tx_acquisition.c'),('rtu_framer','tx_rtu_framer.c')]:
    exe=BUILD/('host_test_'+name)
    subprocess.run(['gcc','-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',
                    '-I'+str(ROOT/'include'),str(ROOT/'src'/src),str(ROOT/'tests'/('test_'+name+'.c')),
                    '-lm','-o',str(exe)],check=True)
    result=subprocess.run([str(exe)],check=True,stdout=subprocess.PIPE,text=True)
    print(result.stdout,end='');results.append({'module':name,'output':result.stdout.strip(),'sanitizers':'address,undefined'})
exe=BUILD/'host_test_main_integration'
subprocess.run(['gcc','-std=c99','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',
                '-I'+str(ROOT/'include'),'-I'+str(ROOT/'protocol'),'-I'+str(ROOT.parent/'compensation'),
                str(ROOT/'tests/test_main_integration.c'),str(ROOT/'src/tx_acquisition.c'),
                str(ROOT/'protocol/tx_protocol.c'),str(ROOT/'protocol/tx_storage.c'),
                str(ROOT.parent/'compensation/nlf.c'),'-lm','-o',str(exe)],check=True)
result=subprocess.run([str(exe)],check=True,stdout=subprocess.PIPE,text=True)
print(result.stdout,end='');results.append({'module':'main_integration','output':result.stdout.strip(),'sanitizers':'address,undefined'})
(BUILD/'acquisition_test_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
