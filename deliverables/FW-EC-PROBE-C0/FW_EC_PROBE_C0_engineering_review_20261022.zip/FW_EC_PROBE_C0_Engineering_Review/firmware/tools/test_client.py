#!/usr/bin/env python3
"""Host client integration against the actual C protocol/storage implementation.

No physical serial port, sensor, ISO factors, MCU Flash timing or hardware
precision is tested. Synthetic nLF fixture is local to temporary test files.
"""
import ctypes
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
import struct

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
spec=importlib.util.spec_from_file_location('tx_modbus',HERE/'tx_modbus.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

SHIM=r'''
#include "tx_protocol.h"
#include <string.h>
static tx_context_t c;
static unsigned char flash[2][512];
static unsigned int now_ms, sample;
static int fixture, invalid_reads;
static float test_t, test_k25;
static unsigned int test_valid, test_age;
static bool rd(void*u,unsigned s,uint32_t off,void*p,size_t n){(void)u;if(s>1||off+n>512)return false;memcpy(p,flash[s]+off,n);return true;}
static bool er(void*u,unsigned s){(void)u;if(s>1)return false;memset(flash[s],255,512);return true;}
static bool wr(void*u,unsigned s,uint32_t off,const void*p,size_t n){const unsigned char*b=p;(void)u;if(s>1||off+n>512||off%4||n%4)return false;for(size_t i=0;i<n;i++)if((flash[s][off+i]&b[i])!=b[i])return false;for(size_t i=0;i<n;i++)flash[s][off+i]&=b[i];return true;}
void reset_device(void){tx_flash_ops_t ops={rd,er,wr};memset(flash,255,sizeof flash);now_ms=0;sample=0;fixture=0;invalid_reads=0;test_age=0;test_t=25.f;test_k25=0.f/0.f;test_valid=TX_STATUS_TEMP_VALID;tx_protocol_init(&c,&ops,0,0);}
void reboot_device(void){tx_flash_ops_t ops={rd,er,wr};tx_protocol_init(&c,&ops,0,now_ms);}
void set_legacy_values(float t,float ec,unsigned int valid){test_t=t;test_k25=ec;test_valid=valid;}
unsigned int get_format(void){return c.active.serial_format;}
unsigned int get_wait(void){return c.active.polarity_settling_ms;}
void set_sample_age(unsigned int age){test_age=age;}
void set_fixture(int mode,int invalid){fixture=mode;invalid_reads=invalid;}
void set_now(unsigned int n){now_ms=n;}
unsigned int get_revision(void){return c.configuration_revision;}
unsigned int get_mask(void){return c.active.gain_valid_mask;}
unsigned int process(const unsigned char*q,unsigned int n,unsigned char*r){
 tx_snapshot_t s;memset(&s,0,sizeof s);s.conductivity_us_cm=123.f;s.temperature_c=test_t;s.conductivity25_us_cm=test_k25;s.conductance_s=.000123f;
 s.raw_voltage_delta=-123;s.raw_current_delta=456;s.status=TX_STATUS_EC_VALID|test_valid;s.gain_table_index=0;s.sample_counter=++sample;s.sample_time_ms=now_ms-test_age;
 s.frequency_hz=100;s.gain_voltage=10;s.gain_current=10;
 if(fixture){s.frequency_hz=c.maintenance.frequency_index?1000:100;s.gain_voltage=tx_gain_value(c.maintenance.gv_index);s.gain_current=tx_gain_value(c.maintenance.gi_index);s.gain_table_index=(uint16_t)tx_gain_index(c.maintenance.frequency_index,c.maintenance.gv_index,c.maintenance.gi_index);}
 if(invalid_reads>0&&n>=2&&q[1]==4){s.status=TX_STATUS_SETTLING;invalid_reads--;}
 tx_protocol_set_snapshot(&c,&s);now_ms+=100;unsigned int length=(unsigned int)tx_protocol_process(&c,q,n,r,256,now_ms);tx_protocol_after_reply(&c);return length;
}
'''

class FakePort:
    def __init__(self,lib):
        self.lib=lib;self.timeout=.2;self.baudrate=9600;self.parity='N';self.stopbits=1;self.pending=b''
        self.corrupt=False;self.bad_bytecount=False;self.bad_echo=False
        self.last_request=b'';self.last_response=b'';self.fragments=2;self.history=[]
    def reset_input_buffer(self):self.pending=b''
    def flush(self):pass
    def write(self,data):
        self.last_request=data
        out=(ctypes.c_ubyte*256)();q=(ctypes.c_ubyte*len(data)).from_buffer_copy(data)
        n=self.lib.process(q,len(data),out);r=bytes(out[:n])
        if r and self.corrupt:r=r[:-1]+bytes((r[-1]^1,))
        if r and self.bad_bytecount:r=r[:2]+bytes((r[2]+2,))+r[3:]
        if r and self.bad_echo:
            r=r[:2]+bytes((r[2]^1,))+r[3:-2];r+=struct.pack('<H',m.crc16(r))
        self.pending=r;self.last_response=r;self.history.append((data,r));return len(data)
    def read(self,n):
        n=min(n,self.fragments);out=self.pending[:n];self.pending=self.pending[n:];return out

class ClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();p=Path(cls.temp.name)
        (p/'shim.c').write_text(SHIM)
        subprocess.run(['cc','-std=c99','-Wall','-Wextra','-Werror','-O1','-shared','-fPIC',
          '-I'+str(ROOT/'protocol'),str(p/'shim.c'),str(ROOT/'protocol/tx_protocol.c'),
          str(ROOT/'protocol/tx_storage.c'),str(ROOT.parent/'compensation/nlf.c'),'-lm','-o',str(p/'device.so')],check=True)
        cls.lib=ctypes.CDLL(str(p/'device.so'))
        cls.lib.process.argtypes=[ctypes.POINTER(ctypes.c_ubyte),ctypes.c_uint,ctypes.POINTER(ctypes.c_ubyte)]
        cls.lib.process.restype=ctypes.c_uint
        cls.lib.set_legacy_values.argtypes=[ctypes.c_float,ctypes.c_float,ctypes.c_uint]
        cls.real_sleep=m.time.sleep;m.time.sleep=lambda _:None
    @classmethod
    def tearDownClass(cls):m.time.sleep=cls.real_sleep;cls.temp.cleanup()
    def setUp(self):
        self.lib.reset_device();self.port=FakePort(self.lib);self.client=m.RTUClient(self.port,timeout=.01);self.t=m.Transmitter(self.client)
    def test_crc_and_float_wire_vectors(self):
        self.assertEqual(m.crc16(bytes.fromhex('01030000000A')),0xCDC5)
        self.assertEqual(m.f32words(1.0),[0x3F80,0]);self.assertEqual(m.words_float([0x4120,0]),10.)
        self.assertEqual(m.u32words(0xC35A5AC3),[0xC35A,0x5AC3])
    def test_status_partial_reads_and_nan(self):
        s=self.t.status()
        self.assertEqual(s['kappa_T_uScm'],123.)
        self.assertEqual(s['raw_voltage_delta'],-123)
        self.assertTrue(math.isnan(s['kappa25_uScm']))
        self.assertIn('NLF_UNVERIFIED',s['flags']);self.assertIsNone(m.clean_json(s)['kappa25_uScm'])
    def test_configure_crc_commit_and_old_reply_settings(self):
        crc=self.t.configure(cell=1.015,temp_gain=1.001,temp_offset=-.04,address=17,baud=19200,mark_k=True,mark_t=True)
        self.assertIsInstance(crc,int);self.assertEqual(self.lib.get_revision(),1)
        save_response=next(r for q,r in self.port.history if q[1]==16 and q[2:4]==b'\x8f\x02')
        self.assertEqual(save_response[0],1)
        self.assertEqual(self.client.address,17);self.assertEqual(self.client.baud,19200);self.assertEqual(self.port.baudrate,19200)
        self.assertAlmostEqual(m.words_float(self.client.read_words(0x1100,2)),1.015,places=6)
        s=self.t.status();self.assertNotIn('UNCAL_K',s['flags']);self.assertNotIn('UNCAL_TEMP',s['flags'])
    def test_default_and_four_serial_formats(self):
        self.assertEqual(self.client.serial_format,'8N1')
        self.assertEqual(m.character_bits('8N1'),10)
        for value in ('8O1','8E1','8N2'):
            self.assertEqual(m.character_bits(value),11)
        for index,value in enumerate(('8O1','8E1','8N2','8N1')):
            self.lib.set_now(10000*(index+1))
            self.t.configure(serial_format=value,settling_ms=120+index)
            self.assertEqual(self.client.serial_format,value)
            self.assertEqual((self.port.parity,self.port.stopbits),m.format_settings(value))
            self.assertEqual(self.lib.get_format(),m.SERIAL_FORMATS[value])
            self.assertEqual(self.lib.get_wait(),120+index)
            self.lib.reboot_device()
            self.assertEqual(self.lib.get_format(),m.SERIAL_FORMATS[value])
            self.assertEqual(self.lib.get_wait(),120+index)
    def test_quiet_uses_10_or_11_bits(self):
        real_mono=m.time.monotonic;real_sleep=m.time.sleep;waits=[]
        try:
            m.time.monotonic=lambda:0.;m.time.sleep=waits.append
            for value,bits in [('8N1',10),('8O1',11),('8E1',11),('8N2',11)]:
                self.client.serial_format=value;self.client.last_transfer=0;self.client.quiet()
                self.assertAlmostEqual(waits[-1],4.5*bits/9600)
            self.client.baud=115200;self.client.quiet()
            self.assertAlmostEqual(waits[-1],.00175+11/115200)
        finally:m.time.monotonic=real_mono;m.time.sleep=real_sleep
    def test_legacy_status_sentinels_signed_temperature_rounding_high_word(self):
        self.assertEqual(self.t.legacy_status()['temperature_C'],25.)
        default=self.t.legacy_status()
        self.assertIsNone(default['kappa25_integer_uScm'])
        self.assertIn('NLF_UNVERIFIED',default['flags'])
        self.assertFalse(default['kappa25_compatible_valid'])
        p,path=self.synthetic_profile();self.t.import_nlf(p,path)
        self.lib.set_legacy_values(-10.8,70000.5,(1<<1)|(1<<2))
        s=self.t.legacy_status()
        self.assertEqual(s['temperature_raw_hex'],'FBC8')
        self.assertEqual(s['temperature_C'],-10.8)
        self.assertEqual(s['kappa25_integer_uScm'],70001)
        self.assertEqual(s['kappa25_raw_hex'],'00011171')
        self.assertTrue(s['temperature_compatible_valid']);self.assertTrue(s['kappa25_compatible_valid'])
        self.assertIsInstance(s['status'],int);self.assertEqual(s['status_hex'],f"{s['status']:08X}")
        self.lib.set_legacy_values(float('nan'),float('nan'),0)
        s=self.t.legacy_status()
        self.assertEqual(s['temperature_raw_hex'],'8000')
        self.assertEqual(s['kappa25_raw_hex'],'FFFFFFFF')
        self.assertIn('LEGACY_TEMP_INVALID',s['flags'])
        self.assertIn('LEGACY_K25_INVALID',s['flags'])
        self.assertIsNone(s['temperature_C']);self.assertIsNone(s['kappa25_integer_uScm'])
    def test_legacy_auto_commit_and_old_response_without_calibration_commit(self):
        self.t.unlock();self.client.write_words(0x1100,m.f32words(1.1))
        result=self.t.legacy_configure('address',17)
        self.assertEqual(result['address'],17)
        q,r=next((q,r) for q,r in self.port.history if q[2:4]==b'\x01\x30' and q[1]==16)
        self.assertEqual(r[0],1);self.assertEqual(r[1],16)
        # Uncommitted calibration remains staged in RAM; reboot must reload old K.
        self.assertAlmostEqual(m.words_float(self.client.read_words(0x1100,2)),1.1,places=6)
        self.lib.reboot_device()
        self.assertAlmostEqual(m.words_float(self.client.read_words(0x1100,2)),1.0)
        self.assertEqual(self.client.read_words(0x0130,1),[17])
    def test_legacy_saturation_keeps_invalid_sentinels_reserved(self):
        self.lib.set_legacy_values(1000.,4294967296.,(1<<1)|(1<<2))
        s=self.t.legacy_status()
        self.assertEqual(s['temperature_raw_hex'],'7FFF')
        self.assertEqual(s['kappa25_raw_hex'],'FFFFFFFE')
        self.assertIsNone(s['temperature_C']);self.assertIsNone(s['kappa25_integer_uScm'])
        self.assertFalse(s['temperature_compatible_valid']);self.assertFalse(s['kappa25_compatible_valid'])
        flags=s['flags']
        self.assertIn('LEGACY_TEMP_SATURATED',flags);self.assertIn('LEGACY_K25_SATURATED',flags)
        self.lib.set_legacy_values(-1000.,123.,(1<<1)|(1<<2))
        self.assertEqual(self.t.legacy_status()['temperature_raw_hex'],'8001')
    def test_legacy_stale_and_unverified_values_are_not_reported_as_valid(self):
        self.lib.set_legacy_values(25.,123.,(1<<1)|(1<<2))
        s=self.t.legacy_status()
        self.assertIn('NLF_UNVERIFIED',s['flags'])
        self.assertEqual(s['kappa25_raw_hex'],'0000007B')
        self.assertIsNone(s['kappa25_integer_uScm']);self.assertFalse(s['kappa25_compatible_valid'])
        self.lib.set_sample_age(11000)
        s=self.t.legacy_status()
        self.assertIn('STALE',s['flags'])
        self.assertNotIn('LEGACY_TEMP_INVALID',s['flags']);self.assertIn('LEGACY_K25_INVALID',s['flags'])
        self.assertEqual(s['temperature_raw_hex'],'09C4');self.assertEqual(s['kappa25_raw_hex'],'FFFFFFFF')
        self.assertEqual(s['temperature_C'],25.);self.assertIsNone(s['kappa25_integer_uScm'])
        self.assertTrue(s['temperature_compatible_valid']);self.assertFalse(s['kappa25_compatible_valid'])
        self.lib.set_legacy_values(25.,123.,(1<<6))
        s=self.t.legacy_status()
        self.assertIn('RTD_FAULT',s['flags']);self.assertIn('LEGACY_TEMP_INVALID',s['flags'])
        self.assertIsNone(s['temperature_C']);self.assertFalse(s['temperature_compatible_valid'])
    def test_legacy_idempotent_write_does_not_commit_staged_or_wear_flash(self):
        self.t.unlock();self.client.write_words(0x1100,m.f32words(1.1))
        self.t.legacy_configure('address',1)
        self.assertEqual(self.lib.get_revision(),0)
        self.assertEqual(m.words_u32(self.client.read_words(0x8F0C,2)),0)
        self.assertAlmostEqual(m.words_float(self.client.read_words(0x1100,2)),1.1,places=6)
        self.lib.reboot_device()
        self.assertAlmostEqual(m.words_float(self.client.read_words(0x1100,2)),1.)
    def test_legacy_fc06_and_unsupported_manual_aliases_rejected(self):
        with self.assertRaises(m.ModbusException):self.client.write_word(0x0130,2)
        for register in (0x0013,0x0014,0x0133):
            with self.assertRaises(m.ModbusException) as result:self.client.read_words(register,1)
            self.assertEqual(result.exception.code,2)
    def test_legacy_format_write_rate_limit_and_persistence(self):
        self.t.legacy_configure('serial-format','8E1')
        self.assertEqual(self.port.parity,'E');self.assertEqual(self.lib.get_format(),1)
        with self.assertRaises(m.ModbusException) as result:self.t.legacy_configure('address',2)
        self.assertEqual(result.exception.code,6)
        self.assertEqual(self.client.address,1)
        self.lib.set_now(10000);self.t.legacy_configure('address',2)
        self.lib.reboot_device()
        self.assertEqual(self.lib.get_format(),1)
        self.assertEqual(self.client.read_words(0x0130,1),[2])
    def test_legacy_baud_only_documented_code_and_native_nonrepresentable(self):
        self.t.configure(baud=19200)
        self.assertEqual(self.client.read_words(0x0132,1),[0xFFFF])
        self.lib.set_now(10000)
        self.t.legacy_configure('baud',9600)
        self.assertEqual(self.client.read_words(0x0132,1),[1])
        self.assertEqual(self.client.baud,9600)
        with self.assertRaises(ValueError):self.t.legacy_configure('baud',19200)
        self.assertEqual(self.lib.get_revision(),2)
    def test_new_config_validation_before_flash_or_unlock(self):
        for kwargs in ({'serial_format':'8N3'},{'settling_ms':49},{'settling_ms':2001},{'settling_ms':120.5}):
            with self.assertRaises(ValueError):self.t.configure(**kwargs)
        self.assertEqual(self.lib.get_revision(),0);self.assertFalse(self.port.history)
    def test_bad_crc_rejected(self):
        self.port.corrupt=True
        with self.assertRaisesRegex(m.ModbusError,'CRC'):self.t.status()
    def test_bad_length_rejected_before_payload(self):
        self.port.bad_bytecount=True
        with self.assertRaisesRegex(m.ModbusError,'byte count'):self.t.status()
    def test_bad_write_echo_rejected(self):
        self.t.unlock();self.port.bad_echo=True
        with self.assertRaisesRegex(m.ModbusError,'echo'):self.client.write_word(0x1106,2)
    def test_exception_and_locked_write(self):
        with self.assertRaises(m.ModbusException) as result:self.client.write_words(0x1100,m.f32words(1.1))
        self.assertEqual(result.exception.code,3)
    def test_unsupported_read_address(self):
        with self.assertRaises(m.ModbusException) as result:self.client.read_words(0x1022,1)
        self.assertEqual(result.exception.code,2)
    def test_every_documented_register_block_is_readable_in_actual_firmware(self):
        rows=list(csv.DictReader((ROOT/'protocol/register_map.csv').open(encoding='utf-8-sig')))
        self.assertGreaterEqual(len(rows),124)
        for row in rows:
            start=int(row['起始地址HEX_零基'],0);count=int(row['寄存器数'])
            function=4 if 'FC04' in row['访问'] else 3
            with self.subTest(register=hex(start),name=row['名称']):
                self.assertEqual(len(self.client.read_words(start,count,function)),count)
    def test_force_keepalive_and_auto(self):
        self.t.unlock();self.t.force(1000,100,10)
        self.assertEqual(self.client.read_words(0x1400,4),[1,1,2,1])
        self.assertIn('MAINTENANCE',self.t.status()['flags'])
        self.t.keepalive();self.t.auto();self.t.lock()
        self.assertEqual(self.client.read_words(0x1400,1),[0])
        self.assertNotIn('MAINTENANCE',self.t.status()['flags'])
    def test_forced_timeout(self):
        self.t.unlock();self.t.force(100,10,10);self.lib.set_now(40000)
        self.assertEqual(self.client.read_words(0x1400,1),[0])
    def test_gain_calibration_uses_raw_G_not_K_or_existing_correction(self):
        self.lib.set_fixture(1,2)
        result=self.t.calibrate_gain(1000,100,10,.000125,samples=3,timeout=.5)
        self.assertEqual(result['gain_index'],25)
        self.assertEqual(len(result['raw_samples_S']),3)
        self.assertAlmostEqual(result['correction'],.000125/.000123,places=6)
        self.assertEqual(self.lib.get_mask(),1<<25)
        self.assertEqual(self.client.read_words(0x1400,1),[0])
    def test_invalid_calibration_input_does_not_write(self):
        with self.assertRaises(ValueError):self.t.calibrate_gain(100,10,10,-1)
        self.assertEqual(self.lib.get_revision(),0)
        with self.assertRaises(ValueError):self.t.configure(cell=3)
    def synthetic_profile(self):
        # Synthetic strictly decreasing curve for code validation, NOT ISO.
        values=[1/(1+.02*(t-25)) for t in range(36)]
        values=list(struct.unpack('<36f',struct.pack('<36f',*values)))
        path=Path(self.temp.name)/'SYNTHETIC_NOT_ISO.txt';path.write_text('Test-only curve; not an ISO source.')
        sha=hashlib.sha256(path.read_bytes()).digest();crc=m.zlib.crc32(struct.pack('<36f',*values))
        words=list(struct.unpack('>94H',struct.pack('>36f',*values)+struct.pack('>III',1,crc,0)+sha))
        return {'schema':'FW-EC-TX-NLF-PROFILE-1','temperature_points_C':list(range(36)),
          'nlf_factor25':values,'nlf_source_id':1,'nlf_source_sha256':sha.hex(),'nlf_table_crc32':crc,
          'nlf_flags_verified':m.NLF_MAGIC,'operator_review_recorded':True,
          'stage_write':{'function':16,'start_address_zero_based':0x1300,'register_count':94,'words':words}},path
    def test_nlf_import_actual_staging_and_enable_last(self):
        p,path=self.synthetic_profile();self.t.import_nlf(p,path)
        self.assertEqual(m.words_u32(self.client.read_words(0x134C,2)),m.NLF_MAGIC)
        self.assertEqual(m.words_u32(self.client.read_words(0x134A,2)),p['nlf_table_crc32'])
        self.assertNotIn('NLF_UNVERIFIED',self.t.status()['flags'])
    def test_nlf_rejects_unreviewed_and_wrong_source_and_modified_staging(self):
        p,path=self.synthetic_profile();p['operator_review_recorded']=False
        with self.assertRaisesRegex(ValueError,'review'):m.validate_nlf_profile(p,path)
        p['operator_review_recorded']=True;path.write_text('changed')
        with self.assertRaisesRegex(ValueError,'SHA256'):m.validate_nlf_profile(p,path)
        p,path=self.synthetic_profile();p['stage_write']['words'][0]^=1
        with self.assertRaisesRegex(ValueError,'inconsistent'):m.validate_nlf_profile(p,path)
    def test_bad_address_times_out(self):
        self.client.address=247
        with self.assertRaisesRegex(m.ModbusError,'timeout'):self.t.status()

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ClientTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
      'passed':result.wasSuccessful(),'target':'actual C tx_protocol.c + tx_storage.c + nlf.c through fragmented mock serial port',
      'limitations':['not physical UART/RS485/MCU Flash test','synthetic nLF fixture is not an ISO algorithm or production profile']}
    (HERE/'host_client_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
