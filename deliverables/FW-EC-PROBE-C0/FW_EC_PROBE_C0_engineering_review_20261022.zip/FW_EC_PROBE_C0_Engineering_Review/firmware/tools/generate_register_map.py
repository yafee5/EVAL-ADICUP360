#!/usr/bin/env python3
"""Human-readable register definitions reviewed against tx_protocol.c."""
from pathlib import Path
import csv

ROOT=Path(__file__).resolve().parents[1]
rows=[]
FIELDS=['起始地址HEX_零基','起始地址DEC_零基','寄存器数','数据类型','访问','名称','单位/编码','写入条件/说明']
def add_absolute(addr,count,kind,access,name,units='',notes=''):
    rows.append(dict(zip(FIELDS,[f'0x{addr:04X}',addr,count,kind,access,name,units,notes])))

def add(addr,count,kind,access,name,units='',notes=''):
    # B0-native definitions below are expressed relative to the C0 0x1000 bank.
    notes=notes.replace('0x7F02','0x8F02').replace('0x7F04','0x8F04').replace('336字节','340字节')
    units=units.replace('bit0..21','bit0..25').replace('0x0100','0x0200')
    if addr==0x107:
        name='扩展原生波特率代码'
        notes='原生编码与HR兼容0132编码不同；解锁，SAVE旧波特率回复且TEMT后生效。'
    if addr==0xC:notes='位定义见README；含新增HR整数接口无效/饱和标志bit22..25。'
    add_absolute(addr+0x1000,count,kind,access,name,units,notes)

for addr,name,unit in [(0,'实测电导率κ(T)','µS/cm'),(2,'25°C电导率κ25','µS/cm'),(4,'温度','°C'),(6,'原始电导G，未乘分档校正/K','S')]:
    add(addr,2,'float32','FC04/FC03只读',name,unit,'IEEE754，高字在前；无有效结果为NaN，须同时读状态。')
add(8,2,'int32','FC04/FC03只读','电压ADC正负相差值','ADC code','二补码，高字在前。')
add(0xA,2,'int32','FC04/FC03只读','电流ADC正负相差值','ADC code','二补码，高字在前。')
add(0xC,2,'uint32','FC04/FC03只读','状态/故障位','bit0..21','详见协议说明的状态表。')
add(0xE,2,'uint32','FC04/FC03只读','完整周期计数','cycle','用于判别新样本；切档丢弃期间不会发布新有效样本。')
for addr,name,units in [(0x10,'当前激励频率','Hz：100/1000'),(0x11,'当前电压通道增益GV','1/10/100/1000'),(0x12,'当前电流通道增益GI','1/10/100/1000'),(0x13,'当前校正表索引','f×16+v×4+i，初始化0xFFFF')]:add(addr,1,'uint16','FC04/FC03只读',name,units)
for addr,name,units in [(0x14,'运行时间','ms'),(0x16,'电导样本年龄','ms'),(0x1A,'生效配置版本计数','count'),(0x1C,'CRC错误计数','count'),(0x1E,'帧错误计数','count')]:add(addr,2,'uint32','FC04/FC03只读',name,units)
add(0x18,1,'uint16','FC04/FC03只读','协议版本','0x0100')
add(0x19,1,'uint16','FC04/FC03只读','保留','0')
for addr,name,unit,bounds in [(0x100,'电极常数K','cm^-1','0.5..1.5'),(0x102,'温度校准增益','无量纲','0.95..1.05'),(0x104,'温度校准偏移','°C','-5..5')]:
    add(addr,2,'float32','FC03读/FC10写',name,unit,f'解锁后整32位写，范围{bounds}；修改清对应校准标记；SAVE后生效。')
add(0x106,1,'uint16','FC03读/FC06或FC10写','通讯地址','1..247','解锁，SAVE旧地址回复完成后生效；不支持广播写。')
add(0x107,1,'uint16','FC03读/FC06或FC10写','波特率代码','0=9600；1=19200；2=38400；3=57600；4=115200','解锁，SAVE旧波特率回复且TEMT后生效。')
add(0x108,2,'uint32','FC03读/FC10写','增益校准有效掩码','bit n对应表索引n','每个系数写入自动置其bit；未实际校准的组合保留0。')
add(0x10A,1,'uint16','FC03读/FC06或FC10写','K/温度已校准标志','bit0=K，bit1=温度','解锁；只有实际标定完成后设置，不是写入软件即可认证精度。')
add(0x10B,1,'uint16','FC03只读','参数协议版本','0x0100')
add(0x10C,2,'float32','FC03只读','频率切档中心参考值','200 µS/cm','实际自动切换使用190/210滞回；该值不可写。')
gains=(1,10,100,1000)
for f,hz in enumerate((100,1000)):
    for v,gv in enumerate(gains):
        for i,gi in enumerate(gains):
            n=f*16+v*4+i
            add(0x200+2*n,2,'float32','FC03读/FC10写',f'校正系数[{n}]：{hz}Hz GV={gv} GI={gi}','0.5..2.0',
                '解锁后整32位写；乘原始G后再乘K；写入自动置对应有效bit，SAVE后生效。')
for t in range(36):
    add(0x300+2*t,2,'float32','FC03读/FC10写',f'nLF factor25[{t}°C]','κ25=κ(T)×factor25(T)',
        '当前未附ISO正式因子。每次修改清NLF1标记，最后单独启用；必须来源可追溯/人工审定。')
add(0x348,2,'uint32','FC03读/FC10写','nLF来源ID','非0 uint32','修改清NLF1标记。')
add(0x34A,2,'uint32','FC03读/FC10写','nLF表CRC32','36个float32小端字节的标准CRC32','修改清NLF1标记；不是ISO来源真实性认证。')
add(0x34C,2,'uint32','FC03读/FC10写','nLF审定启用标记','0=禁用；0x4E4C4631=NLF1','表、来源ID、SHA、CRC均写完并审定后，单独最后写入。')
add(0x34E,16,'byte[32]','FC03读/FC06或FC10写','nLF来源文件SHA256','每寄存器高字节先传，32原始hash字节','任何来源hash修改清NLF1标记；SHA只是身份追溯。')
for addr,name,units in [(0x400,'维护模式','0=AUTO，1=强制校准'),(0x401,'维护频率索引','0=100Hz，1=1000Hz'),(0x402,'维护GV索引','0/1/2/3→1/10/100/1000'),(0x403,'维护GI索引','0/1/2/3→1/10/100/1000')]:
    add(addr,1,'uint16','FC03读/FC06或FC10写',name,units,'解锁，仅RAM；模式/档位变化丢整周期；30秒无维护写/keepalive则退AUTO，SAVE/锁定也退AUTO。')
add(0x404,1,'uint16','FC03读/FC06或FC10写','维护/解锁续期','写0xA55A，读0','仅已解锁可写；延长30秒，不重置暂存参数。')
add(0x405,1,'uint16','FC03只读','保留','0')
add(0x406,2,'uint32','FC03只读','维护模式版本','count','采集模块据变化丢完整周期。')
add(0x7F00,2,'uint32','FC03读/FC10写','解锁/取消','写0xC35A5AC3解锁，写0取消，读0','解锁会重新复制active到staged；不要拿重复unlock作keepalive。')
add(0x7F02,2,'uint32','FC03读/FC10组合写','SAVE命令','写0x53415645，读0','必须从0x7F02一次FC10写4寄存器：SAVE键+staged参数CRC；不能只写这2字。')
add(0x7F04,2,'uint32','FC03读/FC10组合写','SAVE预期参数CRC','读0','仅作0x7F02 count=4组合写的后两字；不得独立写0x7F04。')
add(0x7F06,2,'uint32','FC03只读','当前active参数CRC32','CRC32','336字节规范编码payload的CRC。')
add(0x7F08,2,'uint32','FC03只读','当前staged参数CRC32','CRC32','提交时读取此值，一并写SAVE。')
add(0x7F0A,1,'uint16','FC03只读','参数状态','bit0解锁，bit1待生效，bit2已从Flash加载，bit3存储故障')
add(0x7F0B,1,'uint16','FC03只读','最后存储错误','0正常，1无记录，2IO，3回读校验，4参数非法，5未解锁，6CRC错，7提交过密')
add(0x7F0C,2,'uint32','FC03只读','Flash序号','uint32环回序号')
add(0x7F0E,2,'uint32','FC03只读','剩余解锁时间','ms')
add(0x7F10,2,'uint32','FC03读/FC10写','恢复默认值到staged','写0x44454654，读0','仅已解锁；尚不改active/Flash，须另SAVE；不用于日常维护。')

# Absolute HR compatibility fields and C0 additions.
add_absolute(3,1,'int16','FC03只读','HR兼容温度','0.01°C','二补码，四舍五入；无效0x8000；饱和范围0x8001..0x7FFF，须读bit24；+10.80°C=0x0438，-10.80°C=0xFBC8；完整精度用0x1004。')
add_absolute(6,2,'uint32','FC03只读','HR兼容κ25整数','µS/cm','高字在前，四舍五入；无效0xFFFFFFFF；饱和上限0xFFFFFFFE，须读bit25；量化±0.5 µS/cm，仅兼容外机，完整精度用0x1002。')
add_absolute(304,1,'uint16','FC03读/FC10单字写','HR兼容通讯地址','1..247','无需校准解锁；active副本独立A/B保存，旧地址/格式回包后生效；不提交staged校准；同值写不擦Flash。')
add_absolute(306,1,'uint16','FC03读/FC10单字写','HR兼容波特率代码','仅1=9600','手册仅明确1=9600；写其他值拒绝；原生波特率非9600时读0xFFFF。其他波特率用扩展0x1107。')
add_absolute(308,1,'uint16','FC03读/FC10单字写','HR兼容校验格式代码','0=8O1；1=8E1；2=8N2；3=8N1','默认3；无需校准解锁；至少5s写Flash限频，失败异常无切换；旧格式回包TEMT后生效。')
add_absolute(4366,1,'uint16','FC03读/FC06或FC10写','扩展串口校验格式','0=8O1；1=8E1；2=8N2；3=8N1','默认3；解锁，范围校验，CRC保护，SAVE回复完成后生效；Flash schema2。')
add_absolute(4367,1,'uint16','FC03读/FC06或FC10写','换极性后稳定等待','ms，50..2000','默认120ms；解锁、SAVE后生效，并丢弃完整电导周期；不替代实际探头的稳定性验证。')
rows.sort(key=lambda row:int(row['起始地址HEX_零基'],0))

if __name__=='__main__':
    out=ROOT/'protocol/register_map.csv'
    with out.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=FIELDS,lineterminator='\n');writer.writeheader();writer.writerows(rows)
    print(f'Wrote {out}: {len(rows)} register blocks')
