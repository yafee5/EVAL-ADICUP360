#!/usr/bin/env python3
"""Run the actual software checks and produce a truthful release summary."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'build';OUT.mkdir(exist_ok=True)
jobs=[
 ('acquisition_framer_main_hal',['python3','tests/run_tests.py']),
 ('modbus_flash_journal',['sh','protocol/tests/run_tests.sh']),
 ('nlf_numerics_integrity',['python3','../compensation/test_nlf.py']),
 ('client_actual_C_protocol',['python3','tools/test_client.py']),
 ('arm_image',['python3','build_firmware.py']),
]
results=[]
for name,cmd in jobs:
 start=time.monotonic()
 p=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 elapsed=time.monotonic()-start
 (OUT/(name+'_verification.log')).write_text(p.stdout,encoding='utf-8')
 results.append({'name':name,'command':cmd,'cwd':'firmware','exit_code':p.returncode,
                 'wall_seconds':round(elapsed,3),'output':p.stdout.strip()})
 print(name+': '+('PASS' if p.returncode==0 else 'FAIL'),flush=True)
 if p.returncode:print(p.stdout,flush=True);break
passed=len(results)==len(jobs) and all(r['exit_code']==0 for r in results)
summary={'target':'FW-EC-PROBE Rev C0 bench candidate',
         'board_pinmap':'CN0359 Rev A bench only; final C0 PCB not verified',
         'C0_PCB_finalized':False,
         'checked_at_utc':datetime.now(timezone.utc).isoformat(),'all_checks_passed':passed,
         'commands':results,'hardware_execution_tested':False,
         'physical_UART_RS485_tested':False,'physical_Flash_power_loss_tested':False,
         'sensor_accuracy_verified':False,'ISO_nLF_conformance_verified':False,
         'nlf_factory_profile':'Disabled; kappa25=NaN and NLF_UNVERIFIED until reviewed traceable factors are provisioned',
         'limitations':['C0 PCB pin mapping, power budget and mechanical layout are not finalized; HEX is a Rev A bench candidate.',
                        'HAL and client tests use the actual C application/protocol with simulated peripheral operations.',
                        'nLF fixtures test interpolation and corruption handling; they are synthetic, not ISO coefficients.',
                        'Compiler stack reports and image bounds do not replace measured stack watermark or board tests.']}
if (OUT/'manifest.json').exists():summary['build_manifest']=json.loads((OUT/'manifest.json').read_text())
if (OUT/'image_validation.json').exists():summary['image_validation']=json.loads((OUT/'image_validation.json').read_text())
if (ROOT/'tools/host_client_validation.json').exists():summary['client_validation']=json.loads((ROOT/'tools/host_client_validation.json').read_text())
if (ROOT.parent/'compensation/host_validation.json').exists():summary['nlf_validation']=json.loads((ROOT.parent/'compensation/host_validation.json').read_text())
(OUT/'firmware_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if passed else 1)
