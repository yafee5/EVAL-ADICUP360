/* SPDX-License-Identifier: MIT
 * ADuCM360 User Guide UG-367 Rev E pp105-109: 512-byte erase pages,
 * 32-bit stores, status clear-on-read. Keep final security/configuration page
 * 0x1FE00..0x1FFFF untouched. Calibration A/B live immediately below it.
 */
#include "tx_board.h"
#include "ADuCM360.h"
#include <string.h>

static const uintptr_t slot_address[2]={0x1FA00u,0x1FC00u};
static bool read_slot(void *user,unsigned slot,uint32_t off,void *data,size_t n) {
 (void)user;if(slot>=2||off>512||n>512-off)return false;
 memcpy(data,(const void *)(slot_address[slot]+off),n);return true;
}
/* Runs from copied .data/RAM, including literal pools, while flash is busy. */
__attribute__((section(".ramfunc"),noinline))
static bool flash_erase_ram(uintptr_t address) {
 uint32_t status;unsigned limit=1000000;
 do {status=pADI_FEE->FEESTA;}while((status&3u)&&--limit);
 if(!limit)return false;
 pADI_FEE->FEEADR0H=(uint16_t)((address>>16)&1u);
 pADI_FEE->FEEADR0L=(uint16_t)(address&0xFE00u);
 pADI_FEE->FEEKEY=FEEKEY_VALUE_USERKEY1;
 pADI_FEE->FEEKEY=FEEKEY_VALUE_USERKEY2;
 pADI_FEE->FEECMD=FEECMD_CMD_ERASEPAGE;
 limit=1000000;
 do {status=pADI_FEE->FEESTA;}while(!(status&FEESTA_CMDDONE_MSK)&&--limit);
 if(!limit||(status&FEESTA_CMDRES_MSK))return false;
 for(unsigned i=0;i<128;i++)if(((volatile const uint32_t*)address)[i]!=UINT32_MAX)return false;
 return true;
}
__attribute__((section(".ramfunc"),noinline))
static bool flash_program_ram(uintptr_t addr,const uint8_t *p,size_t bytes) {
 uint32_t status;unsigned limit=1000000;
 do {status=pADI_FEE->FEESTA;}while((status&3u)&&--limit);
 if(!limit)return false;
 pADI_FEE->FEECON0|=FEECON0_WREN_MSK;
 for(size_t i=0;i<bytes;i+=4) {
  uint32_t word=(uint32_t)p[i]|((uint32_t)p[i+1]<<8)|((uint32_t)p[i+2]<<16)|((uint32_t)p[i+3]<<24);
  /* Only previously erased words are programmed, once per transaction. */
  if(*(volatile const uint32_t*)(addr+i)!=UINT32_MAX){pADI_FEE->FEECON0&=(uint16_t)~FEECON0_WREN_MSK;return false;}
  *(volatile uint32_t*)(addr+i)=word;
  limit=1000000;
  do {status=pADI_FEE->FEESTA;}while(!(status&FEESTA_WRDONE_MSK)&&--limit);
  if(!limit||(status&FEESTA_CMDRES_MSK)||*(volatile const uint32_t*)(addr+i)!=word) {
   pADI_FEE->FEECON0&=(uint16_t)~FEECON0_WREN_MSK;return false;
  }
 }
 pADI_FEE->FEECON0&=(uint16_t)~FEECON0_WREN_MSK;return true;
}
static bool erase_slot(void *user,unsigned slot) {
 (void)user;if(slot>=2)return false;
 tx_board_adc_pause();
 uint32_t primask=__get_PRIMASK();__disable_irq();
 bool ok=flash_erase_ram(slot_address[slot]);
 __set_PRIMASK(primask);return ok;
}
static bool program_slot(void *user,unsigned slot,uint32_t off,const void *data,size_t n) {
 (void)user;if(slot>=2||off>512||n>512-off||(off&3u)||(n&3u))return false;
 uint32_t primask=__get_PRIMASK();__disable_irq();
 bool ok=flash_program_ram(slot_address[slot]+off,(const uint8_t*)data,n);
 __set_PRIMASK(primask);return ok;
}
const tx_flash_ops_t tx_board_flash_ops={read_slot,erase_slot,program_slot};
