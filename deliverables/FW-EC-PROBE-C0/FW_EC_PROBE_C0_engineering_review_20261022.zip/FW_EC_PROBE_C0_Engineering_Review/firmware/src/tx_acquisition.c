/* SPDX-License-Identifier: MIT
 * Four complete synchronous phases use the Rev A AIN/PWM polarity mapping.
 * Electrical gain/frequency calibration is applied only to a coherent cycle.
 */
#include "tx_acquisition.h"
#include <math.h>
#include <string.h>

static const unsigned gains[4]={1,10,100,1000};
void tx_acq_init(tx_acq_state *s) {
 memset(s,0,sizeof(*s));s->gv_index=1;s->gi_index=1;s->discard_cycles=1;
}
void tx_acq_restart(tx_acq_state *s) {
 s->phase=0;s->cycle_fault=0;s->discard_cycles=1;
}
static unsigned choose_gain(unsigned old, float peak) {
 const float full=268435456.0f;
 if(peak>0.94f*full && old) return old-1;
 if(peak<0.080f*full && old<3) return old+1;
 return old;
}
tx_acq_event tx_acq_push(tx_acq_state *s,int32_t code,uint32_t adc_fault,
                        float cell_constant,float correction,tx_acq_result *o) {
 s->raw[s->phase]=code;s->cycle_fault|=adc_fault?TX_ACQ_ADC_ERROR:0;
 if(++s->phase<4)return TX_ACQ_MORE;
 s->phase=0;++s->cycle;
 const float ip=fmaxf(fabsf((float)s->raw[0]),fabsf((float)s->raw[2]));
 const float vp=fmaxf(fabsf((float)s->raw[1]),fabsf((float)s->raw[3]));
 if(s->discard_cycles){--s->discard_cycles;s->cycle_fault=0;return TX_ACQ_DISCARDED;}
 unsigned ngv=choose_gain(s->gv_index,vp),ngi=choose_gain(s->gi_index,ip);
 if(s->forced){ngv=s->gv_index;ngi=s->gi_index;}
 /* A saturated ADC reports ERR: reducing gain must still recover from it.
  * Never increase a gain on an otherwise invalid/underrange conversion. */
 if(s->cycle_fault) {
  if(ngv>s->gv_index)ngv=s->gv_index;
  if(ngi>s->gi_index)ngi=s->gi_index;
 }
 if(ngv!=s->gv_index || ngi!=s->gi_index) {
  s->gv_index=(uint8_t)ngv;s->gi_index=(uint8_t)ngi;
  s->discard_cycles=1;s->cycle_fault=0;return TX_ACQ_CHANGED;
 }
 memset(o,0,sizeof(*o));memcpy(o->raw,s->raw,sizeof(o->raw));
 o->gv=(uint16_t)gains[s->gv_index];o->gi=(uint16_t)gains[s->gi_index];
 o->frequency_hz=s->frequency_index?1000:100;o->cycle=s->cycle;
 o->status=s->cycle_fault;s->cycle_fault=0;
 if(ip>0.94f*268435456.f || vp>0.94f*268435456.f)o->status|=TX_ACQ_OVERLOAD;
 if(ip<0.008f*268435456.f || vp<0.008f*268435456.f)o->status|=TX_ACQ_WEAK;
 float di=(float)s->raw[0]-(float)s->raw[2];
 float dv=(float)s->raw[1]-(float)s->raw[3];
 o->conductance_s=NAN;o->kappa_t_us_cm=NAN;
 if(!(o->status&(TX_ACQ_ADC_ERROR|TX_ACQ_OVERLOAD|TX_ACQ_WEAK)) && fabsf(dv)>1.f &&
     isfinite(cell_constant) && cell_constant>0 && isfinite(correction) && correction>0) {
  /* R47=1000 ohm; equal nominal attenuation ratios cancel. */
  o->conductance_s=fabsf(di/dv)*((float)o->gv/(float)o->gi)/1000.f;
  o->kappa_t_us_cm=o->conductance_s*1e6f*cell_constant*correction;
  unsigned next=s->frequency_index;
  if(!next && o->kappa_t_us_cm>210.f)next=1;
  else if(next && o->kappa_t_us_cm<190.f)next=0;
  if(!s->forced&&next!=s->frequency_index) {
   s->frequency_index=(uint8_t)next;s->discard_cycles=1;return TX_ACQ_CHANGED;
  }
  if(o->kappa_t_us_cm<10.f || o->kappa_t_us_cm>2000.f)o->status|=TX_ACQ_OUT_OF_RANGE;
 }
 else o->status|=TX_ACQ_ADC_ERROR;
 ++s->published;return TX_ACQ_READY;
}

float tx_pt1000_resistance(uint32_t code) {
 /* The 2 Mohm unbuffered-input model is ADI typical, not a precision shunt.
  * Final sensor+AFE calibration must absorb actual input loading. */
 if(code>=0x10000000u)return NAN;
 float x=(float)code/268435456.f;
 return 4990.f*2000000.f*x/(2000000.f+4990.f-4990.f*x);
}
bool tx_pt1000_temperature(uint32_t code,float gain,float offset,float *t,float *r) {
 *t=NAN;*r=tx_pt1000_resistance(code);
 if(!isfinite(*r)||*r<980.f||*r>1220.f||!isfinite(gain)||!isfinite(offset)||gain<=0)return false;
 float q=*r/1000.f,c=1.f-q;
 const float a=3.9083e-3f,b=-5.775e-7f;
 float d=a*a-4.f*b*c;
 if(d<=0)return false;
 float raw=-2.f*c/(a+sqrtf(d));
 float calibrated=raw*gain+offset;
 if(!isfinite(calibrated)||calibrated< -5.f||calibrated>55.f)return false;
 *t=calibrated;return true;
}
unsigned tx_pwm_period(unsigned clock,unsigned hz,unsigned *pre) {
 *pre=0;
 while((clock/hz)/(2u<<*pre)>65536u && *pre<7u)++*pre;
 return (clock+hz*(1u<<*pre))/(hz*(2u<<*pre));
}
