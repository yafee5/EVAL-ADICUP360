/***************************************************************************//**
 *   @file   adc.cpp
 *   @brief  Implementation of adc.cpp
 *   @author
 *******************************************************************************
 * Copyright 2023(c) Analog Devices, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  - Neither the name of Analog Devices, Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *  - The use of this software may or may not infringe the patent rights
 *    of one or more patent holders.  This license does not release you
 *    from the requirement that you obtain separate licenses from these
 *    patent holders to use this software.
 *  - Use of the software either in source or binary form, must be run
 *    on or directly connected to an Analog Devices Inc. component.
 *
 * THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT,
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL ANALOG DEVICES BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, INTELLECTUAL PROPERTY RIGHTS, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/* SPDX-License-Identifier: LicenseRef-ADI-CN0359
 * ADC/PWM/DAC/gain register setup derived from ADI CN0359 Rev A source.
 * Copyright 2023 Analog Devices, Inc.; adaptations copyright 2026 project.
 * The complete original license is in vendor/ADI_CN0359_LICENSE.txt.
 * No LCD/SPI/menu/encoder/buzzer code is linked into this product.
 * C0 bench-candidate HAL retains the CN0359 Rev A pin assignment.
 * The narrow C0 PCB is not finalized; this is not a verified C0 board mapping.
 */
#include "tx_board.h"
#include "tx_acquisition.h"
#include "tx_rtu_framer.h"
#include "ADuCM360.h"
#include <string.h>
extern uint32_t uClk;

static volatile uint32_t ms,paused_epoch;
static volatile int32_t a0_code;
static volatile uint32_t a0_fault,a1_code,a1_fault;
static volatile bool a0_ready,a1_ready;
static volatile unsigned rtd_mode;
static tx_rtu_framer framer;
static uint8_t transmit[TX_RTU_MAX];
static volatile uint16_t transmit_length,transmit_position;
static volatile bool transmit_active;
static volatile uint32_t uart_line_errors;
static uint32_t uart_framer_errors_base; /* Keep public count monotonic across format changes. */
static unsigned pwm_frequency=99;
void SysTick_Handler(void){++ms;}
uint32_t tx_board_millis(void){return ms;}
uint32_t tx_board_pause_epoch(void){return paused_epoch;}
/* Keep CYCCNT advancing: sleeping the core can stop DWT on this MCU.
 * The bench candidate intentionally polls rather than entering WFI. */
void tx_board_sleep(void){__NOP();}

static void gpio_setup(void) {
 /* Unpopulated LCD pins: input, pull-up, no SPI clock. */
 pADI_GP0->GPCON &= (uint16_t)~(GP0CON_CON1_MSK|GP0CON_CON2_MSK|GP0CON_CON3_MSK|GP0CON_CON4_MSK);
 pADI_GP0->GPOEN &= (uint8_t)~0x1Eu;pADI_GP0->GPPUL|=0x1Eu;
 /* Encoder inputs stay high and no external IRQ is enabled. */
 pADI_GP1->GPCON &= (uint16_t)~(GP1CON_CON1_MSK|GP1CON_CON5_MSK|GP1CON_CON7_MSK);
 pADI_GP1->GPOEN &= (uint8_t)~0xA2u;pADI_GP1->GPPUL|=0xA2u;
 pADI_GP2->GPCON &= (uint16_t)~GP2CON_CON2_MSK;
 GP2OEN_OEN2_BBA=0;GP2PUL_PUL2_BBA=1;
 /* AD8253 gain address/latches and PWMSYNC. */
 pADI_GP0->GPCON&=(uint16_t)~GP0CON_CON0_MSK;
 pADI_GP1->GPCON=(pADI_GP1->GPCON&~(GP1CON_CON0_MSK|GP1CON_CON2_MSK|GP1CON_CON3_MSK|GP1CON_CON4_MSK|GP1CON_CON6_MSK))|
                  GP1CON_CON0_PWMSYNC|GP1CON_CON3_PWM1|GP1CON_CON4_PWM2|GP1CON_CON6_PWM4;
 pADI_GP2->GPCON&=(uint16_t)~(GP2CON_CON0_MSK|GP2CON_CON1_MSK);
 GP0OCE_OCE0_BBA=0;GP1OCE_OCE0_BBA=0;GP1OCE_OCE2_BBA=0;
 GP1OCE_OCE3_BBA=0;GP1OCE_OCE4_BBA=0;GP1OCE_OCE6_BBA=0;
 GP2OCE_OCE0_BBA=0;GP2OCE_OCE1_BBA=0;
 GP0SET_SET0_BBA=1;GP2SET_SET0_BBA=1;
 GP0OEN_OEN0_BBA=1;GP1OEN_OEN0_BBA=1;GP1OEN_OEN2_BBA=1;
 GP1OEN_OEN3_BBA=1;GP1OEN_OEN4_BBA=1;GP1OEN_OEN6_BBA=1;
 GP2OEN_OEN0_BBA=1;GP2OEN_OEN1_BBA=1;
 GP0PUL_PUL0_BBA=1;GP1PUL_PUL0_BBA=1;GP1PUL_PUL2_BBA=1;
 GP1PUL_PUL3_BBA=1;GP1PUL_PUL4_BBA=1;GP1PUL_PUL6_BBA=1;
 GP2PUL_PUL0_BBA=1;GP2PUL_PUL1_BBA=1;
}
static void gain_address(unsigned index) {
 if(index&1u)GP1SET_SET2_BBA=1;else GP1CLR_CLR2_BBA=1;
 if(index&2u)GP2SET_SET1_BBA=1;else GP2CLR_CLR1_BBA=1;
 __DSB();
}
void tx_board_gains(unsigned gv,unsigned gi) {
 gain_address(gv);GP0CLR_CLR0_BBA=1;__NOP();__NOP();GP0SET_SET0_BBA=1;
 gain_address(gi);GP2CLR_CLR0_BBA=1;__NOP();__NOP();GP2SET_SET0_BBA=1;
}
void tx_board_pwm(unsigned frequency,bool invert) {
 if(pwm_frequency==frequency) {PWMCON0_PWM1INV_BBA=invert;return;}
 unsigned pre,len=tx_pwm_period(uClk,frequency?1000u:100u,&pre);
 PWMCON0_ENABLE_BBA=0;
 pADI_PWM->PWMCON0=(uint16_t)(pre<<6);
 pADI_PWM->PWM0LEN=pADI_PWM->PWM1LEN=pADI_PWM->PWM2LEN=(uint16_t)(len-1u);
 pADI_PWM->PWM0COM0=0;pADI_PWM->PWM0COM1=0xFFFF;
 pADI_PWM->PWM0COM2=(uint16_t)((len-1u)>>1);
 pADI_PWM->PWM1COM2=0;pADI_PWM->PWM2COM2=0;
 unsigned half=pADI_PWM->PWM0COM2;
 unsigned setup=(half+5u)/10u,hold=(half+50u)/100u;
 pADI_PWM->PWM1COM1=(uint16_t)setup;pADI_PWM->PWM1COM0=(uint16_t)(half-hold);
 pADI_PWM->PWM2COM1=(uint16_t)(half+setup);pADI_PWM->PWM2COM0=(uint16_t)(len-1u-hold);
 PWMCON0_PWM1INV_BBA=invert;PWMCON1_TRIPEN_BBA=0;
 PWMCON0_SYNC_BBA=1;PWMCON0_ENABLE_BBA=1;
 GP1TGL_TGL2_BBA=1;GP1TGL_TGL2_BBA=1;
 PWMCON0_ENABLE_BBA=0;PWMCON0_SYNC_BBA=0;PWMCON0_ENABLE_BBA=1;
 PWMCON0_LCOMP_BBA=1;pwm_frequency=frequency;
}

void tx_board_adc0_begin(unsigned phase) {
 uint32_t mask=__get_PRIMASK();__disable_irq();
 ADC0CON_ADCEN_BBA=0;
 (void)pADI_ADC0->DAT;NVIC_ClearPendingIRQ(ADC0_IRQn);
 pADI_ADC0->CON=(pADI_ADC0->CON&~(ADC0CON_ADCCP_MSK|ADC0CON_ADCCN_MSK))|
   ((phase&1u)?(ADC0CON_ADCCP_AIN2|ADC0CON_ADCCN_AIN3):(ADC0CON_ADCCP_AIN0|ADC0CON_ADCCN_AIN1));
 pADI_ADC0->MDE=(pADI_ADC0->MDE&~ADC0MDE_ADCMD_MSK)|ADC0MDE_ADCMD_SINGLE;
 a0_ready=false;ADC0CON_ADCEN_BBA=1;__set_PRIMASK(mask);
}
void tx_board_rtd_begin(unsigned state) {
 uint32_t mask=__get_PRIMASK();__disable_irq();
 ADC1CON_ADCEN_BBA=0;rtd_mode=state;
 (void)pADI_ADC1->DAT;NVIC_ClearPendingIRQ(ADC1_IRQn);
 uint32_t con=pADI_ADC1->CON&~(ADC1CON_ADCREF_MSK|ADC1CON_ADCDIAG_MSK|ADC1CON_ADCCP_MSK|ADC1CON_ADCCN_MSK);
 if(state<2) {
  pADI_ADCSTEP->DETCON=0;
  con|=ADC1CON_ADCREF_INTREF|ADC1CON_ADCDIAG_DIAG_ALL|ADC1CON_ADCCN_AGND|
       (state==0?ADC1CON_ADCCP_AIN6:ADC1CON_ADCCP_AIN5);
 } else {
  /* UG-367 Table43: write bit3 to clear the latched REFSTA bit4. */
  pADI_ADCSTEP->DETSTA=DETSTA_DATOF_MSK;
  pADI_ADCSTEP->DETCON=DETCON_REFDET_EN|DETCON_ADCSEL_EN;
  con|=ADC1CON_ADCREF_EXTREF2|ADC1CON_ADCDIAG_DIAG_OFF|ADC1CON_ADCCP_AIN6|ADC1CON_ADCCN_AIN5;
 }
 pADI_ADC1->CON=con;
 pADI_ADC1->MDE=(pADI_ADC1->MDE&~ADC1MDE_ADCMD_MSK)|ADC1MDE_ADCMD_SINGLE;
 a1_ready=false;ADC1CON_ADCEN_BBA=1;__set_PRIMASK(mask);
}
void tx_board_adc_pause(void) {
 uint32_t mask=__get_PRIMASK();__disable_irq();
 ADC0CON_ADCEN_BBA=0;ADC1CON_ADCEN_BBA=0;
 (void)pADI_ADC0->DAT;(void)pADI_ADC1->DAT;
 NVIC_ClearPendingIRQ(ADC0_IRQn);NVIC_ClearPendingIRQ(ADC1_IRQn);
 a0_ready=false;a1_ready=false;++paused_epoch;
 __set_PRIMASK(mask);
}
bool tx_board_adc0_result(int32_t *code,uint32_t *fault) {
 if(!a0_ready)return false;
 uint32_t p=__get_PRIMASK();__disable_irq();
 *code=a0_code;*fault=a0_fault;a0_ready=false;__set_PRIMASK(p);return true;
}
bool tx_board_adc1_result(uint32_t *code,uint32_t *fault) {
 if(!a1_ready)return false;
 uint32_t p=__get_PRIMASK();__disable_irq();
 *code=a1_code;*fault=a1_fault;a1_ready=false;__set_PRIMASK(p);return true;
}
void ADC0_Int_Handler(void) {
 a0_fault=pADI_ADC0->STA&(ADC0STA_ERR_MSK|ADC0STA_OVR_MSK);
 a0_code=(int32_t)pADI_ADC0->DAT;a0_ready=true;
}
void ADC1_Int_Handler(void) {
 a1_fault=pADI_ADC1->STA&(ADC1STA_ERR_MSK|ADC1STA_OVR_MSK);
 if(rtd_mode==2 && (pADI_ADCSTEP->DETSTA&DETSTA_REFSTA_MSK))a1_fault|=0x100u;
 a1_code=pADI_ADC1->DAT;a1_ready=true;
}

static void uart_baud(uint32_t baud) {
 uint64_t numerator=(uint64_t)uClk*64u,best_error=UINT64_MAX;
 unsigned best_div=1,best_f=2048;
 unsigned low=(unsigned)(numerator/(baud*8191u));if(low<1)low=1;
 unsigned high=(unsigned)(numerator/(baud*2048u))+1;if(high>65535)high=65535;
 for(unsigned div=low;div<=high;div++) {
  uint64_t denom=(uint64_t)baud*div;
  unsigned f=(unsigned)((numerator+denom/2)/denom);
  if(f<2048)f=2048;
  if(f>8191)f=8191;
  uint64_t actual=denom*f,error=actual>numerator?actual-numerator:numerator-actual;
  if(error<best_error){best_error=error;best_div=div;best_f=f;}
 }
 pADI_UART->COMDIV=(uint16_t)best_div;
 pADI_UART->COMFBR=(uint16_t)(COMFBR_ENABLE_EN|best_f);
}
void tx_board_uart_init(uint32_t baud,uint8_t serial_format) {
 NVIC_DisableIRQ(UART_IRQn);pADI_UART->COMIEN=0;
 pADI_GP0->GPCON=(pADI_GP0->GPCON&~(GP0CON_CON5_MSK|GP0CON_CON6_MSK|GP0CON_CON7_MSK))|
                  GP0CON_CON5_GPIOIRQ1|GP0CON_CON6_UARTRXD|GP0CON_CON7_UARTTXD;
 GP0CLR_CLR5_BBA=1;GP0OCE_OCE5_BBA=0;GP0OCE_OCE6_BBA=0;GP0OCE_OCE7_BBA=0;
 GP0OEN_OEN5_BBA=1;GP0OEN_OEN6_BBA=0;GP0OEN_OEN7_BBA=1;
 GP0PUL_PUL5_BBA=1;GP0PUL_PUL6_BBA=1;GP0PUL_PUL7_BBA=1;
 pADI_UART->COMCON=COMCON_DISABLE_DIS;
 /* HR8033 format codes: parity enabled for O/E, two stops only for 8N2.
  * tx_params_valid() restricts the stored code to 0..3; default is 8N1. */
 uint8_t line_control=COMLCR_WLS_8BITS;
 switch(serial_format) {
 case 0:line_control|=COMLCR_PEN_EN;break; /* 8O1: EPS clear */
 case 1:line_control|=COMLCR_PEN_EN|COMLCR_EPS_EN;break; /* 8E1 */
 case 2:line_control|=COMLCR_STOP_EN;break; /* 8N2 */
 default:break; /* 8N1 */
 }
 pADI_UART->COMLCR=line_control;
 pADI_UART->COMMCR=0;uart_baud(baud);
 uart_framer_errors_base+=framer.discarded;
 tx_rtu_init(&framer,uClk,baud,serial_format);transmit_active=false;transmit_length=0;transmit_position=0;
 (void)pADI_UART->COMLSR;
 if(pADI_UART->COMLSR&COMLSR_DR_MSK)(void)pADI_UART->COMRX;
 pADI_UART->COMIEN=COMIEN_ERBFI_EN|COMIEN_ELSI_EN;
 NVIC_SetPriority(UART_IRQn,1);NVIC_ClearPendingIRQ(UART_IRQn);NVIC_EnableIRQ(UART_IRQn);
}
size_t tx_board_uart_receive(uint8_t *out,size_t cap) {
 uint32_t p=__get_PRIMASK();__disable_irq();
 tx_rtu_idle(&framer,DWT->CYCCNT);size_t n=tx_rtu_take(&framer,out,cap);
 __set_PRIMASK(p);return n;
}
uint32_t tx_board_uart_frame_errors(void){return uart_framer_errors_base+framer.discarded+uart_line_errors;}
void tx_board_uart_send(const uint8_t *p,size_t n) {
 if(!n||n>TX_RTU_MAX||transmit_active)return;
 uint32_t mask=__get_PRIMASK();__disable_irq();
 memcpy(transmit,p,n);transmit_length=(uint16_t)n;transmit_position=1;transmit_active=true;
 GP0SET_SET5_BBA=1;
 /* ADM2587E enable propagation margin before first start bit. */
 for(volatile unsigned i=0;i<32;i++)__NOP();
 pADI_UART->COMTX=transmit[0];pADI_UART->COMIEN|=COMIEN_ETBEI_EN;
 __set_PRIMASK(mask);
}
bool tx_board_uart_transmitted(void) {
 if(transmit_active&&transmit_position==transmit_length&&(pADI_UART->COMLSR&COMLSR_TEMT_MSK)) {
  pADI_UART->COMIEN&=(uint8_t)~COMIEN_ETBEI_EN;
  GP0CLR_CLR5_BBA=1;transmit_active=false;return true;
 }
 return false;
}
void UART_Int_Handler(void) {
 unsigned lsr=pADI_UART->COMLSR;
 bool error=(lsr&(COMLSR_BI_MSK|COMLSR_FE_MSK|COMLSR_PE_MSK|COMLSR_OE_MSK))!=0;
 if(error)++uart_line_errors;
 if(lsr&COMLSR_DR_MSK) {
  uint8_t b=(uint8_t)pADI_UART->COMRX;
  if(!transmit_active)tx_rtu_byte(&framer,b,DWT->CYCCNT,error);
 } else if(error&&!transmit_active){framer.invalid=true;framer.active_seen=true;framer.last_tick=DWT->CYCCNT;}
 if((lsr&COMLSR_THRE_MSK)&&transmit_active) {
  if(transmit_position<transmit_length)pADI_UART->COMTX=transmit[transmit_position++];
  else pADI_UART->COMIEN&=(uint8_t)~COMIEN_ETBEI_EN;
 }
}

void tx_board_init(void) {
 SystemCoreClockUpdate();
 CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;DWT->CYCCNT=0;DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk;
 SysTick_Config(SystemCoreClock/1000u);NVIC_SetPriority(SysTick_IRQn,3);
 pADI_CLKCTL->CLKDIS=CLKDIS_DISDMACLK_EN|CLKDIS_DIST1CLK_EN|CLKDIS_DIST0CLK_EN|
                       CLKDIS_DISI2CCLK_EN|CLKDIS_DISSPI1CLK_EN|CLKDIS_DISSPI0CLK_EN;
 gpio_setup();
 pADI_ANA->REFCTRL=REFCTRL_REFPD_DIS;
 pADI_DAC->DACCON=DACCON_DMAEN_Off|DACCON_PD_DIS|DACCON_NPN_DIS|DACCON_BUFBYP_DIS|
                   DACCON_CLK_HCLK|DACCON_CLR_On|DACCON_MDE_16BitFast|DACCON_RNG_IntVref;
 DACCON_CLR_BBA=1;pADI_DAC->DACDAT=5367398u; /* same RevA scaling, nominal 0.2 V excitation */
 tx_board_gains(1,1);tx_board_pwm(0,false);
 pADI_ADC0->MDE=ADC0MDE_PGA_G1|ADC0MDE_ADCMOD2_MOD2OFF|ADC0MDE_ADCMD_SINGLE;
 pADI_ADC0->FLT=ADC0FLT_CHOP_ON|ADC0FLT_RAVG2_ON|ADC0FLT_NOTCH2_EN|(15u<<8)|124u;
 pADI_ADC0->CON=ADC0CON_ADCCODE_INT|ADC0CON_BUFPOWN_EN|ADC0CON_BUFPOWP_EN|
                 ADC0CON_BUFBYPP_EN|ADC0CON_BUFBYPN_EN|ADC0CON_ADCREF_AVDDREF|
                 ADC0CON_ADCDIAG_DIAG_OFF|ADC0CON_ADCCP_AIN0|ADC0CON_ADCCN_AIN1;
 /* ADCCFG is physically shared between both ADCs. */
 pADI_ADC0->ADCCFG=ADCCFG_GNDSWON_EN;
 pADI_ADC0->MSKI=ADC0MSKI_RDY_EN;
 pADI_ADC1->MDE=ADC1MDE_PGA_G1|ADC1MDE_ADCMOD2_MOD2OFF|ADC1MDE_ADCMD_SINGLE;
 pADI_ADC1->FLT=ADC1FLT_CHOP_ON|ADC1FLT_RAVG2_ON|ADC1FLT_NOTCH2_EN|(15u<<8)|124u;
 pADI_ADC1->CON=ADC1CON_ADCCODE_UINT|ADC1CON_BUFPOWN_EN|ADC1CON_BUFPOWP_EN|
                 ADC1CON_BUFBYPP_EN|ADC1CON_BUFBYPN_EN|ADC1CON_ADCREF_EXTREF2|
                 ADC1CON_ADCDIAG_DIAG_OFF|ADC1CON_ADCCP_AIN6|ADC1CON_ADCCN_AIN5;
 pADI_ANA->IEXCCON=IEXCCON_PD_off|IEXCCON_REFSEL_Int|IEXCCON_IPSEL1_AIN7|IEXCCON_IPSEL0_Off;
 /* UG-367 Tables49/50: IDAT0 adds 10uA. Keep it DIS for nominal 200uA. */
 pADI_ANA->IEXCDAT=IEXCDAT_IDAT_200uA|IEXCDAT_IDAT0_DIS;
 pADI_ADC1->MSKI=ADC1MSKI_RDY_EN;
 NVIC_SetPriority(ADC0_IRQn,2);NVIC_SetPriority(ADC1_IRQn,2);
 NVIC_ClearPendingIRQ(ADC0_IRQn);NVIC_ClearPendingIRQ(ADC1_IRQn);
 NVIC_EnableIRQ(ADC0_IRQn);NVIC_EnableIRQ(ADC1_IRQn);
}
