/* SPDX-License-Identifier: MIT
 * FW-EC-PROBE Rev C0 bench candidate: four electrodes + four-wire Pt1000.
 * Rev A HAL pinout retained; new narrow C0 PCB is not finalized or validated.
 * Host tests verify mathematics/protocol/state machines; no board has been run.
 */
#include "tx_board.h"
#include "tx_acquisition.h"
#include "tx_protocol.h"
#include "nlf.h"
#include <math.h>
#include <string.h>

static tx_context_t protocol;
static tx_acq_state acquisition;
static tx_snapshot_t snapshot;
static tx_acq_result cycle;
static uint8_t request[256],response[256];
static uint32_t adc0_started,adc0_due,adc1_started,temp_updated;
static bool adc0_waiting,reply_waiting,diagnostic_ok;
static unsigned rtd_state;
static uint32_t rtd_status,seen_frame_errors;
static uint32_t seen_maintenance_revision;

static bool elapsed(uint32_t now,uint32_t then,uint32_t duration){return now-then>=duration;}
static void compensate(void) {
 uint32_t flags=0;
 snapshot.conductivity25_us_cm=NAN;
 snapshot.status&=~(TX_STATUS_K25_VALID|TX_STATUS_NLF_TEMP_OOR|TX_STATUS_NLF_EC_OOR);
 const tx_params_t *p=tx_protocol_params(&protocol);
 if((snapshot.status&(TX_STATUS_EC_VALID|TX_STATUS_TEMP_VALID))==(TX_STATUS_EC_VALID|TX_STATUS_TEMP_VALID)) {
  bool valid=nlf_compensate_from_fields(snapshot.conductivity_us_cm,snapshot.temperature_c,
       p->nlf_factor25,p->nlf_source_id,p->nlf_source_sha256,p->nlf_table_crc32,p->nlf_flags_verified,
       &snapshot.conductivity25_us_cm,&flags);
  if(valid)snapshot.status|=TX_STATUS_K25_VALID;
  if(flags&NLF_FLAG_TEMPERATURE_RANGE)snapshot.status|=TX_STATUS_NLF_TEMP_OOR;
  if(flags&NLF_FLAG_CONDUCTIVITY_RANGE)snapshot.status|=TX_STATUS_NLF_EC_OOR;
 }
 if(!(snapshot.status&TX_STATUS_TEMP_VALID) || snapshot.temperature_c<0 || snapshot.temperature_c>35)
  snapshot.status|=TX_STATUS_NLF_TEMP_OOR;
 tx_protocol_set_snapshot(&protocol,&snapshot);
}
static void mark_settling(void) {
 snapshot.status&=~(TX_STATUS_EC_VALID|TX_STATUS_K25_VALID|TX_STATUS_EC_FAULT|TX_STATUS_EC_OUT_OF_RANGE|TX_STATUS_EC_LOW_RANGE);
 snapshot.status|=TX_STATUS_SETTLING;
 snapshot.conductivity_us_cm=NAN;snapshot.conductivity25_us_cm=NAN;snapshot.conductance_s=NAN;
 snapshot.frequency_hz=acquisition.frequency_index?1000:100;
 snapshot.gain_voltage=tx_gain_value(acquisition.gv_index);
 snapshot.gain_current=tx_gain_value(acquisition.gi_index);
 snapshot.gain_table_index=(uint16_t)tx_gain_index(acquisition.frequency_index,acquisition.gv_index,acquisition.gi_index);
 compensate();
}
static void schedule_phase(uint32_t now) {
 tx_board_pwm(acquisition.frequency_index,acquisition.phase>=2);
 if(!(acquisition.phase&1u)) {adc0_waiting=false;adc0_due=now+tx_protocol_params(&protocol)->polarity_settling_ms;}
 else {tx_board_adc0_begin(acquisition.phase);adc0_waiting=true;adc0_started=now;}
}
static void restart_measurement(uint32_t now) {
 tx_board_adc_pause();tx_acq_restart(&acquisition);
 tx_board_gains(acquisition.gv_index,acquisition.gi_index);
 rtd_state=0;diagnostic_ok=true;rtd_status=TX_STATUS_RTD_FAULT;
 snapshot.temperature_c=NAN;
 snapshot.status&=~(TX_STATUS_TEMP_VALID|TX_STATUS_TEMP_OUT_OF_RANGE|TX_STATUS_RTD_OPEN|TX_STATUS_RTD_SHORT);
 snapshot.status|=TX_STATUS_RTD_FAULT;
 tx_board_rtd_begin(rtd_state);adc1_started=now;
 mark_settling();schedule_phase(now);
}
static void applied(uint32_t now) {
 uint32_t changes=tx_protocol_after_reply(&protocol);
 if(changes&TX_APPLIED_COMMUNICATION)
  tx_board_uart_init(tx_baud_rate(tx_protocol_params(&protocol)->baud_code),
                     tx_protocol_params(&protocol)->serial_format);
 if(changes&TX_APPLIED_CALIBRATION)restart_measurement(now);
}
static void service_conductivity(uint32_t now) {
 int32_t raw;uint32_t fault;
 if(!adc0_waiting && (uint32_t)(now-adc0_due)<0x80000000u) {
  tx_board_adc0_begin(acquisition.phase);adc0_waiting=true;adc0_started=now;
 }
 /* A timed-out conversion can finish during the configurable polarity-settling restart
  * delay. Its late result belongs to the abandoned phase, not the new cycle. */
 if(adc0_waiting&&tx_board_adc0_result(&raw,&fault)) {
  const tx_params_t*p=tx_protocol_params(&protocol);
  float correction=p->gain_correction[acquisition.frequency_index][acquisition.gv_index][acquisition.gi_index];
  tx_acq_event event=tx_acq_push(&acquisition,raw,fault,p->cell_constant,correction,&cycle);
  if(event==TX_ACQ_CHANGED) {
   tx_board_gains(acquisition.gv_index,acquisition.gi_index);mark_settling();
  } else if(event==TX_ACQ_READY) {
   snapshot.status&=~(TX_STATUS_EC_VALID|TX_STATUS_K25_VALID|TX_STATUS_EC_FAULT|TX_STATUS_SETTLING|
                      TX_STATUS_EC_OUT_OF_RANGE|TX_STATUS_EC_LOW_RANGE|TX_STATUS_ADC_TIMEOUT);
   snapshot.conductivity_us_cm=cycle.kappa_t_us_cm;snapshot.conductance_s=cycle.conductance_s;
   snapshot.raw_current_delta=cycle.raw[0]-cycle.raw[2];
   snapshot.raw_voltage_delta=cycle.raw[1]-cycle.raw[3];
   snapshot.sample_counter=cycle.cycle;snapshot.sample_time_ms=now;
   snapshot.frequency_hz=cycle.frequency_hz;snapshot.gain_voltage=cycle.gv;snapshot.gain_current=cycle.gi;
   snapshot.gain_table_index=(uint16_t)tx_gain_index(acquisition.frequency_index,acquisition.gv_index,acquisition.gi_index);
   if(isfinite(cycle.kappa_t_us_cm)) {
    snapshot.status|=TX_STATUS_EC_VALID;
    if(cycle.kappa_t_us_cm<10 || cycle.kappa_t_us_cm>2000)snapshot.status|=TX_STATUS_EC_OUT_OF_RANGE;
    if(cycle.kappa_t_us_cm>=10 && cycle.kappa_t_us_cm<50)snapshot.status|=TX_STATUS_EC_LOW_RANGE;
   } else snapshot.status|=TX_STATUS_EC_FAULT;
   compensate();
  }
  schedule_phase(now);
 }
 if(adc0_waiting&&elapsed(now,adc0_started,2000u)) {
  snapshot.status|=TX_STATUS_ADC_TIMEOUT|TX_STATUS_EC_FAULT;
  snapshot.status&=~(TX_STATUS_EC_VALID|TX_STATUS_K25_VALID);
  snapshot.conductivity_us_cm=NAN;snapshot.conductivity25_us_cm=NAN;snapshot.conductance_s=NAN;
  tx_acq_restart(&acquisition);schedule_phase(now);compensate();
 }
}
static void publish_temperature_fault(uint32_t status) {
 snapshot.temperature_c=NAN;
 snapshot.status&=~(TX_STATUS_TEMP_VALID|TX_STATUS_K25_VALID|TX_STATUS_TEMP_OUT_OF_RANGE|TX_STATUS_RTD_OPEN|TX_STATUS_RTD_SHORT);
 snapshot.status|=TX_STATUS_RTD_FAULT|status;compensate();
}
static void service_temperature(uint32_t now) {
 uint32_t raw,fault;
 if(tx_board_adc1_result(&raw,&fault)) {
  if(rtd_state<2) {
   if(rtd_state==0){diagnostic_ok=true;rtd_status=0;}
   if(fault||raw>=0x0FFF0000u) {
    diagnostic_ok=false;rtd_status|=TX_STATUS_RTD_FAULT|TX_STATUS_RTD_OPEN;
    publish_temperature_fault(rtd_status);
   }
   ++rtd_state;
  } else {
   float t,r;const tx_params_t*p=tx_protocol_params(&protocol);
   bool valid=diagnostic_ok&&!fault&&tx_pt1000_temperature(raw,p->temperature_gain,p->temperature_offset,&t,&r);
   if(valid) {
    snapshot.temperature_c=t;temp_updated=now;
    snapshot.status&=~(TX_STATUS_RTD_FAULT|TX_STATUS_RTD_OPEN|TX_STATUS_RTD_SHORT|TX_STATUS_TEMP_OUT_OF_RANGE);
    snapshot.status|=TX_STATUS_TEMP_VALID;
    if(t<0.f||t>50.f)snapshot.status|=TX_STATUS_TEMP_OUT_OF_RANGE;
    compensate();
   } else {
    uint32_t details=rtd_status;
    if(fault&0x100u)details|=TX_STATUS_RTD_OPEN;
    float resistance=tx_pt1000_resistance(raw);
    if(isfinite(resistance)&&resistance<800.f)details|=TX_STATUS_RTD_SHORT;
    publish_temperature_fault(details);
   }
   rtd_state=0;
  }
  tx_board_rtd_begin(rtd_state);adc1_started=now;
 }
 if(elapsed(now,adc1_started,2000u)) {
  publish_temperature_fault(TX_STATUS_ADC_TIMEOUT);
  rtd_state=0;diagnostic_ok=false;tx_board_rtd_begin(0);adc1_started=now;
 }
 if((snapshot.status&TX_STATUS_TEMP_VALID)&&elapsed(now,temp_updated,5000u))
  publish_temperature_fault(TX_STATUS_ADC_TIMEOUT);
}
/* Kept as one foreground step so the actual HAL/protocol integration can also
 * be exercised with a host board stub. This is not a second measurement path. */
static void firmware_poll(void) {
  uint32_t now=tx_board_millis();tx_protocol_poll(&protocol,now);
  if(reply_waiting&&tx_board_uart_transmitted()){reply_waiting=false;applied(now);}
  if(!reply_waiting) {
   size_t bytes=tx_board_uart_receive(request,sizeof(request));
   if(bytes) {
    uint32_t before=tx_board_pause_epoch();
    size_t n=tx_protocol_process(&protocol,request,bytes,response,sizeof(response),now);
    /* Even a failed Flash commit may have paused the ADCs. Always recover. */
    if(tx_board_pause_epoch()!=before)restart_measurement(tx_board_millis());
    if(n){tx_board_uart_send(response,n);reply_waiting=true;}
    else applied(tx_board_millis());
   }
  }
  uint32_t frames=tx_board_uart_frame_errors();
  protocol.frame_error_count+=frames-seen_frame_errors;seen_frame_errors=frames;
  const tx_maintenance_t *maintenance=tx_protocol_maintenance(&protocol);
  if(maintenance->revision!=seen_maintenance_revision) {
   seen_maintenance_revision=maintenance->revision;
   acquisition.forced=maintenance->mode==1;
   if(acquisition.forced) {
    acquisition.frequency_index=(uint8_t)maintenance->frequency_index;
    acquisition.gv_index=(uint8_t)maintenance->gv_index;
    acquisition.gi_index=(uint8_t)maintenance->gi_index;
   }
   restart_measurement(tx_board_millis());
  }
  /* Flash writes or a configuration/maintenance restart can cross SysTick.
   * Passing the old loop timestamp after starting a new ADC conversion would
   * make unsigned elapsed() wrap and immediately declare an ADC timeout. */
  now=tx_board_millis();
  service_temperature(now);service_conductivity(now);tx_board_sleep();
}
int main(void) {
 tx_board_init();
 tx_protocol_init(&protocol,&tx_board_flash_ops,0,tx_board_millis());
 tx_acq_init(&acquisition);memset(&snapshot,0,sizeof(snapshot));
 snapshot.conductivity_us_cm=NAN;snapshot.conductivity25_us_cm=NAN;snapshot.temperature_c=NAN;
 snapshot.conductance_s=NAN;snapshot.status=TX_STATUS_SETTLING|TX_STATUS_RTD_FAULT;
 tx_board_uart_init(tx_baud_rate(tx_protocol_params(&protocol)->baud_code),
                     tx_protocol_params(&protocol)->serial_format);
 restart_measurement(tx_board_millis());
 for(;;)firmware_poll();
}

/* CMSIS startup calls after copying .data/.ramfunc and clearing .bss.
 * All product modules are C99 and need no C++ constructors or dynamic heap. */
void firmware_start(void) {
 (void)main();for(;;){}
}
