/* SPDX-License-Identifier: MIT
 * RTU timing uses raw wrap-safe CPU cycles (DWT CYCCNT on Cortex M3).
 * Called under a brief IRQ lock when the foreground also accesses the state.
 */
#include "tx_rtu_framer.h"
#include <string.h>
void tx_rtu_init(tx_rtu_framer *s,uint32_t clock,uint32_t baud,uint8_t serial_format) {
 unsigned bits=serial_format<3u?11u:10u;
 memset(s,0,sizeof(*s));
 s->character_ticks=(uint32_t)(((uint64_t)clock*bits+baud-1u)/baud);
 if(baud>19200){
  s->t15=(uint32_t)(((uint64_t)clock*750u+999999u)/1000000u);
  s->t35=(uint32_t)(((uint64_t)clock*1750u+999999u)/1000000u);
 }
 else {
  s->t15=(uint32_t)(((uint64_t)clock*bits*3u+2u*baud-1u)/(2u*baud));
  s->t35=(uint32_t)(((uint64_t)clock*bits*7u+2u*baud-1u)/(2u*baud));
 }
}
static void finish(tx_rtu_framer *s) {
 if(!s->invalid&&s->length>=4&&s->ready_length==0) {
  memcpy(s->ready,s->active,s->length);s->ready_length=s->length;
 } else if(s->length||s->invalid)++s->discarded;
 s->length=0;s->active_seen=false;s->invalid=false;
}
void tx_rtu_idle(tx_rtu_framer *s,uint32_t tick) {
 if(s->active_seen&&(uint32_t)(tick-s->last_tick)>=s->t35+s->character_ticks)finish(s);
}
void tx_rtu_byte(tx_rtu_framer *s,uint8_t b,uint32_t tick,bool error) {
 if(s->active_seen) {
  uint32_t gap=tick-s->last_tick;
  /* UART reports at the end of the new byte: the endpoint difference includes
   * its full 10- or 11-bit character time in addition to the bus silence. */
  if(gap>=s->t35+s->character_ticks)finish(s);
  else if(gap>s->t15+s->character_ticks)s->invalid=true;
 }
 s->active_seen=true;s->last_tick=tick;
 if(error)s->invalid=true;
 if(s->length<TX_RTU_MAX)s->active[s->length++]=b;
 else s->invalid=true;
}
size_t tx_rtu_take(tx_rtu_framer *s,uint8_t*out,size_t cap) {
 size_t n=s->ready_length;
 if(!n)return 0;
 if(cap<n){++s->discarded;s->ready_length=0;return 0;}
 memcpy(out,s->ready,n);s->ready_length=0;return n;
}
