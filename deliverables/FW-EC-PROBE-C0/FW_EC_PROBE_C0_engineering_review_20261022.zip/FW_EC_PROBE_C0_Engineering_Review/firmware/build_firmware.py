#!/usr/bin/env python3
"""Reproducible bare-metal ADuCM360 FW-EC-TX build, without UI/stdio/heap."""
from pathlib import Path
import os,subprocess,hashlib,json,shutil,re
ROOT=Path(__file__).resolve().parent
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
prefix=os.environ.get('CROSS_COMPILE','arm-none-eabi-')
if not shutil.which(prefix+'gcc'):
    local=Path('/workspace/toolchains/arm/usr/bin/arm-none-eabi-gcc')
    if local.exists():prefix=str(local).removesuffix('gcc')
    else:raise SystemExit('Install GNU Arm Embedded toolchain or set CROSS_COMPILE=/path/arm-none-eabi-')
flags=['-mcpu=cortex-m3','-mthumb','-mfloat-abi=soft','-Os','-g3','-ffunction-sections','-fdata-sections',
       '-fno-common','-fno-strict-aliasing','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
       '-D__ADUCM360__','-D__STARTUP_CLEAR_BSS','-D__START=firmware_start','-D__STACK_SIZE=2048','-D__HEAP_SIZE=0',
       '--specs=nano.specs','-I'+str(ROOT/'vendor/cmsis'),'-I'+str(ROOT/'include'),
       '-I'+str(ROOT/'protocol'),'-I'+str(ROOT.parent/'compensation')]
sources=sorted((ROOT/'src').glob('*.c'))+sorted((ROOT/'protocol').glob('*.c'))+[
    ROOT.parent/'compensation/nlf.c',ROOT/'vendor/system_ADuCM360.c',ROOT/'vendor/startup_ADuCM360.S']
objects=[]
def run(command,log):
    p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    log.write_text('$ '+' '.join(command)+'\n'+p.stdout)
    if p.returncode:raise SystemExit(p.stdout+'\nBuild failed; see '+str(log))
    return p.stdout
for source in sources:
    obj=BUILD/(source.stem+'.o');objects.append(obj)
    run([prefix+'gcc',*flags,*(['-std=c99','-fstack-usage'] if source.suffix=='.c' else []),'-c',str(source),'-o',str(obj)],obj.with_suffix('.log'))
elf=BUILD/'fw_ec_probe_c0_bench.elf'
result=run([prefix+'gcc','-mcpu=cortex-m3','-mthumb','-mfloat-abi=soft','--specs=nano.specs','-nostartfiles',
     '-T'+str(ROOT/'ld/aducm360_transmitter.ld'),'-Wl,--gc-sections','-Wl,-Map='+str(elf.with_suffix('.map')),
     '-Wl,--print-memory-usage',*map(str,objects),'-Wl,--start-group','-lc_nano','-lm','-lgcc','-lnosys','-Wl,--end-group','-o',str(elf)],BUILD/'link.log')
print(result,end='')
for fmt,suffix in [('ihex','.hex'),('binary','.bin')]:
    run([prefix+'objcopy','-O',fmt,str(elf),str(elf.with_suffix(suffix))],BUILD/(suffix[1:]+'.log'))
print(run([prefix+'size',str(elf)],BUILD/'size.log'),end='')
symbols=subprocess.check_output([prefix+'nm','-S','--size-sort',str(elf)],text=True)
(BUILD/'symbols.txt').write_text(symbols)
assert not re.search(r'\b(?:malloc|calloc|realloc|printf|scanf|lcd_open|beep|encoder_open)\b',symbols)
all_symbols=subprocess.check_output([prefix+'nm','-n',str(elf)],text=True)
addresses={m.group(2):int(m.group(1),16) for m in re.finditer(r'^([0-9a-fA-F]+)\s+\S\s+(\S+)$',all_symbols,re.M)}
disassembly=subprocess.check_output([prefix+'objdump','-d',str(elf)],text=True)
(BUILD/'disassembly.txt').write_text(disassembly)
for name in ['flash_erase_ram','flash_program_ram']:
    assert 0x20000000<=addresses[name]<addresses['__data_end__'],name+' not in copied RAM'
    block=re.search(r'^[0-9a-f]+ <'+name+r'>:\n(.*?)(?=^[0-9a-f]+ <|\Z)',disassembly,re.M|re.S).group(1)
    assert not re.search(r'\bblx?(?:\.w)?\s',block),name+' calls another routine while Flash may be busy'
image={};base=0
for line in elf.with_suffix('.hex').read_text().splitlines():
    raw=bytes.fromhex(line[1:]);assert line.startswith(':') and sum(raw)%256==0
    size,offset,kind=raw[0],int.from_bytes(raw[1:3],'big'),raw[3]
    assert len(raw)==size+5
    if kind==0:
        for i,b in enumerate(raw[4:4+size]):
            address=base+offset+i
            assert address<0x1FA00,'HEX overlaps calibration/security pages'
            assert address not in image,'overlapping HEX records'
            image[address]=b
    elif kind==4:base=int.from_bytes(raw[4:6],'big')<<16
    elif kind==2:base=int.from_bytes(raw[4:6],'big')<<4
vector=bytes(image[i] for i in range(8))
assert int.from_bytes(vector[:4],'little')==0x20002000
assert int.from_bytes(vector[4:],'little')&1
assert (int.from_bytes(vector[4:],'little')&~1)<0x1FA00
memory={'hex_programmed_bytes':len(image),'flash_address_end_exclusive':max(image)+1,
        'ram_static_and_copied_code_bytes':addresses['__HeapLimit']-0x20000000,
        'reserved_stack_bytes':addresses['__StackTop']-addresses['__StackLimit'],
        'unallocated_ram_between_static_and_stack':addresses['__StackLimit']-addresses['__HeapLimit'],
        'ram_flash_routines':{name:hex(addresses[name]) for name in ['flash_erase_ram','flash_program_ram']},
        'hex_checks':'all checksums; no overlap; no calibration/security addresses; valid initial SP and Thumb reset vector',
        'ram_flash_routines_check':'both in startup-copied RAM, no subroutine calls in their disassembly',
        'stack_usage_reports':'*.su contain compiler static frame sizes; no measured stack watermark yet'}
(BUILD/'image_validation.json').write_text(json.dumps(memory,indent=2)+'\n')
headers=sorted((ROOT/'include').glob('*.h'))+sorted((ROOT/'protocol').glob('*.h'))+[ROOT.parent/'compensation/nlf.h']
manifest={'version':'FW-EC-PROBE Rev C0 bench candidate','compiler':subprocess.check_output([prefix+'gcc','--version'],text=True).splitlines()[0],
          'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [elf,elf.with_suffix('.hex'),elf.with_suffix('.bin')]},
          'source_files':{str(p.relative_to(ROOT.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources+headers},
          'build_inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'build_firmware.py',ROOT/'ld/aducm360_transmitter.ld',ROOT/'vendor/ADI_CN0359_LICENSE.txt']},
          'vendor_header_dependencies':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'vendor').rglob('*.h'))},
          'review_and_host_check_inputs':{str(p.relative_to(ROOT.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'README.md',ROOT/'protocol/register_map.csv',*sorted((ROOT/'tools').glob('*.py')),*sorted((ROOT/'tests').glob('*')),*sorted((ROOT/'protocol/tests').glob('*.c')),ROOT/'protocol/tests/run_tests.sh',ROOT.parent/'compensation/make_nlf_profile.py',ROOT.parent/'compensation/test_nlf.py'] if p.is_file()},
          'flash':{'application_end_exclusive':'0x1FA00','calibration_a':'0x1FA00','calibration_b':'0x1FC00','security_page_untouched':'0x1FE00..0x1FFFF'},
          'uart':'9600 8N1 address 1 default; formats 0=8O1/1=8E1/2=8N2/3=8N1; Modbus RTU',
          'hardware_execution_tested':False,
          'PCB_pinmap_status':'Rev A bench HAL retained; narrow C0 PCB is not finalized; HEX is not production-qualified for C0',
          'flash_record_schema':2,'parameter_payload_bytes':340,'polarity_settling_default_ms':120,
          'electrodes':'four-electrode default; two-electrode needs two physical electrode bridges; no software electrical switch',
          'image_validation':memory,
          'nlf_default':'disabled until traceable ISO table provisioned; k25=NaN + unverified flag',
          'removed':['LCD','menus','encoder','buzzer','Pt100','2/3-wire RTD autodetection','ASCII console'],
          'build_verified':['ARM GCC -Wall -Wextra -Werror','linker RAM and Flash bounds','no UI/heap/printf symbols','hex generated from ELF']}
(BUILD/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('Built',elf.with_suffix('.hex'))
