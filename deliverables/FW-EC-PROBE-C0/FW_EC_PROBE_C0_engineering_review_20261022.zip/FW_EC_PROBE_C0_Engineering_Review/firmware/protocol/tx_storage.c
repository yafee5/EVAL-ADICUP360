#include "tx_protocol.h"
#include "../../compensation/nlf.h"
#include <math.h>
#include <string.h>

#define RECORD_MAGIC UINT32_C(0x31505854)
#define RECORD_SCHEMA 2u
#define RECORD_VALID UINT32_C(0xA55A3CC3)
#define PAYLOAD_OFFSET 16u
#define VALID_OFFSET (PAYLOAD_OFFSET + TX_PARAMS_BYTES)

static void put16(uint8_t *p, uint16_t v) { p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void put32(uint8_t *p, uint32_t v) { unsigned i; for(i=0;i<4;i++) p[i]=(uint8_t)(v>>(8*i)); }
static uint16_t get16(const uint8_t *p) { return (uint16_t)(p[0]|((uint16_t)p[1]<<8)); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static void put_float(uint8_t *p, float f) { uint32_t v; memcpy(&v,&f,4); put32(p,v); }
static float get_float(const uint8_t *p) { uint32_t v=get32(p); float f; memcpy(&f,&v,4); return f; }

static uint32_t crc_extend(uint32_t crc, const uint8_t *p, size_t n)
{
    size_t i; unsigned j;
    for(i=0;i<n;i++) { crc^=p[i]; for(j=0;j<8;j++) crc=(crc>>1)^((crc&1)?UINT32_C(0xEDB88320):0); }
    return crc;
}
uint32_t tx_crc32(const void *data, size_t size) { return ~crc_extend(UINT32_C(0xFFFFFFFF),(const uint8_t*)data,size); }
uint32_t tx_params_crc(const tx_params_t *p) { uint8_t b[TX_PARAMS_BYTES]; tx_params_encode(p,b); return tx_crc32(b,sizeof b); }

void tx_params_defaults(tx_params_t *p)
{
    unsigned f,v,i;
    memset(p,0,sizeof *p); p->cell_constant=1.0f; p->temperature_gain=1.0f;
    p->address=1; p->baud_code=0; p->serial_format=3; p->polarity_settling_ms=120;
    for(f=0;f<TX_FREQUENCY_COUNT;f++) for(v=0;v<TX_GAIN_COUNT;v++) for(i=0;i<TX_GAIN_COUNT;i++) p->gain_correction[f][v][i]=1.0f;
    for(i=0;i<36;i++)p->nlf_factor25[i]=1.0f;
}
uint32_t tx_baud_rate(uint8_t code)
{
    static const uint32_t baud[]={9600u,19200u,38400u,57600u,115200u};
    return code<sizeof baud/sizeof baud[0]?baud[code]:0;
}
uint16_t tx_gain_value(unsigned i) { static const uint16_t g[]={1,10,100,1000}; return i<4?g[i]:0; }
unsigned tx_gain_index(unsigned f,unsigned v,unsigned i) { return f*16u+v*4u+i; }
bool tx_params_valid(const tx_params_t *p)
{
    unsigned f,v,i;
    if(!isfinite(p->cell_constant)||p->cell_constant<0.5f||p->cell_constant>1.5f) return false;
    if(!isfinite(p->temperature_gain)||p->temperature_gain<0.95f||p->temperature_gain>1.05f) return false;
    if(!isfinite(p->temperature_offset)||p->temperature_offset<-5.0f||p->temperature_offset>5.0f) return false;
    if(p->address<1||p->address>247||tx_baud_rate(p->baud_code)==0) return false;
    if(p->serial_format>3||p->polarity_settling_ms<50||p->polarity_settling_ms>2000) return false;
    if(p->calibration_flags&~(TX_CAL_K|TX_CAL_TEMPERATURE)) return false;
    for(f=0;f<2;f++) for(v=0;v<4;v++) for(i=0;i<4;i++) {
        float x=p->gain_correction[f][v][i];
        if(!isfinite(x)||x<0.5f||x>2.0f) return false;
    }
    for(i=0;i<36;i++)if(!isfinite(p->nlf_factor25[i])||p->nlf_factor25[i]<0.1f||p->nlf_factor25[i]>10.0f)return false;
    if(p->nlf_flags_verified!=0&&p->nlf_flags_verified!=NLF_VERIFIED_MAGIC)return false;
    if(p->nlf_flags_verified==NLF_VERIFIED_MAGIC&&nlf_validate_fields(p->nlf_factor25,p->nlf_source_id,
       p->nlf_source_sha256,p->nlf_table_crc32,p->nlf_flags_verified)!=0)return false;
    return true;
}
void tx_params_encode(const tx_params_t *p,uint8_t out[TX_PARAMS_BYTES])
{
    unsigned f,v,i;size_t n=12;
    put_float(out,p->cell_constant);put_float(out+4,p->temperature_gain);put_float(out+8,p->temperature_offset);
    for(f=0;f<2;f++) for(v=0;v<4;v++) for(i=0;i<4;i++,n+=4) put_float(out+n,p->gain_correction[f][v][i]);
    put32(out+140,p->gain_valid_mask);put16(out+144,p->calibration_flags);out[146]=p->address;out[147]=p->baud_code;
    for(i=0;i<36;i++)put_float(out+148+4*i,p->nlf_factor25[i]);
    put32(out+292,p->nlf_source_id);memcpy(out+296,p->nlf_source_sha256,32);
    put32(out+328,p->nlf_table_crc32);put32(out+332,p->nlf_flags_verified);
    out[336]=p->serial_format;out[337]=0;put16(out+338,p->polarity_settling_ms);
}
bool tx_params_decode(tx_params_t *p,const uint8_t in[TX_PARAMS_BYTES])
{
    unsigned f,v,i;size_t n=12;memset(p,0,sizeof *p);
    p->cell_constant=get_float(in);p->temperature_gain=get_float(in+4);p->temperature_offset=get_float(in+8);
    for(f=0;f<2;f++) for(v=0;v<4;v++) for(i=0;i<4;i++,n+=4) p->gain_correction[f][v][i]=get_float(in+n);
    p->gain_valid_mask=get32(in+140);p->calibration_flags=get16(in+144);p->address=in[146];p->baud_code=in[147];
    for(i=0;i<36;i++)p->nlf_factor25[i]=get_float(in+148+4*i);
    p->nlf_source_id=get32(in+292);memcpy(p->nlf_source_sha256,in+296,32);
    p->nlf_table_crc32=get32(in+328);p->nlf_flags_verified=get32(in+332);
    if(in[337]!=0)return false;
    p->serial_format=in[336];p->polarity_settling_ms=get16(in+338);
    return tx_params_valid(p);
}
static uint32_t record_crc(const uint8_t b[TX_RECORD_BYTES])
{
    uint32_t crc=crc_extend(UINT32_C(0xFFFFFFFF),b,12);
    return ~crc_extend(crc,b+PAYLOAD_OFFSET,TX_PARAMS_BYTES);
}
static bool parse_record(const uint8_t b[TX_RECORD_BYTES],tx_params_t *p,uint32_t *sequence)
{
    if(get32(b)!=RECORD_MAGIC||get16(b+4)!=RECORD_SCHEMA||get16(b+6)!=TX_PARAMS_BYTES||get32(b+VALID_OFFSET)!=RECORD_VALID) return false;
    if(get32(b+12)!=record_crc(b)||!tx_params_decode(p,b+PAYLOAD_OFFSET)) return false;
    *sequence=get32(b+8);return true;
}
static bool seq_newer(uint32_t a,uint32_t b) { uint32_t d=a-b;return d!=0&&d<UINT32_C(0x80000000); }
bool tx_storage_load(tx_context_t *ctx)
{
    uint8_t b[TX_RECORD_BYTES];tx_params_t p;uint32_t seq=0;unsigned slot;bool found=false,io_error=false;
    ctx->active_slot=-1;ctx->sequence=0;ctx->loaded_from_flash=false;
    if(!ctx->flash.read) { ctx->last_error=TX_STORE_IO_ERROR;ctx->storage_fault=true;return false; }
    for(slot=0;slot<2;slot++) {
        if(!ctx->flash.read(ctx->flash_user,slot,0,b,sizeof b)) { io_error=true;continue; }
        if(parse_record(b,&p,&seq)&&(!found||seq_newer(seq,ctx->sequence))) {
            found=true;ctx->active=p;ctx->sequence=seq;ctx->active_slot=(int)slot;
        }
    }
    ctx->loaded_from_flash=found;ctx->storage_fault=io_error;
    ctx->last_error=io_error?TX_STORE_IO_ERROR:(found?TX_STORE_OK:TX_STORE_NO_VALID_RECORD);
    return found;
}
bool tx_storage_commit(tx_context_t *ctx,const tx_params_t *params)
{
    uint8_t b[TX_RECORD_BYTES],verify[TX_RECORD_BYTES];tx_params_t decoded;uint32_t seq;
    unsigned slot=ctx->active_slot<0?0u:1u-(unsigned)ctx->active_slot;
    if(!tx_params_valid(params)) {ctx->last_error=TX_STORE_INVALID_PARAMS;return false;}
    if(!ctx->flash.read||!ctx->flash.erase||!ctx->flash.program) goto io_fail;
    memset(b,0xFF,sizeof b);put32(b,RECORD_MAGIC);put16(b+4,RECORD_SCHEMA);put16(b+6,TX_PARAMS_BYTES);
    put32(b+8,ctx->sequence+1u);tx_params_encode(params,b+PAYLOAD_OFFSET);put32(b+12,record_crc(b));
    if(!ctx->flash.erase(ctx->flash_user,slot)) goto io_fail;
    if(!ctx->flash.program(ctx->flash_user,slot,0,b,VALID_OFFSET)) goto io_fail;
    if(!ctx->flash.read(ctx->flash_user,slot,0,verify,VALID_OFFSET)) goto io_fail;
    if(memcmp(b,verify,VALID_OFFSET)!=0) goto verify_fail;
    put32(b+VALID_OFFSET,RECORD_VALID);
    if(!ctx->flash.program(ctx->flash_user,slot,VALID_OFFSET,b+VALID_OFFSET,4)) goto io_fail;
    if(!ctx->flash.read(ctx->flash_user,slot,0,verify,sizeof verify)) goto io_fail;
    if(memcmp(b,verify,sizeof b)!=0||!parse_record(verify,&decoded,&seq)) goto verify_fail;
    ctx->active_slot=(int)slot;ctx->sequence=seq;ctx->loaded_from_flash=true;ctx->storage_fault=false;ctx->last_error=TX_STORE_OK;
    return true;
io_fail:
    ctx->last_error=TX_STORE_IO_ERROR;ctx->storage_fault=true;return false;
verify_fail:
    ctx->last_error=TX_STORE_VERIFY_ERROR;ctx->storage_fault=true;return false;
}
