#include "../tx_protocol.h"
#include "../../../compensation/nlf.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks;
#define CHECK(x) do {++checks;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
typedef struct {uint8_t page[2][TX_FLASH_SLOT_BYTES];int budget;unsigned writes,erases;bool bad_read,bad_erase;} memflash_t;
static bool rd(void *v,unsigned slot,uint32_t off,void *p,size_t n)
{memflash_t*m=v;if(m->bad_read||slot>=2||off+n>512)return false;memcpy(p,m->page[slot]+off,n);return true;}
static bool er(void *v,unsigned slot)
{memflash_t*m=v;if(slot>=2||m->bad_erase)return false;memset(m->page[slot],0xFF,512);m->erases++;return true;}
static bool pg(void *v,unsigned slot,uint32_t off,const void *p,size_t n)
{
    memflash_t*m=v;const uint8_t*b=p;size_t i,j;
    CHECK(slot<2&&off+n<=512&&(off&3)==0&&(n&3)==0);
    for(i=0;i<n;i+=4) {
        if(m->budget==0)return false;
        if(m->budget>0)m->budget--;
        for(j=0;j<4;j++){CHECK((m->page[slot][off+i+j]&b[i+j])==b[i+j]);m->page[slot][off+i+j]&=b[i+j];}
        m->writes++;
    }
    return true;
}
static const tx_flash_ops_t flash={rd,er,pg};
static void clean(memflash_t *m) {memset(m,0,sizeof *m);memset(m->page,0xFF,sizeof m->page);m->budget=-1;}
static size_t finish(uint8_t *q,size_t n) {uint16_t c=tx_modbus_crc16(q,n);q[n]=(uint8_t)c;q[n+1]=(uint8_t)(c>>8);return n+2;}
static void be16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static uint32_t read32(const uint8_t*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static float readfloat(const uint8_t*p){uint32_t v=read32(p);float f;memcpy(&f,&v,4);return f;}
static uint32_t floatbits(float f){uint32_t v;memcpy(&v,&f,4);return v;}
static size_t write_wire(tx_context_t*c,uint8_t addr,uint16_t start,const uint16_t *w,uint16_t n,uint8_t*r,uint32_t now)
{
    uint8_t q[256];unsigned i;q[0]=addr;q[1]=16;be16(q+2,start);be16(q+4,n);q[6]=(uint8_t)(2*n);
    for(i=0;i<n;i++)be16(q+7+2*i,w[i]);
    return tx_protocol_process(c,q,finish(q,7+2*n),r,256,now);
}
static size_t write_words(tx_context_t*c,uint8_t addr,uint16_t start,const uint16_t *w,uint16_t n,uint8_t*r,uint32_t now)
{return write_wire(c,addr,(uint16_t)(start+0x1000u),w,n,r,now);}
static size_t write_u32(tx_context_t*c,uint16_t a,uint32_t v,uint8_t*r,uint32_t now)
{uint16_t w[2]={(uint16_t)(v>>16),(uint16_t)v};return write_words(c,c->active.address,a,w,2,r,now);}
static size_t write_float(tx_context_t*c,uint16_t a,float f,uint8_t*r,uint32_t now){return write_u32(c,a,floatbits(f),r,now);}
static size_t single(tx_context_t*c,uint16_t a,uint16_t v,uint8_t*r,uint32_t now)
{uint8_t q[8]={0};q[0]=c->active.address;q[1]=6;be16(q+2,(uint16_t)(a+0x1000));be16(q+4,v);return tx_protocol_process(c,q,finish(q,6),r,256,now);}
static size_t read_wire(tx_context_t*c,uint8_t f,uint16_t a,uint16_t count,uint8_t*r,uint32_t now)
{uint8_t q[8]={0};q[0]=c->active.address;q[1]=f;be16(q+2,a);be16(q+4,count);return tx_protocol_process(c,q,finish(q,6),r,256,now);}
static size_t read_regs(tx_context_t*c,uint8_t f,uint16_t a,uint16_t count,uint8_t*r,uint32_t now)
{return read_wire(c,f,(uint16_t)(a+0x1000u),count,r,now);}
static size_t commit(tx_context_t*c,uint8_t*r,uint32_t now)
{uint32_t crc=tx_params_crc(&c->staged);uint16_t w[4]={0x5341,0x5645,(uint16_t)(crc>>16),(uint16_t)crc};return write_words(c,c->active.address,0x7F02,w,4,r,now);}
static void expect_exception(const uint8_t*r,size_t n,uint8_t f,uint8_t ex)
{CHECK(n==5);CHECK(r[1]==(uint8_t)(f|0x80));CHECK(r[2]==ex);CHECK(tx_modbus_crc16(r,n)==0);}
static void unlock(tx_context_t*c,uint8_t*r,uint32_t now){CHECK(write_u32(c,0x7F00,TX_UNLOCK_KEY,r,now)==8);CHECK(c->unlocked);}

static void test_crc_and_params(void)
{
    tx_params_t p,q;uint8_t b[TX_PARAMS_BYTES];unsigned i;
    const uint8_t request[]={1,3,0,0,0,10};
    CHECK(tx_modbus_crc16("123456789",9)==0x4B37);CHECK(tx_crc32("123456789",9)==UINT32_C(0xCBF43926));
    CHECK(tx_modbus_crc16(request,sizeof request)==0xCDC5);
    CHECK(sizeof(float)==4);CHECK(TX_RECORD_BYTES<=512&&TX_RECORD_BYTES%4==0);
    tx_params_defaults(&p);CHECK(tx_params_valid(&p));CHECK(p.serial_format==3&&p.polarity_settling_ms==120);CHECK(p.gain_valid_mask==0&&p.calibration_flags==0&&p.nlf_flags_verified==0);
    p.address=247;p.baud_code=4;p.serial_format=2;p.polarity_settling_ms=1999;p.cell_constant=1.03f;p.temperature_offset=-0.1f;p.gain_correction[1][3][3]=1.001f;p.gain_valid_mask=0x80000000u;
    tx_params_encode(&p,b);CHECK(tx_params_decode(&q,b));CHECK(tx_params_crc(&p)==tx_params_crc(&q));CHECK(q.gain_correction[1][3][3]==1.001f);CHECK(q.serial_format==2&&q.polarity_settling_ms==1999);CHECK(b[336]==2&&b[337]==0&&b[338]==0xCF&&b[339]==7);
    b[337]=1;CHECK(!tx_params_decode(&q,b));b[337]=0;
    CHECK(tx_gain_index(1,3,3)==31);CHECK(tx_gain_value(0)==1&&tx_gain_value(3)==1000&&tx_gain_value(4)==0);
    CHECK(tx_baud_rate(0)==9600&&tx_baud_rate(4)==115200&&tx_baud_rate(5)==0);
    for(i=0;i<36;i++)p.nlf_factor25[i]=1.5f-0.02f*(float)i; /* synthetic integrity fixture, NOT ISO data */
    p.nlf_source_id=0x54455354;for(i=0;i<32;i++)p.nlf_source_sha256[i]=(uint8_t)(i+1);
    p.nlf_table_crc32=nlf_factors_crc32(p.nlf_factor25);p.nlf_flags_verified=NLF_VERIFIED_MAGIC;
    CHECK(tx_params_valid(&p));p.nlf_table_crc32^=1;CHECK(!tx_params_valid(&p));p.nlf_table_crc32^=1;
    p.nlf_factor25[3]=p.nlf_factor25[2];p.nlf_table_crc32=nlf_factors_crc32(p.nlf_factor25);CHECK(!tx_params_valid(&p));
    tx_params_defaults(&p);p.cell_constant=NAN;CHECK(!tx_params_valid(&p));tx_params_defaults(&p);p.address=0;CHECK(!tx_params_valid(&p));
    tx_params_defaults(&p);p.temperature_gain=1.1f;CHECK(!tx_params_valid(&p));tx_params_defaults(&p);p.gain_correction[0][0][0]=INFINITY;CHECK(!tx_params_valid(&p));
}
static void test_transactions(void)
{
    memflash_t m;tx_context_t c,boot;uint8_t r[256];uint16_t words[4];size_t n;uint32_t crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);CHECK(!c.loaded_from_flash&&!c.storage_fault&&c.active_slot==-1);
    expect_exception(r,write_float(&c,0x100,1.02f,r,1),16,3);CHECK(c.active.cell_constant==1);
    expect_exception(r,write_u32(&c,0x7F00,123,r,2),16,3);unlock(&c,r,3);
    CHECK(write_float(&c,0x100,1.02f,r,4)==8);CHECK(c.staged.cell_constant==1.02f&&c.active.cell_constant==1);
    CHECK(read_regs(&c,3,0x100,2,r,5)==9&&readfloat(r+3)==1.02f);
    expect_exception(r,single(&c,0x100,0x3F80,r,6),6,3);CHECK(c.staged.cell_constant==1.02f);
    words[0]=42;words[1]=5;expect_exception(r,write_words(&c,1,0x106,words,2,r,7),16,3);CHECK(c.staged.address==1&&c.staged.baud_code==0);
    expect_exception(r,write_float(&c,0x100,NAN,r,8),16,3);CHECK(c.staged.cell_constant==1.02f);
    CHECK(write_float(&c,0x200,1.0002f,r,9)==8);CHECK(c.staged.gain_valid_mask==1);
    CHECK(write_float(&c,0x23E,0.999f,r,10)==8);CHECK(c.staged.gain_valid_mask==0x80000001u);
    expect_exception(r,write_float(&c,0x201,1.0f,r,11),16,3);
    CHECK(write_float(&c,0x102,1.0001f,r,12)==8);CHECK(write_float(&c,0x104,-0.05f,r,13)==8);
    CHECK(single(&c,0x10A,TX_CAL_K|TX_CAL_TEMPERATURE,r,14)==8);
    CHECK(c.staged.calibration_flags==3);
    crc=tx_params_crc(&c.staged);words[0]=0x5341;words[1]=0x5645;words[2]=(uint16_t)(crc>>16);words[3]=(uint16_t)(crc^1);
    expect_exception(r,write_words(&c,1,0x7F02,words,4,r,15),16,3);CHECK(c.last_error==TX_STORE_BAD_CRC&&!c.pending_apply&&m.erases==0);
    CHECK(commit(&c,r,16)==8);CHECK(r[0]==1&&c.pending_apply&&c.active.cell_constant==1&&c.sequence==1);
    expect_exception(r,read_regs(&c,3,0,2,r,17),3,6);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION);CHECK(c.active.cell_constant==1.02f&&!c.unlocked);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.loaded_from_flash&&boot.active.cell_constant==1.02f&&boot.sequence==1);
    unlock(&c,r,20);words[0]=31;words[1]=4;CHECK(write_words(&c,1,0x106,words,2,r,21)==8);
    expect_exception(r,commit(&c,r,22),16,6);CHECK(c.last_error==TX_STORE_RATE_LIMIT);
    CHECK(commit(&c,r,5016)==8);CHECK(r[0]==1&&c.active.address==1&&c.active.baud_code==0);
    CHECK(tx_protocol_after_reply(&c)==(TX_APPLIED_CALIBRATION|TX_APPLIED_COMMUNICATION));CHECK(c.active.address==31&&tx_baud_rate(c.active.baud_code)==115200);
    CHECK(c.configuration_revision==2);n=read_regs(&c,3,0x106,2,r,5017);CHECK(n==9&&r[3]==0&&r[4]==31&&r[6]==4);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.address==31&&boot.active_slot==1&&boot.sequence==2);
    unlock(&c,r,5020);CHECK(write_u32(&c,0x7F10,TX_DEFAULTS_KEY,r,5021)==8);CHECK(c.staged.address==1&&c.staged.gain_valid_mask==0);
    CHECK(write_u32(&c,0x7F00,0,r,5022)==8);CHECK(!c.unlocked&&c.staged.address==31);
    unlock(&c,r,UINT32_C(0xFFFFFFF0));tx_protocol_poll(&c,10000);CHECK(c.unlocked);tx_protocol_poll(&c,30000);CHECK(!c.unlocked);
}
static void test_wire_errors_and_telemetry(void)
{
    memflash_t m;tx_context_t c;tx_snapshot_t s;uint8_t q[256],r[256];size_t n;uint32_t flags;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);unlock(&c,r,1);
    q[0]=0;q[1]=6;be16(q+2,0x1106);be16(q+4,32);n=finish(q,6);
    CHECK(tx_protocol_process(&c,q,n,r,sizeof r,2)==0&&c.staged.address==1);
    q[0]=2;n=finish(q,6);CHECK(tx_protocol_process(&c,q,n,r,sizeof r,2)==0);
    q[0]=1;n=finish(q,6);q[n-1]^=1;CHECK(tx_protocol_process(&c,q,n,r,sizeof r,3)==0&&c.crc_error_count==1);
    q[0]=1;q[1]=99;n=finish(q,2);expect_exception(r,tx_protocol_process(&c,q,n,r,sizeof r,4),99,1);
    expect_exception(r,read_regs(&c,4,0,0,r,5),4,3);expect_exception(r,read_regs(&c,4,0x20,1,r,6),4,2);
    expect_exception(r,read_wire(&c,3,0xFFFF,2,r,7),3,3);
    q[0]=1;q[1]=16;be16(q+2,0x1106);be16(q+4,2);q[6]=2;be16(q+7,5);n=finish(q,9);
    expect_exception(r,tx_protocol_process(&c,q,n,r,sizeof r,8),16,3);CHECK(c.staged.address==1);
    q[0]=1;q[1]=6;be16(q+2,0x1106);be16(q+4,32);n=finish(q,6);
    CHECK(tx_protocol_process(&c,q,n,r,7,9)==0&&c.staged.address==1);
    CHECK(tx_protocol_process(&c,q,3,r,sizeof r,10)==0);
    memset(&s,0,sizeof s);s.conductivity_us_cm=123.25f;s.conductivity25_us_cm=NAN;s.temperature_c=NAN;s.conductance_s=.00012325f;
    s.status=TX_STATUS_EC_VALID|TX_STATUS_RTD_FAULT;s.frequency_hz=1000;s.gain_voltage=10;s.gain_current=1000;
    s.gain_table_index=23;s.raw_voltage_delta=-1234567;s.raw_current_delta=7654321;s.sample_counter=0x12345678;s.sample_time_ms=100;
    tx_protocol_set_snapshot(&c,&s);n=read_regs(&c,4,0,0x20,r,101);CHECK(n==69);
    CHECK(readfloat(r+3)==123.25f&&isnan(readfloat(r+7))&&isnan(readfloat(r+11)));
    CHECK(read32(r+3+8*2)==(uint32_t)-1234567);CHECK(read32(r+3+14*2)==0x12345678u);
    flags=read32(r+3+12*2);CHECK(flags&TX_STATUS_EC_VALID);CHECK(flags&TX_STATUS_RTD_FAULT);CHECK(!(flags&TX_STATUS_TEMP_VALID));
    CHECK(flags&TX_STATUS_UNCAL_GAIN);CHECK(flags&TX_STATUS_NLF_UNVERIFIED);CHECK(flags&TX_STATUS_FACTORY_DEFAULTS);
    CHECK(read_regs(&c,3,0,2,r,102)==9&&readfloat(r+3)==123.25f);
    CHECK(read_regs(&c,4,12,2,r,10200)==9&&(read32(r+3)&TX_STATUS_STALE));
}
static void test_nlf_registers(void)
{
    memflash_t m;tx_context_t c;uint8_t r[256];uint16_t w[94];float table[36];unsigned i;uint32_t crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);unlock(&c,r,1);
    for(i=0;i<36;i++){uint32_t bits;table[i]=1.5f-0.02f*(float)i;bits=floatbits(table[i]);w[2*i]=(uint16_t)(bits>>16);w[2*i+1]=(uint16_t)bits;}
    crc=nlf_factors_crc32(table);w[72]=0x5445;w[73]=0x5354;w[74]=(uint16_t)(crc>>16);w[75]=(uint16_t)crc;w[76]=0;w[77]=0;
    for(i=0;i<16;i++)w[78+i]=(uint16_t)(0x0102+0x0202*i);
    CHECK(write_words(&c,1,0x300,w,94,r,2)==8);CHECK(c.staged.nlf_flags_verified==0);
    CHECK(write_u32(&c,0x34C,NLF_VERIFIED_MAGIC,r,3)==8);CHECK(tx_params_valid(&c.staged));
    CHECK(commit(&c,r,4)==8);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION);
    CHECK(read_regs(&c,3,0x34C,2,r,5)==9&&read32(r+3)==NLF_VERIFIED_MAGIC);
    unlock(&c,r,6);CHECK(write_float(&c,0x300,1.51f,r,7)==8);CHECK(c.staged.nlf_flags_verified==0);
    expect_exception(r,write_u32(&c,0x34C,NLF_VERIFIED_MAGIC,r,8),16,3);CHECK(c.staged.nlf_flags_verified==0);
}
static void test_power_loss(void)
{
    memflash_t saved,m;tx_context_t c,boot;tx_params_t oldp,newp;int cut;unsigned i;
    clean(&saved);tx_protocol_init(&c,&flash,&saved,0);tx_params_defaults(&oldp);oldp.cell_constant=1.01f;
    CHECK(tx_storage_commit(&c,&oldp));tx_protocol_init(&c,&flash,&saved,0);CHECK(c.active.cell_constant==1.01f);
    newp=oldp;newp.cell_constant=1.02f;newp.serial_format=0;newp.polarity_settling_ms=777;
    /* Every 32-bit program boundary, including valid-marker-last, loses power. */
    for(cut=0;cut<=(int)(TX_RECORD_BYTES/4);cut++) {
        bool ok;m=saved;tx_protocol_init(&c,&flash,&m,0);m.budget=cut;ok=tx_storage_commit(&c,&newp);m.budget=-1;
        tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.loaded_from_flash);
        if(cut<(int)(TX_RECORD_BYTES/4)){CHECK(!ok);CHECK(boot.active.cell_constant==1.01f&&boot.sequence==1);}
        else{CHECK(ok);CHECK(boot.active.cell_constant==1.02f&&boot.sequence==2&&boot.active.serial_format==0&&boot.active.polarity_settling_ms==777);}
        CHECK(memcmp(m.page[0],saved.page[0],512)==0);
    }
    m=saved;tx_protocol_init(&c,&flash,&m,0);m.bad_erase=true;CHECK(!tx_storage_commit(&c,&newp));m.bad_erase=false;
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.cell_constant==1.01f);
    m=saved;tx_protocol_init(&c,&flash,&m,0);CHECK(tx_storage_commit(&c,&newp));
    /* Corrupt each committed header/payload/CRC byte individually: old slot wins. */
    for(i=0;i<TX_RECORD_BYTES;i++) {
        uint8_t value=m.page[1][i];m.page[1][i]^=1;tx_protocol_init(&boot,&flash,&m,0);
        CHECK(boot.loaded_from_flash&&boot.active.cell_constant==1.01f&&boot.sequence==1);m.page[1][i]=value;
    }
    memset(m.page,0xFF,sizeof m.page);tx_protocol_init(&boot,&flash,&m,0);CHECK(!boot.loaded_from_flash&&boot.active.gain_valid_mask==0);
    m.bad_read=true;tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.storage_fault&&!boot.loaded_from_flash);
}
static void test_maintenance(void)
{
    memflash_t m;tx_context_t c,boot;uint8_t r[256];uint16_t w[4]={1,1,2,3};uint32_t revision,crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);
    expect_exception(r,write_words(&c,1,0x400,w,4,r,1),16,3);CHECK(c.maintenance.mode==0);
    unlock(&c,r,2);crc=tx_params_crc(&c.staged);CHECK(write_words(&c,1,0x400,w,4,r,3)==8);
    CHECK(c.maintenance.mode==1&&c.maintenance.frequency_index==1&&c.maintenance.gv_index==2&&c.maintenance.gi_index==3);
    CHECK(tx_params_crc(&c.staged)==crc);revision=c.maintenance.revision;
    CHECK(read_regs(&c,4,0xC,2,r,4)==9&&(read32(r+3)&TX_STATUS_MAINTENANCE));
    w[2]=4;expect_exception(r,write_words(&c,1,0x400,w,4,r,5),16,3);CHECK(c.maintenance.gv_index==2&&c.maintenance.revision==revision);
    CHECK(single(&c,0x404,0xA55A,r,20000)==8);tx_protocol_poll(&c,40000);CHECK(c.unlocked&&c.maintenance.mode==1);
    tx_protocol_poll(&c,50001);CHECK(!c.unlocked&&c.maintenance.mode==0&&c.maintenance.revision==revision+1);
    unlock(&c,r,50002);w[2]=2;CHECK(write_words(&c,1,0x400,w,4,r,50003)==8);CHECK(commit(&c,r,50004)==8);
    CHECK(c.maintenance.mode==1);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION);CHECK(c.maintenance.mode==0);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.loaded_from_flash&&boot.maintenance.mode==0&&boot.maintenance.revision==0);
}
static void test_c0_parameters_and_mapping(void)
{
    memflash_t m;tx_context_t c,boot;tx_params_t p;uint8_t r[256],b[TX_PARAMS_BYTES],joined[12+TX_PARAMS_BYTES];uint32_t crc;unsigned i;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);
    CHECK(c.active.serial_format==3&&c.active.polarity_settling_ms==120);
    expect_exception(r,read_wire(&c,3,0x0000,2,r,1),3,2);
    expect_exception(r,read_wire(&c,4,0x0003,1,r,1),4,2);
    CHECK(read_wire(&c,3,0x110E,2,r,2)==9&&r[4]==3&&r[6]==120);
    expect_exception(r,single(&c,0x10E,1,r,3),6,3);
    unlock(&c,r,4);
    CHECK(single(&c,0x10E,0,r,5)==8&&c.staged.serial_format==0);
    CHECK(single(&c,0x10F,50,r,6)==8&&c.staged.polarity_settling_ms==50);
    expect_exception(r,single(&c,0x10E,4,r,7),6,3);CHECK(c.staged.serial_format==0);
    expect_exception(r,single(&c,0x10F,49,r,8),6,3);CHECK(c.staged.polarity_settling_ms==50);
    expect_exception(r,single(&c,0x10F,2001,r,9),6,3);CHECK(c.staged.polarity_settling_ms==50);
    CHECK(single(&c,0x10F,2000,r,10)==8);CHECK(commit(&c,r,11)==8);
    CHECK(tx_protocol_after_reply(&c)==(TX_APPLIED_CALIBRATION|TX_APPLIED_COMMUNICATION));
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.serial_format==0&&boot.active.polarity_settling_ms==2000);
    /* All serial formats round-trip and affect the canonical CRC. */
    tx_params_defaults(&p);crc=tx_params_crc(&p);
    for(i=0;i<4;i++) {
        p.serial_format=(uint8_t)i;p.polarity_settling_ms=(uint16_t)(120+i);
        tx_params_encode(&p,b);CHECK(tx_params_decode(&boot.active,b));
        CHECK(boot.active.serial_format==i&&boot.active.polarity_settling_ms==120+i);
        CHECK(tx_params_crc(&p)!=crc||i==3);
    }
    /* Reject an otherwise CRC-correct record using obsolete schema 1. */
    m.page[c.active_slot][4]=1;
    memcpy(joined,m.page[c.active_slot],12);memcpy(joined+12,m.page[c.active_slot]+16,TX_PARAMS_BYTES);
    crc=tx_crc32(joined,sizeof joined);
    for(i=0;i<4;i++)m.page[c.active_slot][12+i]=(uint8_t)(crc>>(8*i));
    tx_protocol_init(&boot,&flash,&m,0);
    CHECK(!boot.loaded_from_flash&&boot.active.serial_format==3&&boot.active.polarity_settling_ms==120);
    /* A real old-size 336-byte schema-1 payload must likewise stay ignored. */
    clean(&m);memcpy(m.page[0],"TXP1",4);m.page[0][4]=1;m.page[0][5]=0;m.page[0][6]=0x50;m.page[0][7]=1;
    tx_params_encode(&p,b);memcpy(m.page[0]+16,b,336);
    m.page[0][352]=0xC3;m.page[0][353]=0x3C;m.page[0][354]=0x5A;m.page[0][355]=0xA5;
    tx_protocol_init(&boot,&flash,&m,0);CHECK(!boot.loaded_from_flash&&boot.active.serial_format==3);
}
static void test_hr_measurements(void)
{
    memflash_t m;tx_context_t c;tx_snapshot_t s;uint8_t r[256];uint32_t flags,bits;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);memset(&s,0,sizeof s);
    s.status=TX_STATUS_TEMP_VALID|TX_STATUS_K25_VALID|TX_STATUS_EC_VALID;
    s.temperature_c=10.80f;s.conductivity25_us_cm=70000.5f;s.conductivity_us_cm=123.456f;s.sample_time_ms=10;
    tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==4&&r[4]==0x38);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==70001);
    CHECK(read_wire(&c,3,0x1000,2,r,10)==9&&readfloat(r+3)==123.456f);
    CHECK(read_wire(&c,4,0x1002,2,r,10)==9&&readfloat(r+3)==70000.5f);
    /* High word and low word agree between multi-register and single reads. */
    CHECK(read_wire(&c,3,6,1,r,10)==7&&r[3]==0&&r[4]==1);
    CHECK(read_wire(&c,3,7,1,r,10)==7&&r[3]==0x11&&r[4]==0x71);
    s.temperature_c=-10.80f;s.conductivity25_us_cm=10.49f;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==0xFB&&r[4]==0xC8);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==10);
    s.temperature_c=0.125f;s.conductivity25_us_cm=10.5f;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[4]==13);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==11);
    s.temperature_c=-0.125f;s.conductivity25_us_cm=0;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==0xFF&&r[4]==0xF3);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==0);
    s.temperature_c=1000;s.conductivity25_us_cm=4294967296.0f;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==0x7F&&r[4]==0xFF);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==0xFFFFFFFEu);
    CHECK(read_wire(&c,3,0x100C,2,r,10)==9);flags=read32(r+3);
    CHECK((flags&(TX_STATUS_LEGACY_TEMP_SATURATED|TX_STATUS_LEGACY_K25_SATURATED))==(TX_STATUS_LEGACY_TEMP_SATURATED|TX_STATUS_LEGACY_K25_SATURATED));
    s.temperature_c=-1000;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==0x80&&r[4]==1);
    s.temperature_c=NAN;s.conductivity25_us_cm=NAN;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==0x80&&r[4]==0);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==0xFFFFFFFFu);
    CHECK(read_wire(&c,3,0x100C,2,r,10)==9);flags=read32(r+3);
    CHECK((flags&(TX_STATUS_LEGACY_TEMP_INVALID|TX_STATUS_LEGACY_K25_INVALID))==(TX_STATUS_LEGACY_TEMP_INVALID|TX_STATUS_LEGACY_K25_INVALID));
    s.temperature_c=25;s.conductivity25_us_cm=100;s.status=TX_STATUS_RTD_FAULT|TX_STATUS_TEMP_VALID|TX_STATUS_K25_VALID;
    tx_protocol_set_snapshot(&c,&s);CHECK(read_wire(&c,3,3,1,r,10)==7&&r[3]==0x80&&r[4]==0);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==0xFFFFFFFFu);
    s.status=0;tx_protocol_set_snapshot(&c,&s);CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==0xFFFFFFFFu);
    s.status=TX_STATUS_TEMP_VALID|TX_STATUS_K25_VALID;s.conductivity25_us_cm=-1;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,6,2,r,10)==9&&read32(r+3)==0xFFFFFFFFu);
    s.conductivity25_us_cm=100;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,6,2,r,10011)==9&&read32(r+3)==0xFFFFFFFFu);
    /* EC is stale, but the independent RTD remains healthy/newly updated. */
    CHECK(read_wire(&c,3,3,1,r,10011)==7&&r[3]==9&&r[4]==0xC4);
    CHECK(read_wire(&c,3,0x100C,2,r,10011)==9);flags=read32(r+3);
    CHECK((flags&TX_STATUS_STALE)&&(flags&TX_STATUS_LEGACY_K25_INVALID)&&!(flags&TX_STATUS_LEGACY_TEMP_INVALID));
    s.sample_time_ms=0xFFFFFFFEu;tx_protocol_set_snapshot(&c,&s);
    CHECK(read_wire(&c,3,3,1,r,1)==7&&r[3]==9&&r[4]==0xC4);
    CHECK(read_wire(&c,4,0x1004,2,r,1)==9);bits=read32(r+3);CHECK(bits==floatbits(25.f));
}
static void test_hr_communication(void)
{
    memflash_t m;tx_context_t c,boot;uint8_t r[256];uint16_t w;unsigned erases;uint32_t staged_crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);
    CHECK(read_wire(&c,3,0x130,1,r,0)==7&&r[4]==1);
    CHECK(read_wire(&c,3,0x132,1,r,0)==7&&r[4]==1);
    CHECK(read_wire(&c,3,0x134,1,r,0)==7&&r[4]==3);
    w=0;expect_exception(r,write_wire(&c,1,0x130,&w,1,r,1),16,3);
    w=248;expect_exception(r,write_wire(&c,1,0x130,&w,1,r,2),16,3);
    w=0;expect_exception(r,write_wire(&c,1,0x132,&w,1,r,3),16,3);
    w=2;expect_exception(r,write_wire(&c,1,0x132,&w,1,r,4),16,3);
    w=4;expect_exception(r,write_wire(&c,1,0x134,&w,1,r,5),16,3);
    w=1;expect_exception(r,write_wire(&c,1,0x133,&w,1,r,6),16,2);CHECK(m.erases==0);
    /* Idempotent settings are acknowledged without Flash wear. */
    w=1;CHECK(write_wire(&c,1,0x132,&w,1,r,7)==8&&!c.pending_apply&&m.erases==0);
    unlock(&c,r,8);CHECK(write_float(&c,0x100,1.12f,r,9)==8);staged_crc=tx_params_crc(&c.staged);
    w=0;CHECK(write_wire(&c,1,0x134,&w,1,r,10)==8);
    CHECK(c.pending_apply&&c.pending_communication_only&&r[0]==1&&c.active.serial_format==3);
    CHECK(c.unlocked&&tx_params_crc(&c.staged)==staged_crc&&c.active.cell_constant==1.f);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.serial_format==0&&boot.active.cell_constant==1.f);
    expect_exception(r,read_wire(&c,3,0x134,1,r,11),3,6);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION);
    CHECK(c.active.serial_format==0&&c.staged.serial_format==0&&c.unlocked);
    CHECK(c.active.cell_constant==1.f&&c.staged.cell_constant==1.12f);
    erases=m.erases;w=1;expect_exception(r,write_wire(&c,1,0x134,&w,1,r,12),16,6);
    CHECK(m.erases==erases&&c.active.serial_format==0);
    CHECK(write_wire(&c,1,0x134,&w,1,r,5010)==8);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION);
    CHECK(c.active.serial_format==1&&c.staged.cell_constant==1.12f);
    w=2;CHECK(write_wire(&c,1,0x134,&w,1,r,10010)==8);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION);
    w=3;CHECK(write_wire(&c,1,0x134,&w,1,r,15010)==8);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION);
    w=17;CHECK(write_wire(&c,1,0x130,&w,1,r,20010)==8&&r[0]==1&&c.active.address==1);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION&&c.active.address==17&&c.staged.address==17);
    CHECK(c.staged.cell_constant==1.12f);CHECK(commit(&c,r,25010)==8);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION&&c.active.cell_constant==1.12f);
    unlock(&c,r,25011);CHECK(single(&c,0x107,4,r,25012)==8);CHECK(commit(&c,r,30010)==8);
    CHECK(tx_protocol_after_reply(&c)==(TX_APPLIED_COMMUNICATION|TX_APPLIED_CALIBRATION));
    CHECK(read_wire(&c,3,0x132,1,r,30011)==7&&r[3]==0xFF&&r[4]==0xFF);
    w=1;CHECK(write_wire(&c,17,0x132,&w,1,r,35010)==8&&c.active.baud_code==4);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION&&c.active.baud_code==0);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.address==17&&boot.active.serial_format==3&&boot.active.baud_code==0&&boot.active.cell_constant==1.12f);
}
static void test_hr_power_loss(void)
{
    memflash_t baseline,m;tx_context_t c,boot;tx_params_t p;uint8_t r[256];uint16_t w=42;int cut;
    clean(&baseline);tx_protocol_init(&c,&flash,&baseline,0);tx_params_defaults(&p);p.cell_constant=1.01f;
    CHECK(tx_storage_commit(&c,&p));
    for(cut=0;cut<=(int)(TX_RECORD_BYTES/4);cut++) {
        size_t n;m=baseline;tx_protocol_init(&c,&flash,&m,0);c.unlocked=true;c.unlock_deadline_ms=30000;c.staged.cell_constant=1.2f;
        m.budget=cut;n=write_wire(&c,1,0x130,&w,1,r,1);m.budget=-1;
        CHECK(c.active.address==1&&c.active.cell_constant==1.01f&&c.staged.cell_constant==1.2f);
        tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.cell_constant==1.01f);
        if(cut<(int)(TX_RECORD_BYTES/4)) {
            expect_exception(r,n,16,4);CHECK(!c.pending_apply&&boot.active.address==1);
        } else {
            CHECK(n==8&&r[0]==1&&c.pending_apply&&boot.active.address==42);
            CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION&&c.active.address==42&&c.unlocked);
        }
        CHECK(memcmp(m.page[0],baseline.page[0],512)==0);
    }
    /* The five-second rate limiter is also wrap-safe. */
    m=baseline;tx_protocol_init(&c,&flash,&m,0);
    CHECK(write_wire(&c,1,0x130,&w,1,r,0xFFFFFFF0u)==8);(void)tx_protocol_after_reply(&c);
    w=43;expect_exception(r,write_wire(&c,42,0x130,&w,1,r,100),16,6);
    CHECK(write_wire(&c,42,0x130,&w,1,r,5000)==8);
}

static void test_failed_flash_attempt_rate_limit(void)
{
    memflash_t m;tx_context_t c,boot;uint8_t r[256];uint16_t w=42;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);m.budget=0;
    expect_exception(r,write_wire(&c,1,0x130,&w,1,r,100),16,4);
    CHECK(m.erases==1&&!c.pending_apply&&c.active.address==1);
    m.budget=-1;
    expect_exception(r,write_wire(&c,1,0x130,&w,1,r,101),16,6);
    CHECK(m.erases==1&&c.last_error==TX_STORE_RATE_LIMIT);
    unlock(&c,r,102);expect_exception(r,commit(&c,r,103),16,6);CHECK(m.erases==1);
    CHECK(write_wire(&c,1,0x130,&w,1,r,5100)==8&&m.erases==2);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION&&c.active.address==42);
    /* Reverse direction: a failed protected SAVE throttles legacy as well. */
    clean(&m);tx_protocol_init(&c,&flash,&m,0);unlock(&c,r,1);
    CHECK(write_float(&c,0x100,1.1f,r,2)==8);m.budget=0;
    expect_exception(r,commit(&c,r,100),16,4);CHECK(m.erases==1);
    m.budget=-1;expect_exception(r,commit(&c,r,101),16,6);CHECK(m.erases==1);
    expect_exception(r,write_wire(&c,1,0x130,&w,1,r,102),16,6);CHECK(m.erases==1);
    CHECK(write_wire(&c,1,0x130,&w,1,r,5100)==8&&m.erases==2);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.address==42&&boot.active.cell_constant==1.f);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_COMMUNICATION&&c.staged.cell_constant==1.1f);
}

int main(void)
{
    test_failed_flash_attempt_rate_limit();test_c0_parameters_and_mapping();test_hr_measurements();test_hr_communication();test_hr_power_loss();
    test_crc_and_params();test_transactions();test_wire_errors_and_telemetry();test_nlf_registers();test_maintenance();test_power_loss();
    printf("PASS: %u protocol/storage checks (synthetic nLF integrity fixtures only; no hardware or ISO coefficient validation)\n",checks);
    return 0;
}
