#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p tests/build
${CC:-cc} -std=c99 -O1 -g -Wall -Wextra -Werror -pedantic \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  tx_protocol.c tx_storage.c ../../compensation/nlf.c tests/test_protocol.c \
  -lm -o tests/build/test_protocol
./tests/build/test_protocol
