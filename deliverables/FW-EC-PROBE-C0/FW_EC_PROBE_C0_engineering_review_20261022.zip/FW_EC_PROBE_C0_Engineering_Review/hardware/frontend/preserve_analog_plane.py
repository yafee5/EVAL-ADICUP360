#!/usr/bin/python3
"""Reserve inner1 for a continuous quiet plane rather than automatic signal cuts."""
import os,json,hashlib
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config'),('XDG_CACHE_HOME','/tmp/c0-front-cache'),('XDG_DATA_HOME','/tmp/c0-front-data')]:os.environ.setdefault(k,v)
import pcbnew as p
ROOT=Path(__file__).resolve().parent;NAME='FW_EC_FRONTEND_C0_LAYOUT_DRAFT'
b=p.LoadBoard(str(ROOT/'routing_trial/routed_EXPERIMENT.kicad_pcb'))
# Do not change footprints or wire any NC pins. KiCad uses an encoded slash in
# automatic unconnected net names, whereas its XML netlist spells it literally.
renamed=[]
for net in b.GetNetInfo().NetsByName().values():
    n=net.GetNetname()
    if n.startswith('unconnected-') and '/' in n:
        z=n.replace('/','{slash}');net.SetNetname(z);renamed.append([n,z])
removed=[]
for t in list(b.GetTracks()):
    if isinstance(t,p.PCB_VIA):continue
    if t.GetLayer()==p.In1_Cu and t.GetNetname()!='GND' and min(t.GetStart().y,t.GetEnd().y)<p.FromMM(133):
        removed.append({'net':t.GetNetname(),'start':[p.ToMM(t.GetStart().x),p.ToMM(t.GetStart().y)],'end':[p.ToMM(t.GetEnd().x),p.ToMM(t.GetEnd().y)]})
        b.Delete(t)
for z in b.Zones():
    if z.GetNetname()=='PGND':z.SetPadConnection(p.ZONE_CONNECTION_FULL)
p.SaveBoard(str(ROOT/'routing_trial/plane_pending_fill.kicad_pcb'),b)
b=p.LoadBoard(str(ROOT/'routing_trial/plane_pending_fill.kicad_pcb'))
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones())
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
(ROOT/(NAME+'.kicad_dru')).write_text('''(version 1)
(rule "C0 user 0.1mm copper clearance" (constraint clearance (min 0.1mm)))
(rule "C0 trace width" (constraint track_width (min 0.1mm)))
(rule "C0 drilled via geometry" (constraint via_diameter (min 0.45mm)))
(rule "C0 drill minimum" (constraint hole_size (min 0.2mm)))
(rule "C0 drill to copper manufacturing" (constraint hole_clearance (min 0.2mm)))
(rule "C0 copper to board edge" (constraint edge_clearance (min 0.2mm)))
''')
tracks=list(b.GetTracks())
a={'removed_non_ground_tracks_on_quiet_inner1':removed,'removed_segment_count':len(removed),
   'reason':'Preserve requested quiet ground under TIA/sample-hold/reference, retain incomplete nets instead of routing signals through that plane.',
   'remaining_actual_track_segments':sum(not isinstance(t,p.PCB_VIA) for t in tracks),
   'actual_through_vias':sum(isinstance(t,p.PCB_VIA) for t in tracks),
   'nc_name_encoding_changes':renamed,'positions_changed':False,
   'inner1_ground_region_board_relative_y_mm':[0.3,83],
   'production_ready':False,'gerbers_exported':False}
(ROOT/'analog_plane_preservation.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in a.items() if k!='removed_non_ground_tracks_on_quiet_inner1'}))
