#!/usr/bin/python3
import os,json,shutil
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config'),('XDG_CACHE_HOME','/tmp/c0-front-cache'),('XDG_DATA_HOME','/tmp/c0-front-data')]:os.environ.setdefault(k,v)
import pcbnew as p
ROOT=Path(__file__).resolve().parent
NAME='FW_EC_FRONTEND_C0_LAYOUT_DRAFT'
TRIAL=ROOT/'routing_trial';TRIAL.mkdir(exist_ok=True)
b=p.LoadBoard(str(ROOT/(NAME+'.kicad_pcb')))
idx=json.loads((ROOT.parent/'native/cad_index.json').read_text())
for f in b.GetFootprints():
    if f.GetReference() in idx:
        row=idx[f.GetReference()];path=p.KIID_PATH()
        for u in ['dcceb44c-3625-5fe2-80d4-059e6831f38d',row['sheet_uuid'],row['symbol_uuid']]:path.push_back(p.KIID(u))
        f.SetPath(path)
    if f.GetReference()=='J5':f.SetValue('EC_4E_PLUS_GND_WIRE_LANDS')
for t in b.GetDrawings():
    if isinstance(t,p.PCB_TEXT):
        t.SetTextSize(p.VECTOR2I(p.FromMM(.8),p.FromMM(.8)));t.SetTextThickness(p.FromMM(.12))
        val=t.GetText()
        if val=='ISOLATED ELECTRODE DOMAIN':
            t.SetText('ISO DOMAIN');t.SetPosition(p.VECTOR2I(p.FromMM(58.25),p.FromMM(154.2)))
        elif val.startswith('SWD:'):
            t.SetText('SWD:1V2IO3CK4R5G');t.SetPosition(p.VECTOR2I(p.FromMM(58.25),p.FromMM(124.8)))
        elif val=='2E: bridge BOTH':
            t.SetText('BRIDGE BOTH=2E');t.SetLayer(p.Dwgs_User)
        elif val in ('F+','S+','S-','F-','AG'):
            q=t.GetPosition();q.y=p.FromMM(53.5);t.SetPosition(q)
        elif val.startswith(('TF','TS')):
            q=t.GetPosition();q.y=p.FromMM(56.4);t.SetPosition(q)
        elif val=='FW-EC C0 DRAFT':
            t.SetText('FW-EC C0');t.SetPosition(p.VECTOR2I(p.FromMM(58.25),p.FromMM(50.65)))
nc=b.GetAllNetClasses()['Default'];nc.SetClearance(p.FromMM(.1));nc.SetTrackWidth(p.FromMM(.15));nc.SetViaDiameter(p.FromMM(.45));nc.SetViaDrill(p.FromMM(.2))
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
shutil.copy2(ROOT/(NAME+'.kicad_pcb'),TRIAL/'placement_unrouted.kicad_pcb')
# This states the user's actual 0.1mm manufacturing constraint. It does not
# exclude shorts, unconnected nets, or geometrical errors.
(ROOT/(NAME+'.kicad_dru')).write_text('''(version 1)
(rule "C0 user minimum 0.1mm clearance"
  (constraint clearance (min 0.1mm)))
(rule "C0 trace manufacturing limits"
  (constraint track_width (min 0.1mm)))
''')
print('DSN export',p.ExportSpecctraDSN(b,str(TRIAL/'frontend_trial.dsn')))
