#!/usr/bin/python3
"""Generate C0 real-footprint frontend layout DRAFT, never a production release."""
import os, json, math, uuid, csv, re
from pathlib import Path
from collections import defaultdict, deque
for k,v in [('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config'),('XDG_CACHE_HOME','/tmp/c0-front-cache'),('XDG_DATA_HOME','/tmp/c0-front-data')]:
    os.environ.setdefault(k,v)
import pcbnew as p
ROOT=Path(__file__).resolve().parent
NATIVE=ROOT.parent/'native'
NAME='FW_EC_FRONTEND_C0_LAYOUT_DRAFT'
UID=lambda s:str(uuid.uuid5(uuid.NAMESPACE_URL,'fw-ec-probe-c0/'+s))
ROOT_UUID='dcceb44c-3625-5fe2-80d4-059e6831f38d'
mm=p.FromMM
vec=lambda x,y:p.VECTOR2I(mm(x),mm(y))
OX,OY=50.,50.
WIDTH,LENGTH=16.5,105.
ALL=json.loads((NATIVE/'merged_components.json').read_text())
INDEX=json.loads((NATIVE/'cad_index.json').read_text())
COMP={r:c for r,c in ALL.items() if INDEX[r]['sheet'] in ('afe','core')}
assert len(COMP) in (162,165)
LIBROOT=Path('/usr/share/kicad/footprints')
def lset(*layers):
    z=p.LSET()
    for layer in layers:z.AddLayer(layer)
    return z
FPLIB=ROOT/'C0Frontend.pretty';FPLIB.mkdir(exist_ok=True)

def new_wire_fp(key,count,pitch=2.5,drill=.6,padsize=1.3):
    f=p.FOOTPRINT(None);f.SetValue(key);f.SetFPID(p.LIB_ID('C0Frontend',key))
    f.SetAttributes(p.FP_THROUGH_HOLE|p.FP_EXCLUDE_FROM_BOM|p.FP_EXCLUDE_FROM_POS_FILES)
    for i in range(count):
        q=p.PAD(f);q.SetNumber(str(i+1));q.SetShape(p.PAD_SHAPE_CIRCLE);q.SetAttribute(p.PAD_ATTRIB_PTH)
        q.SetPosition(vec((i-(count-1)/2)*pitch,0));q.SetSize(vec(padsize,padsize));q.SetDrillSize(vec(drill,drill))
        q.SetLayerSet(p.LSET.AllCuMask());q.SetLayerSet(lset(p.F_Cu,p.B_Cu,p.In1_Cu,p.In2_Cu,p.F_Mask,p.B_Mask));f.Add(q)
    return f

def new_swd_fp():
    f=p.FOOTPRINT(None);f.SetValue('SWD5PAD');f.SetFPID(p.LIB_ID('C0Frontend','SWD5PAD'))
    f.SetAttributes(p.FP_SMD|p.FP_EXCLUDE_FROM_BOM|p.FP_EXCLUDE_FROM_POS_FILES)
    for i in range(5):
        q=p.PAD(f);q.SetNumber(str(i+1));q.SetShape(p.PAD_SHAPE_CIRCLE);q.SetAttribute(p.PAD_ATTRIB_SMD)
        q.SetPosition(vec((i-2)*1.27,0));q.SetSize(vec(.85,.85));q.SetLayerSet(lset(p.F_Cu,p.F_Mask));f.Add(q)
    return f

def bbox(f,margin=0.):
    q=f.GetBoundingBox(False,False)
    return (p.ToMM(q.GetLeft())-margin,p.ToMM(q.GetTop())-margin,p.ToMM(q.GetRight())+margin,p.ToMM(q.GetBottom())+margin)

def footprint(ref,c):
    if ref=='J5': f=new_wire_fp('EC5_WIRE',5)
    elif ref=='J3': f=new_wire_fp('PT1000_4WIRE',4)
    elif ref=='J401':f=new_swd_fp()
    elif ref.startswith('L') and ref in ('L3','L4','L5'):
        f=p.FootprintLoad(str(LIBROOT/'Filter.pretty'),'Filter_Murata_BNX025')
        grounds=[q for q in f.Pads() if q.GetNumber()=='4']
        # Right-side CG stays4; bottom-long CG5; upper-central CG6.
        for q in grounds:
            x,y=p.ToMM(q.GetPosition().x),p.ToMM(q.GetPosition().y)
            q.SetNumber('4' if x>5 else '5' if y>0 else '6')
        f.SetFPID(p.LIB_ID('C0Frontend','BNX025_6PAD'))
    else:
        fp=c.get('recommended_footprint')
        if not fp or 'TBD' in fp:
            pack=c.get('package','')
            if ref[0]=='R':fp='Resistor_SMD:R_0805_2012Metric'
            elif ref[0]=='C':fp='Capacitor_SMD:C_0805_2012Metric'
            elif pack.startswith('SOIC127'):fp='Package_SO:SOIC-8_3.9x4.9mm_P1.27mm'
            elif ref in ('U15','U18'):fp='Package_SO:MSOP-10_3x3mm_P0.5mm'
            elif ref=='U17':fp='Package_SO:TSSOP-16_4.4x5mm_P0.65mm'
            elif pack.startswith('SOP65P490'):fp='Package_SO:MSOP-8_3x3mm_P0.65mm'
            elif ref=='D5':fp='Package_TO_SOT_SMD:SOT-23'
            else:raise ValueError((ref,pack))
        lib,name=fp.split(':');f=p.FootprintLoad(str(LIBROOT/(lib+'.pretty')),name)
        if not f:raise RuntimeError((ref,fp))
        f.SetFPID(p.LIB_ID(lib,name))
    f.SetReference(ref);f.SetValue(c.get('value') or c.get('mpn') or ref)
    f.Reference().SetVisible(False);f.Value().SetVisible(False)
    f.SetPosition(vec(0,0))
    return f

# Additional unavoidable functional configuration features, not evaluation
# test headers: electrode compatibility bridges and internal board connector.
COMP.setdefault('J402',{'value':'INTERNAL_8PIN','mpn':'PINHEADER_2X4_1.27_TBD','pins':{'1':'VCC','2':'PGND','3':'UART_TX','4':'UART_RX','5':'RS485_DE_REn','6':'RS485_DE_REn','7':'+3.3V','8':'GND'},'notes':'Internal connector mate J202; pin1..8 fixed; no cable domain copper.'})
for ref,a,z in [('JP401','AFE_FORCE_P','AFE_SENSE_P'),('JP402','AFE_FORCE_M','AFE_SENSE_M')]:
    COMP.setdefault(ref,{'value':'2E_MODE_OPEN','mpn':'PCB_SOLDER_BRIDGE','pins':{'1':a,'2':z},'notes':'OPEN for4-electrode mode; bridge both JP401/402 only for2-electrode. No software-only short.'})

b=p.BOARD();b.SetFileName(str(ROOT/(NAME+'.kicad_pcb')))
b.GetDesignSettings().SetCopperLayerCount(4);b.GetDesignSettings().SetBoardThickness(mm(1.0))
b.GetDesignSettings().SetAuxOrigin(vec(OX,OY+LENGTH))
NETNAMES=sorted({n for c in COMP.values() for n in c['pins'].values() if n})
NETS={}
for i,n in enumerate(NETNAMES,1):q=p.NETINFO_ITEM(b,n,i);b.Add(q);NETS[n]=q
FP={}
for ref,c in COMP.items():
    if ref=='J402':
        f=p.FootprintLoad(str(LIBROOT/'Connector_PinHeader_1.27mm.pretty'),'PinHeader_2x04_P1.27mm_Horizontal')
        assert f;f.SetFPID(p.LIB_ID('Connector_PinHeader_1.27mm','PinHeader_2x04_P1.27mm_Horizontal'))
        f.SetReference(ref);f.SetValue(c['value']);f.Reference().SetVisible(False);f.Value().SetVisible(False)
    elif ref.startswith('JP'):
        f=p.FootprintLoad(str(LIBROOT/'Jumper.pretty'),'SolderJumper-2_P1.3mm_Open_Pad1.0x1.5mm')
        assert f;f.SetFPID(p.LIB_ID('Jumper','SolderJumper-2_P1.3mm_Open_Pad1.0x1.5mm'));f.SetReference(ref);f.SetValue(c['value']);f.Reference().SetVisible(False);f.Value().SetVisible(False)
    else:f=footprint(ref,c)
    if ref in INDEX:
        row=INDEX[ref];path=p.KIID_PATH();path.push_back(p.KIID(ROOT_UUID));path.push_back(p.KIID(row['sheet_uuid']));path.push_back(p.KIID(row['symbol_uuid']));f.SetPath(path)
    for q in f.Pads():
        n=c['pins'].get(q.GetNumber());q.SetNet(NETS[n] if n else b.GetNetInfo().GetNetItem(0))
    b.Add(f);FP[ref]=f
    if str(f.GetFPID().GetLibNickname())=='C0Frontend':
        p.PCB_IO_MGR.PluginFind(p.PCB_IO_MGR.KICAD_SEXP).FootprintSave(str(FPLIB),f)

OCC=[]
PLACED={}
def place(ref,x,y,side='top',angle=0,collision=True):
    f=FP[ref]
    if (side=='bottom') != f.IsFlipped():f.Flip(vec(0,0),False)
    f.SetOrientationDegrees(angle);f.SetPosition(vec(OX+x,OY+y))
    bb=bbox(f,.05)
    # Through-hole interfaces reserve both faces, including all live pad shells.
    sides=('top','bottom') if ref in ('J5','J3','J402') else (side,)
    if collision:
        for _,s,r in OCC:
            if s in sides and overlap(bb,r):raise ValueError(('fixed footprint overlap',ref,_,bb,r))
    for s in sides:OCC.append((ref,s,bb))
    PLACED[ref]={'x_mm':x,'y_mm':y,'side':side,'rotation_deg':angle,'bbox_mm':[round(v,4) for v in bb]}

def overlap(a,z):return a[0]<z[2]-1e-6 and a[2]>z[0]+1e-6 and a[1]<z[3]-1e-6 and a[3]>z[1]+1e-6

# Sensor end at y=0, power/cable end at y=100. Original physical packages kept.
FIXED={
 'J5':(8.25,2.0,'top',0),'J3':(8.25,5.0,'top',0),
 'U14':(4.1,12,'top',0),'U19':(12.4,12,'top',0),
 'U11':(4.1,12,'bottom',0),
 'U15':(4.1,21,'top',0),'U18':(12.4,21,'top',0),
 'U17':(8.25,30,'top',0),
 'U16':(4.1,29,'bottom',0),'U21':(12.4,29,'bottom',0),
 'U10':(4.1,40,'top',0),'U13':(12.4,40,'top',0),
 'U12':(4.1,49,'top',0),'U20':(4.1,40,'bottom',0),'U22':(12.4,40,'bottom',0),
 'U9':(8.25,45.85,'bottom',0),
 'U8':(8.25,59,'top',0),'L5':(8.25,59,'bottom',90),
 'U401':(12.4,68,'top',0),
 'L1':(4.5,73.5,'top',0),'U5':(12.4,74,'top',0),
 'L3':(8.25,86.3,'bottom',90),'L4':(8.25,86.3,'top',90),
 # PinHeader origin is pin1, not physical center; rotation90 gives bbox shifted.
 'J402':(10.155,96.6,'top',270),
 'J401':(8.25,72.0,'bottom',0),
 'JP401':(3.5,7.7,'top',0),'JP402':(12.8,7.7,'top',0),
 'R47':(12.4,16.25,'top',0),'C95':(9.05,16.7,'top',90),
}
for ref in ('U8','L5','U401','L1','U5','L3','L4','J402','J401'):
    x,y,side,angle=FIXED[ref];FIXED[ref]=(x,y+5,side,angle)
FIXED.update({
    'C401':(12.4,74.5,'bottom',0),'C402':(12.4,75.95,'top',180),
    'C26':(2.2,71.6,'top',0),'C25':(2.2,73.9,'top',0),
    'C31':(2.2,55,'top',0),'C81':(14.3,55,'top',0),
    'C40':(2.5,60.4,'top',90),'C57':(13.8,60.55,'top',90),
    'C44':(2.8,64.25,'top',90),'C56':(2.2,69.3,'top',0),
    'C42':(6.0,69.3,'top',0),'C48':(9.8,69.3,'top',0),
    'R13':(13.8,64.15,'top',90),'C39':(13.8,67.9,'top',90),
    'C6':(4.1,25.3,'top',0),'C7':(12.4,25.3,'top',0),
})
for ref,pars in FIXED.items():place(ref,*pars)

GLOBAL={'GND','PGND','+15V','-15V','+3.3V','+3.3V_PREFILTER','VCC','VMID'}
netrefs=defaultdict(set)
for ref,c in COMP.items():
    for n in c['pins'].values():
        if n and n not in GLOBAL:netrefs[n].add(ref)

# Assign original rail bypasses by function rather than clustering all identical
# power-net capacitors in a distant corner.
OWNER={
 'C2':'U11','C3':'U11','C4':'U14','C5':'U18','C6':'U17','C7':'U17','C8':'U22',
 'C47':'U10','C53':'U10','C61':'U13','C69':'U13','C70':'U14','C71':'U12',
 'C77':'U16','C80':'U16','C82':'U19','C86':'U19','C88':'U21','C90':'U21','C91':'U20','C98':'U18',
 'C46':'U9','C58':'U9','C1':'U8','C43':'U8','C51':'U8','C40':'U8','C48':'U8','C57':'U8',
 'C9':'U401','C401':'U401','C402':'U401','C25':'U401','C26':'U401','C31':'U8','C81':'U8',
 'C29':'L3','C30':'L4','C10':'U5','C11':'U5','C12':'U5','C20':'U5','C21':'U5','C22':'U5','C23':'U5',
}

def targets(ref):
    if ref in OWNER:return [(OWNER[ref],1.)]
    reached={ref};todo=deque([(ref,0)]);t={}
    while todo:
        r,d=todo.popleft()
        if d>=3:continue
        for n in COMP[r]['pins'].values():
            if n and n not in GLOBAL:
                for other in netrefs[n]-reached:
                    reached.add(other)
                    if other in FIXED and other.startswith('U'):t[other]=1/(d+1)**2
                    elif other not in FIXED:todo.append((other,d+1))
        if t and d>=1:break
    if not t:
        if ref in ('R49','R50','C100'):t={'U22':1,'U12':.3,'U20':.3}
        elif ref[0] in 'RC' and int(re.sub(r'\D','',ref))<42:t={'U8':1}
        else:t={'U17':1}
    return list(t.items())

def edge_candidates(tx,ty,base,side):
    xs={OX+.2-base[0],OX+WIDTH-.2-base[2],OX+tx}
    ys={OY+.2-base[1],OY+LENGTH-.2-base[3],OY+ty}
    for _,s,z in OCC:
        if s==side:
            xs.update((z[0]-base[2]-.005,z[2]-base[0]+.005))
            ys.update((z[1]-base[3]-.005,z[3]-base[1]+.005))
    xs=[x-OX for x in xs if x+base[0]>=OX+.199 and x+base[2]<=OX+WIDTH-.199]
    ys=[y-OY for y in ys if y+base[1]>=OY+.199 and y+base[3]<=OY+LENGTH-.199]
    out=[((x-tx)**2+(y-ty)**2,x,y) for x in xs for y in ys]
    out.sort()
    return out

def grid_candidates(tx,ty):
    out=[]
    for xi in range(4,int(WIDTH*2)-3):
        x=xi*.5
        for yi in range(16,int(LENGTH*2)-3):
            y=yi*.5
            out.append(((x-tx)**2+(y-ty)**2,x,y))
    out.sort()
    return out

remaining=[r for r in COMP if r not in PLACED]
def priority(ref):
    if ref in ('C50','C73','C84','C93'):return 0
    if ref in ('R13','C42','C44','C56'):return 1
    if ref in OWNER:return 1
    if ref.startswith('D'):return 2
    return 3
remaining.sort(key=lambda r:(priority(r),-len(netrefs.get(next(iter(COMP[r]['pins'].values())),set())),r))
unplaced=[]
for ref in remaining:
    ts=targets(ref);sw=sum(w for r,w in ts)
    tx=sum(PLACED[r]['x_mm']*w for r,w in ts)/sw
    ty=sum(PLACED[r]['y_mm']*w for r,w in ts)/sw
    sides=sorted(('top','bottom'),key=lambda s:-sum(w for r,w in ts if PLACED[r]['side']==s))
    f=FP[ref];best=None
    # Near-target trials first, then whole-board search as a fallback. Cost also
    # penalizes placing a decoupler on the opposite face from its associated IC.
    cand=None
    for side in sides:
        if (side=='bottom') != f.IsFlipped():f.Flip(vec(0,0),False)
        for angle in (0,90):
            f.SetOrientationDegrees(angle);f.SetPosition(vec(0,0));base=bbox(f,.05)
            cand=edge_candidates(tx,ty,base,side)
            for dist,x,y in cand:
                penalty=4*sum(w for r,w in ts if PLACED[r]['side']!=side)/sw
                cost=dist+penalty
                if best and cost>=best[0]:break
                z=(base[0]+OX+x,base[1]+OY+y,base[2]+OX+x,base[3]+OY+y)
                if z[0]<OX+.2 or z[2]>OX+WIDTH-.2 or z[1]<OY+.2 or z[3]>OY+LENGTH-.2:continue
                if any(s==side and overlap(z,r) for _,s,r in OCC):continue
                best=(cost,x,y,side,angle)
                break
    if best:place(ref,*best[1:])
    else:unplaced.append(ref)
if unplaced:
    print('DEBUG_OCC',len(OCC),sum((z[2]-z[0])*(z[3]-z[1]) for _,s,z in OCC),flush=True)
    print('DEBUG_UNPLACED',[(r,bbox(FP[r])) for r in unplaced[:5]],flush=True)
    (ROOT/'layout_debug.json').write_text(json.dumps({'occ':OCC,'placed':PLACED},indent=2))
    raise RuntimeError(('No room at current length; do not delete:',unplaced))

# Hide all library symbol names; use board name only, no ADI logos or marks.
for a,z in [((OX,OY),(OX+WIDTH,OY)),((OX+WIDTH,OY),(OX+WIDTH,OY+LENGTH)),((OX+WIDTH,OY+LENGTH),(OX,OY+LENGTH)),((OX,OY+LENGTH),(OX,OY))]:
    s=p.PCB_SHAPE();s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*z));s.SetLayer(p.Edge_Cuts);s.SetWidth(mm(.05));b.Add(s)
def label(txt,x,y,side='top',size=.7):
    q=p.PCB_TEXT(b);q.SetText(txt);q.SetPosition(vec(OX+x,OY+y));q.SetTextSize(vec(size,size));q.SetTextThickness(mm(.1));q.SetLayer(p.F_SilkS if side=='top' else p.B_SilkS);q.SetMirrored(side=='bottom');b.Add(q)
label('FW-EC C0 DRAFT',8.25,.7,size=.6)
for txt,x in [('F+',3.25),('S+',5.75),('S-',8.25),('F-',10.75),('AG',13.25)]:label(txt,x,3.1,size=.6)
for txt,x in [('TF+',4.5),('TS+',7),('TS-',9.5),('TF-',12)]:label(txt,x,6.15,size=.6)
label('2E: bridge BOTH',8.25,8.7,'bottom',.55)
label('SWD:1V 2IO 3CK 4R 5G',8.25,70.8,'bottom',.55)
label('ISOLATED ELECTRODE DOMAIN',8.25,99,'bottom',.55)

# Copper pours are created, but are intentionally not used to pretend all nets
# are routed. Inner1 is quietGND over the analog section. A distinct rear PGND
# island serves switching supply return, without shorting the BNX ground paths.
def zone(net,layer,x0,y0,x1,y1):
    z=p.ZONE(b);z.SetLayer(layer);z.SetNet(NETS[net]);z.SetLocalClearance(mm(.15));z.SetThermalReliefGap(mm(.2));z.SetThermalReliefSpokeWidth(mm(.2));z.SetMinThickness(mm(.1));z.SetPadConnection(p.ZONE_CONNECTION_THERMAL)
    z.Outline().NewOutline()
    for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]:z.Outline().Append(int(mm(OX+x)),int(mm(OY+y)))
    b.Add(z)
zone('GND',p.In1_Cu,.3,.3,WIDTH-.3,83)
zone('GND',p.In2_Cu,.3,.3,WIDTH-.3,73)
zone('PGND',p.In2_Cu,.3,74,WIDTH-.3,LENGTH-.3)

p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
pro={'meta':{'filename':NAME+'.kicad_pro','version':1},'board':{'design_settings':{'rules':{'min_clearance':.1,'min_track_width':.1,'min_via_diameter':.45,'min_through_hole_diameter':.2,'min_hole_to_hole':.2,'min_copper_edge_clearance':.2}}},'net_settings':{'classes':[{'name':'Default','clearance':.1,'track_width':.15,'via_diameter':.45,'via_drill':.2,'microvia_diameter':.3,'microvia_drill':.1,'diff_pair_width':.15,'diff_pair_gap':.1,'diff_pair_via_gap':.1,'bus_width':12,'line_style':0,'wire_width':6,'pcb_color':'rgba(0,0,0,0)','schematic_color':'rgba(0,0,0,0)'}],'netclass_patterns':[]}}
(ROOT/(NAME+'.kicad_pro')).write_text(json.dumps(pro,indent=2))
(ROOT/'fp-lib-table').write_text('(fp_lib_table (version7) (lib (name "C0Frontend") (type "KiCad") (uri "${KIPRJMOD}/C0Frontend.pretty") (options "") (descr "C0 wire lands and original BNX six-pad mapping")))'.replace('(version7)','(version 7)'))

# Audit real library bounding envelopes and actual pad inclusion, not nominal
# body dimensions. These are placement envelopes, not manufacturer STEP proof.
env=[];outofwidth=[];intersections=[]
for ref,f in FP.items():
    z=bbox(f)
    pads=list(f.Pads())
    pmap={q.GetNumber():q.GetNetname() for q in pads}
    for pin,n in COMP[ref]['pins'].items():
        if n and pmap.get(pin)!=n:raise AssertionError(('pin-map mismatch',ref,pin,n,pmap))
    if z[0]<OX-.001 or z[2]>OX+WIDTH+.001:outofwidth.append(ref)
    height=9.5 if ref in ('L3','L4','L5') else 4.5 if ref=='L1' else 1.75 if COMP[ref].get('package','').startswith('SOIC') else .8 if ref=='U8' else 1.25
    env.append({'reference':ref,'footprint':str(f.GetFPID().GetLibNickname())+':'+str(f.GetFPID().GetLibItemName()),'x_mm':round(p.ToMM(f.GetPosition().x)-OX,4),'y_mm':round(p.ToMM(f.GetPosition().y)-OY,4),'rotation_deg':f.GetOrientationDegrees(),'side':'bottom' if f.IsFlipped() else 'top','bbox_xy_mm':[round(z[0]-OX,4),round(z[1]-OY,4),round(z[2]-OX,4),round(z[3]-OY,4)],'height_envelope_assumed_mm':height,'height_manufacturer_verified':False,'notes':'Height envelope is modeling assumption until manufacturer maximum drawing is checked; BNX9.5mm is NOT verified.'})
for i,(ref,s,z) in enumerate(OCC):
    for other,ss,zz in OCC[:i]:
        if ref!=other and s==ss and overlap(z,zz):intersections.append([ref,other,s])
status={'board':NAME,'status':'PLACEMENT_DRAFT_NOT_FOR_MANUFACTURE','size_mm':[WIDTH,LENGTH],'layers':4,'thickness_mm':1,'component_count':len(COMP),'all_original_frontend_components_preserved':True,'out_of_width_refs':outofwidth,'same_face_envelope_collisions':intersections,'all_footprint_bbox_width_within_17mm':not outofwidth,'tracks':len(list(b.GetTracks())),'production_gerber_exported':False,'erc_is_separate_native_project':True,'drc_pass':False,'notes':['No component shrink or precision part deletion.','Pin/net mapping checked for every connected component pin.','PCB widths verified against library envelope, mechanical heights provisional.','BNX original six logical pad numbers restored from duplicateCG pads.','Unrouted and electrical DRC errors must be resolved before any manufacturing release.']}
(ROOT/'placement_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
(ROOT/'component_envelopes.json').write_text(json.dumps(env,ensure_ascii=False,indent=2)+'\n')
(ROOT/'additional_components_for_schematic.json').write_text(json.dumps({r:COMP[r] for r in ('J402','JP401','JP402')},ensure_ascii=False,indent=2)+'\n')
(ROOT/'placement_and_pinmap.json').write_text(json.dumps({'placements':PLACED,'components':COMP},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(status,ensure_ascii=False))
