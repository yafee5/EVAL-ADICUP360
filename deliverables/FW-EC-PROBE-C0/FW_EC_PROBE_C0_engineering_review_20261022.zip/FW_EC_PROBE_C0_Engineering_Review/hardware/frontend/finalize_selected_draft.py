#!/usr/bin/python3
"""Remove measured edge encroachments and add actual passive guard copper.

Connections removed by this operation remain explicit DRC unconnected items.
No precision part is removed and no manufacturing files are exported.
"""
import os,json
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config'),('XDG_CACHE_HOME','/tmp/c0-front-cache'),('XDG_DATA_HOME','/tmp/c0-front-data')]:os.environ.setdefault(k,v)
import pcbnew as p
ROOT=Path(__file__).resolve().parent;NAME='FW_EC_FRONTEND_C0_LAYOUT_DRAFT'
report=json.loads((ROOT/'drc_selected_draft.json').read_text())
# Keep the pre-cleanup raw report, so nothing is hidden by later counts.
(ROOT/'drc_before_edge_cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
b=p.LoadBoard(str(ROOT/(NAME+'.kicad_pcb')))
removeids=set()
for v in report['violations']:
    if v['type'] not in ('copper_edge_clearance','via_dangling'):continue
    for item in v['items']:
        if item['description'].startswith(('Track [','Via [')):removeids.add(item['uuid'])
removed=[]
for t in list(b.GetTracks()):
    if t.m_Uuid.AsString() in removeids:
        removed.append({'uuid':t.m_Uuid.AsString(),'net':t.GetNetname(),'kind':'via' if isinstance(t,p.PCB_VIA) else 'track'})
        b.Delete(t)
gnd=next(n for n in b.GetNetInfo().NetsByName().values() if n.GetNetname()=='GND')
def guard(layer):
    z=p.ZONE(b);z.SetLayer(layer);z.SetNet(gnd);z.SetLocalClearance(p.FromMM(.25));z.SetMinThickness(p.FromMM(.1));z.SetPadConnection(p.ZONE_CONNECTION_THERMAL);z.SetThermalReliefGap(p.FromMM(.25));z.SetThermalReliefSpokeWidth(p.FromMM(.2))
    z.Outline().NewOutline()
    for x,y in [(50.3,50.3),(66.2,50.3),(66.2,73.5),(50.3,73.5)]:z.Outline().Append(p.FromMM(x),p.FromMM(y))
    b.Add(z)
guard(p.F_Cu);guard(p.B_Cu)
p.SaveBoard(str(ROOT/'routing_trial/guard_pending_fill.kicad_pcb'),b)
b=p.LoadBoard(str(ROOT/'routing_trial/guard_pending_fill.kicad_pcb'))
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
tracks=list(b.GetTracks())
out={'removed_measured_edge_or_dangling_items':removed,
     'guard_copper':{'layers':['F.Cu','B.Cu'],'net':'GND','board_relative_polygon_mm':[[.3,.3],[16.2,.3],[16.2,23.5],[.3,23.5]],'clearance_mm':.25,'passive_guard_not_driven_guard':True,'complete_closed_ring_verified':False,'note':'Real copper exists and is filled. Low-leakage input guard continuity and leakage performance require final layout review/bench measurement.'},
     'components_removed':False,'component_positions_changed':False,'actual_track_segments':sum(not isinstance(t,p.PCB_VIA) for t in tracks),'actual_vias':sum(isinstance(t,p.PCB_VIA) for t in tracks),'status':'INCOMPLETE_ENGINEERING_LAYOUT_NO_GERBERS'}
(ROOT/'selected_cleanup_and_guard.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='removed_measured_edge_or_dangling_items'}))
