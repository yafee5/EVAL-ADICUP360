#!/usr/bin/python3
"""Import local router SES and align one-pad NC net names to real schematic.

This never creates Gerbers and never treats connectivity as analog validation.
"""
import os,json,xml.etree.ElementTree as E,hashlib
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config'),('XDG_CACHE_HOME','/tmp/c0-front-cache'),('XDG_DATA_HOME','/tmp/c0-front-data')]:os.environ.setdefault(k,v)
import pcbnew as p
ROOT=Path(__file__).resolve().parent;NAME='FW_EC_FRONTEND_C0_LAYOUT_DRAFT'
b=p.LoadBoard(str(ROOT/'routing_trial/placement_unrouted.kicad_pcb'))
ses=ROOT/'routing_trial/frontend_trial.ses'
ok=p.ImportSpecctraSES(b,str(ses));assert ok,'SES import failed'
assert len(list(b.GetFootprints()))==165
idx=json.loads((ROOT.parent/'native/cad_index.json').read_text())
fps={f.GetReference():f for f in b.GetFootprints()}
for ref,f in fps.items():
    row=idx[ref];path=p.KIID_PATH()
    for u in ['dcceb44c-3625-5fe2-80d4-059e6831f38d',row['sheet_uuid'],row['symbol_uuid']]:path.push_back(p.KIID(u))
    f.SetPath(path)
    if ref=='J5':f.SetValue('EC_4E_PLUS_GND_WIRE_LANDS')
nl=E.parse(ROOT/'frontend_native.net')
named={n.GetNetname():n for n in b.GetNetInfo().NetsByName().values()}
counter=max(n.GetNetCode() for n in named.values())+1
nc=[]
for net in nl.findall('.//nets/net'):
    name=net.get('name');nodes=net.findall('node')
    if not name.startswith('unconnected-'):continue
    assert len(nodes)==1,'NC net must have exactly one pad; never join NCs'
    node=nodes[0];r,pin=node.get('ref'),node.get('pin')
    if name not in named:
        item=p.NETINFO_ITEM(b,name,counter);counter+=1;b.Add(item);named[name]=item
    pad=next(q for q in fps[r].Pads() if q.GetNumber()==pin)
    assert not pad.GetNetname(),'Unexpected connection on a declared NC pin'
    pad.SetNet(named[name]);nc.append([r,pin,name])
b.BuildConnectivity()
try:
    fill=p.ZONE_FILLER(b);fill.Fill(b.Zones());filled=True
except Exception as e:
    filled=False;print('Plane fill failed:',repr(e))
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
p.SaveBoard(str(ROOT/'routing_trial/routed_EXPERIMENT.kicad_pcb'),b)
tracks=list(b.GetTracks())
meta={'imported_ses_sha256':hashlib.sha256(ses.read_bytes()).hexdigest(),'import_success':ok,
      'actual_track_segments':sum(not isinstance(t,p.PCB_VIA) for t in tracks),
      'actual_through_vias':sum(isinstance(t,p.PCB_VIA) for t in tracks),
      'component_count':165,'planes_filled':filled,'nc_single_pad_nets_named':len(nc),
      'nc_connections_added':False,'component_positions_changed':False,
      'status':'ROUTING_EXPERIMENT_PENDING_ACTUAL_KICAD_DRC_AND_ANALOG_REVIEW',
      'gerbers_exported':False}
(ROOT/'routing_trial/import_status.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
