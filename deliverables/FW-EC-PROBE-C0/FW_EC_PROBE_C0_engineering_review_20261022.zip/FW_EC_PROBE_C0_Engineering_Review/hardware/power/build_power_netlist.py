#!/usr/bin/env python3
"""C0 rear-board design candidate; physical transformer mapping is deliberately HOLD."""
import json, pathlib, hashlib, csv
ROOT=pathlib.Path(__file__).resolve().parent
components={}
def part(ref,value,mpn,manufacturer,package,pins,pin_names=None,pin_types=None,source='',notes='',status='VERIFIED_MPN_STOCK_UNCHECKED',footprint=None):
    components[ref]=dict(value=value,mpn=mpn,manufacturer=manufacturer,package=package,footprint=footprint,pins=pins,pin_names=pin_names or {p:p for p in pins},pin_types=pin_types or {p:'passive' for p in pins},source=source,notes=notes,procurement_status=status,quantity=1)
def r(ref,value,a,b,mpn=None,package='0402',notes='',tol='1%'):
    part(ref,value,mpn,'Panasonic' if mpn and mpn.startswith('ERJ') else None,package,{'1':a,'2':b},source='E96 value; manufacturer ordering code requires supplier confirmation unless noted',notes=f'{tol}. '+notes,status='HOLD_MPN_DATASHEET' if mpn is None else 'CANDIDATE_MPN_SUPPLIER_CONFIRM',footprint=f'Resistor_SMD:R_{package}_1005Metric' if package=='0402' else None)
def c(ref,value,a,b,mpn=None,package='0805',notes='',source='ADI CN0359 original BOM / ADI power reference component table'):
    part(ref,value,mpn,'Murata' if mpn and mpn.startswith('GRM') else 'Yageo' if mpn and mpn.startswith('CC') else None,package,{'1':a,'2':b},source=source,notes=notes,status='VERIFIED_REFERENCE_MPN_STOCK_UNCHECKED' if mpn else 'HOLD_MPN_DATASHEET')
part('J201','CABLE 4 wires + shield','WIRE_SOLDER_PADS_5',None,'5 independent solder pads',{'1':'VIN_CABLE','2':'GND_CABLE','3':'485A','4':'485B','5':'CHASSIS'},pin_names={'1':'RED +12..30V','2':'YELLOW RETURN','3':'BLUE A','4':'GREEN B','5':'SHIELD TO HOUSING'},source='User cable definition',notes='Shield direct to metal housing; no bridge to quiet electrode ground. No pressure vent required for EC/T-only unit.',status='CUSTOM_FOOTPRINT_PENDING')
part('J202','INTERNAL 2x4 1.27mm','INTERNAL_8PAD_PINMAP_FIXED',None,'2x4 1.27mm or wire solder pads',{'1':'VCC','2':'PGND','3':'UART_TX','4':'UART_RX','5':'DE','6':'nRE','7':'+3.3V','8':'GND'},pin_names={'1':'5V_ISO','2':'PGND_ISO','3':'TX from MCU','4':'RX to MCU','5':'DE','6':'nRE','7':'3V3_ISO filtered','8':'GND_ISO quiet'},source='Root/MCU/power interface agreement 2026-10-22',notes='PGND and GND are not bridged on this board. MCU board preserves original BNX filter ground scheme. Bare header MPN not selected until assembly mechanics frozen.',status='HOLD_CONNECTOR_MPN')
part('D201','100V/2A Schottky reverse protection','SS210-E3/52T','Vishay','SMB DO-214AA',{'1':'VIN_PROTECTED','2':'VIN_CABLE'},pin_names={'1':'K','2':'A'},source='Candidate known manufacturer part, current manufacturer PDF not obtained',notes='Series diode before TVS; worst forward drop and thermal dissipation must be measured. No claim of automotive reverse-transient qualification.',status='CANDIDATE_MPN_DATASHEET_REQUIRED')
part('D202','33V 600W unidirectional TVS','SMBJ33A','Littelfuse','SMB DO-214AA',{'1':'VIN_PROTECTED','2':'GND_CABLE'},pin_names={'1':'K','2':'A'},source='Candidate SMBJ family; manufacturer datasheet still needed',notes='Nominal 33V standoff and approximately53V clamping are design assumptions pending exact vendor curve; TVS alone does not establish IEC61000-4-5 immunity. Supply current limit/fusing coordinated outside this board.',status='CANDIDATE_MPN_DATASHEET_REQUIRED')
c('C201','2.2uF 100V','VIN_PROTECTED','GND_CABLE','GRM32ER72A225KA35L','1210',notes='Candidate full code; DC bias/stock not verified',source='Candidate Murata MLCC code, manufacturer confirmation required');components['C201']['procurement_status']='CANDIDATE_MPN_DATASHEET_REQUIRED'
c('C202','100nF 100V','VIN_PROTECTED','GND_CABLE',None,'0805',notes='Must survive TVS clamp; do not substitute original25V decoupler')
pins={'1':'VIN_PROTECTED','3':'BUCK_EN','5':None,'6':None,'7':'GND_CABLE','8':'BUCK_RT','9':None,'10':'BUCK_SS','11':'BUCK_FB','12':'5V_CABLE','13':None,'14':'BUCK_IND','15':None,'16':'BUCK_INTVCC','18':'BUCK_BST','20':'BUCK_SW','21':'GND_CABLE'}
names={'1':'VIN','3':'EN/UV','5':'PG','6':'NC','7':'SYNC/MODE','8':'RT','9':'NC','10':'TR/SS','11':'FB','12':'VOUT','13':'NC','14':'IND','15':'NC','16':'INTVCC','18':'BST','20':'SW','21':'GND_EP'}
types={p:('no_connect' if pins[p] is None else 'power_in' if p in ('1','21') else 'power_out' if p in ('12','16','20') else 'input' if p in ('3','7','8','10','11') else 'passive') for p in pins};types['5']='open_collector'
part('U201','LT8631 100V/1A buck','LT8631IFE#PBF','Analog Devices','TSSOP-20(16 populated leads)+EP FE20(16)',pins,names,types,'LT8631 RevD p2,p9,p21,p24',notes='Pins2/4/17/19 physically omitted by high-voltage package; do not use a generic20-lead footprint with these pads. 1A total5V budget must include converter primary and485 bus TX. 5.038V nominal from1M/191k and0.808Vref.',footprint='C0Power:LT8631_FE20_16_EP2.74x3.86')
part('L201','22uH','SLF10145T-220M1R9','TDK','10.1x10.1x4.5mm power inductor',{'1':'BUCK_SW','2':'BUCK_IND'},source='LT8631 RevD p21 recommends this exact part; KiCad L_TDK_SLF10145 references TDK SLF series drawing',notes='Dimensions, height, saturation current and land pattern still require TDK drawing before production.',status='VERIFIED_REFERENCE_MPN_HOLD_FOOTPRINT')
c('C203','100nF 25V','BUCK_BST','BUCK_SW','CC0805KRX7R8BB104')
c('C204','2.2uF 10V','BUCK_INTVCC','GND_CABLE',None,'0603')
c('C205','100nF 25V','BUCK_SS','GND_CABLE','CC0805KRX7R8BB104')
r('R201','25.5k','BUCK_RT','GND_CABLE',None)
r('R202','1M','5V_CABLE','BUCK_FB',None,notes='LT8631 reference value')
r('R203','191k','BUCK_FB','GND_CABLE',None,notes='LT8631 reference value')
c('C206','4.7pF C0G','5V_CABLE','BUCK_FB',None,'0402')
c('C207','47uF 16V','5V_CABLE','GND_CABLE',None,'1210',notes='Effective C at5V must be checked against LT8631 stability/output ripple requirements')
r('R204','806k','VIN_PROTECTED','BUCK_EN',None,notes='Design UVLO rising1.19*(1+806/100)=10.78V, must tolerance-check startup after reverse diode')
r('R205','100k','BUCK_EN','GND_CABLE',None)
c('C210','10uF 10V','5V_CABLE','GND_CABLE','GRM31CR71A106KA01L','1206',notes='At transformer center tap, loop short',source='ADuM4070 RevA recommended components table')
c('C211','100nF 25V','5V_CABLE','GND_CABLE','CC0805KRX7R8BB104',notes='VDDA bypass lead length<2mm')
upins={'1':'ISO_X1','2':'GND_CABLE','3':None,'4':'ISO_X2','5':None,'6':None,'7':'5V_CABLE','8':'GND_CABLE','9':'PGND','10':'ISO_OC','11':None,'12':None,'13':'ISO_FB','14':'ISO_CTRL5','15':'PGND','16':'ISO_RAW6V5'}
unames={'1':'X1','2':'GND1','3':'NC','4':'X2','5':'NC','6':'NC','7':'VDDA','8':'GND1','9':'GND2','10':'OC','11':'NC','12':'NC','13':'FB','14':'VDD2','15':'GND2','16':'VREG'}
utypes={p:('no_connect' if upins[p] is None else 'power_in' if p in ('2','7','8','9','15','16') else 'power_out' if p=='14' else 'output' if p in ('1','4') else 'input') for p in upins}
part('U202','ADuM4070 isolated regulator','ADUM4070ARIZ','Analog Devices','SOIC16 wide increased creepage RI-16-2',upins,unames,utypes,'ADuM4070 RevA p9,p16,p20',notes='Output set6.525V then regulated5V. VREG=raw6.525V; VDD2 is INTERNAL5V output, NEVER tie VDD2 to6.525V. Datasheet package max lead span10.55mm; external air gap>8mm. Component5kVrms does not certify assembled-board withstand.',footprint='Package_SO:SOIC-16W_7.5x12.8mm_P1.27mm')
part('T201','1CT:3CT isolated transformer','JA4650-BL','Coilcraft','HOLD manufacturer mechanical drawing',{'P1':'ISO_X1','PCT':'5V_CABLE','P2':'ISO_X2','S1':'ISO_SEC_A','SCT':'PGND','S2':'ISO_SEC_B'},pin_names={'P1':'PRIMARY END1 logical','PCT':'PRIMARY CENTER logical','P2':'PRIMARY END2 logical','S1':'SECONDARY END1 logical','SCT':'SECONDARY CENTER logical','S2':'SECONDARY END2 logical'},source='ADuM3070 RevB Table13:1CT:3CT,2500Vrms,18Vus,255uH total primary,0.2ohm total primary',notes='Functional winding names ONLY, not physical pin numbers. Manufacturer drawing/physical mapping/width/height are NOT obtained. BLOCK PCB release and fit claim until confirmed. One must not assign guessed numeric pin numbers or generic transformer pads.',status='HOLD_FOOTPRINT_PINMAP',footprint=None)
for ref,sec in [('D203','ISO_SEC_A'),('D204','ISO_SEC_B')]:
 part(ref,'40V/0.5A Schottky','MBR0540T1G','onsemi','SOD-123',{'1':'ISO_RECT','2':sec},pin_names={'1':'K','2':'A'},source='ADuM3070/4070 reference MBR0540T1 family; G suffix lead-free ordering requires supplier confirmation',notes='At3x turns ratio check worst secondary PIV<40V including ringing. Startup/short-circuit bench test required.',status='VERIFIED_REFERENCE_FAMILY_ORDER_SUFFIX_CHECK')
part('L202','47uH','LQH3NPN470MM0','Murata','1212',{'1':'ISO_RECT','2':'ISO_RAW6V5'},source='ADuM3070 RevB Table14 recommends this exact part',notes='0.41A reference current rating; final load/temp/availability/footprint must be checked',status='VERIFIED_REFERENCE_MPN_HOLD_FOOTPRINT')
c('C212','47uF 10V X7R','ISO_RAW6V5','PGND','GRM32ER71A476KE15L','1210',notes='Nominal47uF reference; DC-bias at6.525V may significantly reduce effective C, loop response unverified',source='ADuM3070/4070 reference recommended capacitor')
c('C213','100nF 25V','ISO_CTRL5','PGND','CC0805KRX7R8BB104',notes='VDD2 bypass<2mm')
r('R210','42.2k','ISO_RAW6V5','ISO_FB',None,tol='0.1%',notes='1.25*(1+42.2/10)=6.525V nominal;1.15..1.37V reference implies6.003..7.151V before resistor/load/ripple')
r('R211','10.0k','ISO_FB','PGND',None,tol='0.1%')
r('R212','100k','ISO_OC','PGND',None,notes='Approximately500kHz reference switching frequency')
c('C214','100nF 25V','ISO_RAW6V5','ISO_FB','CC0805KRX7R8BB104',notes='ADuM4070 recommends this CFB for lower transient overshoot; must test actual loop')
c('C220','10uF 25V','ISO_RAW6V5','PGND','GRM21BR61E106KA73L','0805',notes='OriginalCN0359 MPN with final L packaging suffix; input DC bias must be checked')
c('C221','10uF 25V','VCC','PGND','GRM21BR61E106KA73L','0805')
vpins={'1':'VCC','2':'VCC','3':'PGND','4':None,'5':'ISO_RAW6V5','6':'PGND','7':None,'8':'ISO_RAW6V5','9':'PGND'}
vnames={'1':'VOUT','2':'SENSE','3':'GND','4':'NC','5':'EN/UVLO','6':'GND','7':'PG','8':'VIN','9':'EPAD'}
vtypes={'1':'power_out','2':'input','3':'power_in','4':'no_connect','5':'input','6':'power_in','7':'open_collector','8':'power_in','9':'power_in'}
part('U203','5V 500mA low-noise LDO','ADP7104ARDZ-5.0-R7','Analog Devices','SOIC8 exposed pad RD-8-4',vpins,vnames,vtypes,'ADP7104 RevL p6/p24',notes='0.55V maxdropout at500mA; targetraw6.525V provides headroom even for ref tolerance. Heat=(Vraw-5V)*Iload, not negligible. PG left unconnected is allowed; NC4 MUST float.',footprint='Package_SO:SOIC-8-1EP_3.9x4.9mm_P1.27mm_EP2.29x3mm')
wpins={'1':'+3.3V','2':'GND','3':'UART_RX','4':'nRE','5':'DE','6':'UART_TX','7':'GND','8':'GND','9':'GND_CABLE','10':None,'11':'485A','12':'485B','13':'485B','14':'485A','15':'GND_CABLE','16':'5V_CABLE'}
wnames={'1':'VDD1','2':'GND1','3':'RxD','4':'nRE','5':'DE','6':'TxD','7':'INVR','8':'GND1','9':'GND2','10':'NIC','11':'Y','12':'Z','13':'B','14':'A','15':'GND2','16':'VDD2'}
wtypes={p:('power_in' if p in ('1','2','8','9','15','16') else 'output' if p in ('3','11','12') else 'no_connect' if p=='10' else 'input') for p in wpins}
part('U204','ADM2763E isolated485','ADM2763EBRWZ','Analog Devices','SOIC16 wide RW-16',wpins,wnames,wtypes,'ADM2761E/ADM2763E RevA p13,p24',notes='Full-duplex device wired half-duplex by Y=A and Z=B. INVR tiedGND. logic1 supply3.3/GND quiet, bus2 supply5V/GND_CABLE. 500kbps rated; wholeunit all cable-facing supplies stay cable domain.',footprint='Package_SO:SOIC-16W_7.5x10.3mm_P1.27mm')
for ref,rail,ret in [('C230','+3.3V','GND'),('C231','5V_CABLE','GND_CABLE')]:c(ref,'100nF 25V',rail,ret,'CC0805KRX7R8BB104',notes='AtVDD1/VDD2 pin respectively')
for ref,rail,ret in [('C232','+3.3V','GND'),('C233','5V_CABLE','GND_CABLE')]:c(ref,'10uF 25V',rail,ret,'GRM21BR61E106KA73L','0805')
r('R220','100k','DE','GND',None,notes='Driver disabled during MCUreset')
r('R221','100k','nRE','GND',None,notes='Receiver enabled during MCUreset; MCU mapsDE/nRE to same output')
r('R222','100k','UART_TX','+3.3V',None,notes='UARTidle high duringreset')
part('D205','RS485 asymmetric TVS','CDSOT23-SM712','Bourns','SOT-23',{'1':'485A','2':'485B','3':'GND_CABLE'},pin_names={'1':'LINE1','2':'LINE2','3':'COMMON'},source='B0 audited isolation netlist references Bourns figure4 and BOM',notes='TVS return is cable ground, never electrode ground. Actual IEC surge/ESD tests not done.',footprint='Package_TO_SOT_SMD:SOT-23')
r('R223','120R','485A','TERM_JUMPER',None,'0805',notes='Permanent resistor through normallyopen solderbridge; fits only atbusend')
part('JP201','120ohm termination enable','CUSTOM_SOLDER_BRIDGE_OPEN',None,'2pad normallyopen solder bridge',{'1':'TERM_JUMPER','2':'485B'},source='User optional termination requirement',notes='Required termination option, not an obsolete evaluation test jumper. Close only if thisunit is oneof2 busends. No DNP resistor footprint.',status='CUSTOM_FUNCTIONAL_OPTION',footprint='Jumper:SolderJumper-2_P1.3mm_Open_RoundedPad1.0x1.5mm')
# Standard footprint assignment is separate from supplier-MPN signoff.
capfp={'0402':'C_0402_1005Metric','0603':'C_0603_1608Metric','0805':'C_0805_2012Metric','1206':'C_1206_3216Metric','1210':'C_1210_3225Metric'}
resfp={'0402':'R_0402_1005Metric','0805':'R_0805_2012Metric'}
for ref,p in components.items():
 if ref.startswith('C') and p['package'] in capfp:p['footprint']='Capacitor_SMD:'+capfp[p['package']]
 if ref.startswith('R') and p['package'] in resfp:p['footprint']='Resistor_SMD:'+resfp[p['package']]
components['J201']['footprint']='C0Power:Cable_5_SMD_2.5mm'
components['J202']['footprint']='Connector_PinHeader_1.27mm:PinHeader_2x04_P1.27mm_Vertical'
for ref in ('D201','D202'):components[ref]['footprint']='Diode_SMD:D_SMB'
for ref in ('D203','D204'):components[ref]['footprint']='Diode_SMD:D_SOD-123'
components['L201']['footprint']='Inductor_SMD:L_TDK_SLF10145'
components['L201']['procurement_status']='VERIFIED_REFERENCE_MPN_STOCK_UNCHECKED'
components['L201']['notes']='Nominal22uH; TDK saturation/DCR/temperature curve must still be confirmed at peak current. Same-family KiCad footprint referenced from manufacturer drawing, not a different inductor series.'
components['L202']['footprint']=None
components['L202']['notes']+='; exact land pattern unavailable: HOLD, do not replace with a guessed1210/1212 footprint'
components['U203']['footprint']=None
components['U203']['procurement_status']='VERIFIED_MPN_HOLD_EP_FOOTPRINT'
components['U203']['notes']+='; latestRD8-4 preciseEPdrawing notobtained. Prior2.29x3.0 footprint retracted; oldCN/JPrev showsRD8-2 EP2.41x3.098,2025PCN saysRD8-1->4 changesstandoffonly, cannot assumeold2geometryequalscurrent1/4.'
components['U201']['pin_types']['7']='input'
meta={'revision':'C0_POWER_ENGINEERING_CANDIDATE','board':'rear_power_485','release_status':'NOT_FOR_PRODUCTION','net_aliases':{'VCC':'5V_ISO','PGND':'PGND_ISO','GND':'GND_ISO quiet','+3.3V':'3V3_ISO filtered'},'input':'12..30V DC; continuous current relaxed by user','architecture':'cable input seriesSchottky/TVS -> LT8631 5V -> ADUM4070 + JA4650BL isolation6.525V -> ADP7104 5V -> frontboard originalAFE supplies; ADM2763E signal barrier','blockers':['T201 mechanical drawing and physicalpin mapping not obtained; NO production footprint','Buck1A combinedload engineering envelope approximately0.916A; transient/thermal margin not yet measured','NonADI new passive fullMPNs and supplier stock not yet verified','No final route/ERC/DRC/CAM or thermal/EMC/withstand test'], 'ground_policy':'No direct copper or capacitor bridges GND_CABLE to either PGND or GND. PGND and GND distinct onrearboard; originalBNX frontboard scheme retained.', 'creepage_policy':'Target>=4mm cable-vsISO boardcopper all layers; ADM2763E and ADUM4070 package ratings alone do not certify assembly; T201 footprint unknown preventsclearance signoff.'}
data={'metadata':meta,'components':components}
(ROOT/'power_netlist.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
fields=['board','reference','quantity','value','manufacturer','mpn','package','procurement_status','source','notes']
with (ROOT/'power_bom_candidate.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
 for ref,p in components.items():w.writerow({'board':meta['board'],'reference':ref,**{k:p.get(k) for k in fields if k not in ('board','reference')}})
manifest=[]
for p in sorted((ROOT/'references').glob('*.pdf')):manifest.append({'file':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(ROOT/'references_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Components',len(components));print('HOLD',sum('HOLD' in p['procurement_status'] for p in components.values()))
