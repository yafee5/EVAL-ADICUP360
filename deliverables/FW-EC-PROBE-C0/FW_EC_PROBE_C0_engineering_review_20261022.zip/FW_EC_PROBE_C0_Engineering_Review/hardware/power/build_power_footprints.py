#!/usr/bin/env python3
"""Create source-supported footprints by sexpr transform; no guessed transformer pads."""
import pathlib,json,re
root=pathlib.Path(__file__).resolve().parent;lib=root/'C0Power.pretty';lib.mkdir(exist_ok=True)
std=pathlib.Path('/usr/share/kicad/footprints')
s=(std/'Package_SO.pretty/HTSSOP-20-1EP_4.4x6.5mm_P0.65mm_EP2.74x3.86mm.kicad_mod').read_text()
old='HTSSOP-20-1EP_4.4x6.5mm_P0.65mm_EP2.74x3.86mm';new='LT8631_FE20_16_EP2.74x3.86'
s=s.replace(old,new)
s=re.sub(r'\(descr "[^"]*"\)','(descr "LT8631 RevD p24 FE20(16) CB; LT8630 RevB p22 same mechanical. Missing2,4,17,19; leadland1.05x0.45mm outerspan6.60mm; EP2.74x3.86mm. Paste and thermalvia assembly review pending.")',s, count=1)
def endblock(t,start):
 depth=0;quoted=False;escape=False
 for i in range(start,len(t)):
  ch=t[i]
  if quoted:
   if escape:escape=False
   elif ch=='\\':escape=True
   elif ch=='"':quoted=False
  elif ch=='"':quoted=True
  elif ch=='(':depth+=1
  elif ch==')':
   depth-=1
   if depth==0:return i+1
 raise ValueError('unbalanced')
blocks=[]
for m in re.finditer(r'\(pad "([^\"]*)"',s):
 n=m.group(1);a=m.start();b=endblock(s,a);block=s[a:b]
 if n in ('2','4','17','19'):block=''
 elif n and n!='21':
  pos=re.search(r'\(at ([-0-9.]+) ([-0-9.]+)(?: [-0-9.]+)?\)',block);x=float(pos[1]);y=float(pos[2]);block=block[:pos.start()]+f'(at {(-2.775 if x<0 else 2.775):.3f} {y})'+block[pos.end():]
  block=re.sub(r'\(size [-0-9.]+ [-0-9.]+\)','(size 1.05 0.45)',block,count=1)
 blocks.append((a,b,block))
for a,b,replacement in reversed(blocks):s=s[:a]+replacement+s[b:]
# Generic20lead library3Dmodel would depict nonexisting pins; removeit.
for m in reversed(list(re.finditer(r'\(model ',s))):
 a=m.start();b=endblock(s,a);s=s[:a]+s[b:]
(lib/(new+'.kicad_mod')).write_text(s)
# Retain compatibility filename while root updates source references.
compat=s.replace(new,'LT8630_FE20_16_EP2.74x3.86');(lib/'LT8630_FE20_16_EP2.74x3.86.kicad_mod').write_text(compat)
wire=['(footprint "Cable_5_SMD_2.5mm" (version 20241229) (generator "C0Power") (layer "F.Cu")','(descr "Five1.8x2.2mm solderlands2.5mm pitch; housingstrainrelief required; assemblypulltest pending.") (attr smd)', '(property "Reference" "REF**" (at 0 -2.2) (layer "F.SilkS") (effects(font(size 0.7 0.7)(thickness 0.12))))', '(property "Value" "CABLE5" (at 0 2.2) (layer "F.Fab") (effects(font(size 0.7 0.7)(thickness 0.12))))']
for n in range(1,6):wire.append(f'(pad "{n}" smd roundrect (at {(n-3)*2.5} 0) (size 1.8 2.2) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.2))')
wire.append('(fp_rect(start -6.15 -1.35)(end 6.15 1.35)(stroke(width 0.05)(type default))(fill none)(layer "F.CrtYd"))')
wire.append(')');(lib/'Cable_5_SMD_2.5mm.kicad_mod').write_text('\n'.join(wire)+'\n')
report={'LT8631':{'file':'C0Power.pretty/LT8631_FE20_16_EP2.74x3.86.kicad_mod','physical_pin_numbers':sorted([n for n in re.findall(r'\(pad "([^\"]+)"',s)],key=int),'source':'LT8631 RevD p24 and LT8630 RevB p22 same FE20(16) drawing','checked':['missingpins2/4/17/19','EP21 2.74x3.86','leadpitch0.65','pad1.05x0.45','padouterspan6.60'], 'unchecked':['manufacturing stencil reduction/thermal vias','soldering trial']},'ADUM4070':{'footprint':'Package_SO:SOIC-16W_7.5x12.8mm_P1.27mm','source':'ADuM4070 RevA p20 RI16-2 bodylength12.65..12.95,leadspan10.05..10.55,pitch1.27','warning':'DO NOTuse7.5x10.3mm bodylength footprint; thatisADM2763E RW16'},'HOLD':['T201 transformer mechanicaldrawing/physicalpinmap','L202 LQH3NPN470MM0 exactlandpattern','U203 EP size confirmation if packagePDFnot obtained']}
(root/'footprint_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
assert report['LT8631']['physical_pin_numbers']==['1','3','5','6','7','8','9','10','11','12','13','14','15','16','18','20','21']
print('Customfootprints generated; LT8631 mechanicalpinset verified',len(report['LT8631']['physical_pin_numbers']))
