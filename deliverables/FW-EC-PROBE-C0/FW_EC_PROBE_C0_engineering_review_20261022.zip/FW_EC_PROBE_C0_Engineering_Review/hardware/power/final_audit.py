#!/usr/bin/python3
"""Independent source/netlist/footprint audit; NOT electrical simulation/ERC/DRC."""
import pathlib,json,hashlib
import pcbnew
root=pathlib.Path(__file__).resolve().parent
j=json.loads((root/'power_netlist.json').read_text());c=j['components'];checks=[]
def ck(name,ok):
 checks.append({'check':name,'passed':bool(ok)})
 if not ok:raise AssertionError(name)
ck('45 distinct component references',len(c)==45)
for ref,p in c.items():ck(ref+' pins/names/types have identical keys',set(p['pins'])==set(p['pin_names'])==set(p['pin_types']))
ck('LT8631 selected',c['U201']['mpn']=='LT8631IFE#PBF')
ck('LT8631 pin7 SYNC/MODE grounded',c['U201']['pins']['7']=='GND_CABLE' and c['U201']['pin_names']['7']=='SYNC/MODE')
ck('LT8631 400kHz RT resistor',c['R201']['value']=='25.5k')
ck('LT8631 4.7pF feedforward',c['C206']['value']=='4.7pF C0G')
ck('LT8631 reference recommended22uH part',c['L201']['mpn']=='SLF10145T-220M1R9')
ck('ADC chain5V afterLDO',c['U203']['pins']['1']=='VCC')
ck('IsolatorVREGraw6V5',c['U202']['pins']['16']=='ISO_RAW6V5')
ck('IsolatorinternalVDD2notshortedraw6V5',c['U202']['pins']['14']=='ISO_CTRL5')
ck('HalfduplexYtoA',c['U204']['pins']['11']==c['U204']['pins']['14']=='485A')
ck('HalfduplexZtoB',c['U204']['pins']['12']==c['U204']['pins']['13']=='485B')
ck('CableTVSreturnsnotquietground',c['D205']['pins']['3']=='GND_CABLE')
ck('Interfacepowerreturnquietgroundseparate',c['J202']['pins']['2']=='PGND' and c['J202']['pins']['8']=='GND')
ck('NoMCUIOpowerfromcable5V',c['U204']['pins']['1']=='+3.3V')
ck('CorrectextendedbodyADUM4070footprint',c['U202']['footprint']=='Package_SO:SOIC-16W_7.5x12.8mm_P1.27mm')
ck('Threeunknownproductionfootprintsremainexplicit',{r for r,p in c.items() if not p.get('footprint')}=={'T201','L202','U203'})
ck('Transformerphysicalpinnumbersnotfabricated',set(c['T201']['pins'])=={'P1','PCT','P2','S1','SCT','S2'})
loads=[]
for ref,p in c.items():
 fid=p.get('footprint')
 if not fid:continue
 lib,name=fid.split(':',1);path=root/'C0Power.pretty' if lib=='C0Power' else pathlib.Path('/usr/share/kicad/footprints')/(lib+'.pretty')
 f=pcbnew.FootprintLoad(str(path),name);ck(ref+' footprintloads',f is not None)
 actual={p.GetNumber() for p in f.Pads() if p.GetNumber()};ck(ref+' allnetlistpinsexistinlandpattern',set(p['pins'])<=actual)
 loads.append(ref)
f=pcbnew.FootprintLoad(str(root/'C0Power.pretty'),'LT8631_FE20_16_EP2.74x3.86')
pads={p.GetNumber():p for p in f.Pads() if p.GetNumber()}
ck('LT8631absentpads2_4_17_19',not set(['2','4','17','19'])&set(pads))
ck('LT8631EP21size2_74x3_86',abs(pcbnew.ToMM(pads['21'].GetSize().x)-2.74)<1e-6 and abs(pcbnew.ToMM(pads['21'].GetSize().y)-3.86)<1e-6)
for n,p in pads.items():
 if n=='21':continue
 ck('LT8631lead'+n+'sizeandposition',abs(pcbnew.ToMM(p.GetSize().x)-1.05)<1e-6 and abs(pcbnew.ToMM(p.GetSize().y)-.45)<1e-6 and abs(abs(pcbnew.ToMM(p.GetPosition().x))-2.775)<1e-6)
ck('LT8631noincorrectgeneric20lead3Dmodel',len(list(f.Models()))==0)
refs=[]
for p in sorted((root/'references').glob('*.pdf')):
 raw=p.read_bytes();ck(p.name+'ispdfheader',raw[:4]==b'%PDF');refs.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
report={'scope':'Independentsource-and-libraryaudit only; NO ERC/DRC, noPCB, noactualhardwaretests','netlist_sha256':hashlib.sha256((root/'power_netlist.json').read_bytes()).hexdigest(),'checks':checks,'checks_passed':len(checks),'footprints_loaded':len(loads),'production_holds':{'T201':'Manufacturermechanicaldrawingandphysicalpinnumbersnotobtained','L202':'LQH3NPN470MM0exactmanufacturerlandpatternnotobtained','U203':'CurrentRD8_4exposedpaddrawingnotobtained;unverified2.29x3.0candidatewasretracted'},'additional_unverified':['newpassivecompleteMPNs/currentstock','bucktransientandclosedtubeheatderatingat~915mAengineeringenvelope','ADUM4070/transformer6.525Vloadandcurrentlimiting','ceramicDCbiasandloopstability','TVSsurge/ESDwithcable','assembledboard>=1kVwithstand','thermalcouplingtoPt1000','actual17mmcomponentenvelopeandrearboardlength'],'references':refs}
(root/'independent_power_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(len(checks),'checks passed;',len(loads),'footprints loaded;3 explicit productionfootprintHOLD')
