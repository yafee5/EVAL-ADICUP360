#!/usr/bin/env python3
"""Transcribe retained Rev A sheets 1/2; not a PCB/ERC/DRC result."""
from pathlib import Path
import csv, hashlib, json

ROOT = Path(__file__).resolve().parent
SRC = ROOT.parents[1] / 'references'
BOM = {r['reference']: r for r in csv.DictReader((SRC/'official_bom_reva_expanded.csv').open())}
C = {}

def add(ref, pins, page, *, value=None, notes='', recommended_footprint=None,
        no_connect=(), pin_names=None):
    b = BOM.get(ref, {})
    C[ref] = {
        'value': value if value is not None else b.get('value', ''),
        'mpn': b.get('manufacturer_part_number', ''),
        'manufacturer': b.get('manufacturer', ''),
        'package': b.get('package', ''),
        'original_package': b.get('package', ''),
        'original_mpn': b.get('manufacturer_part_number', ''),
        'recommended_footprint': recommended_footprint,
        'pins': {str(k): v for k, v in pins.items()},
        'no_connect_pins': [str(p) for p in no_connect],
        'source_page': page,
        'notes': notes,
    }
    if pin_names:
        C[ref]['pin_names'] = {str(k): v for k, v in pin_names.items()}

def passive(ref, a, b, page, **kw):
    prefix = ref[0]
    fp = 'Resistor_SMD:R_0805_2012Metric' if prefix == 'R' else 'Capacitor_SMD:C_0805_2012Metric'
    add(ref, {1:a, 2:b}, page, recommended_footprint=fp, **kw)

# Sheet 1: original named ADC/PWM/PGA/DAC nets and unchanged MCU pad mapping.
u8 = {
    1:'RESET_n', 2:'AD8253_A1', 3:'BM', 6:'+3.3V', 7:'VREG_1V8',
    8:'ADC0', 9:'ADC1', 10:'ADC2', 11:'ADC3', 14:'INT_REF', 15:'GND',
    16:'GND', 17:'+3.3V', 18:'VREG_1V8', 19:'DAC', 20:'INT_REF',
    22:'RTD_SENSE_LO', 23:'RTD_SENSE_HI', 24:'RTD_REF_HI_IEXC',
    25:'RTD_FORCE_HI', 26:'RTD_FORCE_LO_BIAS', 29:'AD8253_WR0_n',
    34:'RS485_DE_REn', 35:'UART_RX', 36:'UART_TX', 37:'+3.3V',
    38:'AD8253_A0', 40:'AD8253_A0', 41:'PWM0', 42:'PWM1', 44:'PWM2',
    46:'AD8253_WR1_n', 47:'SWCLK', 48:'SWDIO', 49:'GND'
}
u8nc = (4,5,12,13,21,27,28,30,31,32,33,39,43,45)
add('U8', u8, [1,2], no_connect=u8nc,
    recommended_footprint='Package_DFN_QFN:QFN-48-1EP_7x7mm_P0.5mm_EP5.1x5.1mm',
    notes='Pin 49 is exposed pad, must be soldered to GND. P1.0 pin38 and P1.2 pin40 remain physically tied for PWM sync. Former LCD/encoder pins are intentionally NC, firmware input pullups; no interface footprints. XTALI/XTALO NC, internal 16MHz clock.')

passive('R17', '+3.3V', 'BM', 1,
    notes='47k BOOT/BM pull-UP. Earlier verbal description as a pulldown was wrong; source drawing and MCU pinmap confirm pullup. Not a buzzer feature.')
passive('R13', 'RTD_REF_HI_IEXC', 'RTD_FORCE_HI', 1, value='4.99k',
    notes='Explicit C0 exception to Rev A 1.50k. Require 0.01%, <=2ppm/K; full qualified procurement MPN not yet selected. With 200uA gives nominal 0.998V reference. Preserve Kelvin routing.')
C['R13']['mpn'] = None
C['R13']['procurement_status'] = 'HOLD: qualified full MPN required'
C['R13']['tolerance_percent'] = 0.01
C['R13']['tcr_ppm_per_K_max'] = 2
passive('R11', '+3.3V', 'RTD_FORCE_LO_BIAS', 1)
passive('R12', 'RTD_FORCE_LO_BIAS', 'GND', 1)
for r, n in [('C38','RTD_FORCE_HI'),('C39','RTD_REF_HI_IEXC'),
             ('C37','RTD_SENSE_HI'),('C41','RTD_SENSE_LO'),('C36','RTD_FORCE_LO_BIAS')]:
    passive(r, n, 'GND', 1)
add('J3', {1:'RTD_FORCE_HI',2:'RTD_SENSE_HI',3:'RTD_SENSE_LO',4:'RTD_FORCE_LO_BIAS'},1,
    value='PT1000_4WIRE_LANDS', recommended_footprint='C0_Custom:RTD_4wire_lands_TBD',
    notes='Original screw terminal is replaced by four separately labelled solder lands; DO NOT join force/sense traces before sensor. Original physical OSTTC042162 not fitted; new lands not yet laid out. Pin4 is bias node, NOT GND.')
C['J3']['mpn'] = 'PCB feature; no purchased connector'
for ref in ('C1','C43','C51'):
    passive(ref, '+3.3V', 'GND', 1,
        notes='Original global 3.3V decoupling retained; no UI or old RS485 signal connection retained. Final local placement may be reassigned to MCU rail.')

# Minimal SWD lands replace old J4 entirely; use new reference so it cannot be
# confused with the original twenty pin connector numbering.
add('J401', {1:'+3.3V',2:'SWDIO',3:'SWCLK',4:'RESET_n',5:'GND'},1,
    value='SWD_5PAD', recommended_footprint='C0_Custom:SWD_5pad_TBD',
    notes='New five-pad SWD group, NOT original J4 pin order. VTref is reference input for debugger, not a 3.3V supply input. Pins located only on electrode-isolated side.')
C['J401']['mpn'] = 'PCB feature; no purchased connector'

# Sheet 2: retained ADP1613 5V -> +/-15V inverter/boost and original EMI filters.
add('U5', {1:'CORE_COMP',2:'CORE_FB',3:'VCC',4:'PGND',5:'CORE_SW',6:'VCC',7:'PGND',8:'CORE_SS'},2,
    recommended_footprint='Package_SO:MSOP-8_3x3mm_P0.65mm',
    pin_names={1:'COMP',2:'FB',3:'EN',4:'GND',5:'SW',6:'VIN',7:'FREQ',8:'SS'},
    notes='VCC must be regulated isolated nominal 5V (recommended input2.5..5.5V), never 12..30V. FREQ grounded as original 650kHz mode.')
add('L1', {1:'VCC',2:'CORE_SW'},2,
    recommended_footprint='Inductor_SMD:L_TDK_SLF6045',
    notes='Original 22uH SLF6045T-220M1R1-3PF retained, no speculative miniature substitute.')
add('D2', {1:'CORE_POS_RAW',2:'CORE_SW'},2,
    recommended_footprint='Diode_SMD:D_SOD-123',
    pin_names={1:'K',2:'A'}, notes='1N4148W, cathode at raw positive output.')
add('D1', {1:'CORE_NEG_RAW',2:'PGND',3:'CORE_PUMP'},2,
    recommended_footprint='Package_TO_SOT_SMD:SOT-23',
    pin_names={1:'A',2:'K',3:'COM'},
    notes='BAT54S series dual: A1->COM3->K2; A1 at negative output, K2 PGND. Source drawing top diode points toward flying-cap common; do not reverse both diodes.')
passive('C14','CORE_SW','CORE_PUMP',2)
for ref in ('C9','C10','C11','C12'):
    passive(ref,'VCC','PGND',2,
        notes='Original isolated 5V/VCC decoupling retained; input source replaced, capacitance/voltage rating not shrunk.')
for ref in ('C20','C21'):
    passive(ref,'CORE_NEG_RAW','PGND',2)
for ref in ('C22','C23'):
    passive(ref,'CORE_POS_RAW','PGND',2)
passive('R4','CORE_POS_RAW','CORE_FB',2)
passive('R3','CORE_FB','PGND',2)
passive('R1','CORE_COMP','CORE_RC_COMP',2)
passive('C24','CORE_RC_COMP','PGND',2)
passive('C16','CORE_COMP','PGND',2)
passive('C13','CORE_SS','PGND',2)
for ref,src,dst in [('L3','CORE_NEG_RAW','-15V'),('L4','CORE_POS_RAW','+15V'),('L5','+3.3V_PREFILTER','+3.3V')]:
    add(ref,{1:src,2:dst,3:'PGND',4:'GND',5:'GND',6:'GND'},2,
        value='BNX025H01', recommended_footprint='Filter:Filter_Murata_BNX025_RENUMBER_CG_4_5_6',
        pin_names={1:'B',2:'CB',3:'PSG',4:'CG',5:'CG',6:'CG'},
        notes='Original PADS uses six pad numbers; KiCad standard footprint repeats number4 on all three CG pads. Explicit custom renumbering or verified 4-logical-pin mapping required, not a drop-in six-pin footprint. Standard pad envelope about17.5x12.5mm: orient long direction along PCB length. PGND and GND retained separately; do not join by guessed global labels. Internal ground-path behavior requires manufacturer datasheet verification.')
passive('C29','-15V','GND',2)
passive('C30','+15V','GND',2)
for ref in ('C25','C26'):
    passive(ref,'+3.3V_PREFILTER','PGND',2,
        notes='Kept as output/bulk capacitors of replacement isolated-side 3.3V supply before L5. Original ADP2300 switched input path no longer present.')
for ref in ('C31','C81'):
    passive(ref,'+3.3V','GND',2)

# New front-board LDO; source selection verified by power-design agent using
# ADP7118 official ordering guide p21/23 and UJ-5 pin description.
add('U401',{1:'VCC',2:'PGND',3:'VCC',4:'+3.3V_PREFILTER',5:'+3.3V_PREFILTER'},2,
    value='ADP7118_3V3', recommended_footprint='Package_TO_SOT_SMD:TSOT-23-5',
    pin_names={1:'VIN',2:'GND',3:'EN',4:'SENSE',5:'VOUT'},
    notes='New isolated-side 5V->3.3V 200mA low-noise LDO. Place at rear end of analog/core board adjacent to L5; SENSE uses short Kelvin sense at C402 before L5, never after L5. Datasheet recommends nominal2.2uF input/output; minimum effective1.5uF including tolerance and DC bias over full conditions, ESR0.001..0.3ohm. Datasheet qualified MPN, actual stock not checked.')
C['U401'].update(mpn='ADP7118AUJZ-3.3-R7',manufacturer='Analog Devices',
    package='TSOT-5',original_package=None,original_mpn=None,
    procurement_status='Orderable MPN verified in manufacturer datasheet; stock unverified',
    source_page='New C0 power design; ADP7118 datasheet pin table/ordering guide')
for ref,rail in [('C401','VCC'),('C402','+3.3V_PREFILTER')]:
    passive(ref,rail,'PGND','New C0 power design',value='4.7u',
        notes='New immediately local LDO capacitor. Original CN0359 4.7u25V0805 part reused; effective capacitance at5V/3.3V must exceed1.5uF manufacturer minimum across tolerance, DC bias and temperature before release; design target>=2.2uF effective.')
    C[ref].update(mpn='GRM21BR61E475KA12L',manufacturer='Murata',package='0805',original_package=None,original_mpn=None)

# DAC low-pass, +gain stage, unity negative stage exactly as Rev A.
add('U9',{1:'+10V',2:'CORE_EXC_FB',3:'CORE_DAC_LPF',4:'-15V',5:'CORE_EXC_BIAS',6:'CORE_EXC_INV_FB',7:'-10V',8:'+15V'},2,
    recommended_footprint='Package_SO:SOIC-8_3.9x4.9mm_P1.27mm',
    pin_names={1:'OUTA',2:'INA-',3:'INA+',4:'V-',5:'INB+',6:'INB-',7:'OUTB',8:'V+'},
    notes='Original ADA4077-2ARZ SOIC retained. Nominal net names +/-10V are original excitation nets; actual voltage is DAC-programmable and not a fixed10V output. Same-model MSOP may be chosen only with a verified orderable MPN and new footprint review.')
passive('R16','DAC','CORE_DAC_LPF',2)
passive('C49','CORE_DAC_LPF','GND',2)
passive('R15','CORE_EXC_FB','GND',2)
passive('R14','+10V','CORE_EXC_FB',2)
passive('C45','+10V','CORE_EXC_FB',2)
passive('R24','+10V','CORE_EXC_INV_FB',2)
passive('R27','-10V','CORE_EXC_INV_FB',2)
passive('C68','-10V','CORE_EXC_INV_FB',2)
passive('R22','CORE_EXC_BIAS','GND',2)
passive('C59','CORE_EXC_BIAS','GND',2)
passive('C58','+15V','GND',2)
passive('C46','-15V','GND',2)

# Midpoint for all four ADA4528 attenuation stages.
passive('R49','+3.3V','VMID',2)
passive('R50','VMID','GND',2)
passive('C100','VMID','GND',2)

# MCU power/reference decoupling, all original values kept.
passive('C42','INT_REF','GND',2)
for ref in ('C44','C56'):
    passive(ref,'VREG_1V8','GND',2,
        notes='Internal AVDD_REG and DVDD_REG common 1.8V node; must NOT connect to 3.3V.')
for ref in ('C48','C40','C57'):
    passive(ref,'+3.3V','GND',2)

# Types are modeled by actual analog/digital function, not made all-passive to
# suppress ERC. The two internal-regulator pins are true power outputs and their
# intentional tie is a named review item for final KiCad ERC configuration.
u8_names = {
    1:'RESET_n',2:'P2.1',3:'P2.2/BM',4:'XTALO',5:'XTALI',6:'IOVDD',
    7:'DVDD_REG',8:'AIN0',9:'AIN1',10:'AIN2',11:'AIN3',12:'AIN4/IEXC',
    13:'GND_SW',14:'VREF+',15:'VREF-',16:'AGND',17:'AVDD',18:'AVDD_REG',
    19:'DAC',20:'INT_REF',21:'IREF',22:'AIN5/IEXC',23:'AIN6/IEXC',
    24:'AIN7/IEXC/EXTREF2+',25:'AIN8/EXTREF2-',26:'AIN9',27:'AIN10',
    28:'AIN11/VBIAS1',29:'P0.0',30:'P0.1',31:'P0.2',32:'P0.3',33:'P0.4',
    34:'P0.5',35:'P0.6/UART_RX',36:'P0.7/UART_TX',37:'IOVDD',
    38:'P1.0/PWMSYNC',39:'P1.1',40:'P1.2',41:'P1.3/PWM1',
    42:'P1.4/PWM2',43:'P1.5',44:'P1.6/PWM4',45:'P1.7',46:'P2.0',
    47:'SWCLK',48:'SWDIO',49:'DGND_EP'}
u8_types = {k:'input' for k in u8_names}
for k in (2,29,34,36,40,41,42,44,46): u8_types[k]='output'
for k in (6,15,16,17,37,49): u8_types[k]='power_in'
for k in (7,18,20): u8_types[k]='power_out'
for k in (12,22,23,24,28,30,31,32,33,39,43,45,48): u8_types[k]='bidirectional'
u8_types.update({4:'output',13:'open_collector',19:'output'})
C['U8']['pin_names']={str(k):v for k,v in u8_names.items()}
C['U8']['pin_types']={str(k):v for k,v in u8_types.items()}
C['U5']['pin_types']={str(k):v for k,v in {1:'output',2:'input',3:'input',4:'power_in',5:'output',6:'power_in',7:'input',8:'input'}.items()}
C['U9']['pin_types']={str(k):v for k,v in {1:'output',2:'input',3:'input',4:'power_in',5:'input',6:'input',7:'output',8:'power_in'}.items()}
C['U401']['pin_types']={str(k):v for k,v in {1:'power_in',2:'power_in',3:'input',4:'input',5:'power_out'}.items()}
for ref, comp in C.items():
    comp.setdefault('pin_names',{pin:('A' if ref[0] in 'RC' and pin=='1' else 'B' if ref[0] in 'RC' and pin=='2' else pin) for pin in comp['pins']})
    comp.setdefault('pin_types',{pin:'passive' for pin in comp['pins']})

DELETE = {}
def delete(refs, category, reason):
    for ref in refs.split():
        b = BOM[ref]
        DELETE[ref] = dict(reference=ref, original_value=b['value'], original_package=b['package'],
            original_mpn=b['manufacturer_part_number'], original_population=b['population'],
            category=category, reason=reason, c0_action='DELETE FROM SCHEMATIC AND PCB; no DNP footprint')
delete('U1 U6 R6 R7 R8 R9 C27 C28 C35 C33 C34','LCD/backlight','Only serves removed display/backlight function; U6 is AD8592 backlight amplifier, not RS485.')
delete('S1','Encoder/button','Remove entire encoder and button assembly; former MCU pins left NC/input pullup.')
delete('U2 Q1 R18 D4','Buzzer','Only serves buzzer; R17 stays because it also supplies required BM boot pullup.')
delete('U7 R10 J2','Old nonisolated RS485','U7 ADM3075E, its bias resistor and old terminal replaced by wholly isolated cable-side communication design.')
delete('U4 L2 D3 C17 R2 R5 C18 C19','Old ADP2300 branch','Original buck and dedicated bootstrap/feedback/input branch replaced by new 12..30V fully isolated power system; C25/C26/L5/C31/C81 remain for output filtering.')
delete('J1 U3 C15','Old external DC input','Old DC barrel jack, its reverse-PMOS and pre-protection capacitor replaced by new cable input/protection. C9 remains isolated 5V bulk.')
delete('J4','Old evaluation debug connector','Old20-pin header removed; new five-pad SWD-only group J401 added with own numbering.')
delete('Y1 C65 C66','Unpopulated crystal option','Original NP 32.768kHz oscillator option removed completely; firmware uses internal clock.')
delete('C32','Unpopulated LCD option','Original NP display capacitor removed with display; no empty land.')
delete('X1 X2 X3 X4','Evaluation ground mounting pads','Old PAD3MM grounding/mounting features do not fit new tube PCB and have no C0 external function.')

out = {
    'title':'C0 retained MCU/RTD/excitation/ADP1613 original Rev A netlist transcription',
    'revision':'C0 working electrical reconstruction 2026-10-22',
    'source_pdf':str(SRC/'eval-cn0359-eb1z-padsschematic-reva.pdf'),
    'source_pdf_sha256':hashlib.sha256((SRC/'eval-cn0359-eb1z-padsschematic-reva.pdf').read_bytes()).hexdigest(),
    'source_original_bom':str(SRC/'official_bom_reva_expanded.csv'),
    'verification':'Visual review of rendered original sheets1/2 + original BOM + prior verified MCU pinmap; NOT independently reviewed native CAD and NOT an ERC/DRC report.',
    'components':C,
    'external_nets':{
        'isolated_power_input':{'VCC':'Regulated isolated nominal5V;2.5..5.5V ADP1613 operating range','PGND':'Return on converter side of EMI filters','+3.3V_PREFILTER':'Replacement 3.3V LDO output, before L5'},
        'communication':{'UART_TX':'MCU pin36','UART_RX':'MCU pin35','RS485_DE_REn':'MCU pin34; tied DE and active-low RE as original firmware'},
        'afe': ['ADC0','ADC1','ADC2','ADC3','AD8253_A0','AD8253_A1','AD8253_WR0_n','AD8253_WR1_n','PWM0','PWM1','PWM2','+10V','-10V','+15V','-15V','+3.3V','GND','VMID']},
    'do_not_merge_nets':[['PGND','GND'],['VREG_1V8','+3.3V'],['RTD_FORCE_LO_BIAS','GND'],['RTD_FORCE_HI','RTD_SENSE_HI'],['RTD_SENSE_LO','RTD_FORCE_LO_BIAS']],
    'ownership':'U11/U15/U17/U18 including their sheet2 power and digital pins are owned by separate AFE transcription, not missing components.',
    'todos':[
        'R13 qualified full MPN at0.01% <=2ppm/K and availability.',
        'Native schematic and PCB reconstruction, cross-review and ERC/DRC not performed by this file.',
        'J3 RTD wire lands and J401 SWD pad actual footprint coordinates require PCB layout.',
        'BNX025 manufacturer drawing and internal ground topology; standard KiCad duplicateCG-pad number mapping.',
        'U8 EP5.1x5.1 footprint dimensions must match ADuCM360 manufacturer package drawing before production.',
        'No component shrink is asserted; original passive0805 dimensions retained for precision/DC-bias safety until qualified replacements reviewed.',
    ],
    'deletion_count':len(DELETE), 'retained_component_count':len(C),
}
(ROOT/'core_netlist.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'deletion_list.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=next(iter(DELETE.values())).keys());w.writeheader();w.writerows(DELETE.values())
(ROOT/'deletion_list.json').write_text(json.dumps(list(DELETE.values()),ensure_ascii=False,indent=2)+'\n')
print(f'Retained/new components: {len(C)}; deleted original refs: {len(DELETE)}')
