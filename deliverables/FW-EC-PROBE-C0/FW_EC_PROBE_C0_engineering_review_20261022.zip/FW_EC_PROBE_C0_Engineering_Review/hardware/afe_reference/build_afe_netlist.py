#!/usr/bin/env python3
"""Explicit transcription of CN0359 Rev A sheet 3, visually checked against PDF.

This is an electrical transcription, not a claim of a checked PCB or manufacture.
No package shrink has been silently performed. Symmetric R/C pad numbering is
arbitrary; IC/diode/connector pin numbering is physical package numbering.
"""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT.parents[1] / 'references'
pdf = SRC / 'eval-cn0359-eb1z-padsschematic-reva.pdf'
bom = {r['reference']: r for r in csv.DictReader((SRC / 'official_bom_reva_expanded.csv').open())}
C = {}

def part(ref, pins, *, value=None, names=None, notes=None, source_page=3):
    original = bom[ref]
    C[ref] = {
        'reference': ref,
        'value': value or original['value'] or original['manufacturer_part_number'],
        'mpn': original['manufacturer_part_number'],
        'original_mpn': original['manufacturer_part_number'],
        'manufacturer': original['manufacturer'],
        'package': original['package'],
        'pins': {str(p): n for p, n in pins.items()},
        'source_page': source_page,
        'notes': notes or [],
    }
    if names:
        C[ref]['pin_names'] = {str(p): n for p, n in names.items()}
    C[ref]['unconnected_pins'] = [str(p) for p, n in pins.items() if n is None]
    return C[ref]

def two(ref, a, b, **kw):
    return part(ref, {1: a, 2: b}, **kw)

def amp(ref, inv, noninv, out, *, null_pins=False):
    return part(ref,
                {1: None, 2: inv, 3: noninv, 4: '-15V', 5: None, 6: out, 7: '+15V', 8: None},
                names={1: 'NULL' if null_pins else 'NC', 2: '-IN', 3: '+IN', 4: 'V-',
                       5: 'NULL' if null_pins else 'NC', 6: 'OUT', 7: 'V+', 8: 'NC'},
                notes=['Pins 1/5 are unconnected offset-null terminals, not supply pins.'] if null_pins else [])

# Four-electrode connection and polarity switch.
part('J5', {1: 'AFE_FORCE_P', 2: 'AFE_SENSE_P', 3: 'AFE_SENSE_M', 4: 'AFE_FORCE_M', 5: 'GND'},
     names={1:'FORCE+',2:'SENSE+',3:'SENSE-',4:'FORCE-',5:'SHIELD_REFERENCE'},
     notes=['Original connector electrical pinout only; C0 requires a smaller connector/pads.',
            'Original J5.5 is isolated AFE GND. Do not bond to cable shield/housing across isolation barrier without an explicit EMC design.'])
C['J5'].update(value='EC_4E_PLUS_GND_WIRE_LANDS',mpn='PCB feature; no purchased connector',
               manufacturer=None,package='5 labelled wire solder lands',
               footprint='C0Frontend:EC5_WIRE',is_pcb_feature=True,
               procurement_status='PCB_FEATURE_NOT_PURCHASED')
part('U11', {1:'AFE_EXC_SW', 2:'+10V', 3:'GND', 4:'+15V', 5:None, 6:'PWM0', 7:'-15V', 8:'-10V'},
     names={1:'D',2:'SA',3:'GND',4:'VDD',5:'NC',6:'IN',7:'VSS',8:'SB'},
     source_page=[2,3], notes=['MSOP BRMZ pin 5 is NC, not the LFCSP EN pin.'])
two('R23', 'AFE_EXC_SW', 'AFE_FORCE_P')
part('D5', {1:'-10V',2:'+10V',3:'AFE_FORCE_P'},
     names={1:'A1',2:'K2',3:'K1_A2'}, notes=['BAT54S series diode common midpoint pin 3; clamp FORCE+ to excitation rails.'])
two('C54', '+10V', 'GND')
two('C67', '-10V', 'GND')

# Negative sense buffer (no external connection on its feedback summing node).
amp('U14', 'AFE_SENSEBUF_FB', 'AFE_SENSE_M', 'AFE_SENSEBUF_OUT')
two('R35', 'AFE_SENSEBUF_FB', 'AFE_SENSEBUF_OUT')
two('C78', 'AFE_SENSEBUF_FB', 'AFE_SENSEBUF_OUT')

# VMID buffers. 470 pF remains on each buffered REF output as in Rev A.
part('U22', {1:'AFE_I_REF',2:'AFE_I_REF',3:'VMID',4:'GND',5:'VMID',6:'AFE_V_REF',7:'AFE_V_REF',8:'+3.3V'},
     names={1:'OUT_A',2:'-IN_A',3:'+IN_A',4:'V-',5:'+IN_B',6:'-IN_B',7:'OUT_B',8:'V+'})
two('C92', 'AFE_I_REF', 'GND')
two('C79', 'AFE_V_REF', 'GND')
two('C99', 'VMID', 'GND')
two('C8', '+3.3V', 'GND')

def inamp(ref, inv, noninv, out, refnet, wr):
    part(ref, {1:inv,2:'GND',3:'-15V',4:'AD8253_A0',5:'AD8253_A1',6:wr,7:out,8:'+15V',9:refnet,10:noninv},
         names={1:'-IN',2:'DGND',3:'-VS',4:'A0',5:'A1',6:'WR',7:'OUT',8:'+VS',9:'REF',10:'+IN'},
         source_page=[2,3])

inamp('U15', 'AFE_SENSE_P', 'AFE_SENSEBUF_OUT', 'AFE_V_GAIN_OUT', 'AFE_V_REF', 'AD8253_WR0_n')
two('R33', 'AFE_V_GAIN_OUT', 'AFE_V_DEMUX')

# Current TIA, including non-inverting input impedance balancing filter.
amp('U19', 'AFE_FORCE_M', 'AFE_TIA_PLUS', 'AFE_TIA_OUT', null_pins=True)
two('R47', 'AFE_FORCE_M', 'AFE_TIA_OUT', value='1.00k')
C['R47'].update(mpn=None, tolerance='0.01%', tcr_max_ppm_per_C=2,
                 procurement_status='HOLD: select and verify full precision-resistor MPN')
C['R47']['notes'] += ['C0 precision upgrade; resistance and topology unchanged. Original MPN does not meet requested grade.']
two('C95', 'AFE_FORCE_M', 'AFE_TIA_OUT')
two('R40', 'AFE_TIA_PLUS', 'GND')
two('C83', 'AFE_TIA_PLUS', 'GND')
inamp('U18', 'GND', 'AFE_TIA_OUT', 'AFE_I_GAIN_OUT', 'AFE_I_REF', 'AD8253_WR1_n')
two('R45', 'AFE_I_GAIN_OUT', 'AFE_I_DEMUX')

# Synchronous quad SPST sample/hold switch, TSSOP pin map.
part('U17', {1:'PWM2',2:'AFE_V_NEG_SW',3:'AFE_V_DEMUX',4:'-15V',5:'GND',
             6:'AFE_I_DEMUX',7:'AFE_I_POS_SW',8:'PWM1',9:'PWM2',10:'AFE_I_NEG_SW',
             11:'AFE_I_DEMUX',12:None,13:'+15V',14:'AFE_V_DEMUX',15:'AFE_V_POS_SW',16:'PWM1'},
     names={1:'IN1',2:'D1',3:'S1',4:'VSS',5:'GND',6:'S4',7:'D4',8:'IN4',9:'IN3',10:'D3',11:'S3',12:'NC',13:'VDD',14:'S2',15:'D2',16:'IN2'},
     source_page=[2,3])

# ADC3 voltage positive, ADC2 voltage negative, ADC1 current positive, ADC0 current negative.
channels = [
    dict(tag='V_POS', adc='ADC3', holdR='R34', holdC='C50', buf='U10', bufR='R25',bufC='C60',
         dual='U12', invpin=6, pluspin=5, outpin=7, rin='R19',rf='R20',cf='C55',rb='R26',cb='C62',ro='R21',co='C52'),
    dict(tag='V_NEG', adc='ADC2', holdR='R36', holdC='C73', buf='U13', bufR='R30',bufC='C76',
         dual='U12', invpin=2, pluspin=3, outpin=1, rin='R29',rf='R31',cf='C75',rb='R28',cb='C74',ro='R32',co='C63'),
    dict(tag='I_POS', adc='ADC1', holdR='R41', holdC='C84', buf='U16', bufR='R43',bufC='C87',
         dual='U20', invpin=6, pluspin=5, outpin=7, rin='R37',rf='R38',cf='C85',rb='R44',cb='C89',ro='R39',co='C72'),
    dict(tag='I_NEG', adc='ADC0', holdR='R42', holdC='C93', buf='U21', bufR='R51',bufC='C97',
         dual='U20', invpin=2, pluspin=3, outpin=1, rin='R48',rf='R52',cf='C96',rb='R46',cb='C94',ro='R53',co='C64'),
]
dualpins = {u:{4:'GND',8:'+3.3V'} for u in ('U12','U20')}
for ch in channels:
    n = lambda suffix: 'AFE_' + ch['tag'] + '_' + suffix
    two(ch['holdR'], n('SW'), n('HOLD'))
    two(ch['holdC'], n('HOLD'), 'GND')
    amp(ch['buf'], n('BUF_FB'), n('HOLD'), n('BUF_OUT'))
    two(ch['bufR'], n('BUF_FB'), n('BUF_OUT'))
    two(ch['bufC'], n('BUF_FB'), n('BUF_OUT'))
    two(ch['rin'], n('BUF_OUT'), n('ATT_INV'))
    # Crucial: DC resistor senses after 24 ohm; AC capacitor senses before it.
    two(ch['rf'], n('ATT_INV'), ch['adc'])
    two(ch['cf'], n('ATT_INV'), n('ATT_OUT'),
        notes=['820p returns to op-amp output BEFORE 24 ohm. 1.2k returns from ADC AFTER 24 ohm; these are not parallel components.'])
    two(ch['rb'], 'VMID', n('ATT_PLUS'))
    two(ch['cb'], n('ATT_PLUS'), 'GND')
    two(ch['ro'], n('ATT_OUT'), ch['adc'])
    two(ch['co'], ch['adc'], 'GND')
    dualpins[ch['dual']].update({ch['invpin']:n('ATT_INV'),ch['pluspin']:n('ATT_PLUS'),ch['outpin']:n('ATT_OUT')})
    for r in (ch['rin'], ch['rf']):
        C[r].update(mpn=None,tolerance='0.05%',tcr_max_ppm_per_C=5,
                    procurement_status='HOLD: verify full discrete thin-film MPN; no LT5400')
        C[r]['notes'] += ['C0 discrete thin-film precision upgrade; original resistance preserved. Original MPN does not meet requested grade.']
for u,pins in dualpins.items():
    part(u,pins,names={1:'OUT_A',2:'-IN_A',3:'+IN_A',4:'V-',5:'+IN_B',6:'-IN_B',7:'OUT_B',8:'V+'})
two('C71', '+3.3V', 'GND')
two('C91', '+3.3V', 'GND')

# All original sheet-3 +/-15 V bypass capacitors, no deletions.
for ref in 'C98 C86 C77 C7 C61 C53 C4 C88 C3'.split():
    two(ref, '+15V', 'GND', notes=['Original sheet-3 shared bypass array; exact placement must provide local IC decoupling.'])
for ref in 'C70 C80 C6 C5 C47 C82 C2 C69 C90'.split():
    two(ref, '-15V', 'GND', notes=['Original sheet-3 shared bypass array; exact placement must provide local IC decoupling.'])

# KiCad electrical pin types are actual functions, not all-passive ERC masking.
for ref,c in C.items():
    types = {p:'passive' for p in c['pins']}
    names = c.setdefault('pin_names', {})
    if ref.startswith(('R','C')):
        names.update({'1':'1','2':'2'})
    if ref in ('U10','U13','U14','U16','U19','U21'):
        types = {'1':'no_connect','2':'input','3':'input','4':'power_in',
                 '5':'no_connect','6':'output','7':'power_in','8':'no_connect'}
        if ref == 'U19':
            # NULL pins are adjustment terminals, not internally disconnected NC.
            types['1'] = types['5'] = 'passive'
    elif ref in ('U12','U20','U22'):
        types = {'1':'output','2':'input','3':'input','4':'power_in',
                 '5':'input','6':'input','7':'output','8':'power_in'}
    elif ref in ('U15','U18'):
        types = {'1':'input','2':'power_in','3':'power_in','4':'input','5':'input',
                 '6':'input','7':'output','8':'power_in','9':'input','10':'input'}
    elif ref == 'U11':
        types = {'1':'passive','2':'passive','3':'power_in','4':'power_in',
                 '5':'no_connect','6':'input','7':'power_in','8':'passive'}
    elif ref == 'U17':
        types.update({str(p):'input' for p in (1,8,9,16)})
        types.update({str(p):'power_in' for p in (4,5,13)})
        types['12'] = 'no_connect'
    c['pin_types'] = types
    if c['package'] == '0805':
        c['footprint'] = ('Resistor_SMD:R_0805_2012Metric' if ref.startswith('R')
                          else 'Capacitor_SMD:C_0805_2012Metric')
    elif c['package'] == 'SOIC127P600X175-8M':
        c['footprint'] = 'Package_SO:SOIC-8_3.9x4.9mm_P1.27mm'
    elif c['package'] == 'SOP65P490X110-8M':
        c['footprint'] = 'Package_SO:MSOP-8_3x3mm_P0.65mm'
    elif c['package'] == 'SOP50P490X95-10M':
        c['footprint'] = 'Package_SO:MSOP-10_3x3mm_P0.5mm'
    elif c['package'] == 'SOP65P640X120-16M':
        c['footprint'] = 'Package_SO:TSSOP-16_4.4x5mm_P0.65mm'
    elif ref == 'D5':
        c['footprint'] = 'Package_TO_SOT_SMD:SOT-23'
    else:
        c['footprint'] = None
    if c['footprint']:
        library,footprint=c['footprint'].split(':')
        assert (Path('/usr/share/kicad/footprints')/(library+'.pretty')/(footprint+'.kicad_mod')).is_file()
    assert set(c['pin_types']) == set(c['pins'])
    assert set(c['pin_names']) == set(c['pins'])

allnets = {}
for ref, c in C.items():
    for pin, net in c['pins'].items():
        if net is not None:
            allnets.setdefault(net, []).append({'ref':ref,'pin':pin})

external = ['GND','+3.3V','+15V','-15V','+10V','-10V','VMID','PWM0','PWM1','PWM2',
            'AD8253_A0','AD8253_A1','AD8253_WR0_n','AD8253_WR1_n','ADC0','ADC1','ADC2','ADC3']
report = {
    'design':'CN0359 Rev A AFE transcription for FW_EC_PROBE_C0',
    'status':'ELECTRICAL_TRANSCRIPTION_VISUALLY_REVIEWED_NOT_PCB_RELEASE',
    'source_pdf':pdf.name,
    'source_pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
    'source_version':'Rev A; page 3 of 3 plus cross-page power/control units on page 2',
    'component_count':len(C),
    'connected_net_count':len(allnets),
    'external_nets':external,
    'nc_representation':'null; unconnected_pins lists physical pins intentionally left open. Never create a net named NC.',
    'symmetric_passive_numbering':'Resistor/capacitor pin 1/2 assignment is arbitrary and electrically equivalent; not a mapping to original PADS pad orientation.',
    'components':dict(sorted(C.items(),key=lambda kv:(kv[0][0],int(kv[0][1:])))),
    'nets':dict(sorted(allnets.items())),
    'review_findings':[
        'Each 1.2k attenuation feedback resistor senses ADC after its 24 ohm output resistor; each 820p feedback capacitor senses before that resistor.',
        'J5.2 connects U15.1 (-IN), while J5.3 is buffered by U14 into U15.10 (+IN). Preserve sign convention.',
        'U15 REF is U22-B output pin7; U18 REF is U22-A output pin1. Both buffer VMID separately.',
        'TIA R47 and C95 return FORCE- to U19.6. R40/C83 balance the non-inverting input to GND.',
        'No +/-15 V, VMID, hold capacitor, sense buffer, current or voltage gain stage was deleted.',
        'J5.5 isolated AFE GND is not the cable-side shield/housing connection in C0.',
        'Original 0805 footprints and values retained in this electrical transcription, not a declaration that those footprints fit a 17mm layout.',
    ],
    'unfinished':[
        'Complete MPN verification for R47 and eight attenuation resistors.',
        'Second-person independent comparison of the transcription with the original PDF.',
        'Native schematic/PCB integration, ERC, DRC, routing and manufactured testing.',
        'Placement mapping of the +/-15V bypass array to individual ICs.',
    ],
}
(ROOT/'afe_netlist.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'afe_pins.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['Reference','Value','Physical_Pin','Pin_Name','Net','Original_MPN','C0_MPN_Status'])
    for ref,c in report['components'].items():
        for pin,net in sorted(c['pins'].items(),key=lambda kv:int(kv[0])):
            w.writerow([ref,c['value'],pin,c.get('pin_names',{}).get(pin,''),net or 'UNCONNECTED',c['original_mpn'],c.get('procurement_status','original MPN retained')])
print(json.dumps({'components':len(C),'nets':len(allnets),'pins':sum(len(c['pins']) for c in C.values()),'isolated_nets':[n for n,pins in allnets.items() if len(pins)<2]},ensure_ascii=False))
