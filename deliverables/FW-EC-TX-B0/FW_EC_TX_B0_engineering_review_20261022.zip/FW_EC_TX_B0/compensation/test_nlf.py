#!/usr/bin/env python3
"""Host validation of C99 table interpolation/integrity, not ISO conformance.

All factor fixtures are synthetic analytic functions explicitly unrelated to
ISO's coefficients. No synthetic table is shipped as a production profile.
"""
import ctypes as C
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import tempfile
import zlib
from make_nlf_profile import build as build_profile_json

ROOT = Path(__file__).resolve().parent
Float36 = C.c_float * 36
U8_32 = C.c_uint8 * 32
class Profile(C.Structure):
    _fields_ = [('factor25',Float36),('source_id',C.c_uint32),('source_sha256',U8_32),
                ('table_crc32',C.c_uint32),('flags_verified',C.c_uint32)]

INVALID=1; TEMP=2; COND=4; UNVERIFIED=8; CRC=16; BADTABLE=32
MAGIC=0x4e4c4631

def run():
    with tempfile.TemporaryDirectory(prefix='nlf-test-') as tmp:
        libpath=Path(tmp)/'libnlf.so'
        subprocess.run(['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic',
                        '-O2','-fPIC','-shared',str(ROOT/'nlf.c'),'-lm','-o',str(libpath)],check=True)
        lib=C.CDLL(str(libpath))
        lib.nlf_factors_crc32.argtypes=[C.POINTER(C.c_float)]
        lib.nlf_factors_crc32.restype=C.c_uint32
        lib.nlf_compensate_with_profile.argtypes=[C.POINTER(Profile),C.c_float,C.c_float,C.POINTER(C.c_float),C.POINTER(C.c_uint32)]
        lib.nlf_compensate_with_profile.restype=C.c_bool
        def profile(fn):
            p=Profile()
            for i in range(36):p.factor25[i]=fn(i)
            p.source_id=0x53594e54 # SYNT: synthetic tests only, not production.
            p.source_sha256[:]=hashlib.sha256(b'SYNTHETIC-NOT-ISO').digest()
            p.table_crc32=zlib.crc32(struct.pack('<36f',*p.factor25))
            p.flags_verified=MAGIC
            assert lib.nlf_factors_crc32(p.factor25)==p.table_crc32
            return p
        def call(p,k,t):
            out=C.c_float(123.0);flags=C.c_uint32(0xffffffff)
            ok=lib.nlf_compensate_with_profile(C.byref(p) if p is not None else None,k,t,C.byref(out),C.byref(flags))
            return bool(ok),float(out.value),int(flags.value)
        count=0
        def check(cond):
            nonlocal count
            count+=1
            assert cond, f'check {count}'
        p=profile(lambda t:1.5-.02*t)
        # Independent analytic fixture: midpoint and integer interpolation.
        check(call(p,500,12.5)==(True,625.0,0))
        check(call(p,500,0)==(True,750.0,0))
        check(call(p,500,35)==(True,400.0,0))
        for k in [10,50,60,100,1000,2000]:
            ok,out,flags=call(p,k,25)
            check(ok and out==float(k) and bool(flags&COND)==(k<60 or k>1000))
        previous=math.inf
        max_linear_error=0.0
        for j in range(3501):
            t=C.c_float(j/100).value
            ok,out,flags=call(p,500,t)
            check(ok and out<=previous+1e-4)
            previous=out
            max_linear_error=max(max_linear_error,abs(out-500*(1.5-.02*t)))
        check(max_linear_error<0.0001)
        # Real curvature test of interpolation, not a mirrored table equation:
        # interpolating exp(-.02*t) at .5 steps has relative error cosh(.01)-1.
        pexp=profile(lambda t:math.exp(.02*(25-t)))
        max_exp_error=0.0
        for j in range(3501):
            t=C.c_float(j/100).value
            ok,out,flags=call(pexp,300,t)
            check(ok)
            exact=300*math.exp(.02*(25-t))
            max_exp_error=max(max_exp_error,abs(out/exact-1))
        check(max_exp_error<math.cosh(.01)-1+2e-7)
        for t in [-math.inf,-.001,35.001,50,math.inf,math.nan]:
            ok,out,flags=call(p,500,t)
            check(not ok and math.isnan(out) and (flags&TEMP or flags&INVALID))
        for k in [0,-1,math.inf,math.nan]:
            ok,out,flags=call(p,k,20)
            check(not ok and math.isnan(out) and flags&INVALID)
        pbad=profile(lambda t:1.5-.02*t)
        pbad.factor25[10]+=.001 # Valid-looking but corrupted payload CRC.
        ok,out,flags=call(pbad,500,20);check(not ok and math.isnan(out) and flags&CRC)
        pbad=profile(lambda t:1.5-.02*t)
        pbad.factor25[5]=pbad.factor25[4]+.1
        pbad.table_crc32=lib.nlf_factors_crc32(pbad.factor25)
        ok,out,flags=call(pbad,500,20);check(not ok and math.isnan(out) and flags&BADTABLE)
        pbad=profile(lambda t:1.5-.02*t)
        pbad.factor25[25]=.999
        pbad.table_crc32=lib.nlf_factors_crc32(pbad.factor25)
        ok,out,flags=call(pbad,500,25);check(not ok and math.isnan(out) and flags&BADTABLE)
        for badtype in ['source_id','source_sha','magic']:
            pbad=profile(lambda t:1.5-.02*t)
            if badtype=='source_id':pbad.source_id=0
            elif badtype=='source_sha':pbad.source_sha256[:]=bytes(32)
            else:pbad.flags_verified=0
            ok,out,flags=call(pbad,500,25)
            check(not ok and math.isnan(out) and flags&UNVERIFIED)
        empty=Profile()
        for i in range(36):empty.factor25[i]=1.0
        for t in [0,25,35]:
            ok,out,flags=call(empty,500,t);check(not ok and math.isnan(out) and flags&UNVERIFIED)
        ok,out,flags=call(None,500,25);check(not ok and math.isnan(out) and flags&UNVERIFIED)
        # CRC matches Python zlib on independent canonical bytes including bit cases.
        bits=[0,0x80000000,0x3f800000,0x7fc00001,0x7f800000,0xff800000]*6
        arr=Float36(*struct.unpack('<36f',struct.pack('<36I',*bits)))
        check(lib.nlf_factors_crc32(arr)==zlib.crc32(struct.pack('<36f',*arr)))
        # Host import tool: actual CSV and source-artifact hashing are checked
        # against the C evaluator and fixed register layout. Only temp files.
        src=Path(tmp)/'SYNTHETIC-NOT-ISO.txt'
        src.write_text('Numerical-test source artifact, not a standard.')
        csv_path=Path(tmp)/'SYNTHETIC-NOT-ISO.csv'
        csv_path.write_text('temperature_C,factor25\n'+''.join(f'{i},{1.5-.02*i}\n' for i in range(36)))
        imported=build_profile_json(csv_path,src,17,True)
        check(imported['nlf_table_crc32']==p.table_crc32)
        check(imported['nlf_source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest())
        check(len(imported['stage_write']['words'])==94)
        check(imported['stage_write']['words'][76:78]==[0,0])
        check(imported['enable_write_last']['words']==[MAGIC>>16,MAGIC&0xffff])
        not_reviewed=build_profile_json(csv_path,src,17,False)
        check(not_reviewed['enable_write_last']['words']==[0,0])
        check(not_reviewed['nlf_flags_verified']==0)
        csv_path.write_text(csv_path.read_text()+'0,1.5\n')
        try:build_profile_json(csv_path,src,17,True)
        except ValueError:check(True)
        else:check(False)
        result={'checks_passed':count,'profile_size':C.sizeof(Profile),'compiler':'cc C99 -Wall -Wextra -Werror -pedantic -O2',
                'temperature_sweep_points_each_fixture':3501,'max_synthetic_linear_abs_uScm':max_linear_error,
                'max_synthetic_exponential_relative_error':max_exp_error,
                'synthetic_exponential_interpolation_theoretical_bound':math.cosh(.01)-1,
                'standard_conformance_validated':False,'reason':'No traceable ISO/DIN/EN factor table has been obtained; tests are synthetic numerical/integrity checks.'}
        (ROOT/'host_validation.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))

if __name__=='__main__':run()
