#!/usr/bin/env python3
"""Validate operator-supplied 0..35 C factors and prepare protected RTU staging.

No ISO factor values are bundled. Input source and its factors require human
technical review. Passing --reviewed records that review; it does not prove
that a random source artifact or any particular natural water meets ISO 7888.
This tool does not contact a device and does not commit a Flash transaction.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import struct
import zlib

MAGIC=0x4e4c4631

def pack_words(data):
    return list(struct.unpack('>'+str(len(data)//2)+'H',data))

def build(csv_path, source_path, source_id, reviewed=False):
    if not 0<source_id<=0xffffffff:raise ValueError('source ID must be 1..0xffffffff')
    factors={}
    with Path(csv_path).open(encoding='utf-8-sig',newline='') as f:
        rows=csv.DictReader(f)
        if rows.fieldnames != ['temperature_C','factor25']:
            raise ValueError('CSV header must be temperature_C,factor25')
        for r in rows:
            t=float(r['temperature_C']);v=float(r['factor25'])
            if not math.isfinite(t) or t!=int(t) or not 0<=t<=35:
                raise ValueError('temperatures must be integer 0..35 C')
            t=int(t)
            if t in factors:raise ValueError('duplicate temperature '+str(t))
            if not math.isfinite(v) or not .25<=v<=4:
                raise ValueError('invalid or implausible correction factor at '+str(t))
            factors[t]=struct.unpack('<f',struct.pack('<f',v))[0]
    if sorted(factors)!=list(range(36)):raise ValueError('exactly one factor for every 0..35 C point is required')
    values=[factors[t] for t in range(36)]
    if abs(values[25]-1)>1e-6:raise ValueError('25 C reference factor must equal 1 within 1e-6')
    if any(values[t]<=values[t+1] for t in range(35)):
        raise ValueError('factors must decrease strictly with temperature after float32 rounding')
    source=Path(source_path)
    sha=hashlib.sha256(source.read_bytes()).digest()
    crc=zlib.crc32(struct.pack('<36f',*values))
    factor_words=pack_words(struct.pack('>36f',*values))
    metadata_words=pack_words(struct.pack('>III',source_id,crc,0)+sha)
    # Any change to source/factors clears verification in firmware. Stage all
    # values with tag=0, then issue the separate enable write last after review.
    stage_words=factor_words+metadata_words
    assert len(stage_words)==94
    result={
        'schema':'FW-EC-TX-NLF-PROFILE-1',
        'format':'kappa25_uScm = kappaT_uScm * factor25(T_C)',
        'temperature_points_C':list(range(36)),
        'nlf_factor25':values,
        'nlf_source_id':source_id,
        'source_artifact_name':source.name,
        'nlf_source_sha256':sha.hex(),
        'nlf_table_crc32':crc,
        'nlf_table_crc32_hex':f'{crc:08X}',
        'nlf_flags_verified':MAGIC if reviewed else 0,
        'operator_review_recorded':bool(reviewed),
        'standards_conformance_proved_by_this_tool':False,
        'stage_write':{'function':16,'start_address_zero_based':0x0300,'register_count':94,'words':stage_words},
        'enable_write_last':{'function':16,'start_address_zero_based':0x034c,'register_count':2,
                             'words':[MAGIC>>16,MAGIC&0xffff] if reviewed else [0,0]},
        'commit_note':'Unlock and stage under the protocol write-protection workflow. Write enable tag LAST after source/factor review. Then read the full staged-parameter CRC and use the documented CRC/commit transaction. This JSON does not contain or invent the full parameter CRC.',
        'validation_note':'Source SHA256 records an artifact identity; CRC detects data damage. Neither proves that the artifact is ISO nor that its factors represent the actual sample water.'
    }
    return result

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--factors',type=Path,required=True,help='CSV with temperature_C,factor25; 36 rows, 0..35 C')
    ap.add_argument('--source-artifact',type=Path,required=True,help='reviewed source document used to derive the factors')
    ap.add_argument('--source-id',type=lambda s:int(s,0),required=True,help='local traceability ID, nonzero uint32')
    ap.add_argument('--reviewed',action='store_true',help='operator has checked source identity, 25 C reference, 36 factors and permitted use; emits final enable tag')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    try:r=build(args.factors,args.source_artifact,args.source_id,args.reviewed)
    except (ValueError,OSError,OverflowError) as e:ap.error(str(e))
    args.output.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'Prepared {args.output}; 36 factors, CRC32={r["nlf_table_crc32_hex"]}, enabled={args.reviewed}. No device or Flash has been changed.')

if __name__=='__main__':main()
