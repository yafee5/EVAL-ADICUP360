#!/usr/bin/env python3
"""FW-EC-TX B0 Modbus RTU commissioning/calibration client.

Requires pyserial only for a physical port. Register addresses are zero based;
IEEE754 float32 and uint32 use high register first. No ISO factor values are
included. A successful software write is not evidence of metrological accuracy.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import statistics
import struct
import sys
import time
import zlib
from pathlib import Path

BAUD_CODES={9600:0,19200:1,38400:2,57600:3,115200:4}
GAINS=(1,10,100,1000)
UNLOCK_KEY=0xC35A5AC3
SAVE_KEY=0x53415645
NLF_MAGIC=0x4E4C4631
STATUS_NAMES=[
 'EC_VALID','TEMP_VALID','K25_VALID','EC_LOW_RANGE','NLF_TEMP_OOR','NLF_EC_OOR',
 'RTD_FAULT','EC_FAULT','SETTLING','UNCAL_GAIN','UNCAL_TEMP','UNCAL_K',
 'FLASH_FAULT','ADC_TIMEOUT','EC_OUT_OF_RANGE','TEMP_OUT_OF_RANGE','FACTORY_DEFAULTS',
 'RTD_OPEN','RTD_SHORT','STALE','NLF_UNVERIFIED','MAINTENANCE']

class ModbusError(RuntimeError):pass
class ModbusException(ModbusError):
    def __init__(self,function:int,code:int):
        self.function=function;self.code=code
        super().__init__(f'Modbus exception: function=0x{function:02X}, code={code}')

def crc16(data:bytes)->int:
    result=0xFFFF
    for b in data:
        result^=b
        for _ in range(8):result=(result>>1)^(0xA001 if result&1 else 0)
    return result

def adu(address:int,function:int,payload:bytes)->bytes:
    if not 1<=address<=247:raise ValueError('address must be 1..247; broadcasts are disabled')
    body=bytes((address,function))+payload
    return body+struct.pack('<H',crc16(body))

def u32words(value:int)->list[int]:
    if not 0<=value<=0xFFFFFFFF:raise ValueError('uint32 outside range')
    return [value>>16,value&0xFFFF]

def f32words(value:float)->list[int]:
    if not math.isfinite(value):raise ValueError('configuration float must be finite')
    return list(struct.unpack('>2H',struct.pack('>f',value)))

def words_u32(words:list[int])->int:
    if len(words)!=2:raise ValueError('exactly two words required')
    return (words[0]<<16)|words[1]

def words_float(words:list[int])->float:
    if len(words)!=2:raise ValueError('exactly two words required')
    return struct.unpack('>f',struct.pack('>2H',*words))[0]

class RTUClient:
    """Serialized transactions with complete response/exception/CRC validation."""
    def __init__(self,port,address=1,baud=9600,timeout=1.0):
        if baud not in BAUD_CODES:raise ValueError('unsupported baud rate')
        if not 1<=address<=247:raise ValueError('address must be 1..247')
        self.port=port;self.address=address;self.baud=baud;self.timeout=float(timeout)
        self.last_transfer=0.0
    def quiet(self):
        # Firmware timestamps RX-complete and conservatively leaves one more
        # character before finalizing the RTU frame; match that margin here.
        gap=(3.5*11/self.baud if self.baud<=19200 else .00175)+11/self.baud
        remaining=self.last_transfer+gap-time.monotonic()
        if remaining>0:time.sleep(remaining)
    def _read_exact(self,n,deadline):
        out=bytearray()
        while len(out)<n:
            remaining=deadline-time.monotonic()
            if remaining<=0:raise ModbusError(f'response timeout: got {len(out)}/{n} bytes')
            self.port.timeout=remaining
            block=self.port.read(n-len(out))
            if not block:raise ModbusError(f'response timeout: got {len(out)}/{n} bytes')
            out.extend(block)
        return bytes(out)
    def transaction(self,function,payload):
        self.quiet()
        request=adu(self.address,function,payload)
        self.port.reset_input_buffer()
        original_timeout=self.port.timeout
        try:
            if self.port.write(request)!=len(request):raise ModbusError('short serial write')
            self.port.flush()
            deadline=time.monotonic()+self.timeout
            prefix=self._read_exact(2,deadline)
            if prefix[0]!=self.address:raise ModbusError('unexpected response station address')
            if prefix[1]==(function|0x80):
                response=prefix+self._read_exact(3,deadline)
            elif prefix[1]!=function:raise ModbusError('unexpected response function')
            elif function in (3,4):
                bytecount=self._read_exact(1,deadline)
                expected=struct.unpack('>H',payload[2:4])[0]*2
                if bytecount[0]!=expected or bytecount[0]>250:
                    raise ModbusError(f'response byte count {bytecount[0]} != requested {expected}')
                response=prefix+bytecount+self._read_exact(expected+2,deadline)
            elif function in (6,16):response=prefix+self._read_exact(6,deadline)
            else:raise ValueError('unsupported client function')
            if crc16(response[:-2])!=struct.unpack('<H',response[-2:])[0]:
                raise ModbusError('response CRC mismatch')
            if response[1]&0x80:raise ModbusException(function,response[2])
            if function in (6,16) and response[2:6]!=payload[:4]:
                raise ModbusError('write echo address/count/value mismatch')
            return response
        finally:
            self.last_transfer=time.monotonic();self.port.timeout=original_timeout
    def read_words(self,start,count,function=3):
        if function not in (3,4) or not 1<=count<=125 or start<0 or start+count>65536:
            raise ValueError('invalid read range/function')
        response=self.transaction(function,struct.pack('>HH',start,count))
        return list(struct.unpack('>'+str(count)+'H',response[3:-2]))
    def write_words(self,start,words):
        if not 1<=len(words)<=123 or start<0 or start+len(words)>65536:
            raise ValueError('invalid write range')
        if any(not 0<=w<=65535 for w in words):raise ValueError('word outside uint16 range')
        payload=struct.pack('>HHB',start,len(words),2*len(words))+struct.pack('>'+str(len(words))+'H',*words)
        self.transaction(16,payload)
    def write_word(self,start,value):
        if not 0<=start<=65535 or not 0<=value<=65535:raise ValueError('invalid register/value')
        self.transaction(6,struct.pack('>HH',start,value))

class Transmitter:
    def __init__(self,client):self.client=client
    def unlock(self):self.client.write_words(0x7F00,u32words(UNLOCK_KEY))
    def lock(self):self.client.write_words(0x7F00,[0,0])
    def keepalive(self):self.client.write_word(0x0404,0xA55A)
    def commit(self,new_address=None,new_baud=None):
        crc=self.client.read_words(0x7F08,2)
        self.client.write_words(0x7F02,u32words(SAVE_KEY)+crc)
        # The device replies at the OLD settings and changes only after TEMT.
        self.client.quiet()
        if new_address is not None:self.client.address=new_address
        if new_baud is not None:
            self.client.baud=new_baud;self.client.port.baudrate=new_baud
        if self.client.read_words(0x7F06,2)!=crc:
            raise ModbusError('post-SAVE active-parameter CRC differs from submitted staged CRC')
        return words_u32(crc)
    def status(self):
        w=self.client.read_words(0,32,4)
        bits=words_u32(w[12:14])
        def signed(ws):return struct.unpack('>i',struct.pack('>2H',*ws))[0]
        return {'kappa_T_uScm':words_float(w[0:2]),'kappa25_uScm':words_float(w[2:4]),
          'temperature_C':words_float(w[4:6]),'raw_conductance_S':words_float(w[6:8]),
          'raw_voltage_delta':signed(w[8:10]),'raw_current_delta':signed(w[10:12]),
          'status':bits,'status_hex':f'{bits:08X}',
          'flags':[n for i,n in enumerate(STATUS_NAMES) if bits&(1<<i)],
          'sample_counter':words_u32(w[14:16]),'frequency_Hz':w[16],
          'gain_voltage':w[17],'gain_current':w[18],'gain_index':w[19],
          'uptime_ms':words_u32(w[20:22]),'sample_age_ms':words_u32(w[22:24]),
          'protocol_version':w[24],'configuration_revision':words_u32(w[26:28]),
          'crc_errors':words_u32(w[28:30]),'frame_errors':words_u32(w[30:32])}
    def force(self,frequency,gv,gi):
        if frequency not in (100,1000) or gv not in GAINS or gi not in GAINS:
            raise ValueError('frequency=100/1000; GV/GI=1/10/100/1000')
        self.client.write_words(0x0400,[1,int(frequency==1000),GAINS.index(gv),GAINS.index(gi)])
    def auto(self):self.client.write_word(0x0400,0)
    def configure(self,cell=None,temp_gain=None,temp_offset=None,address=None,baud=None,mark_k=False,mark_t=False):
        if all(x is None for x in (cell,temp_gain,temp_offset,address,baud)) and not (mark_k or mark_t):
            raise ValueError('configure requires an explicit parameter or calibration flag; no Flash write performed')
        if cell is not None and not .5<=cell<=1.5:raise ValueError('K must be .5..1.5 cm^-1')
        if temp_gain is not None and not .95<=temp_gain<=1.05:raise ValueError('temperature gain must be .95..1.05')
        if temp_offset is not None and not -5<=temp_offset<=5:raise ValueError('temperature offset must be -5..5 C')
        if address is not None and not 1<=address<=247:raise ValueError('station address must be 1..247')
        if baud is not None and baud not in BAUD_CODES:raise ValueError('unsupported baud')
        self.unlock()
        for reg,value in [(0x100,cell),(0x102,temp_gain),(0x104,temp_offset)]:
            if value is not None:self.client.write_words(reg,f32words(value))
        if address is not None:self.client.write_word(0x106,address)
        if baud is not None:self.client.write_word(0x107,BAUD_CODES[baud])
        flags=self.client.read_words(0x10A,1)[0]
        flags|=(1 if mark_k else 0)|(2 if mark_t else 0)
        if mark_k or mark_t:self.client.write_word(0x10A,flags)
        return self.commit(address,baud)
    def gain_correction(self,frequency,gv,gi,correction):
        if frequency not in (100,1000) or gv not in GAINS or gi not in GAINS:raise ValueError('invalid frequency/gain')
        if not math.isfinite(correction) or not .5<=correction<=2:raise ValueError('correction must be .5..2')
        ix=int(frequency==1000)*16+GAINS.index(gv)*4+GAINS.index(gi)
        self.client.write_words(0x200+2*ix,f32words(correction))
        return ix
    def calibrate_gain(self,frequency,gv,gi,reference_s,samples=3,timeout=45):
        if not math.isfinite(reference_s) or reference_s<=0:raise ValueError('reference conductance must be positive S')
        if samples<2:raise ValueError('use at least two distinct coherent samples')
        self.unlock();self.force(frequency,gv,gi)
        readings=[];seen=None;started=time.monotonic();next_keepalive=started+5
        rejected=[]
        try:
            while len(readings)<samples:
                now=time.monotonic()
                if now-started>timeout:raise ModbusError('no sufficient valid forced-cycle readings; inspect fixture, gain and fault flags: '+str(rejected[-1:] ))
                if now>=next_keepalive:self.keepalive();next_keepalive=now+5
                s=self.status()
                forbidden=(1<<7)|(1<<8)|(1<<13)|(1<<14)|(1<<19)
                valid=(s['status']&1) and (s['status']&(1<<21)) and not s['status']&forbidden
                valid=valid and (s['frequency_Hz'],s['gain_voltage'],s['gain_current'])==(frequency,gv,gi)
                valid=valid and math.isfinite(s['raw_conductance_S']) and s['raw_conductance_S']>0
                if valid and s['sample_counter']!=seen:
                    seen=s['sample_counter'];readings.append(s['raw_conductance_S'])
                elif not valid:rejected.append(s['flags'])
                time.sleep(.15)
            measured=statistics.mean(readings);coefficient=reference_s/measured
            ix=self.gain_correction(frequency,gv,gi,coefficient)
            crc=self.commit()
            return {'gain_index':ix,'frequency_Hz':frequency,'gain_voltage':gv,'gain_current':gi,
              'reference_conductance_S':reference_s,'raw_samples_S':readings,
              'raw_mean_S':measured,'raw_stdev_S':statistics.stdev(readings),
              'correction':coefficient,'params_crc32':f'{crc:08X}',
              'note':'Only this tested frequency/gain pair is marked; calibration uncertainty and independent verification remain required.'}
        except Exception:
            # Do not mask the original error if link itself has failed.
            try:self.auto();self.lock()
            except ModbusError:pass
            raise
    def import_nlf(self,profile,source_artifact):
        words=validate_nlf_profile(profile,source_artifact)
        self.unlock();self.client.write_words(0x0300,words)
        self.client.write_words(0x034C,u32words(NLF_MAGIC))
        return self.commit()

def validate_nlf_profile(p,source_artifact):
    if p.get('schema')!='FW-EC-TX-NLF-PROFILE-1':raise ValueError('unknown nLF profile schema')
    if not p.get('operator_review_recorded') or p.get('nlf_flags_verified')!=NLF_MAGIC:
        raise ValueError('profile has no recorded operator source/factor review; no table will be enabled')
    values=p.get('nlf_factor25',[])
    if len(values)!=36 or p.get('temperature_points_C')!=list(range(36)):
        raise ValueError('exactly 36 points at 0..35 C required')
    try:values=list(struct.unpack('<36f',struct.pack('<36f',*values)))
    except (struct.error,OverflowError,TypeError) as e:raise ValueError('invalid factor encoding') from e
    if any(not math.isfinite(x) or not .25<=x<=4 for x in values):raise ValueError('invalid nLF factor')
    if abs(values[25]-1)>1e-6 or any(values[i]<=values[i+1] for i in range(35)):
        raise ValueError('25 C factor must be 1 and table strictly decreasing')
    source_id=p.get('nlf_source_id')
    if not isinstance(source_id,int) or not 0<source_id<=0xFFFFFFFF:raise ValueError('invalid source ID')
    source_hash=hashlib.sha256(Path(source_artifact).read_bytes()).digest()
    if source_hash.hex()!=p.get('nlf_source_sha256'):raise ValueError('source artifact SHA256 mismatch')
    crc=zlib.crc32(struct.pack('<36f',*values))
    if crc!=p.get('nlf_table_crc32'):raise ValueError('nLF factors CRC mismatch')
    stage=struct.pack('>36f',*values)+struct.pack('>III',source_id,crc,0)+source_hash
    words=list(struct.unpack('>94H',stage))
    declared=p.get('stage_write',{})
    if declared.get('function')!=16 or declared.get('start_address_zero_based')!=0x300 or declared.get('words')!=words:
        raise ValueError('profile staging data inconsistent with source/factors')
    return words

def clean_json(value):
    if isinstance(value,float) and not math.isfinite(value):return None
    if isinstance(value,dict):return {k:clean_json(v) for k,v in value.items()}
    if isinstance(value,list):return [clean_json(v) for v in value]
    return value

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port',required=True);p.add_argument('--address',type=int,default=1)
    p.add_argument('--baud',type=int,choices=BAUD_CODES,default=9600)
    p.add_argument('--timeout',type=float,default=1.0)
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('status');r=sub.add_parser('read');r.add_argument('register',type=lambda s:int(s,0));r.add_argument('count',type=int);r.add_argument('--function',type=int,choices=[3,4],default=3)
    c=sub.add_parser('configure');c.add_argument('--cell',type=float);c.add_argument('--temperature-gain',type=float);c.add_argument('--temperature-offset',type=float)
    c.add_argument('--new-address',type=int);c.add_argument('--new-baud',type=int,choices=BAUD_CODES)
    c.add_argument('--mark-k-calibrated',action='store_true');c.add_argument('--mark-temperature-calibrated',action='store_true')
    f=sub.add_parser('force');f.add_argument('frequency',type=int,choices=[100,1000]);f.add_argument('gv',type=int,choices=GAINS);f.add_argument('gi',type=int,choices=GAINS);f.add_argument('--hold-seconds',type=float,default=20)
    sub.add_parser('auto')
    g=sub.add_parser('calibrate-gain');g.add_argument('frequency',type=int,choices=[100,1000]);g.add_argument('gv',type=int,choices=GAINS);g.add_argument('gi',type=int,choices=GAINS);g.add_argument('--reference-s',type=float,required=True);g.add_argument('--samples',type=int,default=3);g.add_argument('--wait-seconds',type=float,default=45)
    n=sub.add_parser('import-nlf');n.add_argument('profile',type=Path);n.add_argument('--source-artifact',type=Path,required=True)
    args=p.parse_args(argv)
    try:
        import serial
        with serial.Serial(args.port,args.baud,bytesize=8,parity=serial.PARITY_EVEN,stopbits=1,timeout=args.timeout,write_timeout=args.timeout) as port:
            t=Transmitter(RTUClient(port,args.address,args.baud,args.timeout))
            if args.command=='status':out=t.status()
            elif args.command=='read':out=t.client.read_words(args.register,args.count,args.function)
            elif args.command=='configure':
                crc=t.configure(args.cell,args.temperature_gain,args.temperature_offset,args.new_address,args.new_baud,args.mark_k_calibrated,args.mark_temperature_calibrated)
                out={'committed_crc32':f'{crc:08X}','address':t.client.address,'baud':t.client.baud,'status':t.status()}
            elif args.command=='auto':t.unlock();t.auto();t.lock();out=t.status()
            elif args.command=='force':
                if not 0<args.hold_seconds<=3600:raise ValueError('hold-seconds must be 0..3600')
                t.unlock();t.force(args.frequency,args.gv,args.gi)
                start=time.monotonic();next_keepalive=start+5
                try:
                    while time.monotonic()-start<args.hold_seconds:
                        if time.monotonic()>=next_keepalive:t.keepalive();next_keepalive=time.monotonic()+5
                        print(json.dumps(clean_json(t.status()),ensure_ascii=False),flush=True);time.sleep(1)
                finally:t.auto();t.lock()
                return 0
            elif args.command=='calibrate-gain':out=t.calibrate_gain(args.frequency,args.gv,args.gi,args.reference_s,args.samples,args.wait_seconds)
            else:
                crc=t.import_nlf(json.loads(args.profile.read_text()),args.source_artifact)
                out={'committed_crc32':f'{crc:08X}','note':'Profile identity/integrity checked; source review is an operator responsibility, not an ISO certification.'}
            print(json.dumps(clean_json(out),ensure_ascii=False,indent=2));return 0
    except (ImportError,OSError,ValueError,ModbusError) as e:
        print(str(e),file=sys.stderr)
        if args.command=='configure' and (args.new_address is not None or args.new_baud is not None):
            print('若SAVE回复丢失，设备可能已采用新地址/波特率；请分别用新旧设置查询，不要反复盲写。',file=sys.stderr)
        return 2

if __name__=='__main__':raise SystemExit(main())
