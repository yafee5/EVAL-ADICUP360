# FW-EC-TX B0 固件

固定功能：两极电导池、四线Pt1000、100/1000Hz与AD8253分档校正、Modbus RTU。源代码不编译LCD、菜单、编码器、蜂鸣器、Pt100及2/3线识别。

**当前是未上板的工程固件。未取得可追溯ISO 7888因子，κ25默认NaN并置NLF_UNVERIFIED；不能据此宣称温补功能完成或精度已经达标。** 温补表的校验/导入通路已实现，标准数据就绪后仍须验收。

整个项目解压后保留相邻的`firmware/`与`compensation/`，不能只复制单个固件目录。需要Python3、GNU Arm Embedded工具链；主机测试还需要GCC/Clang与ASan/UBSan。物理串口工具另需`pyserial`。

```sh
cd firmware
make                         # 生成build/fw_ec_tx_b0.hex、elf、bin、map
make test                    # 采集/RTU/应用HAL、协议Flash、nLF、真实C协议客户端测试
python3 tools/verify_release.py  # 上述检查和最终ARM编译，写机器可读验证摘要
```

GNU Arm工具不在PATH时可设置`CROSS_COMPILE=/绝对路径/arm-none-eabi-`。构建脚本在本云环境额外识别`/workspace/toolchains/arm/usr/bin/`；其他机器正常安装工具链即可。

烧录前核实R13=4.99kΩ，四线Pt1000，主板旧U7/R10/J2和原开关3.3V支路停装，合并电源/隔离485板接线正确。IEXC设为名义200µA，附加10µA位关闭。主板R17作为BM启动上拉保留。J4是20针ARM调试口，VTref=3.3V，调试器不向目标板灌5V。

应用区止于0x1FA00；校准A/B页在0x1FA00和0x1FC00，各512字节；最后0x1FE00–0x1FFFF安全配置页不使用。HEX不含这些参数/安全地址。升级时应先备份参数，并核对烧录工具的擦除策略；整片擦除仍会丢失校准，不能因HEX不含参数就假定烧录器必定保留它们。

默认通讯为站址1、9600、8E1。完整寄存器表见`protocol/register_map.csv`及`../docs/firmware_modbus_寄存器与校准.md`；实际CLI在`tools/tx_modbus.py`。正常数据必须结合有效位、校准位、故障位、样本年龄判断；切档会丢弃整周期并输出SETTLING/NaN。完整电导周期约数秒，轮询频率不等于更新频率。

构建摘要`build/manifest.json`和`build/image_validation.json`记录源码/HEX哈希、RAM/Flash边界与RAM擦写例程检查。`build/firmware_validation.json`分开标注主机通过和未做的实物验证。`vendor/ADI_CN0359_LICENSE.txt`及原版权条款保留；板级派生代码使用LicenseRef-ADI-CN0359，不能误当无附加限制的标准BSD许可。
