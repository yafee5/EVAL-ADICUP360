/* SPDX-License-Identifier: MIT */
#ifndef TX_BOARD_H
#define TX_BOARD_H
#include "tx_protocol.h"
#include <stdbool.h>
#include <stdint.h>
extern const tx_flash_ops_t tx_board_flash_ops;
void tx_board_init(void);
void tx_board_gains(unsigned gv_index,unsigned gi_index);
void tx_board_pwm(unsigned frequency_index,bool invert);
void tx_board_adc0_begin(unsigned phase);
void tx_board_rtd_begin(unsigned state);
void tx_board_adc_pause(void);
bool tx_board_adc0_result(int32_t *code,uint32_t *fault);
bool tx_board_adc1_result(uint32_t *code,uint32_t *fault);
void tx_board_uart_init(uint32_t baud);
size_t tx_board_uart_receive(uint8_t *buf,size_t capacity);
void tx_board_uart_send(const uint8_t *buf,size_t bytes);
bool tx_board_uart_transmitted(void);
uint32_t tx_board_uart_frame_errors(void);
uint32_t tx_board_pause_epoch(void);
uint32_t tx_board_millis(void);
void tx_board_sleep(void);
#endif
