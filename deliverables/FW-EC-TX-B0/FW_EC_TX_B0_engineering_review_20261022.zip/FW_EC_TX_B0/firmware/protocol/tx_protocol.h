#ifndef FW_EC_TX_PROTOCOL_H
#define FW_EC_TX_PROTOCOL_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TX_PROTOCOL_VERSION 0x0100u
#define TX_FREQUENCY_COUNT 2u
#define TX_GAIN_COUNT 4u
#define TX_GAIN_ENTRIES 32u
#define TX_FLASH_SLOT_BYTES 512u
#define TX_PARAMS_BYTES 336u
#define TX_RECORD_BYTES 356u
#define TX_UNLOCK_MS 30000u
#define TX_COMMIT_INTERVAL_MS 5000u
#define TX_UNLOCK_KEY UINT32_C(0xC35A5AC3)
#define TX_COMMIT_KEY UINT32_C(0x53415645)
#define TX_DEFAULTS_KEY UINT32_C(0x44454654)

enum {
    TX_CAL_K = 1u << 0,
    TX_CAL_TEMPERATURE = 1u << 1
};
enum {
    TX_STATUS_EC_VALID = 1u << 0,
    TX_STATUS_TEMP_VALID = 1u << 1,
    TX_STATUS_K25_VALID = 1u << 2,
    TX_STATUS_EC_LOW_RANGE = 1u << 3,
    TX_STATUS_NLF_TEMP_OOR = 1u << 4,
    TX_STATUS_NLF_EC_OOR = 1u << 5,
    TX_STATUS_RTD_FAULT = 1u << 6,
    TX_STATUS_EC_FAULT = 1u << 7,
    TX_STATUS_SETTLING = 1u << 8,
    TX_STATUS_UNCAL_GAIN = 1u << 9,
    TX_STATUS_UNCAL_TEMP = 1u << 10,
    TX_STATUS_UNCAL_K = 1u << 11,
    TX_STATUS_FLASH_FAULT = 1u << 12,
    TX_STATUS_ADC_TIMEOUT = 1u << 13,
    TX_STATUS_EC_OUT_OF_RANGE = 1u << 14,
    TX_STATUS_TEMP_OUT_OF_RANGE = 1u << 15,
    TX_STATUS_FACTORY_DEFAULTS = 1u << 16,
    TX_STATUS_RTD_OPEN = 1u << 17,
    TX_STATUS_RTD_SHORT = 1u << 18,
    TX_STATUS_STALE = 1u << 19,
    TX_STATUS_NLF_UNVERIFIED = 1u << 20,
    TX_STATUS_MAINTENANCE = 1u << 21
};
enum {
    TX_APPLIED_NONE = 0,
    TX_APPLIED_CALIBRATION = 1u << 0,
    TX_APPLIED_COMMUNICATION = 1u << 1
};
typedef enum {
    TX_STORE_OK = 0,
    TX_STORE_NO_VALID_RECORD = 1,
    TX_STORE_IO_ERROR = 2,
    TX_STORE_VERIFY_ERROR = 3,
    TX_STORE_INVALID_PARAMS = 4,
    TX_STORE_LOCKED = 5,
    TX_STORE_BAD_CRC = 6,
    TX_STORE_RATE_LIMIT = 7
} tx_store_error_t;

typedef struct {
    float cell_constant;
    float temperature_gain;
    float temperature_offset;
    /* [frequency=100Hz/1000Hz][GV index][GI index], indexes 0..3=1/10/100/1000. */
    float gain_correction[TX_FREQUENCY_COUNT][TX_GAIN_COUNT][TX_GAIN_COUNT];
    uint32_t gain_valid_mask;
    uint16_t calibration_flags;
    uint8_t address;
    uint8_t baud_code;
    /* ISO nLF factors are externally sourced/verified; defaults are disabled. */
    float nlf_factor25[36];
    uint32_t nlf_source_id;
    uint8_t nlf_source_sha256[32];
    uint32_t nlf_table_crc32;
    uint32_t nlf_flags_verified;
} tx_params_t;

typedef struct {
    float conductivity_us_cm;
    float conductivity25_us_cm;
    float temperature_c;
    float conductance_s;
    int32_t raw_voltage_delta;
    int32_t raw_current_delta;
    uint32_t status;
    uint32_t sample_counter;
    uint32_t sample_time_ms;
    uint16_t frequency_hz;
    uint16_t gain_voltage;
    uint16_t gain_current;
    uint16_t gain_table_index;
} tx_snapshot_t;

typedef struct {
    uint16_t mode; /* 0=AUTO, 1=forced calibration/maintenance, RAM only. */
    uint16_t frequency_index;
    uint16_t gv_index;
    uint16_t gi_index;
    uint32_t revision; /* Acquisition must discard a cycle when this changes. */
} tx_maintenance_t;

/* Both slots MUST be separate, independently erasable 512-byte pages.
 * program() is called with 4-byte aligned offset and a multiple of 4 bytes.
 * ADuCM360 integration reserves addresses 0x1FA00 and 0x1FC00 in its linker script.
 * The final page 0x1FE00 is NOT used: it contains device security/user-key words.
 * Callbacks return true only after completion/error-status verification.
 */
typedef struct {
    bool (*read)(void *user, unsigned slot, uint32_t offset, void *data, size_t bytes);
    bool (*erase)(void *user, unsigned slot);
    bool (*program)(void *user, unsigned slot, uint32_t offset, const void *data, size_t bytes);
} tx_flash_ops_t;

typedef struct {
    tx_params_t active;
    tx_params_t staged;
    tx_snapshot_t snapshot;
    tx_maintenance_t maintenance;
    tx_flash_ops_t flash;
    void *flash_user;
    uint32_t now_ms;
    uint32_t unlock_deadline_ms;
    uint32_t sequence;
    uint32_t configuration_revision;
    uint32_t last_commit_ms;
    uint32_t crc_error_count;
    uint32_t frame_error_count;
    int active_slot;
    tx_store_error_t last_error;
    bool unlocked;
    bool pending_apply;
    bool loaded_from_flash;
    bool storage_fault;
    bool have_committed_this_boot;
} tx_context_t;

void tx_params_defaults(tx_params_t *params);
bool tx_params_valid(const tx_params_t *params);
void tx_params_encode(const tx_params_t *params, uint8_t out[TX_PARAMS_BYTES]);
bool tx_params_decode(tx_params_t *params, const uint8_t in[TX_PARAMS_BYTES]);
uint32_t tx_crc32(const void *data, size_t size);
uint32_t tx_params_crc(const tx_params_t *params);
uint16_t tx_modbus_crc16(const void *data, size_t size);
uint32_t tx_baud_rate(uint8_t code);
uint16_t tx_gain_value(unsigned index);
unsigned tx_gain_index(unsigned frequency_index, unsigned gv_index, unsigned gi_index);

/* Initializes defaults and attempts to load the newest valid journal record.
 * No valid record is normal on a blank board; calibration flags remain clear.
 */
void tx_protocol_init(tx_context_t *ctx, const tx_flash_ops_t *ops, void *user, uint32_t now_ms);
void tx_protocol_poll(tx_context_t *ctx, uint32_t now_ms);
void tx_protocol_set_snapshot(tx_context_t *ctx, const tx_snapshot_t *snapshot);
const tx_params_t *tx_protocol_params(const tx_context_t *ctx);
const tx_maintenance_t *tx_protocol_maintenance(const tx_context_t *ctx);

/* Process exactly one already delimited RTU ADU including its CRC. UART framing,
 * t1.5/t3.5 gap enforcement, parity and overrun rejection belong to the UART HAL.
 * Returns response length, or 0 for silent discard. Never send an ASCII newline.
 * Call from main context with ADC paused around a commit, NOT from an ISR.
 */
size_t tx_protocol_process(tx_context_t *ctx, const uint8_t *request, size_t bytes,
                           uint8_t *response, size_t capacity, uint32_t now_ms);

/* MUST be called after UART transmission complete (not just an empty software
 * queue). Until this call the reply uses the OLD address and baud rate.
 * Return flags tell acquisition to discard a complete measurement cycle and
 * the UART HAL to switch communication settings. Also call after a successfully
 * persisted transaction if the reply could not be transmitted.
 */
uint32_t tx_protocol_after_reply(tx_context_t *ctx);

/* Exposed separately for host power-loss tests and bootloader-independent HALs. */
bool tx_storage_load(tx_context_t *ctx);
bool tx_storage_commit(tx_context_t *ctx, const tx_params_t *params);

#ifdef __cplusplus
}
#endif
#endif
