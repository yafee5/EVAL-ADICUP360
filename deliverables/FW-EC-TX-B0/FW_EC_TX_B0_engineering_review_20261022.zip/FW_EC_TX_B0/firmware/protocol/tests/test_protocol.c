#include "../tx_protocol.h"
#include "../../../compensation/nlf.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks;
#define CHECK(x) do {++checks;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
typedef struct {uint8_t page[2][TX_FLASH_SLOT_BYTES];int budget;unsigned writes,erases;bool bad_read,bad_erase;} memflash_t;
static bool rd(void *v,unsigned slot,uint32_t off,void *p,size_t n)
{memflash_t*m=v;if(m->bad_read||slot>=2||off+n>512)return false;memcpy(p,m->page[slot]+off,n);return true;}
static bool er(void *v,unsigned slot)
{memflash_t*m=v;if(slot>=2||m->bad_erase)return false;memset(m->page[slot],0xFF,512);m->erases++;return true;}
static bool pg(void *v,unsigned slot,uint32_t off,const void *p,size_t n)
{
    memflash_t*m=v;const uint8_t*b=p;size_t i,j;
    CHECK(slot<2&&off+n<=512&&(off&3)==0&&(n&3)==0);
    for(i=0;i<n;i+=4) {
        if(m->budget==0)return false;
        if(m->budget>0)m->budget--;
        for(j=0;j<4;j++){CHECK((m->page[slot][off+i+j]&b[i+j])==b[i+j]);m->page[slot][off+i+j]&=b[i+j];}
        m->writes++;
    }
    return true;
}
static const tx_flash_ops_t flash={rd,er,pg};
static void clean(memflash_t *m) {memset(m,0,sizeof *m);memset(m->page,0xFF,sizeof m->page);m->budget=-1;}
static size_t finish(uint8_t *q,size_t n) {uint16_t c=tx_modbus_crc16(q,n);q[n]=(uint8_t)c;q[n+1]=(uint8_t)(c>>8);return n+2;}
static void be16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static uint32_t read32(const uint8_t*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static float readfloat(const uint8_t*p){uint32_t v=read32(p);float f;memcpy(&f,&v,4);return f;}
static uint32_t floatbits(float f){uint32_t v;memcpy(&v,&f,4);return v;}
static size_t write_words(tx_context_t*c,uint8_t addr,uint16_t start,const uint16_t *w,uint16_t n,uint8_t*r,uint32_t now)
{
    uint8_t q[256];unsigned i;q[0]=addr;q[1]=16;be16(q+2,start);be16(q+4,n);q[6]=(uint8_t)(2*n);
    for(i=0;i<n;i++)be16(q+7+2*i,w[i]);
    return tx_protocol_process(c,q,finish(q,7+2*n),r,256,now);
}
static size_t write_u32(tx_context_t*c,uint16_t a,uint32_t v,uint8_t*r,uint32_t now)
{uint16_t w[2]={(uint16_t)(v>>16),(uint16_t)v};return write_words(c,c->active.address,a,w,2,r,now);}
static size_t write_float(tx_context_t*c,uint16_t a,float f,uint8_t*r,uint32_t now){return write_u32(c,a,floatbits(f),r,now);}
static size_t single(tx_context_t*c,uint16_t a,uint16_t v,uint8_t*r,uint32_t now)
{uint8_t q[8]={0};q[0]=c->active.address;q[1]=6;be16(q+2,a);be16(q+4,v);return tx_protocol_process(c,q,finish(q,6),r,256,now);}
static size_t read_regs(tx_context_t*c,uint8_t f,uint16_t a,uint16_t count,uint8_t*r,uint32_t now)
{uint8_t q[8]={0};q[0]=c->active.address;q[1]=f;be16(q+2,a);be16(q+4,count);return tx_protocol_process(c,q,finish(q,6),r,256,now);}
static size_t commit(tx_context_t*c,uint8_t*r,uint32_t now)
{uint32_t crc=tx_params_crc(&c->staged);uint16_t w[4]={0x5341,0x5645,(uint16_t)(crc>>16),(uint16_t)crc};return write_words(c,c->active.address,0x7F02,w,4,r,now);}
static void expect_exception(const uint8_t*r,size_t n,uint8_t f,uint8_t ex)
{CHECK(n==5);CHECK(r[1]==(uint8_t)(f|0x80));CHECK(r[2]==ex);CHECK(tx_modbus_crc16(r,n)==0);}
static void unlock(tx_context_t*c,uint8_t*r,uint32_t now){CHECK(write_u32(c,0x7F00,TX_UNLOCK_KEY,r,now)==8);CHECK(c->unlocked);}

static void test_crc_and_params(void)
{
    tx_params_t p,q;uint8_t b[TX_PARAMS_BYTES];unsigned i;
    const uint8_t request[]={1,3,0,0,0,10};
    CHECK(tx_modbus_crc16("123456789",9)==0x4B37);CHECK(tx_crc32("123456789",9)==UINT32_C(0xCBF43926));
    CHECK(tx_modbus_crc16(request,sizeof request)==0xCDC5);
    CHECK(sizeof(float)==4);CHECK(TX_RECORD_BYTES<=512&&TX_RECORD_BYTES%4==0);
    tx_params_defaults(&p);CHECK(tx_params_valid(&p));CHECK(p.gain_valid_mask==0&&p.calibration_flags==0&&p.nlf_flags_verified==0);
    p.address=247;p.baud_code=4;p.cell_constant=1.03f;p.temperature_offset=-0.1f;p.gain_correction[1][3][3]=1.001f;p.gain_valid_mask=0x80000000u;
    tx_params_encode(&p,b);CHECK(tx_params_decode(&q,b));CHECK(tx_params_crc(&p)==tx_params_crc(&q));CHECK(q.gain_correction[1][3][3]==1.001f);
    CHECK(tx_gain_index(1,3,3)==31);CHECK(tx_gain_value(0)==1&&tx_gain_value(3)==1000&&tx_gain_value(4)==0);
    CHECK(tx_baud_rate(0)==9600&&tx_baud_rate(4)==115200&&tx_baud_rate(5)==0);
    for(i=0;i<36;i++)p.nlf_factor25[i]=1.5f-0.02f*(float)i; /* synthetic integrity fixture, NOT ISO data */
    p.nlf_source_id=0x54455354;for(i=0;i<32;i++)p.nlf_source_sha256[i]=(uint8_t)(i+1);
    p.nlf_table_crc32=nlf_factors_crc32(p.nlf_factor25);p.nlf_flags_verified=NLF_VERIFIED_MAGIC;
    CHECK(tx_params_valid(&p));p.nlf_table_crc32^=1;CHECK(!tx_params_valid(&p));p.nlf_table_crc32^=1;
    p.nlf_factor25[3]=p.nlf_factor25[2];p.nlf_table_crc32=nlf_factors_crc32(p.nlf_factor25);CHECK(!tx_params_valid(&p));
    tx_params_defaults(&p);p.cell_constant=NAN;CHECK(!tx_params_valid(&p));tx_params_defaults(&p);p.address=0;CHECK(!tx_params_valid(&p));
    tx_params_defaults(&p);p.temperature_gain=1.1f;CHECK(!tx_params_valid(&p));tx_params_defaults(&p);p.gain_correction[0][0][0]=INFINITY;CHECK(!tx_params_valid(&p));
}
static void test_transactions(void)
{
    memflash_t m;tx_context_t c,boot;uint8_t r[256];uint16_t words[4];size_t n;uint32_t crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);CHECK(!c.loaded_from_flash&&!c.storage_fault&&c.active_slot==-1);
    expect_exception(r,write_float(&c,0x100,1.02f,r,1),16,3);CHECK(c.active.cell_constant==1);
    expect_exception(r,write_u32(&c,0x7F00,123,r,2),16,3);unlock(&c,r,3);
    CHECK(write_float(&c,0x100,1.02f,r,4)==8);CHECK(c.staged.cell_constant==1.02f&&c.active.cell_constant==1);
    CHECK(read_regs(&c,3,0x100,2,r,5)==9&&readfloat(r+3)==1.02f);
    expect_exception(r,single(&c,0x100,0x3F80,r,6),6,3);CHECK(c.staged.cell_constant==1.02f);
    words[0]=42;words[1]=5;expect_exception(r,write_words(&c,1,0x106,words,2,r,7),16,3);CHECK(c.staged.address==1&&c.staged.baud_code==0);
    expect_exception(r,write_float(&c,0x100,NAN,r,8),16,3);CHECK(c.staged.cell_constant==1.02f);
    CHECK(write_float(&c,0x200,1.0002f,r,9)==8);CHECK(c.staged.gain_valid_mask==1);
    CHECK(write_float(&c,0x23E,0.999f,r,10)==8);CHECK(c.staged.gain_valid_mask==0x80000001u);
    expect_exception(r,write_float(&c,0x201,1.0f,r,11),16,3);
    CHECK(write_float(&c,0x102,1.0001f,r,12)==8);CHECK(write_float(&c,0x104,-0.05f,r,13)==8);
    CHECK(single(&c,0x10A,TX_CAL_K|TX_CAL_TEMPERATURE,r,14)==8);
    CHECK(c.staged.calibration_flags==3);
    crc=tx_params_crc(&c.staged);words[0]=0x5341;words[1]=0x5645;words[2]=(uint16_t)(crc>>16);words[3]=(uint16_t)(crc^1);
    expect_exception(r,write_words(&c,1,0x7F02,words,4,r,15),16,3);CHECK(c.last_error==TX_STORE_BAD_CRC&&!c.pending_apply&&m.erases==0);
    CHECK(commit(&c,r,16)==8);CHECK(r[0]==1&&c.pending_apply&&c.active.cell_constant==1&&c.sequence==1);
    expect_exception(r,read_regs(&c,3,0,2,r,17),3,6);
    CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION);CHECK(c.active.cell_constant==1.02f&&!c.unlocked);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.loaded_from_flash&&boot.active.cell_constant==1.02f&&boot.sequence==1);
    unlock(&c,r,20);words[0]=31;words[1]=4;CHECK(write_words(&c,1,0x106,words,2,r,21)==8);
    expect_exception(r,commit(&c,r,22),16,6);CHECK(c.last_error==TX_STORE_RATE_LIMIT);
    CHECK(commit(&c,r,5016)==8);CHECK(r[0]==1&&c.active.address==1&&c.active.baud_code==0);
    CHECK(tx_protocol_after_reply(&c)==(TX_APPLIED_CALIBRATION|TX_APPLIED_COMMUNICATION));CHECK(c.active.address==31&&tx_baud_rate(c.active.baud_code)==115200);
    CHECK(c.configuration_revision==2);n=read_regs(&c,3,0x106,2,r,5017);CHECK(n==9&&r[3]==0&&r[4]==31&&r[6]==4);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.address==31&&boot.active_slot==1&&boot.sequence==2);
    unlock(&c,r,5020);CHECK(write_u32(&c,0x7F10,TX_DEFAULTS_KEY,r,5021)==8);CHECK(c.staged.address==1&&c.staged.gain_valid_mask==0);
    CHECK(write_u32(&c,0x7F00,0,r,5022)==8);CHECK(!c.unlocked&&c.staged.address==31);
    unlock(&c,r,UINT32_C(0xFFFFFFF0));tx_protocol_poll(&c,10000);CHECK(c.unlocked);tx_protocol_poll(&c,30000);CHECK(!c.unlocked);
}
static void test_wire_errors_and_telemetry(void)
{
    memflash_t m;tx_context_t c;tx_snapshot_t s;uint8_t q[256],r[256];size_t n;uint32_t flags;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);unlock(&c,r,1);
    q[0]=0;q[1]=6;be16(q+2,0x106);be16(q+4,32);n=finish(q,6);
    CHECK(tx_protocol_process(&c,q,n,r,sizeof r,2)==0&&c.staged.address==1);
    q[0]=2;n=finish(q,6);CHECK(tx_protocol_process(&c,q,n,r,sizeof r,2)==0);
    q[0]=1;n=finish(q,6);q[n-1]^=1;CHECK(tx_protocol_process(&c,q,n,r,sizeof r,3)==0&&c.crc_error_count==1);
    q[0]=1;q[1]=99;n=finish(q,2);expect_exception(r,tx_protocol_process(&c,q,n,r,sizeof r,4),99,1);
    expect_exception(r,read_regs(&c,4,0,0,r,5),4,3);expect_exception(r,read_regs(&c,4,0x20,1,r,6),4,2);
    expect_exception(r,read_regs(&c,3,0xFFFF,2,r,7),3,3);
    q[0]=1;q[1]=16;be16(q+2,0x106);be16(q+4,2);q[6]=2;be16(q+7,5);n=finish(q,9);
    expect_exception(r,tx_protocol_process(&c,q,n,r,sizeof r,8),16,3);CHECK(c.staged.address==1);
    q[0]=1;q[1]=6;be16(q+2,0x106);be16(q+4,32);n=finish(q,6);
    CHECK(tx_protocol_process(&c,q,n,r,7,9)==0&&c.staged.address==1);
    CHECK(tx_protocol_process(&c,q,3,r,sizeof r,10)==0);
    memset(&s,0,sizeof s);s.conductivity_us_cm=123.25f;s.conductivity25_us_cm=NAN;s.temperature_c=NAN;s.conductance_s=.00012325f;
    s.status=TX_STATUS_EC_VALID|TX_STATUS_RTD_FAULT;s.frequency_hz=1000;s.gain_voltage=10;s.gain_current=1000;
    s.gain_table_index=23;s.raw_voltage_delta=-1234567;s.raw_current_delta=7654321;s.sample_counter=0x12345678;s.sample_time_ms=100;
    tx_protocol_set_snapshot(&c,&s);n=read_regs(&c,4,0,0x20,r,101);CHECK(n==69);
    CHECK(readfloat(r+3)==123.25f&&isnan(readfloat(r+7))&&isnan(readfloat(r+11)));
    CHECK(read32(r+3+8*2)==(uint32_t)-1234567);CHECK(read32(r+3+14*2)==0x12345678u);
    flags=read32(r+3+12*2);CHECK(flags&TX_STATUS_EC_VALID);CHECK(flags&TX_STATUS_RTD_FAULT);CHECK(!(flags&TX_STATUS_TEMP_VALID));
    CHECK(flags&TX_STATUS_UNCAL_GAIN);CHECK(flags&TX_STATUS_NLF_UNVERIFIED);CHECK(flags&TX_STATUS_FACTORY_DEFAULTS);
    CHECK(read_regs(&c,3,0,2,r,102)==9&&readfloat(r+3)==123.25f);
    CHECK(read_regs(&c,4,12,2,r,10200)==9&&(read32(r+3)&TX_STATUS_STALE));
}
static void test_nlf_registers(void)
{
    memflash_t m;tx_context_t c;uint8_t r[256];uint16_t w[94];float table[36];unsigned i;uint32_t crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);unlock(&c,r,1);
    for(i=0;i<36;i++){uint32_t bits;table[i]=1.5f-0.02f*(float)i;bits=floatbits(table[i]);w[2*i]=(uint16_t)(bits>>16);w[2*i+1]=(uint16_t)bits;}
    crc=nlf_factors_crc32(table);w[72]=0x5445;w[73]=0x5354;w[74]=(uint16_t)(crc>>16);w[75]=(uint16_t)crc;w[76]=0;w[77]=0;
    for(i=0;i<16;i++)w[78+i]=(uint16_t)(0x0102+0x0202*i);
    CHECK(write_words(&c,1,0x300,w,94,r,2)==8);CHECK(c.staged.nlf_flags_verified==0);
    CHECK(write_u32(&c,0x34C,NLF_VERIFIED_MAGIC,r,3)==8);CHECK(tx_params_valid(&c.staged));
    CHECK(commit(&c,r,4)==8);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION);
    CHECK(read_regs(&c,3,0x34C,2,r,5)==9&&read32(r+3)==NLF_VERIFIED_MAGIC);
    unlock(&c,r,6);CHECK(write_float(&c,0x300,1.51f,r,7)==8);CHECK(c.staged.nlf_flags_verified==0);
    expect_exception(r,write_u32(&c,0x34C,NLF_VERIFIED_MAGIC,r,8),16,3);CHECK(c.staged.nlf_flags_verified==0);
}
static void test_power_loss(void)
{
    memflash_t saved,m;tx_context_t c,boot;tx_params_t oldp,newp;int cut;unsigned i;
    clean(&saved);tx_protocol_init(&c,&flash,&saved,0);tx_params_defaults(&oldp);oldp.cell_constant=1.01f;
    CHECK(tx_storage_commit(&c,&oldp));tx_protocol_init(&c,&flash,&saved,0);CHECK(c.active.cell_constant==1.01f);
    newp=oldp;newp.cell_constant=1.02f;
    /* Every 32-bit program boundary, including valid-marker-last, loses power. */
    for(cut=0;cut<=(int)(TX_RECORD_BYTES/4);cut++) {
        bool ok;m=saved;tx_protocol_init(&c,&flash,&m,0);m.budget=cut;ok=tx_storage_commit(&c,&newp);m.budget=-1;
        tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.loaded_from_flash);
        if(cut<(int)(TX_RECORD_BYTES/4)){CHECK(!ok);CHECK(boot.active.cell_constant==1.01f&&boot.sequence==1);}
        else{CHECK(ok);CHECK(boot.active.cell_constant==1.02f&&boot.sequence==2);}
        CHECK(memcmp(m.page[0],saved.page[0],512)==0);
    }
    m=saved;tx_protocol_init(&c,&flash,&m,0);m.bad_erase=true;CHECK(!tx_storage_commit(&c,&newp));m.bad_erase=false;
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.active.cell_constant==1.01f);
    m=saved;tx_protocol_init(&c,&flash,&m,0);CHECK(tx_storage_commit(&c,&newp));
    /* Corrupt each committed header/payload/CRC byte individually: old slot wins. */
    for(i=0;i<TX_RECORD_BYTES;i++) {
        uint8_t value=m.page[1][i];m.page[1][i]^=1;tx_protocol_init(&boot,&flash,&m,0);
        CHECK(boot.loaded_from_flash&&boot.active.cell_constant==1.01f&&boot.sequence==1);m.page[1][i]=value;
    }
    memset(m.page,0xFF,sizeof m.page);tx_protocol_init(&boot,&flash,&m,0);CHECK(!boot.loaded_from_flash&&boot.active.gain_valid_mask==0);
    m.bad_read=true;tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.storage_fault&&!boot.loaded_from_flash);
}
static void test_maintenance(void)
{
    memflash_t m;tx_context_t c,boot;uint8_t r[256];uint16_t w[4]={1,1,2,3};uint32_t revision,crc;
    clean(&m);tx_protocol_init(&c,&flash,&m,0);
    expect_exception(r,write_words(&c,1,0x400,w,4,r,1),16,3);CHECK(c.maintenance.mode==0);
    unlock(&c,r,2);crc=tx_params_crc(&c.staged);CHECK(write_words(&c,1,0x400,w,4,r,3)==8);
    CHECK(c.maintenance.mode==1&&c.maintenance.frequency_index==1&&c.maintenance.gv_index==2&&c.maintenance.gi_index==3);
    CHECK(tx_params_crc(&c.staged)==crc);revision=c.maintenance.revision;
    CHECK(read_regs(&c,4,0xC,2,r,4)==9&&(read32(r+3)&TX_STATUS_MAINTENANCE));
    w[2]=4;expect_exception(r,write_words(&c,1,0x400,w,4,r,5),16,3);CHECK(c.maintenance.gv_index==2&&c.maintenance.revision==revision);
    CHECK(single(&c,0x404,0xA55A,r,20000)==8);tx_protocol_poll(&c,40000);CHECK(c.unlocked&&c.maintenance.mode==1);
    tx_protocol_poll(&c,50001);CHECK(!c.unlocked&&c.maintenance.mode==0&&c.maintenance.revision==revision+1);
    unlock(&c,r,50002);w[2]=2;CHECK(write_words(&c,1,0x400,w,4,r,50003)==8);CHECK(commit(&c,r,50004)==8);
    CHECK(c.maintenance.mode==1);CHECK(tx_protocol_after_reply(&c)==TX_APPLIED_CALIBRATION);CHECK(c.maintenance.mode==0);
    tx_protocol_init(&boot,&flash,&m,0);CHECK(boot.loaded_from_flash&&boot.maintenance.mode==0&&boot.maintenance.revision==0);
}
int main(void)
{
    test_crc_and_params();test_transactions();test_wire_errors_and_telemetry();test_nlf_registers();test_maintenance();test_power_loss();
    printf("PASS: %u protocol/storage checks (synthetic nLF integrity fixtures only; no hardware or ISO coefficient validation)\n",checks);
    return 0;
}
