#include "tx_protocol.h"
#include "../../compensation/nlf.h"
#include <math.h>
#include <string.h>

enum { EX_FUNCTION=1, EX_ADDRESS=2, EX_VALUE=3, EX_FAILURE=4, EX_BUSY=6 };
static uint16_t be16(const uint8_t *p) { return (uint16_t)(((uint16_t)p[0]<<8)|p[1]); }
static uint32_t be32(const uint8_t *p) { return ((uint32_t)be16(p)<<16)|be16(p+2); }
static void put_be16(uint8_t *p,uint16_t v) { p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v; }
static bool expired(uint32_t now,uint32_t deadline) { return (uint32_t)(now-deadline)<UINT32_C(0x80000000); }
static uint32_t fbits(float f) { uint32_t v;memcpy(&v,&f,4);return v; }
static float from_be_float(const uint8_t *p) { uint32_t v=be32(p);float f;memcpy(&f,&v,4);return f; }
static uint16_t word32(uint32_t v,unsigned low) { return (uint16_t)(low?v:(v>>16)); }
static void maintenance_auto(tx_context_t *c)
{if(c->maintenance.mode){c->maintenance.mode=0;c->maintenance.revision++;}}

uint16_t tx_modbus_crc16(const void *data,size_t bytes)
{
    const uint8_t *p=(const uint8_t*)data;uint16_t crc=0xFFFF;size_t i;unsigned j;
    for(i=0;i<bytes;i++) {crc^=p[i];for(j=0;j<8;j++)crc=(uint16_t)((crc>>1)^((crc&1)?0xA001:0));}
    return crc;
}
static size_t finish(uint8_t *p,size_t n) {uint16_t c=tx_modbus_crc16(p,n);p[n]=(uint8_t)c;p[n+1]=(uint8_t)(c>>8);return n+2;}
static size_t exception(uint8_t address,uint8_t function,unsigned code,uint8_t *p,size_t capacity)
{
    if(capacity<5)return 0;
    p[0]=address;p[1]=(uint8_t)(function|0x80);p[2]=(uint8_t)code;return finish(p,3);
}
void tx_protocol_init(tx_context_t *ctx,const tx_flash_ops_t *ops,void *user,uint32_t now_ms)
{
    memset(ctx,0,sizeof *ctx);if(ops)ctx->flash=*ops;ctx->flash_user=user;ctx->now_ms=now_ms;
    tx_params_defaults(&ctx->active);(void)tx_storage_load(ctx);ctx->staged=ctx->active;
    ctx->snapshot.conductivity_us_cm=NAN;ctx->snapshot.conductivity25_us_cm=NAN;
    ctx->snapshot.temperature_c=NAN;ctx->snapshot.conductance_s=NAN;
    ctx->snapshot.gain_table_index=0xFFFF;ctx->snapshot.sample_time_ms=now_ms;
    ctx->snapshot.status=TX_STATUS_SETTLING;
}
void tx_protocol_poll(tx_context_t *ctx,uint32_t now_ms)
{
    ctx->now_ms=now_ms;
    if(ctx->unlocked&&!ctx->pending_apply&&expired(now_ms,ctx->unlock_deadline_ms)) {
        ctx->unlocked=false;ctx->staged=ctx->active;maintenance_auto(ctx);
    }
}
void tx_protocol_set_snapshot(tx_context_t *ctx,const tx_snapshot_t *s) {ctx->snapshot=*s;}
const tx_params_t *tx_protocol_params(const tx_context_t *ctx) {return &ctx->active;}
const tx_maintenance_t *tx_protocol_maintenance(const tx_context_t *ctx) {return &ctx->maintenance;}
static uint32_t status(const tx_context_t *c)
{
    uint32_t s=c->snapshot.status;
    if(!(c->active.calibration_flags&TX_CAL_K))s|=TX_STATUS_UNCAL_K;
    if(!(c->active.calibration_flags&TX_CAL_TEMPERATURE))s|=TX_STATUS_UNCAL_TEMP;
    if(c->snapshot.gain_table_index>=32||!(c->active.gain_valid_mask&(UINT32_C(1)<<c->snapshot.gain_table_index)))s|=TX_STATUS_UNCAL_GAIN;
    if(c->storage_fault)s|=TX_STATUS_FLASH_FAULT;
    if(!c->loaded_from_flash)s|=TX_STATUS_FACTORY_DEFAULTS;
    if(c->now_ms-c->snapshot.sample_time_ms>10000u)s|=TX_STATUS_STALE;
    if(nlf_validate_fields(c->active.nlf_factor25,c->active.nlf_source_id,c->active.nlf_source_sha256,
       c->active.nlf_table_crc32,c->active.nlf_flags_verified)!=0)s|=TX_STATUS_NLF_UNVERIFIED;
    if(c->maintenance.mode)s|=TX_STATUS_MAINTENANCE;
    return s;
}
static bool input_word(const tx_context_t *c,uint16_t a,uint16_t *value)
{
    uint32_t d;unsigned low=a&1u;
    if(a<=7) {
        switch(a/2) {
        case 0:d=fbits(c->snapshot.conductivity_us_cm);break;
        case 1:d=fbits(c->snapshot.conductivity25_us_cm);break;
        case 2:d=fbits(c->snapshot.temperature_c);break;
        default:d=fbits(c->snapshot.conductance_s);break;
        }
        *value=word32(d,low);return true;
    }
    if(a<=0xF) {
        switch((a-8)/2) {
        case 0:d=(uint32_t)c->snapshot.raw_voltage_delta;break;
        case 1:d=(uint32_t)c->snapshot.raw_current_delta;break;
        case 2:d=status(c);break;
        default:d=c->snapshot.sample_counter;break;
        }
        *value=word32(d,low);return true;
    }
    switch(a) {
    case 0x10:*value=c->snapshot.frequency_hz;return true;
    case 0x11:*value=c->snapshot.gain_voltage;return true;
    case 0x12:*value=c->snapshot.gain_current;return true;
    case 0x13:*value=c->snapshot.gain_table_index;return true;
    case 0x14:case 0x15:*value=word32(c->now_ms,low);return true;
    case 0x16:case 0x17:*value=word32(c->now_ms-c->snapshot.sample_time_ms,low);return true;
    case 0x18:*value=TX_PROTOCOL_VERSION;return true;
    case 0x19:*value=0;return true;
    case 0x1A:case 0x1B:*value=word32(c->configuration_revision,low);return true;
    case 0x1C:case 0x1D:*value=word32(c->crc_error_count,low);return true;
    case 0x1E:case 0x1F:*value=word32(c->frame_error_count,low);return true;
    default:return false;
    }
}
static bool holding_word(const tx_context_t *c,uint16_t a,uint16_t *value)
{
    const tx_params_t *p=c->unlocked?&c->staged:&c->active;unsigned low=a&1u;
    if(input_word(c,a,value))return true;
    switch(a) {
    case 0x100:case 0x101:*value=word32(fbits(p->cell_constant),low);return true;
    case 0x102:case 0x103:*value=word32(fbits(p->temperature_gain),low);return true;
    case 0x104:case 0x105:*value=word32(fbits(p->temperature_offset),low);return true;
    case 0x106:*value=p->address;return true;
    case 0x107:*value=p->baud_code;return true;
    case 0x108:case 0x109:*value=word32(p->gain_valid_mask,low);return true;
    case 0x10A:*value=p->calibration_flags;return true;
    case 0x10B:*value=TX_PROTOCOL_VERSION;return true;
    case 0x10C:case 0x10D:*value=word32(fbits(200.0f),low);return true;
    case 0x400:*value=c->maintenance.mode;return true;
    case 0x401:*value=c->maintenance.frequency_index;return true;
    case 0x402:*value=c->maintenance.gv_index;return true;
    case 0x403:*value=c->maintenance.gi_index;return true;
    case 0x404:*value=0;return true;
    case 0x405:*value=0;return true;
    case 0x406:case 0x407:*value=word32(c->maintenance.revision,low);return true;
    case 0x7F00:case 0x7F01:case 0x7F02:case 0x7F03:case 0x7F04:case 0x7F05:*value=0;return true;
    case 0x7F06:case 0x7F07:*value=word32(tx_params_crc(&c->active),low);return true;
    case 0x7F08:case 0x7F09:*value=word32(tx_params_crc(&c->staged),low);return true;
    case 0x7F0A:*value=(uint16_t)((c->unlocked?1:0)|(c->pending_apply?2:0)|(c->loaded_from_flash?4:0)|(c->storage_fault?8:0));return true;
    case 0x7F0B:*value=(uint16_t)c->last_error;return true;
    case 0x7F0C:case 0x7F0D:*value=word32(c->sequence,low);return true;
    case 0x7F0E:case 0x7F0F:*value=word32(c->unlocked?c->unlock_deadline_ms-c->now_ms:0,low);return true;
    case 0x7F10:case 0x7F11:*value=0;return true;
    default:
        if(a>=0x200&&a<0x240) {
            unsigned ix=(a-0x200)/2,f=ix/16,v=(ix%16)/4,i=ix%4;
            *value=word32(fbits(p->gain_correction[f][v][i]),low);return true;
        }
        if(a>=0x300&&a<0x348) {
            *value=word32(fbits(p->nlf_factor25[(a-0x300)/2]),low);return true;
        }
        if(a>=0x348&&a<0x34E) {
            uint32_t d=a<0x34A?p->nlf_source_id:(a<0x34C?p->nlf_table_crc32:p->nlf_flags_verified);
            *value=word32(d,low);return true;
        }
        if(a>=0x34E&&a<0x35E) {
            unsigned n=(a-0x34E)*2;*value=(uint16_t)(((uint16_t)p->nlf_source_sha256[n]<<8)|p->nlf_source_sha256[n+1]);return true;
        }
        return false;
    }
}
static unsigned stage_words(tx_context_t *c,uint16_t a,uint16_t count,const uint8_t *data)
{
    tx_params_t p=c->staged;uint16_t n=0;
    if(!c->unlocked) {c->last_error=TX_STORE_LOCKED;return EX_VALUE;}
    while(n<count) {
        uint16_t r=(uint16_t)(a+n),w=be16(data+2*n);
        switch(r) {
        case 0x100:case 0x102:case 0x104:
            if(n+2>count)return EX_VALUE;
            if(r==0x100) {p.cell_constant=from_be_float(data+2*n);p.calibration_flags&=(uint16_t)~TX_CAL_K;}
            if(r==0x102) {p.temperature_gain=from_be_float(data+2*n);p.calibration_flags&=(uint16_t)~TX_CAL_TEMPERATURE;}
            if(r==0x104) {p.temperature_offset=from_be_float(data+2*n);p.calibration_flags&=(uint16_t)~TX_CAL_TEMPERATURE;}
            n+=2;break;
        case 0x101:case 0x103:case 0x105:case 0x109:return EX_VALUE;
        case 0x106:if(w>247||w==0)return EX_VALUE;p.address=(uint8_t)w;n++;break;
        case 0x107:if(w>4)return EX_VALUE;p.baud_code=(uint8_t)w;n++;break;
        case 0x108:if(n+2>count)return EX_VALUE;p.gain_valid_mask=be32(data+2*n);n+=2;break;
        case 0x10A:if(w&~(TX_CAL_K|TX_CAL_TEMPERATURE))return EX_VALUE;p.calibration_flags=w;n++;break;
        default:
            if(r>=0x200&&r<0x240) {
                unsigned ix=(r-0x200)/2,f=ix/16,v=(ix%16)/4,i=ix%4;
                if((r&1u)||n+2>count)return EX_VALUE;
                p.gain_correction[f][v][i]=from_be_float(data+2*n);p.gain_valid_mask|=UINT32_C(1)<<ix;n+=2;
            } else if(r>=0x300&&r<0x348) {
                if((r&1u)||n+2>count)return EX_VALUE;
                p.nlf_factor25[(r-0x300)/2]=from_be_float(data+2*n);p.nlf_flags_verified=0;n+=2;
            } else if(r>=0x348&&r<0x34E) {
                uint32_t value;if((r&1u)||n+2>count)return EX_VALUE;value=be32(data+2*n);
                if(r==0x348){p.nlf_source_id=value;p.nlf_flags_verified=0;}
                if(r==0x34A){p.nlf_table_crc32=value;p.nlf_flags_verified=0;}
                if(r==0x34C)p.nlf_flags_verified=value;
                n+=2;
            } else if(r>=0x34E&&r<0x35E) {
                unsigned ix=(r-0x34E)*2;p.nlf_source_sha256[ix]=(uint8_t)(w>>8);p.nlf_source_sha256[ix+1]=(uint8_t)w;p.nlf_flags_verified=0;n++;
            } else return EX_ADDRESS;
        }
    }
    if(!tx_params_valid(&p)) {c->last_error=TX_STORE_INVALID_PARAMS;return EX_VALUE;}
    c->staged=p;c->unlock_deadline_ms=c->now_ms+TX_UNLOCK_MS;c->last_error=TX_STORE_OK;return 0;
}
static unsigned control_words(tx_context_t *c,uint16_t a,uint16_t count,const uint8_t *p)
{
    if(a==0x7F00) {
        uint32_t k;if(count!=2)return EX_VALUE;k=be32(p);
        if(k==0) {c->unlocked=false;c->staged=c->active;c->last_error=TX_STORE_OK;maintenance_auto(c);return 0;}
        if(k!=TX_UNLOCK_KEY)return EX_VALUE;
        c->staged=c->active;c->unlocked=true;c->unlock_deadline_ms=c->now_ms+TX_UNLOCK_MS;c->last_error=TX_STORE_OK;return 0;
    }
    if(a==0x7F10) {
        if(!c->unlocked) {c->last_error=TX_STORE_LOCKED;return EX_VALUE;}
        if(count!=2||be32(p)!=TX_DEFAULTS_KEY)return EX_VALUE;
        tx_params_defaults(&c->staged);c->unlock_deadline_ms=c->now_ms+TX_UNLOCK_MS;c->last_error=TX_STORE_OK;return 0;
    }
    if(a==0x7F02) {
        if(!c->unlocked) {c->last_error=TX_STORE_LOCKED;return EX_VALUE;}
        if(count!=4||be32(p)!=TX_COMMIT_KEY)return EX_VALUE;
        if(be32(p+4)!=tx_params_crc(&c->staged)) {c->last_error=TX_STORE_BAD_CRC;return EX_VALUE;}
        if(c->have_committed_this_boot&&c->now_ms-c->last_commit_ms<TX_COMMIT_INTERVAL_MS) {c->last_error=TX_STORE_RATE_LIMIT;return EX_BUSY;}
        if(!tx_storage_commit(c,&c->staged))return EX_FAILURE;
        c->have_committed_this_boot=true;c->last_commit_ms=c->now_ms;c->pending_apply=true;
        return 0;
    }
    return EX_ADDRESS;
}
static unsigned maintenance_words(tx_context_t *c,uint16_t a,uint16_t count,const uint8_t *data)
{
    tx_maintenance_t p=c->maintenance;unsigned i;
    if(!c->unlocked){c->last_error=TX_STORE_LOCKED;return EX_VALUE;}
    if(a==0x404) {
        if(count!=1||be16(data)!=0xA55A)return EX_VALUE;
        c->unlock_deadline_ms=c->now_ms+TX_UNLOCK_MS;return 0;
    }
    if(a<0x400||(uint32_t)a+count>0x404u)return EX_ADDRESS;
    for(i=0;i<count;i++) {
        uint16_t value=be16(data+2*i);
        switch(a+i) {case 0x400:p.mode=value;break;case 0x401:p.frequency_index=value;break;case 0x402:p.gv_index=value;break;default:p.gi_index=value;break;}
    }
    if(p.mode>1||p.frequency_index>1||p.gv_index>3||p.gi_index>3)return EX_VALUE;
    if(p.mode!=c->maintenance.mode||p.frequency_index!=c->maintenance.frequency_index||p.gv_index!=c->maintenance.gv_index||p.gi_index!=c->maintenance.gi_index)p.revision++;
    c->maintenance=p;c->unlock_deadline_ms=c->now_ms+TX_UNLOCK_MS;c->last_error=TX_STORE_OK;return 0;
}
size_t tx_protocol_process(tx_context_t *c,const uint8_t *q,size_t bytes,uint8_t *r,size_t capacity,uint32_t now_ms)
{
    uint8_t function,address;uint16_t start,count;uint16_t crc;unsigned error;size_t i;
    tx_protocol_poll(c,now_ms);
    if(!q||!r||bytes<4||bytes>256) {c->frame_error_count++;return 0;}
    address=q[0];function=q[1];
    /* Protected calibration/configuration does not accept broadcast writes. */
    if(address==0||address!=c->active.address)return 0;
    crc=tx_modbus_crc16(q,bytes-2);
    if(q[bytes-2]!=(uint8_t)crc||q[bytes-1]!=(uint8_t)(crc>>8)) {c->crc_error_count++;return 0;}
    if(c->pending_apply)return exception(address,function,EX_BUSY,r,capacity);
    if(function==3||function==4) {
        if(bytes!=8) {c->frame_error_count++;return exception(address,function,EX_VALUE,r,capacity);}
        start=be16(q+2);count=be16(q+4);
        if(count==0||count>125||(uint32_t)start+count>65536u)return exception(address,function,EX_VALUE,r,capacity);
        if(capacity<(size_t)count*2+5)return 0;
        r[0]=address;r[1]=function;r[2]=(uint8_t)(count*2);
        for(i=0;i<count;i++) {
            uint16_t v;bool ok=function==4?input_word(c,(uint16_t)(start+i),&v):holding_word(c,(uint16_t)(start+i),&v);
            if(!ok)return exception(address,function,EX_ADDRESS,r,capacity);
            put_be16(r+3+i*2,v);
        }
        return finish(r,3+2*count);
    }
    if(function==6) {
        if(bytes!=8) {c->frame_error_count++;return exception(address,function,EX_VALUE,r,capacity);}
        if(capacity<8)return 0;
        start=be16(q+2);
        error=start>=0x400&&start<=0x407?maintenance_words(c,start,1,q+4):stage_words(c,start,1,q+4);
        if(error)return exception(address,function,error,r,capacity);
        memcpy(r,q,6);return finish(r,6);
    }
    if(function==16) {
        if(bytes<9) {c->frame_error_count++;return exception(address,function,EX_VALUE,r,capacity);}
        start=be16(q+2);count=be16(q+4);
        if(count==0||count>123||q[6]!=(unsigned)count*2||bytes!=(size_t)9+count*2||(uint32_t)start+count>65536u) {
            c->frame_error_count++;return exception(address,function,EX_VALUE,r,capacity);
        }
        if(capacity<8)return 0;
        if(start>=0x7F00)error=control_words(c,start,count,q+7);
        else if(start>=0x400&&start<=0x407)error=maintenance_words(c,start,count,q+7);
        else error=stage_words(c,start,count,q+7);
        if(error)return exception(address,function,error,r,capacity);
        memcpy(r,q,6);return finish(r,6);
    }
    return exception(address,function,EX_FUNCTION,r,capacity);
}
uint32_t tx_protocol_after_reply(tx_context_t *c)
{
    uint32_t changed=TX_APPLIED_NONE;
    if(c->pending_apply) {
        if(c->active.address!=c->staged.address||c->active.baud_code!=c->staged.baud_code)changed|=TX_APPLIED_COMMUNICATION;
        changed|=TX_APPLIED_CALIBRATION;c->active=c->staged;c->configuration_revision++;
        c->pending_apply=false;c->unlocked=false;maintenance_auto(c);
    }
    return changed;
}
