#include "tx_rtu_framer.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static uint32_t send_bytes(tx_rtu_framer *s,uint32_t t,unsigned count,unsigned base) {
 for(unsigned i=0;i<count;i++) {
  t+=s->character_ticks;
  tx_rtu_byte(s,(uint8_t)(base+i),t,false);
 }
 return t;
}
static uint32_t idle(tx_rtu_framer *s,uint32_t t) {
 t+=s->t35+s->character_ticks;tx_rtu_idle(s,t);return t;
}
int main(void) {
 tx_rtu_framer s;uint8_t out[256];uint32_t t=0xfffff000u;
 tx_rtu_init(&s,16000000,9600);
 assert(s.t15==27500&&s.t35==64167&&s.character_ticks==18334);
 t=send_bytes(&s,t,8,0);t=idle(&s,t);
 assert(tx_rtu_take(&s,out,sizeof(out))==8);
 for(unsigned i=0;i<8;i++)assert(out[i]==i);
 /* Receive-complete deltas include a full character beyond the silent gap. */
 for(unsigned test=0;test<3;test++) {
  tx_rtu_init(&s,16000000,9600);t=send_bytes(&s,t,4,0);
  uint32_t silence=test==0?s.character_ticks:test==1?s.t15:s.t15+1;
  t+=silence+s.character_ticks;tx_rtu_byte(&s,5,t,false);t=idle(&s,t);
  if(test<2)assert(tx_rtu_take(&s,out,sizeof(out))==5);
  else assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==1);
 }
 /* The next byte starts after 2.6T of silence and ends after 3.6T. Waiting an
  * extra character prevents replying to a truncated first frame at t3.5. */
 tx_rtu_init(&s,16000000,9600);t=send_bytes(&s,t,4,0);
 uint32_t previous=t;
 tx_rtu_idle(&s,previous+s.t35);assert(tx_rtu_take(&s,out,sizeof(out))==0);
 t+=s.character_ticks+(s.character_ticks*26u)/10u;tx_rtu_byte(&s,9,t,false);
 t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==0&&s.discarded==1);
 /* A true t3.5 silence starts a separate frame. */
 tx_rtu_init(&s,16000000,9600);t=send_bytes(&s,t,4,10);
 t+=s.t35+s.character_ticks;tx_rtu_byte(&s,20,t,false);
 assert(tx_rtu_take(&s,out,sizeof(out))==4&&out[0]==10);
 t=send_bytes(&s,t,3,21);t=idle(&s,t);
 assert(tx_rtu_take(&s,out,sizeof(out))==4&&out[0]==20);
 tx_rtu_init(&s,16000000,115200);
 assert(s.t15==12000&&s.t35==28000&&s.character_ticks==1528);
 t=send_bytes(&s,t,256,0);t=idle(&s,t);
 assert(tx_rtu_take(&s,out,sizeof(out))==256);
 t=send_bytes(&s,t,257,0);t=idle(&s,t);
 assert(tx_rtu_take(&s,out,sizeof(out))==0);
 tx_rtu_init(&s,16000000,115200);t=send_bytes(&s,t,8,10);
 t+=s.t35;t=send_bytes(&s,t,8,20);
 assert(tx_rtu_take(&s,out,sizeof(out))==8&&out[0]==10);
 t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==8&&out[0]==20);
 tx_rtu_init(&s,16000000,9600);
 for(unsigned i=0;i<8;i++) {
  t+=s.character_ticks;tx_rtu_byte(&s,(uint8_t)i,t,i==3);
 }
 t=idle(&s,t);assert(tx_rtu_take(&s,out,sizeof(out))==0);
 puts("PASS RTU: RX-complete timestamps, actual t1.5/t3.5 silence, conservative idle, wrap, parity/error, full/overlength ADU, pending frame");
 return 0;
}
