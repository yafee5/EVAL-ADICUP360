/* Exercise the real foreground application against a deterministic board HAL.
 * This verifies integration behavior; it does not emulate analog electronics. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#define main tx_device_main_not_called
#include "../src/main.c"
#undef main

static uint32_t mock_now,mock_epoch,mock_rx_delay;
static unsigned mock_adc0_starts,mock_adc1_starts,mock_uart_baud;
static uint8_t mock_flash[2][512],mock_request[256],mock_reply[256];
static size_t mock_request_length,mock_reply_length;
static bool mock_transmit_done,mock_adc1_ready,mock_adc0_ready;
static uint32_t mock_adc1_code,mock_adc1_fault;

static bool flash_read(void *u,unsigned slot,uint32_t offset,void *out,size_t n) {
 (void)u;assert(slot<2&&offset+n<=512);memcpy(out,mock_flash[slot]+offset,n);return true;
}
static bool flash_erase(void *u,unsigned slot) {
 (void)u;assert(slot<2);tx_board_adc_pause();mock_now+=20;
 memset(mock_flash[slot],255,512);return true;
}
static bool flash_program(void *u,unsigned slot,uint32_t offset,const void *in,size_t n) {
 (void)u;const uint8_t *p=in;assert(slot<2&&offset+n<=512&&!(offset&3u)&&!(n&3u));
 for(size_t i=0;i<n;i++) {assert((mock_flash[slot][offset+i]&p[i])==p[i]);mock_flash[slot][offset+i]=p[i];}
 mock_now+=2;return true;
}
const tx_flash_ops_t tx_board_flash_ops={flash_read,flash_erase,flash_program};
void tx_board_init(void){}
void tx_board_gains(unsigned v,unsigned i){assert(v<4&&i<4);}
void tx_board_pwm(unsigned f,bool invert){(void)invert;assert(f<2);}
void tx_board_adc0_begin(unsigned p){assert(p<4);mock_adc0_starts++;mock_adc0_ready=false;}
void tx_board_rtd_begin(unsigned p){assert(p<3);mock_adc1_starts++;}
void tx_board_adc_pause(void){mock_epoch++;mock_adc1_ready=mock_adc0_ready=false;}
bool tx_board_adc0_result(int32_t *code,uint32_t *fault){
 if(!mock_adc0_ready)return false;
 *code=100000000;*fault=0;mock_adc0_ready=false;return true;
}
bool tx_board_adc1_result(uint32_t *code,uint32_t *fault){
 if(!mock_adc1_ready)return false;
 *code=mock_adc1_code;*fault=mock_adc1_fault;mock_adc1_ready=false;return true;
}
void tx_board_uart_init(uint32_t b){mock_uart_baud=b;}
size_t tx_board_uart_receive(uint8_t *out,size_t cap){
 size_t n=mock_request_length;assert(n<=cap);memcpy(out,mock_request,n);mock_request_length=0;
 if(n){mock_now+=mock_rx_delay;mock_rx_delay=0;}return n;
}
void tx_board_uart_send(const uint8_t *buf,size_t n){assert(n<=256);memcpy(mock_reply,buf,n);mock_reply_length=n;}
bool tx_board_uart_transmitted(void){bool done=mock_transmit_done;mock_transmit_done=false;return done;}
uint32_t tx_board_uart_frame_errors(void){return 0;}
uint32_t tx_board_pause_epoch(void){return mock_epoch;}
uint32_t tx_board_millis(void){return mock_now;}
void tx_board_sleep(void){}
static void reset(void){
 mock_now=100;mock_epoch=mock_rx_delay=mock_adc0_starts=mock_adc1_starts=mock_uart_baud=0;
 mock_request_length=mock_reply_length=0;mock_transmit_done=mock_adc1_ready=mock_adc0_ready=false;
 memset(mock_flash,255,sizeof mock_flash);memset(&snapshot,0,sizeof snapshot);
 adc0_waiting=reply_waiting=diagnostic_ok=false;seen_maintenance_revision=0;seen_frame_errors=0;
 tx_protocol_init(&protocol,&tx_board_flash_ops,0,mock_now);tx_acq_init(&acquisition);
 snapshot.conductivity_us_cm=snapshot.conductivity25_us_cm=snapshot.temperature_c=snapshot.conductance_s=NAN;
 snapshot.status=TX_STATUS_SETTLING|TX_STATUS_RTD_FAULT;restart_measurement(mock_now);
}
static void put32be(uint8_t *p,uint32_t x){p[0]=x>>24;p[1]=x>>16;p[2]=x>>8;p[3]=x;}
static void queue_write(uint16_t a,uint16_t count,const uint8_t *data){
 mock_request[0]=1;mock_request[1]=16;mock_request[2]=a>>8;mock_request[3]=a;
 mock_request[4]=count>>8;mock_request[5]=count;mock_request[6]=(uint8_t)(2*count);
 memcpy(mock_request+7,data,2*count);size_t n=7+2*count;
 uint16_t crc=tx_modbus_crc16(mock_request,n);mock_request[n]=crc;mock_request[n+1]=crc>>8;
 mock_request_length=n+2;
}
int main(void){
 reset();uint8_t command[8];protocol.unlocked=true;protocol.unlock_deadline_ms=mock_now+30000;
 protocol.staged.cell_constant=1.1f;
 put32be(command,TX_COMMIT_KEY);put32be(command+4,tx_params_crc(&protocol.staged));
 queue_write(0x7F02,4,command);firmware_poll();
 assert(mock_now==124&&mock_reply_length==8&&reply_waiting&&protocol.pending_apply);
 assert(adc1_started==124&&!(snapshot.status&TX_STATUS_ADC_TIMEOUT));
 assert(protocol.active.cell_constant==1.f); /* no apply before final stop bit */
 mock_now+=2;firmware_poll();assert(protocol.active.cell_constant==1.f);
 mock_transmit_done=true;firmware_poll();
 assert(!reply_waiting&&!protocol.pending_apply&&protocol.active.cell_constant==1.1f);
 assert(!(snapshot.status&TX_STATUS_ADC_TIMEOUT));

 reset();adc0_waiting=true;adc0_started=100;mock_now=2101;
 firmware_poll();assert(!adc0_waiting&&adc0_due==2151&&acquisition.phase==0);
 mock_adc0_ready=true;mock_now=2110;firmware_poll();
 assert(mock_adc0_ready&&acquisition.phase==0&&!adc0_waiting);
 mock_now=2151;firmware_poll();
 assert(!mock_adc0_ready&&acquisition.phase==0&&adc0_waiting);

 reset();protocol.unlocked=true;protocol.unlock_deadline_ms=mock_now+30000;
 const uint8_t force[]={0,1,0,1,0,3,0,2};mock_rx_delay=2;
 queue_write(0x400,4,force);firmware_poll();
 assert(acquisition.forced&&acquisition.frequency_index==1&&acquisition.gv_index==3&&acquisition.gi_index==2);
 assert(acquisition.discard_cycles==1&&adc1_started==102);
 assert(snapshot.gain_voltage==1000&&snapshot.gain_current==100&&snapshot.frequency_hz==1000);
 assert(!(snapshot.status&TX_STATUS_ADC_TIMEOUT));
 mock_now=protocol.unlock_deadline_ms;firmware_poll();
 assert(!acquisition.forced&&protocol.maintenance.mode==0&&acquisition.discard_cycles==1);
 assert(!(snapshot.status&TX_STATUS_ADC_TIMEOUT));

 reset();snapshot.status=TX_STATUS_EC_VALID|TX_STATUS_TEMP_VALID;
 snapshot.conductivity_us_cm=125.f;snapshot.temperature_c=25.f;snapshot.conductance_s=.000125f;
 rtd_state=2;diagnostic_ok=true;rtd_status=0;mock_adc1_ready=true;mock_adc1_code=0;mock_adc1_fault=0;
 service_temperature(mock_now);
 assert(isnan(snapshot.temperature_c)&&isnan(snapshot.conductivity25_us_cm));
 assert(snapshot.conductivity_us_cm==125.f&&(snapshot.status&TX_STATUS_EC_VALID));
 assert((snapshot.status&(TX_STATUS_RTD_FAULT|TX_STATUS_RTD_SHORT))==(TX_STATUS_RTD_FAULT|TX_STATUS_RTD_SHORT));
 /* A healthy RTD restores actual temperature but never synthesizes a default
  * 25C substitute or enables an unprovisioned ISO nLF profile. */
 float r25=1000.f*(1.f+3.9083e-3f*25.f-5.775e-7f*625.f);
 float x=(r25*2000000.f/(r25+2000000.f))/(4990.f*2000000.f/(4990.f+2000000.f));
 rtd_state=2;diagnostic_ok=true;rtd_status=0;mock_adc1_ready=true;
 mock_adc1_code=(uint32_t)lroundf(x*268435456.f);mock_adc1_fault=0;
 service_temperature(mock_now);
 assert(fabsf(snapshot.temperature_c-25.f)<.001f&&(snapshot.status&TX_STATUS_TEMP_VALID));
 assert(isnan(snapshot.conductivity25_us_cm)&&!(snapshot.status&TX_STATUS_K25_VALID));
 puts("PASS foreground/HAL integration: Flash timestamp crossing, TEMT-delayed apply, late aborted ADC rejected, forced-mode restart/expiry, RTD fault preserves kT, nLF stays disabled");
 return 0;
}
