# 官方CN0359可编辑CAD补充查找：2026-10-22

本轮没有取得新的原始CAD压缩包，也没有生成主板Paste、CPL、IPC-356或电气DRC。现有Rev A工程CAM保持不变。

## 实际核实的下载路径

1. ADI当前[CN0359产品页](https://www.analog.com/en/resources/reference-designs/circuits-from-the-lab/cn0359.html)实际HTTP200，页面仍将“Design and Integration Files”指向：
   `https://www.analog.com/media/en/reference-design-documentation/design-integration-files/cn0359-designsupport.zip`
2. 使用禁止自动重定向的请求核实，上述ZIP入口并未返回ZIP，而是HTTP307转到：
   `https://form.analog.com/form_pages/securedownloads/cftlsecuredownload.aspx?returnUrl=media/en/reference-design-documentation/design-integration-files/cn0359-designsupport.zip`
3. 随后访问`form.analog.com`在本环境被代理CONNECT403拒绝。因此旧日志中的403不应解释为原ADI页面没有ZIP链接；更准确的是**官方ZIP链接目前转向受控下载表单，而本环境未能读取该表单，更未完成下载**。
4. 未提交表单、未注册或登录账号，也没有绕过下载门槛。没有文件就不能给压缩包SHA、目录清单或声称已经取得Allegro板文件。

原始网页另存`candidate_01.html`，其SHA见`CAD_source_status_20261022.json`。`download_attempts.json`和`redirect_inspection.json`记录真实HTTP/重定向结果，后者仅保留非敏感必要响应头。

## Rev B不能直接补成Rev A数据

2023归档wiki明确列有“Allegro Project”，同时其Rev A→B变更表说明：

- U5从ADP1613ARMZ改为ADP5072ACBZ-R7。
- 原U7 ADM3075EARZ移除，原U8 MCU在Rev B重编号为U7。
- U9从ADA4077-2ARZ改为ADA4077-2ARMZ，封装改变。
- U14从ADA4000-1ARZ改为ADA4522-1ARJZ。
- 显示、J2通信、J4下载接口及大量电源相关R/C/L也改变。

这证明Rev B涉及模拟/电源器件及封装，不能在没有实际板文件、逐层铜/孔/坐标对比的情况下称它为同布局的Rev A。尚未收到候选ZIP，所以没有进行几何比对；不能把变更日志当作几何一致性证明。

## 可执行的后续获取说明

应由资料持有人使用上述ADI正式下载入口取得原始DesignSupport档案，或向ADI技术支持索取**EVAL-CN0359-EB1Z Rev A、PADS 9.5原生PCB/ASCII、原网表、装配坐标、锡膏和叠层规则**。保留原始ZIP及SHA，再比较其铜层、钻孔、板框与本项目既有Rev A CAM。

若只拿到Rev B Allegro档案，它可作参考候选，不能直接替换Rev A。仍需按当前主板生产边界说明进行可信电气/坐标重建，才能发布主板贴片生产资料。
