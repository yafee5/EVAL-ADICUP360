#!/usr/bin/env python3
"""Derive Rev B0 branding from audited Rev A CAM without changing copper.
Run with toolchains/gerber-review/bin/python (gerbonara==1.6.3).
This does not construct missing CAD, placement, paste or electrical DRC files.
"""
from pathlib import Path
import dataclasses, hashlib, json, shutil, zipfile
from gerbonara import GerberFile, ExcellonFile, LayerStack
from gerbonara.cam import FileSettings
from gerbonara.utils import MM
from gerbonara.graphic_objects import Line
from gerbonara.apertures import Aperture, CircleAperture

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parents[2]
SOURCE=PROJECT/'hardware/v0.2/manufacturer/mainboard_4layer/checked_cam'
OUT=ROOT/'manufacturer'
OUT.mkdir(exist_ok=True)

def precise_definition(aperture,settings=None):
    unit=settings.unit if settings else None
    params='X'.join(f'{float(v):.10f}'.rstrip('0').rstrip('.') for v in aperture._params(unit) if v is not None)
    return aperture._gerber_shape_code+(','+params if params else '')
Aperture.to_gerber=precise_definition

# Coordinates in mm, same origin/view as original source Gerber. This free
# top-silk-only block contains the ADI logo, old identity and regulatory artwork.
REMOVE_BOX=((64.0,112.0),(116.0,129.0))

def intersects(a,b):
    return not (a[1][0]<b[0][0] or a[0][0]>b[1][0] or a[1][1]<b[0][1] or a[0][1]>b[1][1])

def sig(o):
    def norm(x):
        if isinstance(x,float):return round(x,5)
        if isinstance(x,dict):return {k:norm(v) for k,v in x.items()}
        if isinstance(x,(list,tuple)):return [norm(v) for v in x]
        return x
    return [(type(p).__name__,norm(dataclasses.asdict(p))) for p in o.to_primitives(unit=MM)]

# Plain vector-stroke lettering avoids external fonts, bitmap artwork or branding.
GLYPHS={
 'F':[[(0,0),(0,1),(0.65,1)],[(0,.55),(.5,.55)]],
 'W':[[(0,1),(.13,0),(.35,.55),(.57,0),(.7,1)]],
 'E':[[(.65,0),(0,0),(0,1),(.65,1)],[(0,.52),(.5,.52)]],
 'C':[[[.65,.12],[.5,0],[.15,0],[0,.18],[0,.82],[.15,1],[.5,1],[.65,.88]]],
 'T':[[(0,1),(.7,1)],[(.35,1),(.35,0)]],
 'X':[[(0,0),(.7,1)],[(0,1),(.7,0)]],
 'R':[[(0,0),(0,1),(.5,1),(.65,.85),(.65,.65),(.5,.5),(0,.5)],[(.35,.5),(.7,0)]],
 'V':[[(0,1),(.35,0),(.7,1)]],
 'B':[[(0,0),(0,1),(.45,1),(.65,.82),(.65,.68),(.45,.5),(0,.5)],[(.45,.5),(.68,.32),(.68,.18),(.45,0),(0,0)]],
 '0':[[(.15,0),(0,.2),(0,.8),(.15,1),(.5,1),(.65,.8),(.65,.2),(.5,0),(.15,0)]],
 '-':[[(0,.5),(.6,.5)]],
 ' ':[]}

def text_objects(text,x,y,height,stroke):
    ap=CircleAperture(stroke,unit=MM)
    objects=[]
    for character in text:
        for path in GLYPHS[character]:
            for a,b in zip(path,path[1:]):
                objects.append(Line(x+a[0]*height,y+a[1]*height,x+b[0]*height,y+b[1]*height,aperture=ap,unit=MM))
        x+=height*.95
    return objects

report={'board':'FW-EC-TX Rev B0','base':'ADI EVAL-CN0359-EB1Z Rev A / v0.2 audited CAM',
        'check_scope':'CAM byte comparison and silk primitive preservation; NOT electrical or assembly DRC',
        'silk_removed_box_mm':REMOVE_BOX,'layers':{}}
for p in sorted(SOURCE.iterdir()):
    target=OUT/p.name.replace('CN0359','FW_EC_TX_B0')
    if p.suffix!='.GTO':
        shutil.copyfile(p,target)
        assert target.read_bytes()==p.read_bytes()
        report['layers'][p.name]={'output':target.name,'byte_identical':True,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
        continue
    g=GerberFile.open(p)
    retained=[];removed=[]
    for o in g.objects:
        if intersects(o.bounding_box(unit=MM),REMOVE_BOX):removed.append(o)
        else:retained.append(o)
    added=text_objects('FW-EC-TX',70,122,2,.18)+text_objects('REV B0',70,118,1.65,.16)
    assert all(intersects(o.bounding_box(unit=MM),REMOVE_BOX) for o in added)
    g.objects=retained+added
    g.save(target,settings=FileSettings(unit=MM,number_format=(4,7),zeros='leading'))
    txt=target.read_text().replace('\nG75\n','\nG75*\n')
    if '\nG75*\n' not in txt:txt=txt.replace('%MOMM*%','%MOMM*%\nG75*',1)
    target.write_text(txt)
    reread=GerberFile.open(target)
    assert len(reread.objects)==len(retained)+len(added)
    for before,after in zip(retained+added,reread.objects):assert sig(before)==sig(after)
    (ROOT/'preview_top_silkscreen.svg').write_text(str(g.to_svg()))
    report['layers'][p.name]={'output':target.name,'byte_identical':False,'retained_objects':len(retained),
        'removed_objects':len(removed),'added_objects':len(added),'retained_and_added_primitive_roundtrip':True,
        'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}

report['copper_layers_unchanged']=all(report['layers'][n]['byte_identical'] for n in ['CN0359.GTL','CN0359.G2','CN0359.G3','CN0359.GBL'])
report['drill_outline_masks_bottom_silk_unchanged']=all(v['byte_identical'] for k,v in report['layers'].items() if k!='CN0359.GTO')
report['electrical_DRC']='NOT_GENERATED: no native PCB + authoritative layout netlist'
report['ipc356']='NOT_GENERATED: no authoritative pad/net assignments'
report['cpl']='NOT_GENERATED: no authoritative component origins/rotations and pin-1 mapping'
report['paste_GTP_GBP']='NOT_GENERATED: original CAM has no paste and DNP-aware aperture data not reconstructed'
(ROOT/'cam_derivation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

originals=PROJECT/'hardware/v0.2/sources'
entries=[]
for name in ['eval-cn0359-eb1z-grb-reva.zip','eval-cn0359-eb1z-bom-reva.xlsx','eval-cn0359-eb1z-padsschematic-reva.pdf','cn0359-sourcecode-reva.zip','source_manifest.json']:
    source=originals/name;dest=ROOT/'sources_original'/name;shutil.copyfile(source,dest)
    entries.append({'file':name,'bytes':source.stat().st_size,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(ROOT/'sources_original/SHA256SUMS').write_text(''.join(v['sha256']+'  '+v['file']+'\n' for v in entries))
(OUT/'README_CAM_FIRST.txt').write_text('FW-EC-TX REV B0 MAINBOARD - ENGINEERING BARE BOARD CAM ONLY\n'
    'Four copper layers are unchanged from official Rev A / v0.2. Only top silk branding changes.\n'
    'Layer order: GTL=L1, G2=L2, G3=L3, GBL=L4. Do not assume G2/G3 single-net planes.\n'
    'Proposed stackup: FR4 finished 1.6mm, outer 35um / inner 17.5um. Vendor must confirm actual stack.\n'
    'No mainboard paste GTP/GBP, CPL or IPC356 has been generated. No electrical PCB DRC performed.\n'
    'Do not order automatic PCB assembly from this CAM set. Read full engineering release status.\n'
    'No automated copper optimization, scaling, mirroring or removal of internal slot.\n',encoding='utf-8')
roles={'.GTL':('top','copper'),'.G2':('inner_1','copper'),'.G3':('inner_2','copper'),'.GBL':('bottom','copper'),
       '.GTS':('top','mask'),'.GBS':('bottom','mask'),'.GTO':('top','silk'),'.GBO':('bottom','silk'),'.GKO':('mechanical','outline')}
layers={role:GerberFile.open(OUT/('FW_EC_TX_B0'+suffix)) for suffix,role in roles.items()}
stack=LayerStack(graphic_layers=layers,drill_pth=ExcellonFile.open(OUT/'FW_EC_TX_B0_explicit_metric.drl'),board_name='FW-EC-TX Rev B0')
for side in ['top','bottom']:(ROOT/f'preview_{side}_board.svg').write_text(str(stack.to_pretty_svg(side=side,margin=2)))
with zipfile.ZipFile(ROOT/'FW_EC_TX_B0_mainboard_CAM_ENGINEERING_ONLY.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.iterdir()):z.write(p,p.name)
    for name in ['cam_derivation_report.json','DRC_and_production_status_NOT_RELEASED.json','README_主板生产边界.md']:
        if (ROOT/name).exists():z.write(ROOT/name,name)

print(json.dumps(report,ensure_ascii=False,indent=2))
