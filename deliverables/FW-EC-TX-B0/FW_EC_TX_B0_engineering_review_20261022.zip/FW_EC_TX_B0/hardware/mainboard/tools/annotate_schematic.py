#!/usr/bin/env python3
"""Assembly ECO overlay on original PDF; not a reconstructed electrical CAD."""
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'sources_original/eval-cn0359-eb1z-padsschematic-reva.pdf'
doc=fitz.open(SOURCE)
notes=[
 ['DNP UI: U1(+connector), S1(+knob), U2, U6, R6/7/8/9/18, Q1, D4, C27/28/33/34/35.',
  'DNP original bus: U7, R10, J2. Preserve J4, C1/C43 and R17 (BM pull-up). External RS485 only on isolated J485.',
  'R13 = 4.99k / 0.01% / <=2ppm/K; four-wire Pt1000 only; 200uA. RTD faults are not replaced by 25C.'],
 ['Power ECO retained: DNP U4, L2, D3, C17. Regulated +5.0 V +/-2% input.',
  'ADP3338-3.3 adapter -> L5 pin1 (B); L5 pin3 is GND. Never parallel the old switching 3.3 V supply.',
  'UI and original nonisolated communication are unpopulated. See isolation-board schematic for all new bus wiring.'],
 ['R47 = 1.000 kOhm / 0.01% / <=5 ppm/K. DNP old R19/29/37/48 + R20/31/38/52; use matched adapters.',
  'LT5400BIMS8E-7: Rin=6.25k, Rf=1k, ratio=0.16, <=2ppm/K ratio drift. Loading +20% vs original; verify.',
  'Original analog copper/topology retained. This PDF records assembly changes; it is not netlisted editable CAD.']]
for i,page in enumerate(doc):
    page.insert_text((56,9),'FW-EC-TX REV B0 - ASSEMBLY ECO OVERLAY ON ORIGINAL ADI REV A SCHEMATIC',fontsize=8,color=(.75,.05,.05))
    page.draw_rect(fitz.Rect(56,14,page.rect.width-56,53),color=(.8,.1,.1),fill=(1,.98,.94),width=.7)
    remaining=page.insert_textbox(fitz.Rect(64,16,page.rect.width-64,53),'\n'.join(notes[i]),fontsize=8,fontname='helv',color=(.75,.05,.05))
    assert remaining>=0,('ECO text overflow',i,remaining)
    if i==0:
        for name in ['U1','S1','U2','U6','R6','R7','R8','R9','R18','Q1','D4','C27','C28','C33','C34','C35','U7','R10','J2']:
            for box in page.search_for(name):
                if box.y0<56:continue
                mark=page.add_rect_annot(box+(-2,-2,2,2));mark.set_colors(stroke=(.85,.05,.05));mark.update()
        for box in page.search_for('1.50k'):
            mark=page.add_strikeout_annot(box);mark.set_colors(stroke=(.85,.05,.05));mark.update()
    if i==2:
        for name in ['R19','R29','R37','R48','R20','R31','R38','R52']:
            for box in page.search_for(name):
                if box.y0<56:continue
                mark=page.add_rect_annot(box+(-2,-2,2,2));mark.set_colors(stroke=(.85,.05,.05));mark.update()
    if i==1:
        for name in ['U4','L2','D3','C17']:
            for box in page.search_for(name):
                if box.y0<56:continue
                mark=page.add_rect_annot(box+(-2,-2,2,2));mark.set_colors(stroke=(.85,.05,.05));mark.update()
OUT=ROOT/'mainboard_RevB0_assembly_ECO.pdf'
doc.save(OUT,garbage=3,deflate=True)
print(OUT)
