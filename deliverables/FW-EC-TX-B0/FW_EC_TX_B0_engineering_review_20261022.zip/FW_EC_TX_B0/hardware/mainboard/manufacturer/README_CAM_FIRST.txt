FW-EC-TX REV B0 MAINBOARD - ENGINEERING BARE BOARD CAM ONLY
Four copper layers are unchanged from official Rev A / v0.2. Only top silk branding changes.
Layer order: GTL=L1, G2=L2, G3=L3, GBL=L4. Do not assume G2/G3 single-net planes.
Proposed stackup: FR4 finished 1.6mm, outer 35um / inner 17.5um. Vendor must confirm actual stack.
No mainboard paste GTP/GBP, CPL or IPC356 has been generated. No electrical PCB DRC performed.
Do not order automatic PCB assembly from this CAM set. Read full engineering release status.
No automated copper optimization, scaling, mirroring or removal of internal slot.
