#!/usr/bin/python3
"""Export only this adapter's production files from its native KiCad design."""
import os, subprocess, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'manufacturer';OUT.mkdir(exist_ok=True)
NAME='FW_EC_RATIO_B0'
env=dict(os.environ)
env.update(XDG_CONFIG_HOME='/workspace/toolchains/kicad-config',XDG_CACHE_HOME='/tmp/ratio-kicad-cache',XDG_DATA_HOME='/tmp/ratio-kicad-data')
pcb=str(ROOT/(NAME+'.kicad_pcb'));sch=str(ROOT/(NAME+'.kicad_sch'))
commands=[
 ['kicad-cli','sch','erc',sch,'--format','json','-o',str(ROOT/'erc.json')],
 ['kicad-cli','pcb','drc',pcb,'--schematic-parity','--format','json','-o',str(ROOT/'drc.json')],
 ['kicad-cli','sch','export','pdf',sch,'-o',str(ROOT/(NAME+'_schematic.pdf'))],
 ['kicad-cli','sch','export','netlist',sch,'--format','kicadxml','-o',str(ROOT/(NAME+'_netlist.xml'))],
 ['kicad-cli','pcb','export','gerbers',pcb,'--layers','F.Cu,B.Cu,F.Paste,B.Paste,F.SilkS,B.SilkS,F.Mask,B.Mask,Edge.Cuts','--use-drill-file-origin','-o',str(OUT)+'/', '--subtract-soldermask'],
 ['kicad-cli','pcb','export','drill',pcb,'--format','excellon','--drill-origin','plot','--excellon-units','mm','--excellon-zeros-format','decimal','--excellon-separate-th','--generate-map','--map-format','pdf','-o',str(OUT)+'/'],
 ['kicad-cli','pcb','export','ipcd356',pcb,'-o',str(OUT/(NAME+'.ipc'))],
 ['kicad-cli','pcb','export','pos',pcb,'--format','csv','--units','mm','--side','both','--use-drill-file-origin','--exclude-dnp','-o',str(OUT/'CPL_KiCad_native.csv')],
 ['kicad-cli','pcb','export','pdf',pcb,'--layers','F.Cu,B.Cu,F.SilkS,B.SilkS,Edge.Cuts','-o',str(ROOT/(NAME+'_pcb_layers.pdf'))],
]
logs=[]
for cmd in commands:
    r=subprocess.run(cmd,env=env,cwd=ROOT,capture_output=True,text=True)
    logs.append({'command':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    if r.returncode:raise RuntimeError(str(cmd)+r.stderr+r.stdout)
    print(r.stdout.strip())
(ROOT/'export_log.json').write_text(json.dumps(logs,indent=2))
drc=json.loads((ROOT/'drc.json').read_text());erc=json.loads((ROOT/'erc.json').read_text())
assert not drc['violations'] and not drc['unconnected_items'] and not drc['schematic_parity']
assert sum(len(s['violations']) for s in erc['sheets'])==0
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt')
(OUT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in files))
print('Adapter ERC/DRC/parity clean; exports',len(files))
