#!/usr/bin/python3
"""Generate a genuine KiCad adapter for one LT5400BIMS8E-7. Not a mainboard CAD reconstruction."""
import os, json, csv, uuid, subprocess, hashlib, math
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','/workspace/toolchains/kicad-config'),('XDG_CACHE_HOME','/tmp/ratio-kicad-cache'),('XDG_DATA_HOME','/tmp/ratio-kicad-data')]:
    os.environ.setdefault(k,v);Path(os.environ[k]).mkdir(parents=True,exist_ok=True)
import pcbnew as p
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'manufacturer';OUT.mkdir(exist_ok=True)
NAME='FW_EC_RATIO_B0'
UID=lambda s:str(uuid.uuid5(uuid.NAMESPACE_URL,'fw-ec-ratio-b0/'+s))
ROOTID=UID('root')
mm=p.FromMM
vec=lambda x,y:p.VECTOR2I(mm(x),mm(y))
FP='Package_SO:MSOP-8-1EP_3x3mm_P0.65mm_EP1.68x1.88mm'
NETS={'1':'IN','2':'MID','3':'SUM','4':'SUM','5':'OUT','6':'OUT','7':'SUM','8':'MID','9':'AGND'}
PADS={'1':('IN',51.5,52),'2':('SUM',51.5,60),'3':('SUM',60.5,60),'4':('OUT',60.5,52),'5':('AGND',56,61)}
def effects(sz=1.27,hidden=False):return f'(effects (font (size {sz} {sz}))'+(' (hide yes)' if hidden else '')+')'
def pin(n,name,x,y,ang):return f'(pin passive line (at {x} {y} {ang}) (length 2.54) (name "{name}" {effects(1.0)}) (number "{n}" {effects(1.0)}))'
def sym(key,pins,texts=[]):
    text=''.join(f'(text "{txt}" (at {x} {y} 0) {effects(.9)})' for txt,x,y in texts)
    return f'''(symbol "RatioAdapter:{key}" (pin_names (offset 0.5)) (exclude_from_sim no) (in_bom yes) (on_board yes)
 (property "Reference" "U" (at 0 16 0) {effects()}) (property "Value" "{key}" (at 0 -16 0) {effects(1.0)})
 (symbol "{key}_0_1" (rectangle (start -7.62 12.7) (end 7.62 -12.7) (stroke (width 0.254) (type default)) (fill (type background))) {text})
 (symbol "{key}_1_1" {''.join(pin(*v) for v in pins)}))'''
u_pins=[('1','R1_A',-10.16,7.62,0),('2','R2_A',-10.16,2.54,0),('3','R3_A',-10.16,-2.54,0),('4','R4_A',-10.16,-7.62,0),
        ('8','R1_B',10.16,7.62,180),('7','R2_B',10.16,2.54,180),('6','R3_B',10.16,-2.54,180),('5','R4_B',10.16,-7.62,180),('9','EP',0,-15.24,90)]
j_pins=[(str(i),name,-10.16,y,0) for i,name,y in [(1,'IN',10.16),(2,'SUM_A',5.08),(3,'SUM_B',0),(4,'OUT',-5.08),(5,'AGND',-10.16)]]
libs=[sym('LT5400_7',u_pins,[('5k',0,7.62),('1.25k',0,2.54),('1.25k',0,-2.54),('5k',0,-7.62)]),sym('WIRE_PADS',j_pins)]
def inst(ref,value,key,x,y,fp,physical=True):
    props=f'(property "Reference" "{ref}" (at {x} {y-18} 0) {effects()}) (property "Value" "{value}" (at {x} {y+18} 0) {effects(1)}) (property "Footprint" "{fp}" (at {x} {y} 0) {effects(hidden=True)})'
    return f'(symbol (lib_id "RatioAdapter:{key}") (at {x} {y} 0) (unit 1) (in_bom {"yes" if physical else "no"}) (on_board yes) (dnp no) (uuid {UID(ref)}) {props} (instances (project "{NAME}" (path "/{ROOTID}" (reference "{ref}") (unit 1)))))'
def wire_label(net,x,y,right=False,key=''):
    endx=x+(12.7 if right else -12.7)
    return f'(wire (pts (xy {x} {y}) (xy {endx} {y})) (stroke (width 0) (type default)) (uuid {UID("wire"+key)})) (label "{net}" (at {endx} {y} 0) (effects (font (size 1 1)) (justify {"right" if right else "left"} bottom)) (uuid {UID("label"+key)}))'
SX,SY,JX=111.76,76.2,200.66
items=[inst('U1','LT5400BIMS8E-7#PBF','LT5400_7',SX,SY,FP),inst('J1','PCB_WIRE_PADS','WIRE_PADS',JX,SY,'RatioAdapter:WirePads_4plusG',False)]
for n,_,x,y,_ in u_pins:
    if n=='9':
        px,py=SX+x,SY-y
        items.append(f'(wire (pts (xy {px} {py}) (xy {px} {py+7.62})) (stroke (width 0) (type default)) (uuid {UID("wireEP")})) (label "AGND" (at {px} {py+7.62} 0) {effects(1)} (uuid {UID("labelEP")}))')
    else:items.append(wire_label(NETS[n],SX+x,SY-y,x>0,'U1'+n))
for n,_,x,y,_ in j_pins:items.append(wire_label(PADS[n][0],JX+x,SY-y,False,'J1'+n))
notes=[
 ('FW-EC-TX Rev B0: one adapter per attenuator; four adapters total.',30,120),
 ('Rin = R1 + R2 = 6.25k. Rf = R3 || R4 = 1k. Rf/Rin = 0.16.',30,126),
 ('Pin 8 links pin 2 (MID). Pins 7,3,4 connect SUM. Pins 6,5 connect OUT.',30,132),
 ('Mainboard DNP R19/R20; R29/R31; R37/R38; R48/R52. Preserve 820pF feedback caps.',30,138),
 ('J1.1=held input; J1.2 and J1.3=same summing node; J1.4=opamp output; J1.5=quiet AGND.',30,144),
 ('This preserves ratio, NOT original absolute 7.5k/1.2k. LT5400 B-grade absolute tolerance +/-15%.',30,150),
 ('EP/AGND is a quiet shield, never RS485 isolated ground or chassis. Read assembly note.',30,156),
 ('Prototype adapter: loop length, parasitic capacitance and mechanical fit require bench validation.',30,162)]
for txt,x,y in notes:items.append(f'(text "{txt}" (at {x} {y} 0) (effects (font (size 1 1)) (justify left)) (uuid {UID(txt)}))')
sch=f'''(kicad_sch (version 20250114) (generator "eeschema") (uuid {ROOTID}) (paper "A4")
 (title_block (title "FW-EC-TX ratio adapter - LT5400-7 0.16 attenuation") (date "2026-10-21") (rev "B0") (company "Independent adapter; original analog copper retained"))
 (lib_symbols {''.join(libs)}) {''.join(items)} (embedded_fonts no))'''
(ROOT/(NAME+'.kicad_sch')).write_text(sch)
(ROOT/'RatioAdapter.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor") '+''.join(libs).replace('(symbol "RatioAdapter:','(symbol "')+')')
(ROOT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "RatioAdapter") (type "KiCad") (uri "${KIPRJMOD}/RatioAdapter.kicad_sym") (options "") (descr "LT5400-7 verified pinout")))')
(ROOT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Package_SO") (type "KiCad") (uri "${KICAD9_FOOTPRINT_DIR}/Package_SO.pretty") (options "") (descr "KiCad standard")) (lib (name "RatioAdapter") (type "KiCad") (uri "${KIPRJMOD}/RatioAdapter.pretty") (options "") (descr "Wire lands, no fitted connector")))')
b=p.BOARD();b.SetFileName(str(ROOT/(NAME+'.kicad_pcb')))
b.GetDesignSettings().SetCopperLayerCount(2);b.GetDesignSettings().SetBoardThickness(mm(.8))
b.GetDesignSettings().SetAuxOrigin(vec(50,62))
nets={}
for i,n in enumerate(['IN','MID','SUM','OUT','AGND'],1):
    net=p.NETINFO_ITEM(b,'/'+n,i);b.Add(net);nets[n]=net
fp=p.FootprintLoad('/usr/share/kicad/footprints/Package_SO.pretty',FP.split(':')[1]);assert fp
fp.SetReference('U1');fp.SetValue('LT5400BIMS8E-7#PBF');fp.SetPosition(vec(56,56));fp.SetFPID(p.LIB_ID(*FP.split(':')))
path=p.KIID_PATH();path.push_back(p.KIID(ROOTID));path.push_back(p.KIID(UID('U1')));fp.SetPath(path)
for pad in fp.Pads():
    if pad.GetNumber() in NETS:pad.SetNet(nets[NETS[pad.GetNumber()]])
fp.Value().SetVisible(False);fp.Reference().SetPosition(vec(56,53.2));fp.Reference().SetTextSize(vec(.8,.8));fp.Reference().SetTextThickness(mm(.12))
b.Add(fp)
# Unpopulated through-hole wire lands; J1 is a PCB feature, not a connector to buy.
j=p.FOOTPRINT(b);j.SetReference('J1');j.SetValue('PCB_WIRE_PADS');j.SetPosition(vec(56,56));j.SetFPID(p.LIB_ID('RatioAdapter','WirePads_4plusG'))
j.SetAttributes(p.FP_THROUGH_HOLE|p.FP_EXCLUDE_FROM_BOM|p.FP_EXCLUDE_FROM_POS_FILES)
path=p.KIID_PATH();path.push_back(p.KIID(ROOTID));path.push_back(p.KIID(UID('J1')));j.SetPath(path)
for n,(net,x,y) in PADS.items():
    layers=p.LSET.AllCuMask();layers.AddLayer(p.F_Mask);layers.AddLayer(p.B_Mask)
    pad=p.PAD(j);pad.SetNumber(n);pad.SetAttribute(p.PAD_ATTRIB_PTH);pad.SetShape(p.PAD_SHAPE_CIRCLE);pad.SetSize(vec(1.2,1.2));pad.SetDrillSize(vec(.6,.6));pad.SetLayerSet(layers);pad.SetPosition(vec(x,y));pad.SetNet(nets[net]);j.Add(pad)
j.Reference().SetVisible(False);j.Value().SetVisible(False);b.Add(j)
lib=ROOT/'RatioAdapter.pretty';lib.mkdir(exist_ok=True)
p.PCB_IO_MGR.PluginFind(p.PCB_IO_MGR.KICAD_SEXP).FootprintSave(str(lib),j)
def xy(n):
    for pad in fp.Pads():
        if pad.GetNumber()==str(n):q=pad.GetPosition();return (p.ToMM(q.x),p.ToMM(q.y))
def seg(net,pts,w=.2,layer=p.F_Cu):
    for a,c in zip(pts,pts[1:]):
        t=p.PCB_TRACK(b);t.SetStart(vec(*a));t.SetEnd(vec(*c));t.SetWidth(mm(w));t.SetLayer(layer);t.SetNet(nets[net]);b.Add(t)
def via(net,x,y):
    v=p.PCB_VIA(b);v.SetPosition(vec(x,y));v.SetWidth(p.F_Cu,mm(.6));v.SetDrill(mm(.3));v.SetViaType(p.VIATYPE_THROUGH);v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetNet(nets[net]);b.Add(v)
seg('IN',[xy(1),(52.3,53.525),(51.5,52)])
seg('MID',[xy(2),(52.6,55.675)]);via('MID',52.6,55.675)
seg('MID',[xy(8),(59.5,54.4)]);via('MID',59.5,54.4)
seg('MID',[(52.6,55.675),(52.6,53.6),(59.5,53.6),(59.5,54.4)],.2,p.B_Cu)
seg('SUM',[xy(3),(52.7,56.325),(51.5,57.525),(51.5,60)])
seg('SUM',[xy(4),(53.2,57.575),(51.5,59.275),(51.5,60)])
seg('SUM',[xy(7),(59.4,55.675)]);via('SUM',59.4,55.675)
seg('SUM',[(59.4,55.675),(59.4,58),(60.5,59.1),(60.5,60),(51.5,60)],.2,p.B_Cu)
seg('OUT',[xy(6),(59.8,56.325),(60.5,55.625),(60.5,52)])
seg('OUT',[xy(5),(59.8,56.975),(60.5,56.275),(60.5,52)])
seg('AGND',[xy(9),(56,61)],.25)
for a,c in [((50,50),(62,50)),((62,50),(62,62)),((62,62),(50,62)),((50,62),(50,50))]:
    s=p.PCB_SHAPE();s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*c));s.SetLayer(p.Edge_Cuts);s.SetWidth(mm(.05));b.Add(s)
def text(txt,x,y,size=.7,layer=p.F_SilkS):
    size=max(size,.8)
    t=p.PCB_TEXT(b);t.SetText(txt);t.SetPosition(vec(x,y));t.SetTextSize(vec(size,size));t.SetTextThickness(mm(.1));t.SetLayer(layer);t.SetMirrored(layer==p.B_SilkS);b.Add(t)
text('FW-RATIO B0',56,51,.7)
for txt,x,y in [('I',51.5,53.7),('S',51.5,58.3),('S',60.5,58.3),('O',60.5,53.7),('G',56,59.4)]:text(txt,x,y)
text('6.25k / 1k',56,51.2,.65,p.B_SilkS)
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b);b.BuildConnectivity();p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
pro={'board':{'design_settings':{'rules':{'min_clearance':.15,'min_track_width':.15,'min_via_diameter':.6,'min_through_hole_diameter':.3,'min_hole_to_hole':.25,'min_copper_edge_clearance':.3}}},'meta':{'filename':NAME+'.kicad_pro','version':1},'net_settings':{'classes':[{'name':'Default','clearance':.15,'track_width':.2,'via_diameter':.6,'via_drill':.3,'microvia_diameter':.3,'microvia_drill':.1,'diff_pair_width':.2,'diff_pair_gap':.2,'diff_pair_via_gap':.2,'bus_width':12,'line_style':0,'wire_width':6,'pcb_color':'rgba(0,0,0,0)','schematic_color':'rgba(0,0,0,0)'}],'net_colors':None,'netclass_assignments':None,'netclass_patterns':[]}}
(ROOT/(NAME+'.kicad_pro')).write_text(json.dumps(pro,indent=2))
metadata={'board':NAME,'size_mm':[12,12],'layers':2,'thickness_mm':.8,'outer_copper_um':35,'network_mpn':'LT5400BIMS8E-7#PBF','network_qty_per_board':1,'boards_per_instrument':4,'wire_lands':PADS,'pins':NETS,'resistors_ohm':{'R1':5000,'R2':1250,'R3':1250,'R4':5000},'Rin_ohm':6250,'Rf_ohm':1000,'ratio':.16,'absolute_tolerance_percent':15,'ratio_tolerance_percent':.025,'ratio_drift_ppm_per_K_derived_upper_bound':1,'assembly_mechanical_fit_verified':False,'motherboard_copper_changed':False,'notes':['Unpopulated J1 is a PCB wire-land feature, not a purchased connector.','Connect short low-leakage insulated wires to existing DNP resistor pads. Maximum preferred free wire length 5 mm subject to fit.','Quiet AGND shield wire J1.5 is separate from the four original resistor lands; EP may not connect to noisy digital/isolated ground.','Mainboard keeps 820pF feedback capacitors. Electrical and mechanical fit require bench validation.']}
(ROOT/'ratio_adapter_netlist.json').write_text(json.dumps(metadata,indent=2))
with (ROOT/'ratio_adapter_bom.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['Reference','Qty_per_adapter','Qty_per_instrument','Value','Footprint','Manufacturer','MPN','DigiKey_part_number','Status','Note'])
    w.writerow(['U1',1,4,'6.25k/1k equivalent = 0.16',FP,'Analog Devices','LT5400BIMS8E-7#PBF','未联网核实；用完整MPN向DigiKey/ADI询价','MPN在官方订货表/产品页；库存未确认','B-grade ratio match0.025%, max matching drift1ppm/K; absolute±15%'])
    w.writerow(['J1',0,0,'5 bare wire lands','RatioAdapter:WirePads_4plusG','','PCB feature, no electronic purchase','','PCB feature','Four resistor-land wires + quiet AGND shield wire'])
with (OUT/'CPL_mm_lower_left.csv').open('w',newline='') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['Designator','Mid X','Mid Y','Rotation','Layer','Units','Origin','Note']);w.writerow(['U1',6,6,0,'Top','mm','board lower-left (50,62) in native CAD','KiCad orientation0deg, pin1 at left-upper when viewed from Top; 4 adapters per instrument'])
print('Generated',NAME,'pads', {i:xy(i) for i in range(1,10)})
