#!/usr/bin/env python3
"""Audit exported pin nets and physical placement, and quantify this network's bounds."""
from pathlib import Path
from itertools import product
from xml.etree import ElementTree as ET
import csv, json, math, re, hashlib, zipfile
ROOT=Path(__file__).resolve().parent
NAME='FW_EC_RATIO_B0'
tree=ET.parse(ROOT/(NAME+'_netlist.xml'))
actual={}
for net in tree.findall('./nets/net'):
    for node in net.findall('node'):actual[(node.attrib['ref'],node.attrib['pin'])]=net.attrib['name']
expected={('U1',str(k)):'/'+v for k,v in {1:'IN',2:'MID',3:'SUM',4:'SUM',5:'OUT',6:'OUT',7:'SUM',8:'MID',9:'AGND'}.items()}
expected.update({('J1',str(k)):'/'+v for k,v in {1:'IN',2:'SUM',3:'SUM',4:'OUT',5:'AGND'}.items()})
assert actual==expected,'Schematic does not implement reviewed LT5400 pin topology'
ipc={}
for line in (ROOT/'manufacturer'/f'{NAME}.ipc').read_text().splitlines():
    m=re.match(r'3[12]7(\S+)\s+(U1|J1)\s+-(\d+)\s',line)
    if m:ipc[(m[2],m[3])]=m[1]
assert ipc==expected,'IPC-356 does not match physical pad nets'
cpl=list(csv.DictReader((ROOT/'manufacturer'/'CPL_KiCad_native.csv').open()))
assert len(cpl)==1 and cpl[0]['Ref']=='U1'
assert (float(cpl[0]['PosX']),float(cpl[0]['PosY']),float(cpl[0]['Rot']),cpl[0]['Side'])==(6.,6.,0.,'top')
drc=json.loads((ROOT/'drc.json').read_text());erc=json.loads((ROOT/'erc.json').read_text())
assert not drc['violations'] and not drc['unconnected_items'] and not drc['schematic_parity']
assert sum(len(s['violations']) for s in erc['sheets'])==0
for suffix in ['gtl','gbl','gtp','gbp','gts','gbs','gto','gbo','gm1']:
    assert len(list((ROOT/'manufacturer').glob('*.'+suffix)))==1
# The graph comes from the exported schematic's terminal assignment and the
# datasheet's independent internal resistor pairs (1-8,2-7,3-6,4-5).
values=[5000,1250,1250,5000]
edges=[(actual[('U1',str(a))],actual[('U1',str(b))],r) for (a,b),r in zip([(1,8),(2,7),(3,6),(4,5)],values)]
assert edges==[('/IN','/MID',5000),('/MID','/SUM',1250),('/SUM','/OUT',1250),('/SUM','/OUT',5000)]
def ratio(v):return (v[2]*v[3]/(v[2]+v[3]))/(v[0]+v[1])
assert abs(ratio(values)-.16)<1e-15
delta=.00025
ratio_errors=[ratio([r*z for r,z in zip(values,zs)])/.16-1 for zs in product([1,1+delta],repeat=4)]
max_drift=0
for a1,a2,a3,a4 in product([0.,1.],repeat=4):
    ain=(values[0]*a1+values[1]*a2)/(values[0]+values[1])
    af=(values[3]*a3+values[2]*a4)/(values[2]+values[3])
    max_drift=max(max_drift,abs(af-ain))
assert max_drift==1.
report={
 'design':NAME,'checks':{'schematic_export_pin_nets_match_review':True,'ipc356_pad_nets_match_schematic':True,'native_CPL_matches_board':True,
 'all_nine_Gerber_layers_present':True,'ERC_violations':0,'DRC_violations':0,'unconnected':0,'schematic_parity_issues':0},
 'Rin_nominal_ohm':6250,'Rf_nominal_ohm':1000,'ratio':.16,'load_change_nominal_percent':20,
 'feedback_pole_nominal_Hz':1/(2*math.pi*1000*820e-12),'feedback_pole_original_Hz':1/(2*math.pi*1200*820e-12),
 'feedback_pole_Hz_with_only_15percent_absolute_spread':[1/(2*math.pi*1150*820e-12),1/(2*math.pi*850*820e-12)],
 'corner_ratio_relative_error_range': [min(ratio_errors),max(ratio_errors)],'matching_TCR_corner_upper_bound_ppm_per_K':max_drift,
 'source_LT5400_RevC_sha256':hashlib.sha256((ROOT/'sources'/'LT5400.pdf').read_bytes()).hexdigest(),
 'hardware_tests_performed':False,'mechanical_fit_verified':False,'mainboard_DRC_performed':False,
 'limitations':['These are exported-design checks and datasheet-derived calculations, not physical precision tests.','The adapter preserves ratio0.16, not absolute7.5k/1.2k.','DigiKey SKU, price and stock are unverified.']}
(ROOT/'validation_ratio_adapter.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
with zipfile.ZipFile(ROOT/'FW_EC_RATIO_B0_manufacturer.zip','w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted((ROOT/'manufacturer').iterdir()):
        if file.is_file():z.write(file,file.name)
print(json.dumps(report,ensure_ascii=False,indent=2))
