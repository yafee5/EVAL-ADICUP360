%TF.GenerationSoftware,KiCad,Pcbnew,9.0.2+dfsg-1*%
%TF.CreationDate,2026-10-21T01:31:53+00:00*%
%TF.ProjectId,FW_EC_RATIO_B0,46575f45-435f-4524-9154-494f5f42302e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2+dfsg-1) date 2026-10-21 01:31:53*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.200000*%
%ADD11RoundRect,0.100000X-0.625000X-0.100000X0.625000X-0.100000X0.625000X0.100000X-0.625000X0.100000X0*%
%ADD12R,1.680000X1.880000*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X1500000Y10000000D03*
X1500000Y2000000D03*
X10500000Y2000000D03*
X10500000Y10000000D03*
X6000000Y1000000D03*
%TD*%
D11*
%TO.C,U1*%
X3850000Y6975000D03*
X3850000Y6325000D03*
X3850000Y5675000D03*
X3850000Y5025000D03*
X8150000Y5025000D03*
X8150000Y5675000D03*
X8150000Y6325000D03*
X8150000Y6975000D03*
D12*
X6000000Y6000000D03*
%TD*%
M02*
