"""Deterministic clearance-aware grid router for this small two-layer module.

Final acceptance is KiCad's independent DRC and schematic parity, not this router.
The two electrical domains have non-overlapping spatial routing bounds.
"""
import json,math,heapq,time
from collections import defaultdict
from pathlib import Path
import numpy as np
import pcbnew as p

def route_board(board,parts,nets,root):
    STEP=.2;OX=20.;OY=20.;NX=501;NY=401;PLANE=NX*NY
    WIDTH=.30;CLEAR=.25;VIA_D=.60;VIA_DR=.30
    occ=np.zeros((2,NY,NX),dtype=np.uint64)
    via_forbid=np.zeros((NY,NX),dtype=bool)
    bit={n:1<<i for i,n in enumerate(nets)};ALL=(1<<len(bit))-1
    mm=p.FromMM;vec=lambda x,y:p.VECTOR2I(mm(x),mm(y))
    gx=lambda x:round((x-OX)/STEP);gy=lambda y:round((y-OY)/STEP)
    pos=lambda x,y:(OX+x*STEP,OY+y*STEP)
    endpoints=defaultdict(list);thru=set();pads=[];escapes=[]
    def rect(x1,y1,x2,y2,b,layers=(0,1),vf=False):
        ix1=max(0,math.ceil((x1-OX)/STEP));ix2=min(NX-1,math.floor((x2-OX)/STEP));iy1=max(0,math.ceil((y1-OY)/STEP));iy2=min(NY-1,math.floor((y2-OY)/STEP))
        if ix1>ix2 or iy1>iy2:return
        if vf:via_forbid[iy1:iy2+1,ix1:ix2+1]=True
        else:
            for layer in layers:occ[layer,iy1:iy2+1,ix1:ix2+1]|=np.uint64(b)
    def disk(x,y,r,b,layers=(0,1),vf=False):
        ix1=max(0,math.ceil((x-r-OX)/STEP));ix2=min(NX-1,math.floor((x+r-OX)/STEP));iy1=max(0,math.ceil((y-r-OY)/STEP));iy2=min(NY-1,math.floor((y+r-OY)/STEP))
        for iy in range(iy1,iy2+1):
            py=OY+iy*STEP
            for ix in range(ix1,ix2+1):
                px=OX+ix*STEP
                if (px-x)**2+(py-y)**2<=r*r+1e-8:
                    if vf:via_forbid[iy,ix]=True
                    else:
                        for layer in layers:occ[layer,iy,ix]|=np.uint64(b)
    def occupy_line(a,c,b,layer,r):
        x1,y1=a;x2,y2=c
        ix1=max(0,math.ceil((min(x1,x2)-r-OX)/STEP));ix2=min(NX-1,math.floor((max(x1,x2)+r-OX)/STEP));iy1=max(0,math.ceil((min(y1,y2)-r-OY)/STEP));iy2=min(NY-1,math.floor((max(y1,y2)+r-OY)/STEP))
        den=(x2-x1)**2+(y2-y1)**2
        for iy in range(iy1,iy2+1):
            py=OY+iy*STEP
            for ix in range(ix1,ix2+1):
                px=OX+ix*STEP;t=max(0,min(1,((px-x1)*(x2-x1)+(py-y1)*(y2-y1))/den)) if den else 0
                if (px-x1-t*(x2-x1))**2+(py-y1-t*(y2-y1))**2<=r*r+1e-8:occ[layer,iy,ix]|=np.uint64(b)
    for fp in board.GetFootprints():
        for pad in fp.Pads():
            x,y=p.ToMM(pad.GetPosition().x),p.ToMM(pad.GetPosition().y)
            sx,sy=p.ToMM(pad.GetSize().x),p.ToMM(pad.GetSize().y)
            n=pad.GetNetname().lstrip('/')
            if pad.GetAttribute()==p.PAD_ATTRIB_NPTH:
                disk(x,y,max(sx,sy)/2+.45,ALL);disk(x,y,max(sx,sy)/2+.55,ALL,vf=True);continue
            if not n:continue
            bb=pad.GetBoundingBox();x1,y1=p.ToMM(bb.GetX()),p.ToMM(bb.GetY());x2,y2=x1+p.ToMM(bb.GetWidth()),y1+p.ToMM(bb.GetHeight())
            ls=(0,1) if pad.GetAttribute()==p.PAD_ATTRIB_PTH else (0,)
            rect(x1-WIDTH/2-CLEAR,y1-WIDTH/2-CLEAR,x2+WIDTH/2+CLEAR,y2+WIDTH/2+CLEAR,bit[n],ls)
            rect(x1-.45,y1-.45,x2+.45,y2+.45,ALL,vf=True)
            if fp.GetReference()=='U1':
                ex=x+(-1.95 if int(pad.GetNumber())<=10 else 1.95)
                ix,iy=gx(ex),gy(y)
                endpoints[n].append((ix,iy,0,ex,y,fp.GetReference(),pad.GetNumber()))
                escapes.append((n,x,y,ex));thru.add((ix,iy))
            else:
                ix,iy=gx(x),gy(y);endpoints[n].append((ix,iy,0,x,y,fp.GetReference(),pad.GetNumber()))
            pads.append((n,x1,y1,x2,y2))
            if len(ls)==2:thru.add((ix,iy))
    # Reserve real regulator output copper before routing. Other nets may not
    # cross either heat-spreading area; otherwise late-added zones/vias could
    # be disconnected or a thermal tie could short a routed return.
    for n,box in [('3V3_MAIN',(38.5,30,46.5,38)),('3V3_COM',(53,69.5,60,75.5))]:
        rect(*box,bit[n],layers=(0,1))
    # There must be no routed conductor between the two domains below U1.
    primary={'PGND','5V_IN','3V3_MAIN','3V3_COM','RX_COM','TX_COM','DE_COM','RX_MCU','TX_MCU','DE_MCU'}
    lower=gx(20.6);upper=gx(119.4);lowy=gy(20.6);highy=gy(99.4)
    def limits(n):return(lower,gx(71.4)) if n in primary else(gx(78.6),upper)
    def block(x,y,l,other):return bool(int(occ[l,y,x])&other)
    moves=[(1,0,1.),(-1,0,1.),(0,1,1.),(0,-1,1.),(1,1,1.41421356),(1,-1,1.41421356),(-1,1,1.41421356),(-1,-1,1.41421356)]
    via_moves=[(dx,dy) for dx in [-1,0,1] for dy in [-1,0,1]]
    def astar(start,target,n):
        sx,sy,sl=start;tx,ty,tl=target;lo,hi=limits(n);other=ALL^bit[n]
        def heuristic(x,y,l):
            a,b=abs(x-tx),abs(y-ty);return max(a,b)+.41421356*min(a,b)+(0 if l==tl else 1)
        s=sl*PLANE+sy*NX+sx;t=tl*PLANE+ty*NX+tx
        q=[(heuristic(sx,sy,sl),0.,s)];dist={s:0.};prev={};expanded=0
        while q:
            _,g,node=heapq.heappop(q)
            if g>dist.get(node,1e20)+1e-8:continue
            if node==t:
                path=[node]
                while node!=s:node=prev[node];path.append(node)
                path.reverse();return[(v%PLANE%NX,v%PLANE//NX,v//PLANE) for v in path],expanded
            layer=node//PLANE;y=node%PLANE//NX;x=node%NX;expanded+=1
            if expanded>850000:break
            for dx,dy,cost in moves:
                xx=x+dx;yy=y+dy
                if xx<lo or xx>hi or yy<lowy or yy>highy:continue
                if block(xx,yy,layer,other):continue
                # Prevent diagonal corner cutting into expanded copper obstacles.
                if dx and dy and (block(x+dx,y,layer,other) or block(x,y+dy,layer,other)):continue
                nn=layer*PLANE+yy*NX+xx;gg=g+cost*(1. if ((layer==0 and dx) or(layer==1 and dy)) else 1.05)
                if gg+1e-8<dist.get(nn,1e20):dist[nn]=gg;prev[nn]=node;heapq.heappush(q,(gg+heuristic(xx,yy,layer),gg,nn))
            th=(x,y) in thru
            if th or not via_forbid[y,x]:
                nl=1-layer;safe=not block(x,y,nl,other)
                if safe and not th:
                    for dx,dy in via_moves:
                        xx=x+dx;yy=y+dy
                        if not (0<=xx<NX and 0<=yy<NY) or block(xx,yy,0,other) or block(xx,yy,1,other):safe=False;break
                if safe:
                    nn=nl*PLANE+y*NX+x;gg=g+(0.25 if th else 16.)
                    if gg+1e-8<dist.get(nn,1e20):dist[nn]=gg;prev[nn]=node;heapq.heappush(q,(gg+heuristic(x,y,nl),gg,nn))
        return None,expanded
    def track(n,a,c,layer):
        if math.dist(a,c)<1e-8:return
        tr=p.PCB_TRACK(board);tr.SetStart(vec(*a));tr.SetEnd(vec(*c));tr.SetWidth(mm(WIDTH));tr.SetLayer(p.F_Cu if layer==0 else p.B_Cu);tr.SetNet(nets[n]);board.Add(tr)
        occupy_line(a,c,bit[n],layer,WIDTH+CLEAR+.04)
    madevias=set()
    def via(n,x,y):
        key=(n,round(x,3),round(y,3))
        if key in madevias:return
        madevias.add(key);v=p.PCB_VIA(board);v.SetPosition(vec(x,y));v.SetWidth(p.F_Cu,mm(VIA_D));v.SetDrill(mm(VIA_DR));v.SetViaType(p.VIATYPE_THROUGH);v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetNet(nets[n]);board.Add(v)
        disk(x,y,VIA_D/2+CLEAR+WIDTH/2+.04,bit[n])
    for n,x,y,ex in escapes:
        track(n,(x,y),(ex,y),0);via(n,ex,y)
    reports=[]
    # Signals first, broad return nets last. Net names are deterministic.
    order=['GND_DC','VISO_OUT','VISO_IN','A','B','TERM_LINK','RX_MCU','TX_MCU','DE_MCU','RX_COM','TX_COM','DE_COM','3V3_COM','3V3_MAIN','5V_IN','ISO_GND','PGND']
    for n in order:
        pts=endpoints[n];assert pts,n
        connected=[pts[0]];left=pts[1:]
        while left:
            # Minimum spanning tree across actual pads; existing same-net routes remain traversable.
            _,i,j=min(((a[0]-c[0])**2+(a[1]-c[1])**2,i,j) for i,a in enumerate(connected) for j,c in enumerate(left))
            a=connected[i];c=left[j];path,expanded=astar(a[:3],c[:3],n)
            if path is None:
                reports.append({'net':n,'from':a[5:],'to':c[5:],'result':'unrouted','expanded':expanded});print('UNROUTED',n,a[5:],c[5:],flush=True);connected.append(left.pop(j));continue
            # Exact pad-center to snapped-grid anchors are both inside the pad copper.
            track(n,(a[3],a[4]),pos(path[0][0],path[0][1]),0)
            first=path[0];last=first;direction=None
            for node in path[1:]:
                if node[2]!=last[2]:
                    track(n,pos(first[0],first[1]),pos(last[0],last[1]),last[2])
                    if (node[0],node[1]) not in thru:via(n,*pos(node[0],node[1]))
                    first=node;direction=None
                else:
                    nd=(node[0]-last[0],node[1]-last[1])
                    if direction is not None and nd!=direction:track(n,pos(first[0],first[1]),pos(last[0],last[1]),last[2]);first=last
                    direction=nd
                last=node
            track(n,pos(first[0],first[1]),pos(last[0],last[1]),last[2]);track(n,pos(last[0],last[1]),(c[3],c[4]),0)
            reports.append({'net':n,'from':a[5:],'to':c[5:],'result':'routed','expanded':expanded,'grid_steps':len(path)})
            print('ROUTED',n,a[5:],c[5:],len(path),'steps',flush=True)
            connected.append(left.pop(j))
    # Ground copper is split. No plane below the two isoPower ferrites.
    def zone(n,layer,points,priority=0):
        z=p.ZONE(board);z.SetLayer(layer);z.SetNet(nets[n]);z.SetLocalClearance(mm(.25));z.SetThermalReliefGap(mm(.25));z.SetThermalReliefSpokeWidth(mm(.35));z.SetAssignedPriority(priority);z.SetPadConnection(p.ZONE_CONNECTION_THERMAL)
        out=z.Outline();out.NewOutline()
        for x,y in points:out.Append(mm(x),mm(y))
        board.Add(z)
    zone('PGND',p.B_Cu,[(20.5,20.5),(71.4,20.5),(71.4,99.5),(20.5,99.5)])
    zone('ISO_GND',p.B_Cu,[(78.6,20.5),(119.5,20.5),(119.5,99.5),(78.6,99.5),(78.6,64.7),(92.3,64.7),(92.3,56.5),(78.6,56.5)])
    # Dedicated output copper; SOT223 TAB is OUT, never PGND.
    for n,box in [('3V3_MAIN',(38.5,30,46.5,38)),('3V3_COM',(53,69.5,60,75.5))]:
        x1,y1,x2,y2=box
        for layer in [p.F_Cu,p.B_Cu]:zone(n,layer,[(x1,y1),(x2,y1),(x2,y2),(x1,y2)],1)
        count=0
        for x in np.arange(x1+.7,x2-.3,1.5):
            for y in np.arange(y1+.7,y2-.3,1.5):
                ix,iy=gx(x),gy(y);other=ALL^bit[n]
                if not via_forbid[iy,ix] and not any(block(ix+dx,iy+dy,l,other) for dx,dy in via_moves for l in [0,1]):
                    via(n,float(x),float(y))
                    tx,ty=(39.15,35.) if n=='3V3_MAIN' else (53.15,74.)
                    # A real, wide copper tie to the TAB is required; thermal
                    # vias must not rely on a fill island to establish their net.
                    track(n,(float(x),float(y)),(float(x),ty),0)
                    track(n,(float(x),ty),(tx,ty),0)
                    count+=1
                if count>=6:break
            if count>=6:break
    board.BuildConnectivity();p.SaveBoard(str(root/'fw_ec_tx_iso_power_b0.kicad_pcb'),board)
    # Reload establishes KiCad's PROJECT/settings pointer; filling a freshly
    # constructed BOARD can segfault in KiCad 9's ZONE_FILLER bindings.
    board=p.LoadBoard(str(root/'fw_ec_tx_iso_power_b0.kicad_pcb'))
    board.BuildConnectivity();filler=p.ZONE_FILLER(board);filler.Fill(board.Zones())
    (root/'routing_report.json').write_text(json.dumps({'grid_step_mm':STEP,'trace_width_mm':WIDTH,'clearance_target_mm':CLEAR,'via_mm':[VIA_D,VIA_DR],'primary_route_max_x_mm':71.4,'secondary_route_min_x_mm':78.6,'edges':reports},indent=2))
    print('Router completed',len(reports),'edges;',sum(x['result']=='unrouted' for x in reports),'unrouted',flush=True)
    return board
