#!/usr/bin/python3
"""Generate an independent, editable 2-layer isolated RS485 + dual-LDO module.

This is not an invented editable version of the original ADI motherboard.
Pin maps come from ADM2587E Rev H, ADP3338 and ADI UG-1266.
"""
import os,json,csv,uuid,math
from pathlib import Path
for k,v in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
    os.environ.setdefault(k,'/tmp/kicad-iso/'+v);Path(os.environ[k]).mkdir(parents=True,exist_ok=True)
import pcbnew as p
ROOT=Path(__file__).resolve().parent
NAME='fw_ec_tx_iso_power_b0'
UID=lambda s:str(uuid.uuid5(uuid.NAMESPACE_URL,'fw-ec-tx-iso-power-b0/'+s))
ROOTID=UID('root');mm=p.FromMM
vec=lambda x,y:p.VECTOR2I(mm(x),mm(y))
LIB=Path('/usr/share/kicad/footprints')
CAP='Capacitor_SMD:C_0805_2012Metric';RES='Resistor_SMD:R_0805_2012Metric'
R1206='Resistor_SMD:R_1206_3216Metric';SOT223='Package_TO_SOT_SMD:SOT-223-3_TabPin2'
ADM='Package_SO:SOIC-20W_7.5x12.8mm_P1.27mm';SOT23='Package_TO_SOT_SMD:SOT-23'
HEAD4='Connector_PinHeader_2.54mm:PinHeader_1x04_P2.54mm_Vertical'
HEAD2='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical'
TERM4='TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-4-5.08_1x04_P5.08mm_Horizontal'
TERM3='TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-3-5.08_1x03_P5.08mm_Horizontal'
HOLE='MountingHole:MountingHole_3.2mm_M3'
grid=lambda v:round(round(v/1.27)*1.27,5)
parts=[]
def add(ref,val,fp,xy,pins,mpn,note,sch=None,dnp=False):
    parts.append(dict(ref=ref,value=val,footprint=fp,xy=list(xy),pins=pins,mpn=mpn,description=note,sch=tuple(grid(v) for v in sch) if sch else None,dnp=dnp))
add('U1','ADM2587EBRWZ',ADM,(75,50),{'1':'PGND','2':'3V3_COM','3':'PGND','4':'RX_COM','5':'DE_COM','6':'DE_COM','7':'TX_COM','8':'3V3_COM','9':'PGND','10':'PGND','11':'GND_DC','12':'VISO_OUT','13':'A','14':'GND_DC','15':'B','16':'ISO_GND','17':'B','18':'A','19':'VISO_IN','20':'ISO_GND'},'ADM2587EBRWZ','500 kbps isolated RS485; VCC=3.3V; U1.11/14 isolated converter return through FB2; U1.16/20 external bus ground',sch=(210,75))
add('U2','ADP3338-3.3 MAIN',SOT223,(36,35),{'1':'PGND','2':'3V3_MAIN','3':'5V_IN'},'ADP3338AKCZ-3.3RL7','MAIN independent 3.3V to motherboard L5.1; 200mA continuous design target only',sch=(60,60))
add('U3','ADP3338-3.3 COM',SOT223,(50,74),{'1':'PGND','2':'3V3_COM','3':'5V_IN'},'ADP3338AKCZ-3.3RL7','COM independent 3.3V for ADM2587E; never parallel MAIN and COM outputs',sch=(60,130))
caps=[('C1',(28,38),'5V_IN','PGND','10u/25V','GRM21BR61E106KA73L'),('C2',(42,40),'3V3_MAIN','PGND','10u/25V','GRM21BR61E106KA73L'),('C3',(43,78),'5V_IN','PGND','10u/25V','GRM21BR61E106KA73L'),('C4',(57,77),'3V3_COM','PGND','10u/25V','GRM21BR61E106KA73L'),('C5',(66,44),'3V3_COM','PGND','100n/25V','GRM21BR71E104KA01L'),('C6',(66,47),'3V3_COM','PGND','10n/50V','GRM216R71H103KA01D'),('C7',(66,54),'3V3_COM','PGND','100n/25V','GRM21BR71E104KA01L'),('C8',(61,57),'3V3_COM','PGND','10u/25V','GRM21BR61E106KA73L'),('C9',(84,58),'VISO_OUT','GND_DC','10u/25V','GRM21BR61E106KA73L'),('C10',(84,55),'VISO_OUT','GND_DC','100n/25V','GRM21BR71E104KA01L'),('C11',(84,44),'VISO_IN','ISO_GND','100n/25V','GRM21BR71E104KA01L'),('C12',(84,47),'VISO_IN','ISO_GND','10n/50V','GRM216R71H103KA01D')]
for ix,(ref,xy,a,c,val,mpn) in enumerate(caps):
    add(ref,val,CAP,xy,{'1':a,'2':c},mpn,'0805 MLCC; 10u parts require effective C>=1uF with bias; ADM power pins follow Rev H decoupling',sch=(175+(ix%4)*60,190+(ix//4)*35))
add('FB1','1k8 @100MHz',CAP,(90,58.5),{'1':'VISO_OUT','2':'VISO_IN'},'BLM21BD182SN1D','Ferrite impedance high at 180/360MHz; verify current/DC resistance from Murata data; no ground pour below FB1/FB2',sch=(290,75))
add('FB2','1k8 @100MHz',CAP,(90,63),{'1':'GND_DC','2':'ISO_GND'},'BLM21BD182SN1D','Only bridge between converter-return GND_DC and bus ISO_GND; no second direct copper connection',sch=(290,110))
add('R1','10k 1%',RES,(55,46),{'1':'DE_COM','2':'PGND'},'RC0805FR-0710KL','DE pulldown; receiver enabled and driver disabled during MCU reset',sch=(145,110))
add('R2','120R 1% 0.25W',R1206,(106,68),{'1':'A','2':'TERM_LINK'},'RC1206FR-07120RL','Optional termination fitted physically, enabled only by JP1; default jumper OPEN',sch=(350,75))
add('R3','1k 1%',RES,(64,27),{'1':'RX_MCU','2':'RX_COM'},'RC0805FR-071KL','UART receiver series resistor limits injection; not a full Ioff/partial power-down guarantee',sch=(145,60))
add('R4','1k 1%',RES,(64,29.54),{'1':'TX_MCU','2':'TX_COM'},'RC0805FR-071KL','UART transmitter series resistor; avoid powering module with motherboard unpowered',sch=(145,85))
add('R5','1k 1%',RES,(64,32.08),{'1':'DE_MCU','2':'DE_COM'},'RC0805FR-071KL','Driver enable series resistor; module RE and DE are connected internally',sch=(145,135))
add('D1','CDSOT23-SM712',SOT23,(100,75),{'1':'A','2':'B','3':'ISO_GND'},'CDSOT23-SM712','Asymmetric RS485 TVS; pin1/2 line, pin3 isolated return. TVS presence does not prove IEC61000-4-5 immunity.',sch=(350,130))
add('J1','5V / G / MAIN3V3 / G',TERM4,(25,87),{'1':'5V_IN','2':'PGND','3':'3V3_MAIN','4':'PGND'},'MKDS 1,5/4-5,08','External wiring: main C9 after U3 / PGND / L5.1 / PGND. No 6V input.',sch=(60,220))
add('J2','RX / TX / DE / G',HEAD4,(60,27),{'1':'RX_MCU','2':'TX_MCU','3':'DE_MCU','4':'PGND'},'1x04 P2.54mm straight header','Motherboard U7 DNP: 1=RO->MCU RX,4=DI<-MCU TX,3=DE; header4=GND. U7.2 not connected separately.',sch=(60,270))
add('J3','B / ISO_GND / A',TERM3,(95,85),{'1':'B','2':'ISO_GND','3':'A'},'MKDS 1,5/3-5,08','External RS485 only; DO NOT connect original motherboard J2 ground to ISO_GND',sch=(350,35))
add('JP1','TERM_ENABLE',HEAD2,(110,73),{'1':'TERM_LINK','2':'B'},'1x02 P2.54mm header + removable shunt','OPEN by default; fit only at physical bus end. R2 120ohm across A/B when closed.',sch=(350,105))
for ref,xy in [('H1',(24,24)),('H2',(116,24)),('H3',(24,96)),('H4',(116,96))]:add(ref,'M3_NYLON',HOLE,xy,{},'M3 nylon standoff','Insulating fasteners; maintain isolation clearance; bolts/nuts/washers separately',sch=(40+int(ref[1])*35,310))

# Symbol geometry and embedded library. Labels represent actual connected nets.
def eff(size=1,hide=False):return f'(effects (font (size {size} {size}))'+(' (hide yes)' if hide else '')+')'
def libsym(key,plist,rect=(-5.08,5.08,5.08,-5.08)):
    x1,y1,x2,y2=rect
    ss=f'(symbol "IsoPower:{key}" (pin_names (offset 0.5)) (exclude_from_sim no) (in_bom yes) (on_board yes) (property "Reference" "U" (at 0 8 0) {eff()}) (property "Value" "{key}" (at 0 -8 0) {eff()}) (symbol "{key}_0_1" (rectangle (start {x1} {y1}) (end {x2} {y2}) (stroke (width 0.254) (type default)) (fill (type background)))) (symbol "{key}_1_1" '
    for n,name,x,y,ang,kind in plist:ss+=f'(pin {kind} line (at {x} {y} {ang}) (length 2.54) (name "{name}" {eff(.9)}) (number "{n}" {eff(.9)}))'
    return ss+'))'
admpins=[]
names=['GND1','VCC','GND1','RxD','nRE','DE','TxD','VCC','GND1','GND1','GND_DC','VISOOUT','Y','GND_DC','Z','GND_BUS','B','A','VISOIN','GND_BUS']
for n in range(1,21):
    right=n>=11;y=(11.43-(n-1)*2.54) if not right else(-11.43+(n-11)*2.54)
    kind='power_in' if n in [1,2,3,8,9,10,11,14,16,19,20] else 'power_out' if n==12 else 'output' if n==4 else 'input' if n in [5,6,7] else 'passive'
    admpins.append((str(n),names[n-1],17.78 if right else -17.78,y,180 if right else 0,kind))
libs=[libsym('ADM2587E',admpins,(-15.24,15.24,15.24,-15.24)),libsym('LDO',[('1','GND',0,-7.62,90,'power_in'),('2','OUT_TAB',7.62,0,180,'power_out'),('3','IN',-7.62,0,0,'power_in')]),libsym('PASSIVE',[('1','1',-5.08,0,0,'passive'),('2','2',5.08,0,180,'passive')],(-2.54,2.54,2.54,-2.54)),libsym('TVS',[('1','A',-7.62,2.54,0,'passive'),('2','B',-7.62,-2.54,0,'passive'),('3','GND',7.62,0,180,'passive')]),libsym('H4',[(str(n),str(n),-7.62,3.81-(n-1)*2.54,0,'passive') for n in range(1,5)]),libsym('H3',[(str(n),str(n),-7.62,2.54-(n-1)*2.54,0,'passive') for n in range(1,4)]),libsym('H2',[(str(n),str(n),-7.62,1.27-(n-1)*2.54,0,'passive') for n in range(1,3)]),libsym('HOLE',[],(-2.54,2.54,2.54,-2.54)),libsym('FLAG',[('1','PWR',0,0,90,'power_out')],(-1.27,1.27,1.27,-1.27))]
def inst(ref,value,key,x,y,fp='',physical=True):
    props=f'(property "Reference" "{ref}" (at {x} {y-19.05 if key=="ADM2587E" else y-10.16} 0) {eff()}) (property "Value" "{value}" (at {x} {y+19.05 if key=="ADM2587E" else y+10.16} 0) {eff(.9)}) (property "Footprint" "{fp}" (at {x} {y} 0) {eff(hide=True)})'
    return f'(symbol (lib_id "IsoPower:{key}") (at {x} {y} 0) (unit 1) (in_bom {"yes" if physical else "no"}) (on_board {"yes" if physical else "no"}) (dnp no) (uuid {UID(ref)}) {props} (instances (project "{NAME}" (path "/{ROOTID}" (reference "{ref}") (unit 1)))))'
def label(net,x,y,justify='left'):return f'(label "{net}" (at {x} {y} 0) (effects (font (size 1 1)) (justify {justify} bottom)) (uuid {UID(net+str(x)+str(y))}))'
def wire(a,c,key):return f'(wire (pts (xy {a[0]} {a[1]}) (xy {c[0]} {c[1]})) (stroke (width 0) (type default)) (uuid {UID(key)}))'
schitems=[]
for a in parts:
    ref=a['ref'];x,y=a['sch'];key='ADM2587E' if ref=='U1' else 'LDO' if ref in ['U2','U3'] else 'TVS' if ref=='D1' else 'H4' if ref in ['J1','J2'] else 'H3' if ref=='J3' else 'H2' if ref=='JP1' else 'HOLE' if ref.startswith('H') else 'PASSIVE'
    schitems.append(inst(ref,a['value'],key,x,y,a['footprint']))
    if key=='ADM2587E':loc={str(n):(x+(17.78 if n>=11 else -17.78),y-((11.43-(n-1)*2.54) if n<=10 else(-11.43+(n-11)*2.54))) for n in range(1,21)}
    elif key=='LDO':loc={'1':(x,y+7.62),'2':(x+7.62,y),'3':(x-7.62,y)}
    elif key=='TVS':loc={'1':(x-7.62,y-2.54),'2':(x-7.62,y+2.54),'3':(x+7.62,y)}
    elif key=='PASSIVE':loc={'1':(x-5.08,y),'2':(x+5.08,y)}
    elif key.startswith('H') and key!='HOLE':cnt=int(key[1]);loc={str(n):(x-7.62,y-((cnt-1)*1.27-(n-1)*2.54)) for n in range(1,cnt+1)}
    else:loc={}
    for num,net in a['pins'].items():
        px,py=loc[num]
        vertical=key=='LDO' and num=='1'
        right=(key=='ADM2587E' and int(num)>=11) or (key in ['LDO','PASSIVE','TVS'] and num=='2' and key!='TVS') or (key=='TVS' and num=='3')
        end=(px,round(py+7.62,5)) if vertical else(round(px+(10.16 if right else -10.16),3),py)
        schitems.extend([wire((px,py),end,ref+num),label(net,*end,'right' if right else 'left')])
for ix,net in enumerate(['5V_IN','PGND','GND_DC','ISO_GND','VISO_IN']):
    x=grid(235+ix*30);y=grid(150);ref=f'#FLG{ix+1:02}';schitems.extend([inst(ref,net,'FLAG',x,y,physical=False),label(net,x,y)])
notes=[('FW-EC-TX B0 isolated RS485 and independent MAIN/COM 3.3V supplies',25,20),('Input 5.0V +/-2% ONLY. Mainboard DNP U4/L2/D3/C17/U7/R10; keep L5.',25,330),('J1.3 -> main L5.1 (not L5.3). J3 ISO_GND must NEVER connect main PGND or original main J2.',25,337),('ADM VCC=3.3V: 5V operation would not guarantee 3.3V MCU logic VIH. Outputs MAIN/COM NEVER parallel.',25,344),('JP1 OPEN by default; 120R only at bus end. TVS/isolator ratings do not prove whole-system surge/EMC or safety certification.',25,351),('Do not separately power COM with MCU/MAIN off. Series R3/R4/R5 limit injection, not Ioff-proof isolation.',25,358)]
for s,x,y in notes:schitems.append(f'(text "{s}" (at {x} {y} 0) (effects (font (size 1.1 1.1)) (justify left)) (uuid {UID(s)}))')
sch=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {ROOTID}) (paper "A2") (title_block (title "FW-EC-TX B0 isolated RS485 + dual LDO") (date "2026-10-21") (rev "B0") (company "Independent module; motherboard analog copper unchanged")) (lib_symbols {"".join(libs)}) {"".join(schitems)} (embedded_fonts no))'
(ROOT/(NAME+'.kicad_sch')).write_text(sch)
(ROOT/'IsoPower.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor") '+''.join(libs).replace('(symbol "IsoPower:','(symbol "')+')')
(ROOT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "IsoPower") (type "KiCad") (uri "${KIPRJMOD}/IsoPower.kicad_sym") (options "") (descr "Verified module symbols")))')
flibs=sorted({a['footprint'].split(':')[0] for a in parts})
(ROOT/'fp-lib-table').write_text('(fp_lib_table (version 7) '+''.join(f'(lib (name "{lib}") (type "KiCad") (uri "${{KICAD9_FOOTPRINT_DIR}}/{lib}.pretty") (options "") (descr "KiCad standard"))' for lib in flibs)+')')

b=p.BOARD();b.SetFileName(str(ROOT/(NAME+'.kicad_pcb')));b.GetDesignSettings().SetCopperLayerCount(2);b.GetDesignSettings().SetBoardThickness(mm(1.6));b.GetDesignSettings().SetAuxOrigin(vec(20,100))
netnames=sorted({n for a in parts for n in a['pins'].values()});nets={}
for ix,n in enumerate(netnames,1):net=p.NETINFO_ITEM(b,'/'+n,ix);b.Add(net);nets[n]=net
fps={}
for a in parts:
    lib,n=a['footprint'].split(':');f=p.FootprintLoad(str(LIB/(lib+'.pretty')),n);assert f,a['footprint']
    f.SetReference(a['ref']);f.SetValue(a['value']);f.SetAttributes(f.GetAttributes() & ~p.FP_EXCLUDE_FROM_BOM);f.SetPosition(vec(*a['xy']));f.SetFPID(p.LIB_ID(lib,n))
    path=p.KIID_PATH();path.push_back(p.KIID(ROOTID));path.push_back(p.KIID(UID(a['ref'])));f.SetPath(path)
    for pad in f.Pads():
        if pad.GetNumber() in a['pins']:pad.SetNet(nets[a['pins'][pad.GetNumber()]])
    f.Value().SetVisible(False);f.Reference().SetTextSize(vec(.8,.8));f.Reference().SetTextThickness(mm(.12));f.Reference().SetVisible(True)
    b.Add(f);fps[a['ref']]=f
    f.Reference().SetPosition(vec(a['xy'][0],a['xy'][1]-2.3 if a['ref'][0] not in 'UJH' else a['xy'][1]-8.0))
    if a['ref'].startswith('C'):
        f.Reference().SetPosition(vec(a['xy'][0]+(-3.8 if a['xy'][0]<75 else 3.8),a['xy'][1]))
    if a['ref'] in ['R3','R4','R5']:f.Reference().SetPosition(vec(68,a['xy'][1]))
    if a['ref'].startswith('H'):f.Reference().SetPosition(vec(a['xy'][0]+4.0,a['xy'][1]))
# Keep all markings independent; no ADI logos or evaluation-product identifiers.
for a,c in [((20,20),(120,20)),((120,20),(120,100)),((120,100),(20,100)),((20,100),(20,20))]:
    s=p.PCB_SHAPE();s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart(vec(*a));s.SetEnd(vec(*c));s.SetLayer(p.Edge_Cuts);s.SetWidth(mm(.05));b.Add(s)
def text(s,x,y,sz=.9,layer=p.F_SilkS):
    t=p.PCB_TEXT(b);t.SetText(s);t.SetPosition(vec(x,y));t.SetTextSize(vec(max(.8,sz),max(.8,sz)));t.SetTextThickness(mm(.12));t.SetLayer(layer);b.Add(t)
text('FW-EC-TX ISO/POWER B0',46,23,.9);text('5V ONLY | MAIN != COM',45,25.5,.8)
text('B  ISO_G  A',100,91,.8);text('TERM OPEN DEFAULT',105,70,.7)
text('5V  G  MAIN  G',32.5,94.5,.8);text('RX TX DE G',59,37,.8)
text('ISO BARRIER',75,34,.8)
# Route the actual netlist; clearance-aware 2-layer router lives in router.py.
p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
from router import route_board
b=route_board(b,parts,nets,ROOT)
b.BuildConnectivity();p.SaveBoard(str(ROOT/(NAME+'.kicad_pcb')),b)
pro={'board':{'design_settings':{'rules':{'min_clearance':.2,'min_track_width':.25,'min_via_diameter':.6,'min_through_hole_diameter':.3,'min_hole_to_hole':.25,'min_copper_edge_clearance':.4}}},'meta':{'filename':NAME+'.kicad_pro','version':1},'net_settings':{'classes':[{'name':'Default','clearance':.2,'track_width':.3,'via_diameter':.6,'via_drill':.3,'microvia_diameter':.3,'microvia_drill':.1,'diff_pair_width':.2,'diff_pair_gap':.25,'diff_pair_via_gap':.25,'bus_width':12,'line_style':0,'wire_width':6,'pcb_color':'rgba(0,0,0,0)','schematic_color':'rgba(0,0,0,0)'}],'net_colors':None,'netclass_assignments':None,'netclass_patterns':[]}}
(ROOT/(NAME+'.kicad_pro')).write_text(json.dumps(pro,indent=2))
metadata={'name':NAME,'revision':'B0','board_mm':[100,80],'layers':2,'board_thickness_mm':1.6,'copper_um':35,'components':parts,'schematic_uuid':ROOTID,'input_V':[4.9,5.1],
 'mainboard_DNP':['U1','S1','U2','Q1','D4','R18','U7','R10','U4','L2','D3','C17'],
 'mainboard_connections':{'J1.1':'C9 VCC after main U3','J1.2':'PGND','J1.3':'L5.1 B / C26 non-ground pad','J1.4':'PGND','J2.1':'U7.1 RO pad -> MCU RX','J2.2':'U7.4 DI pad <- MCU TX','J2.3':'U7.3 DE pad <- MCU DE','J2.4':'U7.5 GND pad'},
 'external_connections':{'J3.1':'RS485 B','J3.2':'ISOLATED RS485 reference ground','J3.3':'RS485 A'},
 'warnings':['Do not connect main J2 or PGND to isolated bus','Never parallel MAIN and COM 3.3V','Do not use 6V input','No mains safety, EMC, or IEC surge compliance has been verified','R3/R4/R5 are injection limiting, not Ioff protection; avoid isolated powering of COM with MAIN off','All ratings are design targets pending assembled hardware qualification'],
 'sources':[{'url':'https://www.analog.com/media/en/technical-documentation/data-sheets/adm2582e-2587e.pdf','revision':'H','pins':'table10,figure35'},{'url':'https://www.analog.com/media/en/technical-documentation/user-guides/eval-adm2587eeb2z-ug-1266.pdf','revision':'0','TVS':'Bourns CDSOT23-SM712, figure4 and BOM'}]}
(ROOT/'isolation_netlist.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
with (ROOT/'isolation_bom.csv').open('w',newline='') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['Reference','Quantity','Value','Manufacturer','MPN','Footprint','Population','Note'])
    for a in parts:
        mfr='Analog Devices' if a['ref'].startswith('U') else 'Murata' if a['ref'].startswith(('C','FB')) else 'Yageo' if a['ref'].startswith('R') else 'Bourns' if a['ref']=='D1' else 'Phoenix Contact' if a['ref'] in ['J1','J3'] else 'Generic'
        w.writerow([a['ref'],1,a['value'],mfr,a['mpn'],a['footprint'],'DNP' if a['dnp'] else 'FIT',a['description']])
print('Generated',ROOT)
