#!/usr/bin/python3
"""Export this native KiCad module only; require actual ERC/DRC to be clean."""
import os,subprocess,json,csv,hashlib,zipfile,re
from pathlib import Path
from xml.etree import ElementTree as ET
import pcbnew as p
ROOT=Path(__file__).resolve().parent
NAME='fw_ec_tx_iso_power_b0'
OUT=ROOT/'manufacturer';OUT.mkdir(exist_ok=True)
env=dict(os.environ)
env.update(XDG_CONFIG_HOME='/tmp/kicad-iso/config',XDG_CACHE_HOME='/tmp/kicad-iso/cache',XDG_DATA_HOME='/tmp/kicad-iso/data')
pcb=str(ROOT/(NAME+'.kicad_pcb'));sch=str(ROOT/(NAME+'.kicad_sch'))
commands=[
 ['kicad-cli','sch','erc',sch,'--format','json','-o',str(ROOT/'erc.json')],
 ['kicad-cli','pcb','drc',pcb,'--schematic-parity','--format','json','-o',str(ROOT/'drc.json')],
 ['kicad-cli','sch','export','pdf',sch,'-o',str(ROOT/(NAME+'_schematic.pdf'))],
 ['kicad-cli','sch','export','netlist',sch,'--format','kicadxml','-o',str(ROOT/(NAME+'_netlist.xml'))],
 ['kicad-cli','pcb','export','gerbers',pcb,'--layers','F.Cu,B.Cu,F.Paste,B.Paste,F.SilkS,B.SilkS,F.Mask,B.Mask,Edge.Cuts','--use-drill-file-origin','-o',str(OUT)+'/', '--subtract-soldermask'],
 ['kicad-cli','pcb','export','drill',pcb,'--format','excellon','--drill-origin','plot','--excellon-units','mm','--excellon-zeros-format','decimal','--excellon-separate-th','--generate-map','--map-format','pdf','-o',str(OUT)+'/'],
 ['kicad-cli','pcb','export','ipcd356',pcb,'-o',str(OUT/(NAME+'.ipc'))],
 ['kicad-cli','pcb','export','pos',pcb,'--format','csv','--units','mm','--side','both','--use-drill-file-origin','--exclude-dnp','-o',str(OUT/'CPL_KiCad_native.csv')],
 ['kicad-cli','pcb','export','pdf',pcb,'--layers','F.Cu,B.Cu,F.SilkS,B.SilkS,Edge.Cuts','-o',str(ROOT/(NAME+'_pcb_layers.pdf'))],
 ['kicad-cli','pcb','export','svg',pcb,'--layers','F.Cu,F.SilkS,Edge.Cuts','--page-size-mode','2','-o',str(ROOT/'preview_top.svg')],
]
logs=[]
for cmd in commands:
    r=subprocess.run(cmd,env=env,cwd=ROOT,capture_output=True,text=True)
    logs.append({'command':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    if r.returncode:raise RuntimeError(str(cmd)+r.stderr+r.stdout)
    print(r.stdout.strip())
    if cmd[1:3]==['sch','erc']:
        erc=json.loads((ROOT/'erc.json').read_text());assert sum(len(s['violations']) for s in erc['sheets'])==0,'ERC not clean'
    if cmd[1:3]==['pcb','drc']:
        d=json.loads((ROOT/'drc.json').read_text());assert not d['violations'] and not d['unconnected_items'] and not d['schematic_parity'],'DRC/parity not clean'
(ROOT/'export_log.json').write_text(json.dumps(logs,indent=2))
metadata=json.loads((ROOT/'isolation_netlist.json').read_text())
expected={(c['ref'],str(pin)):'/'+net for c in metadata['components'] for pin,net in c['pins'].items()}
xml=ET.parse(ROOT/(NAME+'_netlist.xml'))
schematic={(n.attrib['ref'],n.attrib['pin']):net.attrib['name'] for net in xml.findall('./nets/net') for n in net.findall('node')}
assert schematic==expected,'Exported schematic pin nets differ from reviewed circuit'
b=p.LoadBoard(pcb)
actual={(f.GetReference(),pad.GetNumber()):pad.GetNetname() for f in b.GetFootprints() for pad in f.Pads() if pad.GetNumber() and pad.GetNetname()}
assert actual==expected,'PCB pin nets differ from schematic'
ipc={}
for line in (OUT/(NAME+'.ipc')).read_text().splitlines():
    m=re.match(r'3[12]7(\S+)\s+(\S+)\s+-(\d+)\s',line)
    if m:ipc[(m[2],m[3])]=m[1]
assert ipc==expected,'IPC-356 pad networks differ from schematic'
cpl=list(csv.DictReader((OUT/'CPL_KiCad_native.csv').open()))
for r in cpl:
    fp=next(f for f in b.GetFootprints() if f.GetReference()==r['Ref'])
    assert abs(float(r['PosX'])-(p.ToMM(fp.GetPosition().x)-20))<1e-5
    assert abs(float(r['PosY'])-(100-p.ToMM(fp.GetPosition().y)))<1e-5
    assert float(r['Rot'])==fp.GetOrientationDegrees() and r['Side']=='top'
with (OUT/'CPL_mm_lower_left.csv').open('w',newline='') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['Designator','Mid X','Mid Y','Rotation','Layer','Units','Origin','Assembly'])
    for r in cpl:
        fp=next(fp for fp in b.GetFootprints() if fp.GetReference()==r['Ref'])
        w.writerow([r['Ref'],r['PosX'],r['PosY'],r['Rot'],'Top','mm','board lower-left native CAD=(20,100); +X right +Y up','SMT' if fp.GetAttributes()&p.FP_SMD else 'Manual/THT'])
with (OUT/'CPL_SMT_only.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(cpl[0]),lineterminator='\n');w.writeheader()
    for r in cpl:
        fp=next(fp for fp in b.GetFootprints() if fp.GetReference()==r['Ref'])
        if fp.GetAttributes()&p.FP_SMD:w.writerow(r)
for suffix in ['gtl','gbl','gtp','gbp','gts','gbs','gto','gbo','gm1']:
    assert len(list(OUT.glob('*.'+suffix)))==1,suffix
# Conservative separation of *all actual pad/track/filled-zone X extents*.
primary={'PGND','5V_IN','3V3_MAIN','3V3_COM','RX_COM','TX_COM','DE_COM','RX_MCU','TX_MCU','DE_MCU'}
bounds=[[],[]]
def bound(obj,n):
    bb=obj.GetBoundingBox();bounds[0 if n.lstrip('/') in primary else 1].append((p.ToMM(bb.GetX()),p.ToMM(bb.GetX()+bb.GetWidth())))
for f in b.GetFootprints():
    for pad in f.Pads():
        if pad.GetNetname():bound(pad,pad.GetNetname())
for t in b.GetTracks():bound(t,t.GetNetname())
for z in b.Zones():
    for layer in [p.F_Cu,p.B_Cu]:
        if z.HasFilledPolysForLayer(layer):
            box=z.GetFilledPolysList(layer).BBox()
            bounds[0 if z.GetNetname().lstrip('/') in primary else 1].append((p.ToMM(box.GetX()),p.ToMM(box.GetX()+box.GetWidth())))
primary_max=max(a[1] for a in bounds[0]);secondary_min=min(a[0] for a in bounds[1]);gap=secondary_min-primary_max
assert gap>=7.19, 'Isolation domain copper crossed the reviewed corridor'
report={
 'board':NAME,'size_mm':[100,80],'layers':2,'thickness_mm':1.6,'outer_copper_um':35,
 'ERC':0,'DRC':0,'unconnected':0,'schematic_parity':0,
 'schematic_PCB_IPC_pin_nets_equal':True,'CPL_origin_and_rotation_matches_CAD':True,
 'pin_network_records':len(expected),'cpl_records':len(cpl),
 'routing_boundary_primary_max_x_mm':71.4,'routing_boundary_secondary_min_x_mm':78.6,'routing_domain_gap_mm':7.2,'actual_copper_primary_max_X_mm':primary_max,'actual_copper_secondary_min_X_mm':secondary_min,'actual_copper_X_gap_mm':gap,
 'motherboard_DRC_in_scope':False,'assembled_hardware_tested':False,
 'isolation_EMC_surge_certified':False,
 'limitations':['ERC/DRC are design-data checks, not assembled performance tests.','7.2mm domain routing strip is a layout constraint, not a product safety certification.','PCB-level surge, radiation, thermal, power-up and accuracy have not been measured.','MAIN and COM regulator outputs must never be paralleled; external bus ground is isolated.']}
(ROOT/'validation_isolation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
files=sorted(f for f in OUT.iterdir() if f.is_file() and f.name!='SHA256SUMS.txt')
(OUT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in files))
with zipfile.ZipFile(ROOT/'FW_EC_TX_ISO_POWER_B0_manufacturer.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(OUT.iterdir()):
        if f.is_file():z.write(f,f.name)
print(json.dumps(report,ensure_ascii=False,indent=2))
