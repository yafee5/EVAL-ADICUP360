FW-EC-TX ISO/POWER B0 - independent module only
100 x 80 mm; two copper layers; FR4 1.6 mm; outer copper 35 um; ENIG suggested.
GTL=Top copper, GBL=Bottom copper, GTP/GBP=paste, GTS/GBS=soldermask, GTO/GBO=silkscreen, GM1=outline.
PTH/NPTH drills are separate metric decimal Excellon. Four M3 3.2 mm NPTH mounting holes.
All fitted components are Top. Bottom paste is intentionally empty.
CPL auxiliary origin is native CAD (20,100) mm = finished board lower-left. X right, Y up.
CPL_SMT_only.csv is for SMT assembly. Headers/terminals are manual/THT. Use per-reference BOM from project, not a guessed substitute.
JP1 termination jumper OPEN by default. Main/COM 3.3V outputs never parallel. 5.0V +/-2% input only.
The 7.2mm copper separation is design geometry, not system isolation/safety/EMC/surge certification.
ERC/DRC do not certify physical accuracy, temperature rise, EMC or surge performance.
