#!/usr/bin/python3
"""Remove explicitly redundant vias, then require independent KiCad DRC.

No rule is disabled. Native S-expression edits avoid KiCad 9 SWIG ownership
hazards when deleting a PCB object while an iterator still references it.
Existing filled copper is retained; removal of an unused via only leaves its
conservative clearance void. Closely coincident same-net drills are joined by
real copper on both layers before one redundant drill is removed.
"""
from pathlib import Path
import os,json,subprocess,re,uuid
ROOT=Path(__file__).resolve().parent
PCB=ROOT/'fw_ec_tx_iso_power_b0.kicad_pcb'
env=dict(os.environ);env.update(XDG_CONFIG_HOME='/tmp/kicad-iso/config',XDG_CACHE_HOME='/tmp/kicad-iso/cache',XDG_DATA_HOME='/tmp/kicad-iso/data')
events=[]
def vias(text):
    out={}
    for m in re.finditer(r'\t\(via\n.*?\n\t\)',text,re.S):
        b=m.group();uid=re.search(r'\(uuid "([^"]+)"\)',b)[1]
        xy=tuple(map(float,re.search(r'\(at ([^ ]+) ([^)]+)\)',b).groups()))
        out[uid]={'block':b,'xy':xy,'net':int(re.search(r'\(net (\d+)\)',b)[1])}
    return out
for attempt in range(5):
    r=subprocess.run(['kicad-cli','pcb','drc',str(PCB),'--schematic-parity','--format','json','-o',str(ROOT/'drc.json')],capture_output=True,text=True,env=env)
    if r.returncode:raise RuntimeError(r.stderr+r.stdout)
    d=json.loads((ROOT/'drc.json').read_text())
    if not d['violations']:
        assert not d['unconnected_items'] and not d['schematic_parity']
        break
    actionable=[a for a in d['violations'] if a['type'] in ['via_dangling','hole_to_hole']]
    assert actionable,'Non-redundancy electrical/layout errors remain: '+json.dumps(d)
    text=PCB.read_text();vs=vias(text);removed=set();segments=[]
    for a in actionable:
        if a['type']=='via_dangling':
            uid=a['items'][0]['uuid']
            if uid in removed:continue
            assert uid in vs
            text=text.replace(vs[uid]['block'],'',1);removed.add(uid)
            events.append({'action':'remove_via_unused_on_second_layer','uuid':uid,'at':vs[uid]['xy']})
        else:
            uid1,uid2=[i['uuid'] for i in a['items']]
            if uid1 in removed or uid2 in removed:continue
            assert uid1 in vs and uid2 in vs and vs[uid1]['net']==vs[uid2]['net']
            v,c=vs[uid1],vs[uid2];ax,ay=v['xy'];cx,cy=c['xy']
            for layer in ['F.Cu','B.Cu']:
                segments.append(f'\t(segment (start {ax} {ay}) (end {cx} {cy}) (width 0.3) (layer "{layer}") (net {v["net"]}) (uuid "{uuid.uuid4()}"))\n')
            text=text.replace(c['block'],'',1);removed.add(uid2)
            events.append({'action':'merge_nearby_same_net_via','keep':v['xy'],'remove':c['xy'],'net_id':v['net']})
    if segments:
        end=text.rfind(')');text=text[:end]+''.join(segments)+text[end:]
    PCB.write_text(text)
else:raise RuntimeError('DRC cleanup did not finish in five bounded passes')
(ROOT/'layout_cleanup.json').write_text(json.dumps({'events':events,'DRC_violations':0,'unconnected':0,'parity':0,'rules_disabled':False,'exclusions_added':False},indent=2))
print('Final independent DRC: violations=0, unconnected=0, parity=0;',len(events),'redundant-via corrections')
