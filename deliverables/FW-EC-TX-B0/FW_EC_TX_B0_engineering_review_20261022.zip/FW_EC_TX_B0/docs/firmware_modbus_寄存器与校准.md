# FW-EC-TX B0：Modbus RTU 寄存器与校准

此说明对应 `firmware/protocol/tx_protocol.c` 的真实实现，完整逐块地址表见 `firmware/protocol/register_map.csv`。地址全部是 **Modbus PDU 零基地址**，不是屏幕上可能采用的 40001/30001 编号。默认地址 **1**、**9600 baud、8E1**，支持 9600/19200/38400/57600/115200；不支持旧版 ASCII 命令。

## 传输与字序

- RTU CRC16 多项式0xA001、初值0xFFFF，在线先发CRC低字节。
- 每个16位寄存器在线高字节先传；float32/uint32/int32 均高16位寄存器先传。float32 是 IEEE754；例如1.0为 `3F80 0000`，NaN须按状态位处理。
- FC04读测量区；FC03可读测量区和配置区。FC06用于可写16位标量；FC10用于整32位、批量参数和控制事务。32位值不能拆成两次FC06写。
- 最大FC03/04读125字，FC10写123字。非法功能/地址/数据返回异常码1/2/3；Flash提交失败返回4；提交过密返回6。
- 站址0广播和非本站请求静默忽略；所有受保护配置不接受广播写。CRC错、线路错误或非法RTU定界不作为正常命令执行。
- ≤19200 baud按11位8E1字符计t1.5/t3.5，较高波特采用0.75/1.75ms。接收中断时间戳在完整stop bit后，固件据此补偿一个字符时间；前台最终定帧保守再等一个字符，9600下约5.156ms后处理。主机工具同样保留这个余量。
- DE在真正UART TEMT后释放，回复完成后才采用新地址/波特率；不能按软件发送队列空或THRE判断发送完成。

## 数据读取

一次FC04从0x0000读32寄存器可获得一致的当前应用快照及诊断计数。重点字段：

| 零基起始地址 | 长度 | 含义 |
|---|---:|---|
| 0x0000 | 2 | κ(T)，µS/cm |
| 0x0002 | 2 | κ25，µS/cm |
| 0x0004 | 2 | 温度，°C |
| 0x0006 | 2 | 原始电导G，S，未乘分档系数与K |
| 0x0008 / 0x000A | 各2 | 电压/电流ADC正负相差值，int32 |
| 0x000C | 2 | 状态/故障位，uint32 |
| 0x000E | 2 | 完整电导周期计数 |
| 0x0010 / 11 / 12 / 13 | 各1 | Hz、GV、GI、校正表索引 |
| 0x0014 / 0x0016 | 各2 | 运行时间/电导样本年龄，ms |

应用程序必须联合检查有效位、故障位、校准位和样本年龄。有效位表示采样/计算具备有限结果，**不代表仪器已通过精度验收**。完整电导周期约数秒，切档丢整周期时保持SETTLING并输出NaN；不要把轮询速度当测量更新速度。

| bit | 名称 | 含义 |
|---:|---|---|
| 0 | EC_VALID | κ(T)有限、采集通过基本有效性判断 |
| 1 | TEMP_VALID | 温度通道有效 |
| 2 | K25_VALID | 已计算有限κ25；范围标志仍须检查 |
| 3 | EC_LOW_RANGE | 10≤κ(T)<50µS/cm，目标误差带为±1% |
| 4 | NLF_TEMP_OOR | 超出nLF的0–35°C；不外推，κ25为NaN |
| 5 | NLF_EC_OOR | 算得κ25超出60–1000µS/cm；数值保留但适用性超界 |
| 6 | RTD_FAULT | 温度链故障；不得用25°C代替 |
| 7 | EC_FAULT | 电导采集故障/饱和/信号过弱等，κ(T)不可用 |
| 8 | SETTLING | 启动、切频、切增益或参数变更后的建立/整周期丢弃 |
| 9 | UNCAL_GAIN | 当前频率×GV×GI的有效校准位尚未置位 |
| 10 | UNCAL_TEMP | 温度整链标定标记未置位 |
| 11 | UNCAL_K | K标定标记未置位 |
| 12 | FLASH_FAULT | 存储读写/校验异常 |
| 13 | ADC_TIMEOUT | ADC转换或温度更新超时 |
| 14 | EC_OUT_OF_RANGE | κ(T)<10或>2000µS/cm |
| 15 | TEMP_OUT_OF_RANGE | 温度<0或>50°C |
| 16 | FACTORY_DEFAULTS | 未从有效Flash记录加载参数 |
| 17 | RTD_OPEN | 开路/参考检查异常 |
| 18 | RTD_SHORT | 短路样低电阻诊断 |
| 19 | STALE | 电导样本年龄>10秒 |
| 20 | NLF_UNVERIFIED | 无可验证、已审定的nLF表；κ25不可验收 |
| 21 | MAINTENANCE | 当前使用强制频率/增益，仅供校准维护 |

温度故障可保留有效κ(T)，但κ25必须无效。当前正式ISO nLF因子尚未取得，生产默认表禁用；即使温度恰为25°C也返回κ25=NaN+NLF_UNVERIFIED，避免暗中用未经验证的系数。

## 参数与分档校正

FC03在未解锁时读取active，解锁时配置区域读取staged；测量快照和状态仍基于active。K范围0.5–1.5cm⁻¹，温度gain范围0.95–1.05、offset范围±5°C。温度计算为 `Tcal=Traw×gain+offset`。

分档索引 `n=f×16+v×4+i`：f=0/1对应100/1000Hz，v/i=0/1/2/3对应GV/GI=1/10/100/1000。校正系数地址 `0x0200+2n`，共32个float32。计算关系：

`Gcorrected = Graw × gain_correction[f][v][i]`

`κ(T) [µS/cm] = Gcorrected [S] × K [cm⁻¹] × 1e6`

原始G已按实际AD8253增益和R47=1000Ω换算，但尚未乘校正表或K。每项允许0.5–2.0；写入整项自动置gain_valid_mask对应bit。**只标记实际测过的组合**，不要把32个默认1.0都标成已校准。不同档位可能需要不同测试阻抗/激励，有些组合在当前量程会饱和或过弱，不能用强制模式使其自动变得可测。

自动频率在约200µS/cm附近使用190/210回差：100Hz超过210切1000Hz，1000Hz低于190切100Hz。频率/增益或维护模式改变后丢弃完整四相周期，不混用前后档数据。

## 写保护、提交与掉电

1. FC10向0x7F00写2字 `C35A 5AC3`，把active复制到staged并打开30秒窗口。
2. 在staged写K、温度、通讯、系数或nLF字段。32位必须完整成对写；每条批量写先校验再原子接受，非法字段拒绝整条。
3. 修改K/温度系数会清相应已校准标记。实际校准完成后，再设置0x010A的bit0/bit1。
4. 读0x7F08两字，获得整份336字节staged参数CRC32。
5. FC10从0x7F02一次写4字：`5341 5645`加上刚读的CRC高/低字。单写SAVE键或CRC均不接受。
6. MCU把新记录写到另一个独立512字节页、回读、最后写valid标记。成功回复在旧通讯设置发完后，active才采用新配置，自动退维护/上锁。两次SAVE至少间隔5秒。

超过30秒没有有效写或keepalive则取消staged、退AUTO。需延长窗口时向0x0404写0xA55A；**不要重复unlock当续期**，否则会把尚未提交的staged重置为active。向0x7F00写0取消；0x7F10写0x44454654仅把默认值放到staged，仍需独立SAVE。

Flash A/B页为0x1FA00、0x1FC00，各512字节。0x1FE00末页含设备安全信息，禁止擦写；固件链接区在0x1FA00之前。A/B、CRC和valid-last软件测试不代替真实硬件掉电/耐久试验。

若修改通讯的SAVE回复丢失，设备可能已持久化并切到新设置。应分别用新旧站址/波特率读状态，避免反复盲写。多主机同时配置不受支持。

## 维护模式与校准流程

先解锁，再FC10向0x0400一次写4字 `[1,f,v,i]`。固件切到指定频率/增益，置MAINTENANCE，并丢完整周期。读状态直到EC_VALID、无SETTLING/故障、freq/GV/GI与要求一致且sample_counter改变。30秒窗口用0x0404续期；写mode=0或锁定/SAVE均退AUTO。

电子学校正用可溯源标准电阻/电导夹具的实际值：`Gref=1/Rcert`，系数 `C=Gref/mean(Graw)`。应采多个不同完整周期，记录重复性、频率和实际GV/GI，并另作独立检验。电阻夹具只校电子学，不能替代真实电极/线缆的极化、K和液体温度验证。再用有证标准液、最终探头和固定线缆标K，最后验证分段精度；温度须四线Pt1000连整链标定并在独立温点检查。

## 上位机工具

物理串口依赖 `python3 -m pip install pyserial`；Linux可用`/dev/ttyUSB0`，Windows把端口改为`COM3`。以下是操作示例，数值必须来自实际标定：

```sh
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 status
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 read 0x0100 14
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 configure --cell 1.002 --mark-k-calibrated
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 configure --temperature-gain 1.0001 --temperature-offset -0.02 --mark-temperature-calibrated
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 configure --new-address 17 --new-baud 19200
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 --address 17 --baud 19200 status
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 force 100 10 100 --hold-seconds 20
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 calibrate-gain 100 10 100 --reference-s 0.0001 --samples 3
```

`force`命令在指定时长内续期并输出状态，正常结束后退AUTO；`calibrate-gain`只接收所选档的新有效样本，计算并提交该单格。异常时尝试退出维护；断线时硬件30秒自动退AUTO。

nLF导入必须先取得合法可追溯的正式因子并完成人工审定，不附送假表：

```sh
python3 compensation/make_nlf_profile.py --factors reviewed_factors.csv --source-artifact reviewed_source.pdf --source-id 1 --reviewed --output reviewed_nlf.json
python3 firmware/tools/tx_modbus.py --port /dev/ttyUSB0 import-nlf reviewed_nlf.json --source-artifact reviewed_source.pdf
```

工具先核对来源文件SHA256、36点、25°C恒等、单调性、CRC、stage字段一致，再stage全部因子/元数据，最后单独写NLF1并SAVE。CRC和SHA用于完整性/身份追溯，不能证明来源就是ISO或实际水样符合nLF假设。当前尚无正式ISO因子，κ25功能仍未完成验收。

## 已验证与未验证

工具的主机测试把真实 `tx_protocol.c`、`tx_storage.c`、`nlf.c`编为共享库，通过碎片化模拟串口进行端到端测试，覆盖CRC/长度/异常/写echo、保护提交、旧通讯回包、新通讯读取、维护超时、原始G标定、nLF来源损坏拒绝。结果见 `firmware/tools/host_client_validation.json`。测试中的nLF曲线只存在临时测试文件，明确非ISO，不嵌入正式HEX。

未做物理UART/隔离485总线、示波器时序、MCU真实Flash掉电、传感器精度、真实ISO因子与κ25验收；这些需要实板与标准资料。
