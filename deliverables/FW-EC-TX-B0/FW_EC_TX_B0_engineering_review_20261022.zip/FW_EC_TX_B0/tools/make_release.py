#!/usr/bin/env python3
"""Create an explicitly bounded engineering delivery, never a fake production release."""
from pathlib import Path
import json,csv,hashlib,zipfile,subprocess,re,shutil
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Preformatted
import fitz

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
DATE='2026-10-22'

def read(path,default=None):
    p=ROOT/path
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default

def find(directory,pattern,required=True):
    matches=sorted((ROOT/directory).glob(pattern))
    if not matches and required:raise SystemExit(f'Missing {directory}/{pattern}; finish generation first')
    return matches[0] if matches else None

def audit_board(directory):
    base=ROOT/directory
    drc=find(directory,'*drc*.json',False) or find(directory,'*DRC*.json',False)
    erc=find(directory,'*erc*.json',False) or find(directory,'*ERC*.json',False)
    d=json.loads(drc.read_text()) if drc else None
    e=json.loads(erc.read_text()) if erc else None
    def count(obj,key):return len(obj[key]) if obj is not None and isinstance(obj.get(key),list) else None
    erc_count=count(e,'violations')
    if erc_count is None and e is not None and isinstance(e.get('sheets'),list):
        erc_count=sum(len(s['violations']) for s in e['sheets']) if all(isinstance(s.get('violations'),list) for s in e['sheets']) else None
    result={'drc_file':str(drc.relative_to(ROOT)) if drc else None,'erc_file':str(erc.relative_to(ROOT)) if erc else None,
            'DRC_violations':count(d,'violations'),'unconnected':count(d,'unconnected_items'),
            'schematic_parity_issues':count(d,'schematic_parity'),'ERC_violations':erc_count,
            'paste_top':bool(list((base/'manufacturer').glob('*.gtp'))),
            'paste_bottom':bool(list((base/'manufacturer').glob('*.gbp'))),
            'IPC356':bool(list((base/'manufacturer').glob('*.ipc'))),
            'CPL':bool(list((base/'manufacturer').glob('*CPL*.csv')) or list((base/'manufacturer').glob('*pos*.csv'))),
            'KiCad_sch':bool(list(base.glob('*.kicad_sch'))),'KiCad_pcb':bool(list(base.glob('*.kicad_pcb'))),
            'hardware_execution_tested':False}
    return result

boards={name:audit_board(path) for name,path in [('isolation_power','hardware/isolation'),('ratio_adapter','hardware/ratio_adapter')]}
for name,b in boards.items():
    for k in ['DRC_violations','unconnected','schematic_parity_issues','ERC_violations']:
        if b[k]!=0:raise SystemExit(f'{name}: {k}={b[k]}, cannot package as checked CAD')
    for k in ['paste_top','paste_bottom','IPC356','CPL','KiCad_sch','KiCad_pcb']:
        if not b[k]:raise SystemExit(f'{name}: missing {k}')

firmware=read('firmware/build/manifest.json')
if not firmware:raise SystemExit('Missing compiled firmware manifest')
if not read('firmware/build/firmware_validation.json'):
    raise SystemExit('Missing final firmware integration validation summary')
for name,h in firmware['files'].items():
    if hashlib.sha256((ROOT/'firmware/build'/name).read_bytes()).hexdigest()!=h:raise SystemExit('Stale firmware image: '+name)
for name,h in firmware['source_files'].items():
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h:raise SystemExit('Stale source build: '+name)
main_audit=read('hardware/mainboard/cam_derivation_report.json')
for entry in main_audit['layers'].values():
    path=ROOT/'hardware/mainboard/manufacturer'/entry['output']
    if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
        raise SystemExit('Mainboard CAM hash mismatch: '+entry['output'])

status={
 'product':'FW-EC-TX Rev B0','date_Asia_Shanghai':DATE,'release':'ENGINEERING_REVIEW_NOT_PRODUCTION_RELEASED',
 'mainboard':read('hardware/mainboard/DRC_and_production_status_NOT_RELEASED.json'),
 'new_boards':boards,'bom':read('bom/bom_validation.json'),
 'firmware':{'compiled':True,'manifest':'firmware/build/manifest.json','hex':'firmware/build/fw_ec_tx_b0.hex',
             'image_validation':read('firmware/build/image_validation.json'),
             'host_validation':read('firmware/build/firmware_validation.json'),
             'hardware_execution_tested':False},
 'nlf':{'algorithm_framework':'implemented_and_host_tested','traceable_ISO7888_factors_obtained':False,
        'production_profile_generated':False,'default_kappa25':'NaN + NLF_UNVERIFIED',
        'temperature_policy':'0..35 C only, no extrapolation; conductivity applicability currently checked against kappa25 pending standard confirmation'},
 'physical_validation':{'conductivity_accuracy':False,'temperature_chain_accuracy':False,'electrode_frequency_linearity':False,
                        'supply_noise_and_thermal':False,'surge_EMC_isolation':False,'mechanical_adapter_fit':False},
 'production_hold_reasons':[
  'No trustworthy mainboard GTP/GBP, CPL, IPC356 or electrical DRC; native RevA CAD absent.',
  'No verified ISO7888 nLF factors; kappa25 function cannot be accepted as completed.',
  'R13/R47 complete precision-resistor MPNs and distributor SKUs unconfirmed; inventory/lifecycle not live-verified.',
  'Prototype has not been assembled or measured against stated accuracy/thermal/EMC/isolation targets.'
 ]}
(ROOT/'docs/delivery_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

matrix=[
 ('主板铜/阻焊/丝印/板框/钻孔','已生成','铜/孔保持与丝印派生检查','仅工程裸板CAM；不是电气DRC'),
 ('主板GTP/GBP','未生成','无','需要真实足迹、DNP与EP钢网设计'),
 ('主板CPL','未生成','无','缺中心/面别/旋转/针1可信来源'),
 ('主板IPC-356、电气DRC','未生成','无','缺原生PCB与设计意图网表'),
 ('G2/G3层序','已说明','确定L2/L3','逐岛网名未核实；叠层厚度为工程建议'),
 ('电源/隔离485子板生产文件','已生成','ERC/DRC/未连接/一致性均0','含双面paste、drill、IPC、CPL；未实物验证'),
 ('4块匹配网络片生产文件','已生成','ERC/DRC/未连接/一致性均0','同上；绝对阻值改变、安装净空未验证'),
 ('完整原理图PDF','已生成','原主板3页+ECO及新增板图','主板不是重建可编辑电气CAD'),
 ('BOM Excel/CSV','已生成','原位号/DNP及数量对账','R13/R47 MPN及分销SKU待定标，库存未核'),
 ('固件源/HEX','已生成','交叉编译/镜像与源hash/主机测试','未烧录上板'),
 ('Modbus寄存器表/工具','已生成','协议与host客户端模型测试','未实测真实UART/总线'),
 ('nLF计算/表导入/完整性校验','已实现','合成数据数值与防误用测试','正式ISO因子未取得，κ25默认无效'),
 ('ISO7888天然水温补功能','未完成','无真实标准表/水样验证','不能视作已可用成品温补'),
 ('精度、温升、EMC/浪涌/隔离','未验证','无实物','所有指标是验收目标'),
 ('原ADI压缩包/版本/来源','已归档','来源清单与SHA-256','未取得原生RevA可编辑CAD'),
]
with (ROOT/'docs/delivery_status.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f,lineterminator='\n');w.writerow(['项目','文件/功能状态','已做检查','未完成/未验证']);w.writerows(matrix)
status_md=['# 交付状态：已做检查与尚未完成项','',
           '本包为FW-EC-TX Rev B0工程审查资料，不能直接称为完整量产放行包。未生成的文件与已生成但未实测的文件分开列示。','',
           '| 项目 | 状态 | 已做检查 | 未完成/未验证 |','|---|---|---|---|']
for row in matrix:status_md.append('| '+' | '.join(row)+' |')
status_md+=['','当前推进生产还需：取得对应Rev A原生CAD或完成电气重建；取得可追溯nLF表；定标R13/R47与采购SKU；完成首件及精度/环境验证。',
            'ADI现行DesignSupport下载入口会转到受控下载表单。取得后仍须核对版本；Rev B电源、运放封装和接口已变化，不能当作Rev A坐标或网表直接使用。',
            '固件详细检查见firmware/build/firmware_validation.json和image_validation.json；板件分别使用各自ERC/DRC报告。']
(ROOT/'docs/交付状态.md').write_text('\n'.join(status_md)+'\n',encoding='utf-8')

counts=status['bom']
readme=f'''# FW-EC-TX Rev B0：精简电导率变送器工程包

**状态：工程样机，未生产放行。** κ(T)、四线Pt1000和Modbus核心已有源码/HEX及主机测试；正式ISO7888 nLF因子仍缺，κ25默认NaN并置UNVERIFIED。主板paste/CPL/IPC356/电气DRC未生成，不能把本包当完整自动贴片资料。

目标：两极K≈1cm⁻¹；10–50µS/cm ±1%读数、50–2000 ±0.5%；0–50°C温度整链±0.05°C。上述精度尚未实测。

## 先看这些文件

- `docs/交付状态.md` / `docs/delivery_status.json`：按文件与功能列出已做和缺项。
- `bom/FW_EC_TX_B0_BOM.xlsx`：新版10页签物料表；{counts['main_reference_records']}条主板采购子项记录，含DNP；整机{counts['all_records']}条记录、{counts['order_rows']}组合并采购项。两张表是同一批料，勿重复下单。
- `docs/FW_EC_TX_B0_design_and_schematics.pdf`：设计、接线、验证边界与全部现有电路图。
- `docs/整机接线.md` / `docs/FW_EC_TX_B0_wiring.pdf`：电导池、Pt1000、隔离485、5V与MAIN3V3接线。
- `firmware/build/fw_ec_tx_b0.hex`：新固件；禁止当作nLF功能已完成的出厂固件。原ASCII控制台、显示、本地菜单、编码器和蜂鸣器不再链接。
- `firmware/protocol/register_map.csv`、`docs/firmware_modbus_寄存器与校准.md`：完整0基寄存器、状态、写保护和校准操作。
- `firmware/tools/tx_modbus.py`：Modbus读取/配置/维护校准工具；默认地址1、9600 8E1。

## 硬件组成

1. 主板1块：原Rev A四层模拟铜保留，更换顶丝印，按B0 DNP。`hardware/mainboard/manufacturer/`只具备工程裸板CAM。
2. 电源/隔离485合并板1块：两路独立ADP3338-3.3、ADM2587E、TVS和跳线120Ω；旧独立35mm LDO板不再另买。
3. LT5400匹配网络适配片4块：6.25k/1k维持0.16，绝对阻值相对原7.5k/1.2k改变，寄生/负载和安装仍须验证。

已停装LCD/连接器、编码器/旋钮、蜂鸣器及其专用支持件；R17继续作为BM启动上拉，J4继续用于SWD。两块新增设计各有真KiCad源及自己的paste/drill/IPC/CPL/ERC/DRC，不能用其报告代替主板DRC。

## 尚不能跳过的项目

- 对应Rev A的原生PADS PCB/网表尚未取得。主板完整生产文件仍需恢复；详见`hardware/mainboard/README_主板生产边界.md`。
- 正式ISO7888/对应EN标准的nLF表尚未核验，详见`compensation/ISO7888_因子表获取与审核清单.md`；测试表不进生产默认配置。
- R13/R47精密电阻完整MPN及分销SKU待定标；所有库存/价格/生命周期未实时确认，未将访问失败写成缺货/停产。
- 尚未焊装、上电、标定或进行精度/温升/EMC/浪涌/隔离试验。具体指标只可在相应验证后宣称。

## 复现

固件：安装GNU Arm Embedded GCC和Python3，在`firmware/`运行`make`；`CROSS_COMPILE`可指定工具链前缀。主机测试命令以固件验证报告为准。Python串口工具需pyserial。

硬件：KiCad9、Python pcbnew与各目录的生成/审查脚本；元件库表与自定义库在相应板目录。打开源文件可重新审图，重新导出后须重跑ERC/DRC和本项目导出一致性检查。

BOM：`python3 tools/build_bom.py`，内部归档的baseline和规格JSON供追溯。报告打包需openpyxl、reportlab、PyMuPDF、pandoc、Inkscape；`make_release.py`不会把未通过/缺失的新增板制造文件标为检查通过。

原ADI设计档案、源版本/链接及哈希在`hardware/mainboard/sources_original/`。候选受控下载与Rev A/B差异证据在`source_candidates/`。原厂版权/许可原文随源码保留；生产丝印不含原品牌或未经试验的合规标志。
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')

# GFM -> portable Chinese PDF with actual schematic pages appended, without Chromium.
files=[ROOT/'README.md',ROOT/'docs/交付状态.md',ROOT/'docs/设计与验证说明.md',ROOT/'docs/整机接线.md',
       ROOT/'docs/firmware_modbus_寄存器与校准.md',ROOT/'hardware/mainboard/README_主板生产边界.md',
       ROOT/'hardware/ratio_adapter/README_匹配网络与装配.md',ROOT/'compensation/README_nLF_来源与未完成项.md']
iso_notes=next(iter(sorted((ROOT/'hardware/isolation').glob('README*.md'))),None)
if iso_notes:files.insert(-1,iso_notes)
source='\n\n'.join(p.read_text(encoding='utf-8') for p in files if p.exists())
md=ROOT/'docs/engineering_notes.md';md.write_text(source,encoding='utf-8')
ast=json.loads(subprocess.check_output(['pandoc','--from=gfm','--to=json',str(md)]))
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
pdfmetrics.registerFont(TTFont('UnicodeSymbols','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
normal=ParagraphStyle('CN',fontName='STSong-Light',fontSize=9,leading=14,wordWrap='CJK',spaceAfter=6)
cell=ParagraphStyle('Cell',parent=normal,fontSize=7.4,leading=11,spaceAfter=0)
heads={n:ParagraphStyle('H'+str(n),parent=normal,fontSize={1:17,2:13,3:11}.get(n,10),leading=22 if n==1 else 18,
                       textColor=colors.HexColor('#153D54'),keepWithNext=True,spaceBefore=10,spaceAfter=7) for n in range(1,7)}
code=ParagraphStyle('Code',fontName='Courier',fontSize=6.4,leading=9,spaceAfter=7)
def esc(s):
    t=escape(s)
    for c in 'µκΩΣΔαρθα±×−≤≥≈°⁻¹²³':t=t.replace(c,'<font name="UnicodeSymbols">'+c+'</font>')
    return t
def inline(nodes):
    o=[]
    for n in nodes:
        t,c=n['t'],n.get('c')
        if t=='Str':o.append(esc(c))
        elif t in ['Space','SoftBreak']:o.append(' ')
        elif t=='LineBreak':o.append('<br/>')
        elif t=='Code':o.append(esc(c[1]))
        elif t in ['Strong','Emph','Strikeout','SmallCaps','Superscript','Subscript']:o.append(inline(c))
        elif t in ['Link','Image']:o.append(inline(c[1]))
        elif t=='Quoted':o.append(inline(c[1]))
        elif t=='Math':o.append(esc(c[1]))
    return ''.join(o)
def ctext(blocks):return '<br/>'.join(inline(b['c']) for b in blocks if b['t'] in ['Plain','Para'])
story=[]
def blocks(bs,prefix=''):
    for b in bs:
        t,c=b['t'],b.get('c')
        if t=='Header':
            if c[0]==1 and story:story.append(PageBreak())
            story.append(Paragraph(inline(c[2]),heads[c[0]]))
        elif t in ['Plain','Para']:story.append(Paragraph(prefix+inline(c),normal))
        elif t=='BulletList':
            for item in c:blocks(item,'• ')
        elif t=='OrderedList':
            for i,item in enumerate(c[1],c[0][0]):blocks(item,str(i)+'. ')
        elif t=='CodeBlock':story.append(Preformatted(c[1],code,maxLineLength=110))
        elif t=='BlockQuote':blocks(c)
        elif t=='Table':
            rows=list(c[3][1]);nh=len(rows)
            for body in c[4]:rows.extend(body[2]);rows.extend(body[3])
            rows.extend(c[5][1]);data=[[Paragraph(ctext(x[4]),cell) for x in r[1]] for r in rows]
            if not data:continue
            nc=max(map(len,data));ratios={2:[.28,.72],3:[.24,.30,.46],4:[.20,.16,.28,.36]}.get(nc,[1/nc]*nc)
            table=Table(data,colWidths=[180*mm*r for r in ratios],repeatRows=nh,hAlign='LEFT')
            table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#BCCCD5')),
                ('BACKGROUND',(0,0),(-1,max(0,nh-1)),colors.HexColor('#E6EEF3')),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5)]))
            story.extend([table,Spacer(1,7)])
blocks(ast['blocks'])
pdf=ROOT/'docs/FW_EC_TX_B0_design_and_schematics.pdf'
def footer(c,doc):
    c.setFont('STSong-Light',8);c.setFillColor(colors.HexColor('#4B6877'))
    c.drawString(15*mm,10*mm,'FW-EC-TX Rev B0 · 工程审查资料 · 未生产放行 · '+DATE)
    c.drawRightString(195*mm,10*mm,str(doc.page))
SimpleDocTemplate(str(pdf),pagesize=(210*mm,297*mm),leftMargin=15*mm,rightMargin=15*mm,topMargin=15*mm,bottomMargin=18*mm,
                  title='FW-EC-TX B0设计与原理图（未生产放行）').build(story,onFirstPage=footer,onLaterPages=footer)
document=fitz.open(pdf);toc=[[1,'设计、接线、协议与交付状态',1]]
def schematic_pdf(directory):
    preferred=find(directory,'*schematic*.pdf',False) or find(directory,'*_sch.pdf',False)
    if preferred:return preferred
    choices=[p for p in sorted((ROOT/directory).glob('*.pdf')) if not any(x in p.name.lower() for x in ['layer','pcb','render'])]
    if len(choices)!=1:raise SystemExit('Ambiguous schematic PDF in '+directory)
    return choices[0]
append=[('整机接线示意',ROOT/'docs/FW_EC_TX_B0_wiring.pdf'),
        ('主板RevA三页原图与B0装配ECO',ROOT/'hardware/mainboard/mainboard_RevB0_assembly_ECO.pdf'),
        ('电源与隔离485合并板原理图',schematic_pdf('hardware/isolation')),
        ('匹配网络适配片原理图',schematic_pdf('hardware/ratio_adapter'))]
for label,p in append:
    with fitz.open(p) as source_pdf:
        toc.append([1,label,len(document)+1]);document.insert_pdf(source_pdf)
document.set_toc(toc);tmp=pdf.with_suffix('.combined.pdf');document.save(tmp,garbage=4,deflate=True);document.close();tmp.replace(pdf)

# Copy easy-to-download artifacts. The full ZIP includes source, without caches or transient host binaries.
copies={pdf.name:pdf,'FW_EC_TX_B0_BOM.xlsx':ROOT/'bom/FW_EC_TX_B0_BOM.xlsx',
        'FW_EC_TX_B0_BOM_per_reference.csv':ROOT/'bom/FW_EC_TX_B0_BOM_per_reference.csv',
        'FW_EC_TX_B0_BOM_order.csv':ROOT/'bom/FW_EC_TX_B0_BOM_order.csv',
        'FW_EC_TX_B0_modbus_registers.csv':ROOT/'firmware/protocol/register_map.csv',
        'FW_EC_TX_B0_wiring.pdf':ROOT/'docs/FW_EC_TX_B0_wiring.pdf',
        'fw_ec_tx_b0.hex':ROOT/'firmware/build/fw_ec_tx_b0.hex',
        'FW_EC_TX_B0_delivery_status.json':ROOT/'docs/delivery_status.json',
        'README.md':ROOT/'README.md'}
for n,p in copies.items():shutil.copyfile(p,OUT/n)
def include(p):
    rel=p.relative_to(ROOT)
    if p.is_symlink() or not p.is_file():return False
    if any(k in rel.parts for k in ['deliverables','__pycache__','research_search_logs','.pytest_cache']):return False
    if p.suffix in ['.pyc','.o','.kicad_prl','.lck']:return False
    if 'tests' in rel.parts and 'build' in rel.parts:return False
    if p.name.startswith('host_test_'):return False
    return True
package_files=sorted(p for p in ROOT.rglob('*') if include(p) and p.name!='release_manifest.json')
manifest={'date':DATE,'release':status['release'],'files':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in package_files}}
(ROOT/'release_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=OUT/'FW_EC_TX_B0_engineering_review_20261022.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in package_files+[ROOT/'release_manifest.json']:z.write(p,'FW_EC_TX_B0/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n,h in manifest['files'].items():assert hashlib.sha256(z.read('FW_EC_TX_B0/'+n)).hexdigest()==h,n
hashes=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt')
(OUT/'SHA256SUMS.txt').write_text(hashes,encoding='utf-8')
print(json.dumps({'status':status['release'],'source_files':len(package_files),'pdf_pages':len(fitz.open(pdf)),'archive_bytes':archive.stat().st_size,'boards':boards},ensure_ascii=False,indent=2))
