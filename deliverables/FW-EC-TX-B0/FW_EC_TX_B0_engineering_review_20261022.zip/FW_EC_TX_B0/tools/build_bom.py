#!/usr/bin/env python3
"""Regenerate the B0 engineering BOM; never invent distributor SKUs or stock."""
from pathlib import Path
from collections import Counter, defaultdict
from urllib.parse import quote
import csv, json, math, re, ast
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent
OUT=ROOT/'bom';OUT.mkdir(exist_ok=True)
OLD=OUT/'source_baseline_v02.csv'
baseline_external=PROJECT/'hardware/v0.2/assembly/self_solder_bom.csv'
if not OLD.exists():
    if not baseline_external.exists():raise SystemExit('Missing archived source_baseline_v02.csv')
    OLD.write_bytes(baseline_external.read_bytes())
FIELDS=['板件','位号','子项','单台数量','备件建议','建议采购数量','数值/功能','封装','精度/匹配','温漂/比值温漂',
        '厂家','制造商型号MPN','立创或DigiKey料号','采购/供货状态','装配状态','相对v0.2变更','备注',
        '采购入口','淘宝搜索入口','来源']
UI={'U1','S1','U2','U6','Q1','D4','R6','R7','R8','R9','R18','C27','C28','C35','C33','C34'}
POWER={'U4','L2','D3','C17'}
LEGACY485={'U7','R10','J2'}
RATIOS={'R19','R20','R29','R31','R37','R38','R48','R52'}
ADI='https://www.analog.com/cn/lp/002/promotion/china-eshop.html'
DIGI='https://www.digikey.cn/en/products?keywords='
LCSC='https://www.szlcsc.com/'

def newrow(board,ref,qty,value,fp,mpn,mfr='',status='必装',tol='',tcr='',change='',note='',source=''):
    url=(ADI+'\n' if mfr.lower() in ['adi','analog devices','linear technology'] else '')+DIGI+quote(mpn or value)
    return dict(zip(FIELDS,[board,ref,'',qty,0,qty,value,fp,tol,tcr,mfr,mpn,
        'UNVERIFIED：未取得已核实的商城SKU','UNVERIFIED：未实时核实库存/停产/价格',status,change,note,url,
        'https://s.taobao.com/search?q='+quote(mpn or value),source]))

rows=[]
cap_specs={}
cap_archive=OUT/'source_cap_specs.json'
if cap_archive.exists():cap_specs=json.loads(cap_archive.read_text(encoding='utf-8'))
prior_builder=PROJECT/'procurement/build_procurement.py'
if not cap_specs and prior_builder.exists():
    for node in ast.parse(prior_builder.read_text(encoding='utf-8')).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cap_specs' for t in node.targets):
            cap_specs=ast.literal_eval(node.value)
    cap_archive.write_text(json.dumps(cap_specs,ensure_ascii=False,indent=2),encoding='utf-8')
for old in csv.DictReader(OLD.open(encoding='utf-8-sig')):
    if not old['板件'].startswith('CN0359'):continue
    r=old['原位号'];qty=int(old['数量']);m=old['原MPN']
    x=newrow('FW-EC-TX B0主板',r,qty,old['装配值'],old['封装'],m,old['原厂商'],old['装配状态'],
             note=old['备注'],source='ADI Rev.A官方BOM + B0装配ECO')
    x['子项']=old['采购子项']
    if r.startswith('R'):
        x['精度/匹配']='按原厂完整MPN等级；未单独复核'
        x['温漂/比值温漂']='按原厂完整MPN数据表；未单独复核'
        if 'RC0805FR-' in m or 'ERJ-6ENF' in m or 'CRCW0805' in m and 'FKEA' in m:x['精度/匹配']='±1%'
        elif 'RC0805JR-' in m or 'CRCW0805' in m and 'JNEA' in m:x['精度/匹配']='±5%'
    elif r.startswith('C') and m in cap_specs:
        x['备注']=cap_specs[m]+' '+x['备注']
        x['精度/匹配']='保持原MPN容量容差，详见备注/数据表'
        x['温漂/比值温漂']='介质等级见备注；不能用电阻ppm指标代替'
    if r in UI:
        x.update({'单台数量':0,'建议采购数量':0,'数值/功能':'DNP','装配状态':'DNP—删除本地UI',
                  '相对v0.2变更':'停装','备注':'液晶/编码器/蜂鸣器及其专用驱动、背光和泵电容停装；焊盘保留，原模拟铜不改。',
                  '采购/供货状态':'不采购；不再受旧LCD/连接器交期限制','立创或DigiKey料号':'DNP不采购'})
    elif r in POWER:
        x.update({'单台数量':0,'建议采购数量':0,'数值/功能':'DNP','装配状态':'DNP—合并板供3.3V',
                  '相对v0.2变更':'保持停装；独立LDO小板改为电源/通信合并板',
                  '备注':'禁止恢复原开关支路或桥接L2；MAIN 3.3V只从合并板接L5.1。','采购/供货状态':'不采购','立创或DigiKey料号':'DNP不采购'})
    elif r in LEGACY485:
        x.update({'单台数量':0,'建议采购数量':0,'数值/功能':'DNP','装配状态':'DNP—隔离模块替代',
                  '相对v0.2变更':'原非隔离485停装','备注':'原J2的GND是非隔离地，禁止接外部总线；外部485仅接新模块J3。原U7焊盘引出逻辑信号。',
                  '采购/供货状态':'不采购','立创或DigiKey料号':'DNP不采购'})
    elif r in RATIOS:
        x.update({'单台数量':0,'建议采购数量':0,'数值/功能':'DNP，由LT5400适配片替代','装配状态':'DNP—4块网络适配片替代8只分立阻',
                  '相对v0.2变更':'原7.5k/1.2k换成6.25k/1k，维持0.16比例',
                  '备注':'配对R19/R20、R29/R31、R37/R38、R48/R52；每对接一块适配片。名义负载+20%，绝对值±15%及新寄生需验证。',
                  '采购/供货状态':'不采购原独立阻','立创或DigiKey料号':'DNP不采购'})
    elif r=='R13':
        x.update({'数值/功能':'4.99kΩ','精度/匹配':'≤0.01%','温漂/比值温漂':'绝对TCR≤2ppm/°C',
                  '制造商型号MPN':'按4.99kΩ/0805/0.01%/≤2ppm规格定标，完整MPN待确认','厂家':'精密电阻厂商待定标',
                  '采购/供货状态':'HOLD-MPN：付款/生产放行前需原厂数据表与完整订货码',
                  '相对v0.2变更':'保持4990Ω低自热方案','备注':'不能按旧ERA-6YEB152V买1.5k冒充改值；匹配固定四线Pt1000/200µA固件。'})
    elif r=='R47':
        x.update({'数值/功能':'1.000kΩ','精度/匹配':'≤0.01%','温漂/比值温漂':'绝对TCR≤5ppm/°C',
                  '制造商型号MPN':'按1kΩ/0805/0.01%/≤5ppm规格定标，完整MPN待确认','厂家':'精密电阻厂商待定标',
                  '采购/供货状态':'HOLD-MPN：付款/生产放行前需原厂数据表与完整订货码',
                  '相对v0.2变更':'按用户要求放宽为≤5ppm/°C，原阻值不变','备注':'TIA反馈精密电阻；每频率/增益对校准包含其固定偏差。原BOM MPN不冒充升级规格。'})
    elif r in {'R24','R27'}:
        x.update({'数值/功能':'27.0kΩ','制造商型号MPN':old['原MPN'],'精度/匹配':'原BOM等级，建议同批匹配',
                  '温漂/比值温漂':'按原厂订货码；不宣称≤2ppm','相对v0.2变更':'回归原值/已给原厂型号；不额外强制无现货升级',
                  '备注':'两只同系列同批，交流正负幅值/直流分量必须检查；后续升级需单独审料。'})
    elif r in {'R49','R50'}:
        x.update({'制造商型号MPN':old['原MPN'],'精度/匹配':'按原BOM，不冒称1%','相对v0.2变更':'保持原VMID电阻；匹配实测写入装配记录'})
    elif r=='R17':
        x.update({'相对v0.2变更':'保留BM启动上拉，不属于保留蜂鸣器功能',
                  '备注':'47kΩ上拉MCU P2.2/BM（pin3），复位低会进入UART下载模式。R18/Q1/D4/U2已删除，保留R17增加启动余量。'})
    elif r in {'X1','X2','X3','X4'}:
        x.update({'采购/供货状态':'PCB特征，不采购器件','立创或DigiKey料号':'N/A'})
    if x['装配状态'].startswith('DNP') or x['单台数量']==0:
        x['采购入口']='';x['淘宝搜索入口']=''
    elif r in {'R13','R47'}:
        q=x['数值/功能']+' 0805 0.01% '+x['温漂/比值温漂']
        x['采购入口']=DIGI+quote(q);x['淘宝搜索入口']='https://s.taobao.com/search?q='+quote(q)
    rows.append(x)

# Module suppliers expose exact parts in their own CAD-generated BOMs.
module_inputs=[('电源/隔离485合并板',ROOT/'hardware/isolation',1),('匹配电阻网络适配片',ROOT/'hardware/ratio_adapter',4)]
module_sources=[]
def first(d,*keys):
    for k in keys:
        if k in d and str(d[k]).strip():return str(d[k])
    return ''

for board,directory,mult in module_inputs:
    candidates=[p for p in directory.glob('*.csv') if any(t in p.name.lower() for t in ['bom','procurement'])]
    if not candidates:continue
    # Prefer one canonical BOM; don't duplicate a per-reference and grouped export.
    candidates.sort(key=lambda p:('bom' not in p.name.lower(),len(p.name)))
    path=candidates[0];module_sources.append(str(path.relative_to(ROOT)))
    for d in csv.DictReader(path.open(encoding='utf-8-sig')):
        ref=first(d,'Reference','References','reference','Refs','位号','Ref')
        qty_s=first(d,'Quantity','Qty','quantity','数量','Qty_per_adapter')
        qty=int(float(qty_s)) if qty_s else len(re.split(r'[,\s]+',ref))
        val=first(d,'Value','value','数值','功能','Value/Function','装配值')
        mpn=first(d,'MPN','Manufacturer_Part_Number','Manufacturer_Part_Number_or_spec','Manufacturer Part Number','型号','制造商型号','制造商型号MPN')
        fp=first(d,'Footprint','Package','footprint','封装')
        mfr=first(d,'Manufacturer','manufacturer','厂家','制造商')
        note=first(d,'Note','Notes','note','备注')
        state=first(d,'Population','装配状态') or ('DNP' if 'DNP' in first(d,'Status').upper() else '必装')
        x=newrow(board,ref,qty*mult,val,fp,mpn,mfr,state,
                 tol=first(d,'Tolerance','精度/匹配','精度'),tcr=first(d,'TCR','温漂','温漂/比值温漂'),
                 change='B0新增',note=note+f' 本项目装{mult}块，此行数量已乘{mult}，不要再乘。',source=str(path.relative_to(ROOT)))
        if board=='匹配电阻网络适配片' and ref=='U1':
            x['精度/匹配']='B级电阻匹配0.025%；绝对阻值±15%'
            x['温漂/比值温漂']='单片等效比例设计≤1ppm/K；跨两片最坏≤2ppm/K'
        if 'DNP' in state.upper() or qty==0:
            x.update({'单台数量':0,'建议采购数量':0,'装配状态':'DNP/PCB特征不另采购','采购/供货状态':'DNP或PCB特征，不采购','立创或DigiKey料号':'DNP/N/A'})
        rows.append(x)

# Procurement consolidation by physical part and specification, including the four ratio boards.
groups=defaultdict(list)
for x in rows:
    if x['单台数量']>0:groups[(x['制造商型号MPN'],x['数值/功能'],x['封装'],x['精度/匹配'],x['温漂/比值温漂'])].append(x)
orders=[]
for key,rs in groups.items():
    x=rs[0].copy();qty=sum(r['单台数量'] for r in rs)
    x['板件']='；'.join(dict.fromkeys(r['板件'] for r in rs))
    x['位号']='；'.join(r['板件']+':'+r['位号'] for r in rs)
    spare=max(2,qty) if x['位号'].find('R13')>=0 or x['位号'].find('R47')>=0 else 1
    if x['封装']=='0805' and x['精度/匹配'] not in ['≤0.01%']:spare=max(10,math.ceil(qty*1.3))-qty
    x['单台数量']=qty;x['备件建议']=spare;x['建议采购数量']=qty+spare
    orders.append(x)

notes=[
 ('适用版本','FW-EC-TX B0工程样机。主板模拟铜与v0.2保持；UI/旧485/旧3.3V支路停装；4块网络适配片+1块电源/通信合并板。'),
 ('数量','按1台整机列。主板1块、合并板1块、网络适配片4块；裸板打样多片是备份，不把电子料再次乘裸板数。'),
 ('采购口径','逐位号页与合并采购页是同一批物料，不能重复购买。适配片BOM已乘4。'),
 ('已删除','LCD与连接器、编码器与旋钮、蜂鸣器及专用驱动均DNP；不再购买旧独立35mm LDO子板。'),
 ('网络变更','LT5400BIMS8E-7内2×5k+2×1.25k，串联6.25k和并联1k实现0.16。不是原7.5k/1.2k绝对值；每片比值漂移设计上限1ppm，跨片最坏2ppm需实测。'),
 ('R13/R47','规格已固定，但未取得可核验完整MPN和分销SKU，标HOLD-MPN。不得用旧原BOM料号冒充改值/升级件。'),
 ('商城料号与缺货','不猜测立创C编号或DigiKey -ND号；未取得证据的SKU标UNVERIFIED。未实时核实库存/生命周期，不能把访问失败写成停产/缺货。'),
 ('生产状态','主板缺可编辑CAD，未生成可信主板paste/CPL/IPC356/电气DRC；整套尚不能作为无人审核自动贴片生产包放行。新增板件CAD检查另见真实报告。'),
 ('精度状态','10–50µS/cm±1%，50–2000±0.5%，0–50°C±0.05°C均为验收目标，非已实测结果。'),
 ('nLF状态','温补必须使用有来源ISO7888 nLF因子；不把合成测试表或2%线性补偿当正式算法。未装载合格表时κ25应NaN并置状态。'),
]
wb=Workbook();wb.remove(wb.active)
def sheet(name,data,cols):
    ws=wb.create_sheet(name);ws.append(cols)
    for x in data:ws.append([x.get(k,'') for k in cols])
    ws.freeze_panes='D2' if len(cols)>5 else 'A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.zoomScale=75
    for j,col in enumerate(cols,1):
        ws.column_dimensions[get_column_letter(j)].width={'备注':65,'采购/供货状态':45,'制造商型号MPN':48,'来源':50,'采购入口':48,'淘宝搜索入口':42,'相对v0.2变更':44,'说明':110}.get(col,22)
        c=ws.cell(1,j);c.fill=PatternFill('solid',fgColor='123C53');c.font=Font(bold=True,color='FFFFFF',name='Microsoft YaHei');c.alignment=Alignment(wrap_text=True)
    ws.row_dimensions[1].height=35
    for rr in ws.iter_rows(min_row=2):
        ws.row_dimensions[rr[0].row].height=90
        for c in rr:
            c.alignment=Alignment(wrap_text=True,vertical='top');c.font=Font(name='Microsoft YaHei',size=10)
            if isinstance(c.value,str) and c.value.startswith('https://'):
                c.hyperlink=c.value.split('\n')[0];c.font=Font(name='Microsoft YaHei',size=10,color='1565C0',underline='single')
            if isinstance(c.value,str) and ('HOLD-' in c.value or 'UNVERIFIED' in c.value):c.fill=PatternFill('solid',fgColor='FFF1CF')
    return ws
sheet('00先读_生产状态',[{'项目':k,'说明':v} for k,v in notes],['项目','说明'])
sheet('01合并采购_勿重复买',orders,FIELDS)
sheet('02主板逐位号',[x for x in rows if x['板件']=='FW-EC-TX B0主板'],FIELDS)
sheet('03合并电源隔离板',[x for x in rows if x['板件']=='电源/隔离485合并板'],FIELDS)
sheet('04网络片已乘4',[x for x in rows if x['板件']=='匹配电阻网络适配片'],FIELDS)
sheet('05全部DNP不采购',[x for x in rows if x['单台数量']==0],FIELDS)
sheet('06变更对照',rows,['板件','位号','子项','单台数量','装配状态','相对v0.2变更','备注'])
sheet('07缺口待确认',[x for x in rows if x['单台数量']>0 and ('HOLD' in x['采购/供货状态'])],FIELDS)
external=[
 {'项目':'电导池','数量':'先1支，合格后1支备件','规格':'K≈1cm^-1，镀铂黑铂两电极，固定≤1m，10–2000µS/cm，0–50°C；先确认允许频率/幅度，单支K校准。','渠道':'国内探头厂家/淘宝技术定制','变化':'保持两极；优选四端到电极，否则固定两线整链校准'},
 {'项目':'温度探头','数量':'先1支，1支备件可选','规格':'真正四线Pt1000，IEC60751 α=.00385，AA或更好，整链0/25/50°C标定，加12.5/37.5°C检查。','渠道':'国内铂电阻探头厂家/淘宝定制','变化':'仅四线Pt1000，不买Pt100或2/3线自动识别模块'},
 {'项目':'裸板','数量':'主板1+备件；通信电源板1+备件；网络片4+备件','规格':'按各自Gerber独立订单；主板工程CAM尚不具备自动贴片资料。','渠道':'嘉立创/捷多邦','变化':'删旧独立LDO板，新增合并板和4片网络片'},
 {'项目':'直流电源','数量':'1只+1只可选备件','规格':'5.0V±2%，≥1A，隔离稳压；插头按MJ-179PH实测；禁止6/9/12V；实际总负载/启动/温升待测。','渠道':'正规电源品牌渠道/京东/淘宝','变化':'供合并模块两路LDO，保持主ADP1613供电边界'},
 {'项目':'485线与连接器','数量':'短线约1–3m，按接口配','规格':'屏蔽双绞A/B及ISO_GND参考导体；外部仅接新模块J3，不接旧J2或PGND。','渠道':'立创/淘宝线材','变化':'Modbus RTU，默认9600 8E1；不再使用旧ASCII 115200 8N2'},
 {'项目':'隔离USB-RS485调试器','数量':'1只，已有复用','规格':'支持8E1和可设波特率、自动方向，有A/B/参考地；PC端用于Modbus调试。','渠道':'正规工业通信厂商/京东/淘宝','变化':'协议已改变；旧工具若支持8E1可复用'},
 {'项目':'SWD调试器','数量':'正版J-Link+20pin线1套，可借','规格':'ADuCM360支持；3.3V VTref、20pin/2.54mm，目标电源独立。','渠道':'SEGGER官方列出渠道/贸泽/得捷','变化':'保留主J4，不买10pin直插线'},
 {'项目':'校准液与设备','数量':'按首轮标定量','规格':'有证低端10/20、中段50/84/100/500、高段1000/1413/2000附近点，标准液证书U支持分段目标；制冷搅拌槽和参考温度计可租或委托。','渠道':'标准物质平台/计量实验室/品牌技术销售','变化':'每100Hz/1kHz及实际增益对分别校正，不用单K值覆盖全部档位'},
 {'项目':'外壳与绝缘安装件','数量':'实物定型后1套','规格':'按约100×104mm主板及100×80mm合并板、4×12mm网络片留空间，两面元件留净空；尼龙柱固定。','渠道':'淘宝/1688仪器壳/本地加工','变化':'无需LCD开窗、按键和旋钮孔；合并模块外部485端子独立隔离'},
 {'项目':'模块J2配套线束','数量':'2.54mm 1×4配对插壳/端子及短线1套','规格':'RX/TX/DE/PGND逐线标注；与模块直排针配对；主端从停装U7焊盘引出。','渠道':'立创/淘宝线束商','变化':'BOM只含板上排针，此处是线端配对件'},
 {'项目':'内部电源导线','数量':'22–24AWG多股绝缘线约1–2m','规格':'5V/PGND/MAIN3V3用不同色，短线固定，热缩套管防短路。','渠道':'立创/淘宝线材','变化':'两路3.3V不并联；按新接线图连接'},
 {'项目':'网络片连接与固定','数量':'四组短细线与绝缘支架','规格':'每片IN/SUM/OUT+安静AGND，四组各4根；只在确认节点间连接，尽量短；固定不得碰邻脚或压芯片。','渠道':'立创/淘宝工具线材/本地绝缘支架','变化':'原分立8只电阻DNP；不是买8只普通匹配电阻即可'},
 {'项目':'模块固定螺钉垫片','数量':'M3尼龙螺钉/螺母/垫片至少4组','规格':'与合并板H1–H4支撑柱匹配，最终长度按外壳决定；主板另按实际孔位配。','渠道':'淘宝五金/立创','变化':'合并板BOM已列4支撑柱，这里补配套紧固件，不重复算柱'},
]
sheet('08探头附件与校准',external,['项目','数量','规格','渠道','变化'])
sheet('09实际报价回填',[{'板件/位号':x['位号'],'MPN/规格':x['制造商型号MPN'],'建议采购数量':x['建议采购数量'],'商城SKU确认':'','供应商/报价号':'','库存/交期':'','含税单价':'','备注':''} for x in orders],['板件/位号','MPN/规格','建议采购数量','商城SKU确认','供应商/报价号','库存/交期','含税单价','备注'])
wb.save(OUT/'FW_EC_TX_B0_BOM.xlsx')
for name,data in [('FW_EC_TX_B0_BOM_per_reference.csv',rows),('FW_EC_TX_B0_BOM_order.csv',orders)]:
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS,lineterminator='\n');w.writeheader();w.writerows(data)
stats={'main_reference_records':sum(x['板件']=='FW-EC-TX B0主板' for x in rows),'all_records':len(rows),'order_rows':len(orders),
       'module_bom_sources':module_sources,'main_DNP_records':sum(x['板件']=='FW-EC-TX B0主板' and x['单台数量']==0 for x in rows),
       'supplier_skus_verified':0,'inventory_verified':False,'production_release':'HOLD','hold_items':[x['位号'] for x in rows if 'HOLD-' in x['采购/供货状态']]}
assert stats['main_reference_records']==199
for r in UI|POWER|LEGACY485|RATIOS:
    assert all(x['单台数量']==0 for x in rows if x['板件']=='FW-EC-TX B0主板' and x['位号']==r),r
assert all(x['建议采购数量']>=x['单台数量'] for x in orders)
(OUT/'bom_validation.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
print(json.dumps(stats,ensure_ascii=False,indent=2))
