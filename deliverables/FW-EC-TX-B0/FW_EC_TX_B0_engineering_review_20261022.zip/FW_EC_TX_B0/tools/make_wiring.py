#!/usr/bin/env python3
"""Render the assembly connection overview; exact pin tables are in docs."""
from pathlib import Path
from html import escape
import subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs';OUT.mkdir(exist_ok=True)
svg=['''<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="820" viewBox="0 0 1200 820">
<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#355e76"/></marker></defs>
<rect width="1200" height="820" fill="white"/>
<style>text{font-family:"Noto Sans CJK SC",sans-serif;fill:#19384a} .title{font-size:26px;font-weight:bold}.head{font-size:17px;font-weight:bold}.small{font-size:14px}.tiny{font-size:12px}.box{fill:#f3f7fa;stroke:#42677d;stroke-width:2}.wire{fill:none;stroke:#355e76;stroke-width:2;marker-end:url(#arrow)}.warn{fill:#9d4a16}</style>''']
def text(x,y,s,cls='small'):
    svg.append(f'<text x="{x}" y="{y}" class="{cls}">{escape(s)}</text>')
def box(x,y,w,h,title,lines):
    svg.append(f'<rect class="box" x="{x}" y="{y}" width="{w}" height="{h}" rx="8"/>')
    text(x+14,y+27,title,'head')
    for j,s in enumerate(lines):text(x+14,y+53+j*23,s)
def wire(path):svg.append(f'<path class="wire" d="{path}"/>')
text(30,45,'FW-EC-TX Rev B0 整机接线示意','title')
text(30,73,'工程样机；按板名区分同名连接器。精确针号以《整机接线.md》与各板原理图为准。')
box(25,140,235,160,'两极电导池 / K≈1',[
    '主板 J5.1 F+ / J5.2 S+',
    '主板 J5.3 S− / J5.4 F−',
    '两线池：1/2并、3/4并',
    '四端池：F/S独立至电极'])
box(25,340,235,160,'四线 Pt1000',[
    '主板 J3.1 F+ / J3.2 S+',
    '主板 J3.3 S− / J3.4 F−',
    'F/S在元件两端各自共点',
    'J3.4带偏置，不接外壳地'])
box(330,140,270,360,'FW-EC-TX B0 主板',[
    'Rev A 四层模拟铜保留',
    'R13=4.99k / 200µA',
    'R47=1k / 0.01% / ≤5ppm',
    '4块LT5400匹配网络片',
    'J4：20pin SWD下载口',
    'U1/S1/U2与专用驱动DNP',
    '旧U7/R10/J2 DNP',
    'U4/L2/D3/C17 DNP',
    'R17 BM启动上拉保留',
    'L5.1=3V3输入；L5.3=地'])
box(680,140,275,360,'电源 / 隔离485合并板',[
    'J1.1=5V_POST_U3',
    'J1.2/4=PGND',
    'J1.3=3V3_MAIN → L5.1',
    'J2.1 RX → 主U7.1',
    'J2.2 TX ← 主U7.4',
    'J2.3 DE ← 主U7.3',
    'J2.4=PGND',
    '两路LDO：MAIN / COM独立',
    'ADM2587E内置隔离电源',
    'TVS + 可跳线120Ω终端'])
box(1000,205,180,230,'外部设备 / PLC',[
    '子板J3.1 B → B',
    '子板J3.2 ISO_GND',
    '子板J3.3 A → A',
    'Modbus RTU',
    '默认1 / 9600 / 8E1',
    'A/B命名需核极性'])
wire('M260,220 H330');wire('M260,420 H330')
wire('M600,250 H680');text(604,235,'短逻辑线','tiny')
wire('M680,455 H600');text(602,480,'MAIN3V3','tiny')
wire('M955,320 H1000');text(963,297,'隔离','tiny')
svg.append('<path d="M965,155 V485" fill="none" stroke="#a05b31" stroke-width="2" stroke-dasharray="7,5"/>')
text(967,518,'ISO_GND不短接PGND','tiny')
box(330,570,270,120,'外部稳压5.0V±2%',[
    '先接主板J1，经U3反接保护',
    '再由C9取5V给合并板',
    '不是6V；LDO旧小板不另装'])
wire('M465,570 V500');wire('M600,625 H815 V500')
text(705,647,'5V_POST_U3 / PGND','tiny')
text(30,735,'重要：MAIN与COM的3.3V不并联；旧主板J2不接外部总线；120Ω默认断开。','small')
text(30,764,'κ(T)与温度可独立输出；正式nLF因子未核准前，κ25=NaN并置UNVERIFIED。','small')
text(30,791,'主板完整贴片/电气DRC资料仍缺，当前图示不等于生产放行或精度/隔离测试通过。','tiny')
svg.append('</svg>')
p=OUT/'FW_EC_TX_B0_wiring.svg';p.write_text('\n'.join(svg),encoding='utf-8')
for extension in ['pdf','png']:
    subprocess.run(['inkscape',str(p),'--export-type='+extension,
                    '--export-filename='+str(OUT/('FW_EC_TX_B0_wiring.'+extension))],check=True,
                   stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
print(p)
